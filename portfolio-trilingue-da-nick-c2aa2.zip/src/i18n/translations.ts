export type Locale = 'pt' | 'en' | 'es'

export const translations = {
  pt: {
    nav_home: 'INÍCIO',
    nav_about: 'SOBRE',
    nav_experience: 'EXPERIÊNCIA',
    nav_projects: 'PROJETOS',
    nav_systems: 'SISTEMAS',
    nav_games: 'JOGOS',
    nav_skills: 'HABILIDADES',
    nav_certs: 'CERTIFICAÇÕES',
    nav_contact: 'CONTATO',

    hero_player: 'NICK // GAME DEVELOPER',
    hero_status: 'DISPONÍVEL PARA AAA & INDIE',
    hero_title_1: 'GAME DEVELOPER &',
    hero_title_2: 'GAMEPLAY PROGRAMMER',
    hero_desc:
      'Desenvolvedora de jogos focada em Unity (C#), State Machines, Física & Combate. Criando experiências de alta performance para WebGL e Mobile.',
    hero_btn_itch: 'JOGAR NO ITCH.IO',
    hero_btn_github: 'GITHUB',
    hero_btn_linkedin: 'LINKEDIN',
    hero_btn_email: 'EMAIL',
    hero_btn_whatsapp: 'WHATSAPP',

    about_subtitle: 'PERFIL DE DESENVOLVEDORA',
    about_title: 'NICOLE (NICK) LOPES',
    about_text_1:
      'Sou Game Developer e Gameplay Programmer graduada em Análise e Desenvolvimento de Sistemas. Especialista em Unity / C# com foco em arquitetura escalável, controladores de personagem, máquinas de estado e otimização de performance.',
    about_text_2:
      'Possuo vivência em desenvolvimento de jogos WebGL e Mobile, integração de autenticação backend e cloud save, além de experiência corporativa prévia com Java e ASP.NET Core.',
    about_text_3:
      'Entusiasta de jogos 2D/3D, estética cyberpunk, pixel art e sistemas de combate fluidos. Sempre buscando entregar gameplay responsivo com alto padrão técnico.',

    exp_subtitle: 'HISTÓRICO PROFISSIONAL',
    exp_title: 'EXPERIÊNCIA PROFISSIONAL',

    projects_subtitle: 'MÓDULOS DE PROJETO',
    projects_title: 'PROJETOS EM DESTAQUE',
    projects_view: 'INSPECIONAR MÓDULO',

    skills_subtitle: 'REGISTRO DE CAPACIDADES',
    skills_title: 'REGISTRO DE HABILIDADES',

    cert_subtitle: 'CERTIFICAÇÕES VERIFICADAS',
    cert_title: 'CERTIFICADOS & BADGES',

    contact_connection_title: 'CENTRAL DE CONTATO OFICIAL',
  },
  en: {
    nav_home: 'HOME',
    nav_about: 'ABOUT',
    nav_experience: 'EXPERIENCE',
    nav_projects: 'PROJECTS',
    nav_systems: 'SYSTEMS',
    nav_games: 'GAMES',
    nav_skills: 'SKILLS',
    nav_certs: 'CERTIFICATIONS',
    nav_contact: 'CONTACT',

    hero_player: 'NICK // GAME DEVELOPER',
    hero_status: 'AVAILABLE FOR AAA & INDIE',
    hero_title_1: 'GAME DEVELOPER &',
    hero_title_2: 'GAMEPLAY PROGRAMMER',
    hero_desc:
      'Game Developer specialized in Unity (C#), State Machines, Physics & Combat. Building high-performance WebGL and Mobile game experiences.',
    hero_btn_itch: 'PLAY ON ITCH.IO',
    hero_btn_github: 'GITHUB',
    hero_btn_linkedin: 'LINKEDIN',
    hero_btn_email: 'EMAIL',
    hero_btn_whatsapp: 'WHATSAPP',

    about_subtitle: 'DEVELOPER PROFILE',
    about_title: 'NICOLE (NICK) LOPES',
    about_text_1:
      'I am a Game Developer and Gameplay Programmer with a degree in Systems Analysis and Development. Specialized in Unity / C# focusing on scalable architecture, player controllers, state machines, and performance optimization.',
    about_text_2:
      'Experienced in WebGL and Mobile game development, backend authentication and cloud save integration, alongside corporate software engineering experience in Java and ASP.NET Core.',
    about_text_3:
      'Passionate about 2D/3D games, cyberpunk aesthetics, pixel art, and fluid combat mechanics. Always striving to deliver responsive gameplay with AAA-level code cleanliness.',

    exp_subtitle: 'PROFESSIONAL LOG',
    exp_title: 'PROFESSIONAL EXPERIENCE',

    projects_subtitle: 'PROJECT MODULES',
    projects_title: 'FEATURED PROJECTS',
    projects_view: 'INSPECT MODULE',

    skills_subtitle: 'CAPABILITIES REGISTRY',
    skills_title: 'SKILL REGISTRY',

    cert_subtitle: 'VERIFIED CERTIFICATIONS',
    cert_title: 'CERTIFICATES & BADGES',

    contact_connection_title: 'OFFICIAL CONTACT HUB',
  },
  es: {
    nav_home: 'INICIO',
    nav_about: 'ACERCA DE',
    nav_experience: 'EXPERIENCIA',
    nav_projects: 'PROYECTOS',
    nav_systems: 'SISTEMAS',
    nav_games: 'JUEGOS',
    nav_skills: 'HABILIDADES',
    nav_certs: 'CERTIFICACIONES',
    nav_contact: 'CONTACTO',

    hero_player: 'NICK // GAME DEVELOPER',
    hero_status: 'DISPONIBLE PARA AAA & INDIE',
    hero_title_1: 'GAME DEVELOPER &',
    hero_title_2: 'GAMEPLAY PROGRAMMER',
    hero_desc:
      'Desarrolladora de juegos especializada en Unity (C#), State Machines, Física y Combate. Creando experiencias de alto rendimiento para WebGL y Mobile.',
    hero_btn_itch: 'JUGAR EN ITCH.IO',
    hero_btn_github: 'GITHUB',
    hero_btn_linkedin: 'LINKEDIN',
    hero_btn_email: 'EMAIL',
    hero_btn_whatsapp: 'WHATSAPP',

    about_subtitle: 'PERFIL DE DESARROLLADORA',
    about_title: 'NICOLE (NICK) LOPES',
    about_text_1:
      'Soy Game Developer y Gameplay Programmer graduada en Análisis y Desarrollo de Sistemas. Especialista en Unity / C# enfocada en arquitectura escalable, controladores de personaje y optimización de rendimiento.',
    about_text_2:
      'Experiencia en desarrollo de juegos WebGL y Mobile, integración de autenticación backend y cloud save, además de trayectoria previa en Java y ASP.NET Core.',
    about_text_3:
      'Entusiasta de juegos 2D/3D, estética cyberpunk, pixel art y sistemas de combate fluidos. Siempre buscando entregar gameplay limpio y altamente responsivo.',

    exp_subtitle: 'HISTORIAL PROFESIONAL',
    exp_title: 'EXPERIENCIA PROFESIONAL',

    projects_subtitle: 'MÓDULOS DE PROYECTO',
    projects_title: 'PROYECTOS DESTACADOS',
    projects_view: 'INSPECCIONAR MÓDULO',

    skills_subtitle: 'REGISTRO DE CAPACIDADES',
    skills_title: 'REGISTRO DE HABILIDADES',

    cert_subtitle: 'CERTIFICACIONES VERIFICADAS',
    cert_title: 'CERTIFICADOS & BADGES',

    contact_connection_title: 'CENTRAL DE CONTACTO OFICIAL',
  },
}
