import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { type MetricasCsv, type TipoGargalo } from '@/lib/csv/parse'
import { gerarAutomacao } from '@/lib/csv/analyze'
import { formatarMoeda, formatarHoras, formatarPercentual } from '@/lib/csv/format'
import { saveCsvContext } from '@/lib/csv-context'
import {
  RotateCcw,
  Zap,
  Check,
  Bot,
  AlertTriangle,
  TrendingUp,
  Clock,
  FileText,
  Layers,
} from 'lucide-react'

const tipoConfig: Record<TipoGargalo, { label: string; color: string }> = {
  duplicata: { label: 'Duplicata', color: 'bg-rose-50 text-rose-700 border-rose-200' },
  pendencia: { label: 'Pendência', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  vazio: { label: 'Vazio', color: 'bg-orange-50 text-orange-700 border-orange-200' },
  padrao: { label: 'Padrão', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  sobrecarga: { label: 'Sobrecarga', color: 'bg-blue-50 text-blue-700 border-blue-200' },
}

interface CsvAnalysisResultsProps {
  metrics: MetricasCsv
  fileName: string
  onReset: () => void
  rawCsv?: string
}

export function CsvAnalysisResults({
  metrics,
  fileName,
  onReset,
  rawCsv,
}: CsvAnalysisResultsProps) {
  const automacao = gerarAutomacao(metrics.gargalos)
  const [applied, setApplied] = useState(false)
  const navigate = useNavigate()

  const handleGoToAssistant = () => {
    saveCsvContext({
      fileName,
      resumo: `Análise do arquivo ${fileName} com ${metrics.totalLinhas} linhas e ${metrics.gargalos.length} gargalo(s) detectado(s).`,
      diagnostico: null,
      automacao: null,
      metricas: {
        totalLinhas: metrics.totalLinhas,
        totalColunas: metrics.totalColunas,
        pctDuplicatas: metrics.pctDuplicatas,
        pctPendentes: metrics.pctPendentes,
        pctVazios: metrics.pctVazios,
        horasSemana: metrics.horasSemana,
        custoMes: metrics.custoMes,
        gargalos: metrics.gargalos.map((g) => ({
          titulo: g.titulo,
          descricao: g.descricao,
          horasSemana: g.horasSemana,
          custoMes: g.custoMes,
          tipo: g.tipo,
          fonte: g.fonte,
        })),
      },
      automacaoClient: {
        nome: automacao.nome,
        passos: automacao.passos,
        horasEconomizadas: automacao.horasEconomizadas,
        custoEconomizado: automacao.custoEconomizado,
      },
      rawCsv,
      timestamp: Date.now(),
    })
    navigate('/app/assistant')
  }

  useEffect(() => {
    setApplied(localStorage.getItem(`nortia.csvAutomation.${fileName}`) === 'true')
  }, [fileName])

  const handleApply = () => {
    localStorage.setItem(`nortia.csvAutomation.${fileName}`, 'true')
    setApplied(true)
  }

  const metricCards = [
    {
      label: 'Linhas',
      value: String(metrics.totalLinhas),
      icon: FileText,
      color: 'text-indigo-600 bg-indigo-50',
    },
    {
      label: 'Duplicatas',
      value: formatarPercentual(metrics.pctDuplicatas),
      icon: Layers,
      color: 'text-rose-600 bg-rose-50',
    },
    {
      label: 'Pendentes',
      value: formatarPercentual(metrics.pctPendentes),
      icon: AlertTriangle,
      color: 'text-amber-600 bg-amber-50',
    },
    {
      label: 'Vazios',
      value: formatarPercentual(metrics.pctVazios),
      icon: AlertTriangle,
      color: 'text-orange-600 bg-orange-50',
    },
    {
      label: 'Horas/sem',
      value: formatarHoras(metrics.horasSemana),
      icon: Clock,
      color: 'text-purple-600 bg-purple-50',
    },
    {
      label: 'R$/mês',
      value: formatarMoeda(metrics.custoMes),
      icon: TrendingUp,
      color: 'text-emerald-600 bg-emerald-50',
    },
  ]

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-indigo-500" />
          <h2 className="text-lg font-bold font-display text-slate-900">
            Nortia analisou <span className="text-indigo-600">{fileName}</span>
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <Button
            onClick={handleGoToAssistant}
            className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 text-xs h-8"
          >
            <Bot className="w-3.5 h-3.5" />
            Ir para o agente Nort
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onReset}
            className="rounded-xl gap-1.5 text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Testar com outro arquivo
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {metricCards.map((m, i) => {
          const Icon = m.icon
          return (
            <Card key={i} className="p-3 rounded-xl border-slate-200/80 bg-white shadow-soft">
              <div
                className={`w-7 h-7 rounded-lg ${m.color} flex items-center justify-center mb-2`}
              >
                <Icon className="w-3.5 h-3.5" />
              </div>
              <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wide">
                {m.label}
              </p>
              <p className="text-sm font-bold text-slate-900 mt-0.5">{m.value}</p>
            </Card>
          )
        })}
      </div>

      {metrics.gargalos.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
            Gargalos Detectados
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {metrics.gargalos.map((g) => {
              const cfg = tipoConfig[g.tipo]
              return (
                <Card
                  key={g.id}
                  className="p-4 rounded-2xl border-slate-200/80 bg-white shadow-soft"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="font-bold text-sm text-slate-900">{g.titulo}</h4>
                    <Badge variant="outline" className={`text-[10px] ${cfg.color}`}>
                      {cfg.label}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-500 mb-2 leading-relaxed">{g.descricao}</p>
                  <div className="flex items-center gap-3 text-xs text-slate-600">
                    <span>
                      <strong className="text-slate-900">
                        {formatarHoras(g.horasSemana)}/semana
                      </strong>
                    </span>
                    <span>
                      <strong className="text-slate-900">{formatarMoeda(g.custoMes)}/mês</strong>
                    </span>
                  </div>
                  <Badge variant="outline" className="mt-2 text-[10px] bg-slate-50 text-slate-500">
                    detectado em: {g.fonte}
                  </Badge>
                </Card>
              )
            })}
          </div>
        </div>
      )}

      <Card className="p-5 rounded-2xl border-indigo-200/80 bg-white shadow-soft">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">{automacao.nome}</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              A Nortia não só identifica o gargalo: ela executa a solução.
            </p>
            <div className="space-y-1 pt-1">
              {automacao.passos.map((p, i) => (
                <p key={i} className="text-xs text-slate-600 font-medium">
                  {p}
                </p>
              ))}
            </div>
            <div className="flex items-center gap-3 text-xs pt-1">
              <span className="text-emerald-600 font-semibold">
                Economiza: {formatarHoras(automacao.horasEconomizadas)}/semana
              </span>
              <span className="text-slate-600">
                {formatarMoeda(automacao.custoEconomizado)}/mês
              </span>
            </div>
          </div>
          {applied ? (
            <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1 shrink-0">
              <Check className="w-3.5 h-3.5" /> Aplicada
            </Badge>
          ) : (
            <Button
              onClick={handleApply}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 shrink-0"
            >
              <Zap className="w-4 h-4" /> Aplicar
            </Button>
          )}
        </div>
        {applied && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-100">
            <p className="text-xs text-emerald-700 font-medium">
              ✓ Automação ativa — retrabalho eliminado: {formatarHoras(automacao.horasEconomizadas)}
              /semana
            </p>
          </div>
        )}
      </Card>
    </div>
  )
}
