import { useState } from 'react'
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import {
  Compass,
  LayoutDashboard,
  FileSearch,
  Bot,
  Kanban,
  Plus,
  LogOut,
  Settings as SettingsIcon,
  Menu,
  ChevronRight,
  User,
  CreditCard,
  Database,
} from 'lucide-react'
import { ShadowBadge } from '@/components/ShadowBadge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { cn } from '@/lib/utils'

export default function Layout() {
  const { user, signOut } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  const navItems = [
    { label: 'Dashboard', path: '/app/dashboard', icon: LayoutDashboard },
    { label: 'Diagnósticos', path: '/app/diagnostics', icon: FileSearch },
    { label: 'Assistente', path: '/app/assistant', icon: Bot },
    { label: 'Fontes', path: '/app/fontes', icon: Database },
    { label: 'Roadmap', path: '/app/roadmap', icon: Kanban },
    { label: 'Planos', path: '/app/planos', icon: CreditCard },
  ]

  const handleSignOut = () => {
    signOut()
    navigate('/')
  }

  const userInitial = user?.name
    ? user.name.charAt(0).toUpperCase()
    : user?.email
      ? user.email.charAt(0).toUpperCase()
      : 'U'

  const NavContent = () => (
    <div className="flex flex-col h-full text-slate-200">
      {/* Brand Header */}
      <div className="px-6 py-6 flex items-center gap-3 border-b border-slate-800/60">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <Compass className="w-6 h-6 text-white animate-pulse" />
        </div>
        <div>
          <span className="font-display font-bold text-xl tracking-tight text-white flex items-center gap-1.5">
            Nortia
            <span className="text-[10px] uppercase tracking-wider bg-indigo-500/20 text-indigo-300 font-semibold px-2 py-0.5 rounded-full border border-indigo-500/30">
              MVP
            </span>
          </span>
          <p className="text-[11px] text-slate-400 font-medium">Process Intelligence</p>
        </div>
      </div>

      {/* Shadow Badge */}
      <div className="px-4 pt-3">
        <ShadowBadge />
      </div>

      {/* Action CTA */}
      <div className="px-4 mt-5 mb-2">
        <Button
          onClick={() => {
            setMobileOpen(false)
            navigate('/app/diagnostics/new')
          }}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 rounded-xl font-medium gap-2 h-11 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <Plus className="w-4 h-4" />
          <span>Novo diagnóstico</span>
        </Button>
      </div>

      {/* Main Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path)
          const Icon = item.icon
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setMobileOpen(false)}
              className={cn(
                'flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-medium transition-all duration-200 group relative',
                isActive
                  ? 'bg-indigo-600/20 text-indigo-300 font-semibold border border-indigo-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50',
              )}
            >
              {isActive && (
                <div className="absolute left-0 top-2 bottom-2 w-1 bg-indigo-500 rounded-r-full shadow-sm" />
              )}
              <Icon
                className={cn(
                  'w-5 h-5 transition-transform duration-200 group-hover:scale-110',
                  isActive ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-200',
                )}
              />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </nav>

      {/* User Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-800/60 transition-colors text-left group">
              <div className="flex items-center gap-3 min-w-0">
                <Avatar className="w-9 h-9 border border-indigo-500/30 bg-indigo-950">
                  <AvatarFallback className="bg-indigo-600 text-white font-semibold text-xs">
                    {userInitial}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-200 truncate group-hover:text-white">
                    {user?.name || 'Usuário'}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-transform" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            className="w-56 bg-slate-900 border-slate-800 text-slate-200 shadow-2xl rounded-xl"
          >
            <div className="px-3 py-2 border-b border-slate-800">
              <p className="text-xs font-semibold text-slate-300">{user?.name || 'Minha Conta'}</p>
              <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
            </div>
            <DropdownMenuItem
              onClick={() => navigate('/app/settings')}
              className="cursor-pointer hover:bg-slate-800 focus:bg-slate-800 focus:text-white gap-2 py-2"
            >
              <SettingsIcon className="w-4 h-4 text-slate-400" />
              <span>Configurações</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-slate-800" />
            <DropdownMenuItem
              onClick={handleSignOut}
              className="cursor-pointer text-rose-400 hover:bg-rose-950/30 hover:text-rose-300 focus:bg-rose-950/30 focus:text-rose-300 gap-2 py-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Sair</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#F6F7FB] flex flex-col lg:flex-row text-slate-900">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-[260px] flex-col fixed top-0 bottom-0 left-0 bg-[#0B1220] border-r border-slate-800/80 z-30 shadow-xl">
        <NavContent />
      </aside>

      {/* Mobile Top Header */}
      <header className="lg:hidden sticky top-0 z-40 bg-[#0B1220] border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
            <Compass className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-lg text-white">Nortia</span>
        </div>

        <div className="flex items-center gap-2">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-[270px] bg-[#0B1220] border-slate-800">
              <SheetHeader className="sr-only">
                <SheetTitle>Menu de navegação</SheetTitle>
              </SheetHeader>
              <NavContent />
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 lg:pl-[260px] min-h-screen flex flex-col">
        <div className="flex-1 max-w-[1280px] w-full mx-auto p-4 sm:p-6 lg:p-8 animate-fade-in">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
