import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip'

export function ShadowBadge() {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/15 to-teal-500/10 border border-emerald-400/25 backdrop-blur-sm cursor-default transition-all duration-300 hover:border-emerald-400/40 hover:from-emerald-500/20 hover:to-teal-500/15 group">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gradient-to-br from-emerald-400 to-teal-500 shadow-sm shadow-emerald-400/50" />
          </span>
          <span className="text-[11px] font-semibold text-emerald-200 whitespace-nowrap tracking-wide group-hover:text-emerald-100 transition-colors">
            Shadow ativo — monitorando em 2º plano
          </span>
        </div>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs text-xs leading-relaxed text-center">
        Roda na inicialização. Você não precisa abrir nada — a Nortia observa e aprende seu dia a
        dia para mapear seus processos.
      </TooltipContent>
    </Tooltip>
  )
}
