import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { CsvUpload } from '@/components/CsvUpload'
import { DiagnosisReport } from '@/components/csv-process/DiagnosisReport'
import { ProcessingStatus } from '@/components/csv-process/ProcessingStatus'
import { processarCsv, type ProcessarCsvResponse } from '@/services/csv-process'
import { saveCsvContext } from '@/lib/csv-context'
import { Button } from '@/components/ui/button'
import { Bot, AlertCircle, RotateCcw } from 'lucide-react'

type DemoState = 'idle' | 'processing' | 'success' | 'error'

export function CsvDemo() {
  const navigate = useNavigate()
  const [state, setState] = useState<DemoState>('idle')
  const [response, setResponse] = useState<ProcessarCsvResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [fileName, setFileName] = useState('')

  const handleAnalyze = useCallback(async (rawContent: string, name: string) => {
    setFileName(name)
    setState('processing')
    setError(null)
    try {
      const result = await processarCsv(rawContent, name)
      if (result.status === 'erro') {
        setState('error')
        setError(
          result.error ||
            'Não conseguimos analisar o CSV. Confira se o arquivo tem cabeçalho e linhas de dados.',
        )
        return
      }
      setResponse(result)
      setState('success')
    } catch (err: any) {
      setState('error')
      const errMsg = err?.response?.error || err?.data?.error
      setError(
        errMsg ||
          'Não conseguimos analisar o CSV. Confira se o arquivo tem cabeçalho e linhas de dados.',
      )
    }
  }, [])

  const handleReset = useCallback(() => {
    setState('idle')
    setResponse(null)
    setError(null)
    setFileName('')
  }, [])

  const handleGoToNort = useCallback(() => {
    if (response) {
      saveCsvContext({
        fileName,
        resumo: response.resumo,
        diagnostico: response.diagnostico,
        automacao: response.automacao,
        timestamp: Date.now(),
      })
    }
    navigate('/app/assistant')
  }, [response, fileName, navigate])

  if (state === 'processing') {
    return (
      <div className="rounded-3xl bg-[#0a0a0f] p-6 sm:p-8">
        <ProcessingStatus currentStep="analisando" />
      </div>
    )
  }

  if (state === 'error') {
    return (
      <div className="rounded-3xl bg-[#0a0a0f] p-6 sm:p-8">
        <div className="flex flex-col items-center gap-4 py-8">
          <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-sm text-slate-300 text-center max-w-sm">
            {error ||
              'Não conseguimos analisar o CSV. Confira se o arquivo tem cabeçalho e linhas de dados.'}
          </p>
          <Button
            onClick={handleReset}
            className="bg-[#3b82f6] hover:bg-[#3b82f6]/90 text-white rounded-xl gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Tentar novamente
          </Button>
        </div>
      </div>
    )
  }

  if (state === 'success' && response) {
    return (
      <div className="rounded-3xl bg-[#0a0a0f] p-6 sm:p-8 space-y-6">
        <DiagnosisReport response={response} onReset={handleReset} />
        <Button
          onClick={handleGoToNort}
          className="w-full bg-[#22c55e] hover:bg-[#22c55e]/90 text-white rounded-xl gap-2 h-12 font-semibold transition-all hover:scale-[1.01] active:scale-[0.99]"
        >
          <Bot className="w-5 h-5" />
          Ir para o agente Nort
        </Button>
      </div>
    )
  }

  return <CsvUpload onAnalyze={handleAnalyze} />
}
