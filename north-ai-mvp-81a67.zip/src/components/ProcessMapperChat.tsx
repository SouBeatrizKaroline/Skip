import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Loader2, Check, Bot } from 'lucide-react'
import { buildProcessFlow, type ProcessStep } from '@/lib/demo-mocks'

export function ProcessMapperChat({ onSaved }: { onSaved?: () => void }) {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [steps, setSteps] = useState<ProcessStep[]>([])

  const handleSubmit = () => {
    setLoading(true)
    setSteps([])
    setTimeout(() => {
      setSteps(buildProcessFlow(input))
      setLoading(false)
    }, 2000)
  }

  const handleClose = (v: boolean) => {
    setOpen(v)
    if (!v) {
      setSteps([])
      setInput('')
      setLoading(false)
    }
  }

  const handleSave = () => {
    handleClose(false)
    onSaved?.()
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogTrigger asChild>
        <Button className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 text-sm h-10">
          <Bot className="w-4 h-4" />
          Mapear meu processo agora
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold font-display">
            Mapeamento de Processo
          </DialogTitle>
        </DialogHeader>
        {steps.length === 0 && !loading && (
          <div className="space-y-4 py-2">
            <Input
              placeholder="Descreva seu processo em 1 linha"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
              className="h-11 rounded-xl"
            />
            <Button
              onClick={handleSubmit}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl h-11"
            >
              Mapear
            </Button>
          </div>
        )}
        {loading && (
          <div className="flex flex-col items-center justify-center py-10 gap-3">
            <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
            <span className="text-sm text-slate-600 font-medium">Nortia mapeando...</span>
          </div>
        )}
        {steps.length > 0 && !loading && (
          <div className="space-y-5 py-2">
            <div className="space-y-1">
              {steps.map((step, i) => (
                <div key={step.step} className="flex items-center gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0">
                      {step.step}
                    </div>
                    {i < steps.length - 1 && <div className="w-px h-6 bg-indigo-200" />}
                  </div>
                  <span className="text-sm text-slate-700 font-medium">{step.label}</span>
                </div>
              ))}
            </div>
            <Button
              onClick={handleSave}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl h-11 gap-2"
            >
              <Check className="w-4 h-4" />
              Salvar mapeamento e ver diagnóstico
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
