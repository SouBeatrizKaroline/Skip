import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Bot, Check, Zap } from 'lucide-react'

export function AutomationCreated({ diagnosticId }: { diagnosticId: string }) {
  const storageKey = `nortia.automationApplied.${diagnosticId}`
  const [applied, setApplied] = useState(false)

  useEffect(() => {
    setApplied(localStorage.getItem(storageKey) === 'true')
  }, [storageKey])

  const handleApply = () => {
    localStorage.setItem(storageKey, 'true')
    setApplied(true)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Zap className="w-5 h-5 text-indigo-500" />
        <h2 className="text-lg font-bold font-display text-slate-900">Automação Criada</h2>
      </div>
      <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-base text-slate-900">Agente de Aprovação Automática</h3>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Automatiza o fluxo de aprovação manual, integrando ERP e notificando via WhatsApp.
            </p>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-emerald-600 font-semibold">ROI: 320%</span>
              <span className="text-slate-600">Esforço: Baixo</span>
            </div>
          </div>
          {applied ? (
            <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1 shrink-0">
              <Check className="w-3.5 h-3.5" />
              Aplicada
            </Badge>
          ) : (
            <Button
              onClick={handleApply}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 shrink-0"
            >
              <Zap className="w-4 h-4" />
              Aplicar automação
            </Button>
          )}
        </div>
        {applied && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-100">
            <p className="text-xs text-emerald-700 font-medium">
              ✓ Automação aplicada com sucesso! O agente está ativo e processando em segundo plano.
            </p>
          </div>
        )}
      </Card>
    </div>
  )
}
