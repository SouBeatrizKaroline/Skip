import { Loader2, CheckCircle2, Upload, Brain, FileCheck, Bot } from 'lucide-react'
import { cn } from '@/lib/utils'

type StatusStep = 'enviando' | 'analisando' | 'diagnostico' | 'automacao'

const steps = [
  { key: 'enviando', label: 'Enviando...', icon: Upload },
  { key: 'analisando', label: 'Analisando com IA...', icon: Brain },
  { key: 'diagnostico', label: 'Diagnóstico pronto', icon: FileCheck },
  { key: 'automacao', label: 'Automação gerada', icon: Bot },
] as const

export function ProcessingStatus({ currentStep }: { currentStep: StatusStep }) {
  const currentIdx = steps.findIndex((s) => s.key === currentStep)

  return (
    <div className="flex flex-col items-center gap-6 py-12">
      <div className="w-20 h-20 rounded-2xl bg-[#3b82f6]/10 border border-[#3b82f6]/30 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-[#3b82f6] animate-spin" />
      </div>
      <div className="flex flex-col gap-3 w-full max-w-md">
        {steps.map((step, idx) => {
          const Icon = step.icon
          const isDone = idx < currentIdx
          const isActive = idx === currentIdx
          return (
            <div
              key={step.key}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300',
                isActive && 'bg-[#3b82f6]/10 border border-[#3b82f6]/30',
                isDone && 'opacity-60',
              )}
            >
              <div
                className={cn(
                  'w-8 h-8 rounded-lg flex items-center justify-center shrink-0',
                  isDone && 'bg-[#22c55e]/20 text-[#22c55e]',
                  isActive && 'bg-[#3b82f6]/20 text-[#3b82f6]',
                  !isDone && !isActive && 'bg-[#1e1e2a] text-slate-600',
                )}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <Icon className={cn('w-4 h-4', isActive && 'animate-pulse')} />
                )}
              </div>
              <span
                className={cn(
                  'text-sm font-medium',
                  isActive && 'text-[#3b82f6]',
                  isDone && 'text-[#22c55e]',
                  !isDone && !isActive && 'text-slate-600',
                )}
              >
                {step.label}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
