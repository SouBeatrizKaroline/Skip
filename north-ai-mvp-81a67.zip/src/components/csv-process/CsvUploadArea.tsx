import { useRef, useState } from 'react'
import { type CsvRow } from '@/lib/csv/parse'
import { Button } from '@/components/ui/button'
import { Upload, FileText, AlertCircle, Zap, CheckCircle2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface CsvUploadAreaProps {
  file: File | null
  previewRows: CsvRow[]
  error: string | null
  onFileSelect: (file: File) => void
  onAnalyze: () => void
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function CsvUploadArea({
  file,
  previewRows,
  error,
  onFileSelect,
  onAnalyze,
}: CsvUploadAreaProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const header = previewRows[0]?.colunas || []
  const dataRows = previewRows.map((r) => r.valores)

  return (
    <div className="space-y-5">
      {!file ? (
        <>
          <div
            onDragOver={(e) => {
              e.preventDefault()
              setDragging(true)
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDragging(false)
              const f = e.dataTransfer.files[0]
              if (f) onFileSelect(f)
            }}
            onClick={() => inputRef.current?.click()}
            className={cn(
              'border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all duration-200',
              dragging
                ? 'border-[#3b82f6] bg-[#3b82f6]/5 scale-[1.01]'
                : 'border-slate-700 hover:border-[#3b82f6]/50 hover:bg-slate-800/30',
            )}
          >
            <Upload className="w-10 h-10 text-slate-500 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-300">Arraste seu CSV aqui</p>
            <p className="text-xs text-slate-500 mt-1">ou clique para selecionar</p>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept=".csv"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) onFileSelect(f)
              e.target.value = ''
            }}
          />
          <Button
            onClick={() => inputRef.current?.click()}
            variant="outline"
            className="bg-[#12121a] border-slate-700 text-slate-200 hover:bg-slate-800 rounded-xl gap-2"
          >
            <FileText className="w-4 h-4" />
            Carregar planilha (CSV)
          </Button>
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <p className="text-xs text-red-400">{error}</p>
            </div>
          )}
        </>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 rounded-xl bg-[#12121a] border border-slate-700">
            <div className="w-10 h-10 rounded-lg bg-[#3b82f6]/20 text-[#3b82f6] flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{file.name}</p>
              <p className="text-xs text-slate-400">{formatFileSize(file.size)}</p>
            </div>
          </div>

          {header.length > 0 && (
            <div className="overflow-x-auto rounded-xl border border-slate-700 bg-[#12121a]">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-700">
                    {header.map((h, i) => (
                      <th
                        key={i}
                        className="px-3 py-2 text-left font-semibold text-[#3b82f6] whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {dataRows.map((row, ri) => (
                    <tr key={ri} className="border-b border-slate-800 last:border-0">
                      {row.map((cell, ci) => (
                        <td key={ci} className="px-3 py-2 text-slate-300 whitespace-nowrap">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <p className="text-xs text-slate-500">Pré-visualização: cabeçalho + 3 primeiras linhas</p>

          <Button
            onClick={onAnalyze}
            className="w-full bg-[#3b82f6] hover:bg-[#3b82f6]/90 text-white rounded-xl gap-2 h-12 font-semibold"
          >
            <Zap className="w-4 h-4" />
            Analisar processos
          </Button>
        </div>
      )}
    </div>
  )
}
