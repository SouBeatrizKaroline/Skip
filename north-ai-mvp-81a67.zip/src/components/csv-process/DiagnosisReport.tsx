import { useState } from 'react'
import { type ProcessarCsvResponse } from '@/services/csv-process'
import { Button } from '@/components/ui/button'
import {
  AlertTriangle,
  Clock,
  DollarSign,
  Hand,
  TrendingDown,
  ArrowRight,
  Bot,
  CheckCircle2,
  Sparkles,
  RotateCcw,
} from 'lucide-react'

function formatCurrency(val: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 0,
  }).format(val)
}

export function DiagnosisReport({
  response,
  onReset,
}: {
  response: ProcessarCsvResponse
  onReset: () => void
}) {
  const [showDetails, setShowDetails] = useState(false)
  const diag = response.diagnostico
  const auto = response.automacao

  if (!diag || !auto) return null

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-[#12121a] border border-slate-700">
        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Resumo Executivo</p>
        <p className="text-sm text-slate-300 leading-relaxed">{response.resumo}</p>
      </div>

      <div className="p-6 rounded-2xl bg-[#12121a] border border-slate-700 space-y-4">
        <div className="flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-amber-500" />
          <h3 className="text-base font-bold text-white">Diagnóstico do Gargalo</h3>
        </div>

        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="text-xs font-semibold text-red-400 uppercase">Gargalo Principal</span>
          </div>
          <p className="text-lg font-bold text-white">{diag.gargalo_principal}</p>
          <p className="text-xs text-slate-400 mt-1">Etapa: {diag.etapa}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-slate-800/50">
            <div className="flex items-center gap-1.5 mb-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Horas/dia</span>
            </div>
            <p className="text-2xl font-extrabold text-white">{diag.horas_por_dia}h</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-800/50">
            <div className="flex items-center gap-1.5 mb-1">
              <DollarSign className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Custo/mês</span>
            </div>
            <p className="text-2xl font-extrabold text-white">
              {formatCurrency(diag.custo_mensal)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/5 border border-amber-500/20">
          <Hand className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-amber-300 font-medium">
            {diag.manual ? 'Processo 100% manual' : 'Processo parcialmente automatizado'}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-[#3b82f6]/5 border border-[#3b82f6]/20">
          <p className="text-xs font-semibold text-slate-400 uppercase mb-2">
            Impacto da Automação
          </p>
          <div className="flex items-center gap-3">
            <span className="text-lg font-bold text-red-400 line-through">
              {diag.metrica_antes}
            </span>
            <ArrowRight className="w-5 h-5 text-[#3b82f6]" />
            <span className="text-lg font-bold text-[#22c55e]">{diag.metrica_depois}</span>
          </div>
          {diag.relatorio && (
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">{diag.relatorio}</p>
          )}
        </div>
      </div>

      <div className="p-6 rounded-2xl bg-[#22c55e]/5 border border-[#22c55e]/30 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#22c55e]/20 text-[#22c55e] flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">{auto.nome}</h3>
              <p className="text-xs text-slate-400 capitalize">{auto.tipo}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className="text-[10px] font-bold text-[#22c55e] bg-[#22c55e]/10 px-2 py-1 rounded-full border border-[#22c55e]/30 uppercase tracking-wide">
              GERADA AUTOMATICAMENTE
            </span>
            <span className="text-xs font-semibold text-[#22c55e] flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              {auto.status}
            </span>
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed">{auto.descricao}</p>

        {showDetails && (
          <div className="p-3 rounded-xl bg-[#22c55e]/5 border border-[#22c55e]/20">
            <p className="text-xs text-slate-400 leading-relaxed">
              {diag.relatorio || auto.descricao}
            </p>
          </div>
        )}

        <Button
          onClick={() => setShowDetails(!showDetails)}
          className="bg-[#22c55e] hover:bg-[#22c55e]/90 text-white rounded-xl gap-2"
        >
          <Sparkles className="w-4 h-4" />
          Ver como funciona
        </Button>
      </div>

      <Button
        onClick={onReset}
        variant="outline"
        className="bg-[#12121a] border-slate-700 text-slate-300 hover:bg-slate-800 rounded-xl gap-2"
      >
        <RotateCcw className="w-4 h-4" />
        Analisar outro CSV
      </Button>
    </div>
  )
}
