import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { parseCsv, type CsvRow } from '@/lib/csv/parse'
import { gerarCsvExemplo } from '@/lib/csv/sample'
import { Upload, AlertCircle, Download, Sparkles, Zap, CheckCircle2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface CsvUploadProps {
  onAnalyze: (rawContent: string, fileName: string) => void
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function CsvUpload({ onAnalyze }: CsvUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [rawContent, setRawContent] = useState('')
  const [previewRows, setPreviewRows] = useState<CsvRow[]>([])
  const [error, setError] = useState<string | null>(null)
  const [dragging, setDragging] = useState(false)

  const handleFile = (selectedFile: File) => {
    setError(null)
    setFile(null)
    setRawContent('')
    setPreviewRows([])
    if (!selectedFile.name.match(/\.(csv|txt)$/i)) {
      setError('Formato inválido. Selecione um arquivo .csv ou .txt.')
      return
    }
    const reader = new FileReader()
    reader.onload = (e) => {
      const content = e.target?.result as string
      if (!content?.trim()) {
        setError('Arquivo vazio.')
        return
      }
      const result = parseCsv(content)
      if ('erro' in result) {
        setError(result.erro)
        return
      }
      setFile(selectedFile)
      setRawContent(content)
      setPreviewRows(result.slice(0, 3))
    }
    reader.onerror = () =>
      setError('Não consegui ler o arquivo. Verifique se é um CSV com cabeçalho.')
    reader.readAsText(selectedFile)
  }

  const handleDownloadSample = () => {
    const blob = new Blob([gerarCsvExemplo()], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'ofertas-mercadinho.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  const header = previewRows[0]?.colunas || []
  const dataRows = previewRows.map((r) => r.valores)

  return (
    <div className="rounded-3xl bg-[#0a0a0f] p-6 sm:p-8 text-white">
      <div className="flex items-center gap-2 mb-1">
        <Sparkles className="w-5 h-5 text-[#3b82f6]" />
        <h2 className="text-lg font-bold">Teste ao vivo com seu CSV</h2>
      </div>
      <p className="text-xs text-slate-400 mb-5">
        Envie uma planilha de ofertas, vendas ou tarefas. A Nortia analisa com IA e gera automação.
      </p>

      {!file ? (
        <>
          <div
            onDragOver={(e) => {
              e.preventDefault()
              setDragging(true)
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDragging(false)
              const f = e.dataTransfer.files[0]
              if (f) handleFile(f)
            }}
            onClick={() => inputRef.current?.click()}
            className={cn(
              'border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all duration-200',
              dragging
                ? 'border-[#3b82f6] bg-[#3b82f6]/5 scale-[1.01]'
                : 'border-slate-700 hover:border-[#3b82f6]/50 hover:bg-slate-800/30',
            )}
          >
            <Upload className="w-10 h-10 text-slate-500 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-300">Arraste seu CSV aqui</p>
            <p className="text-xs text-slate-500 mt-1">ou clique para selecionar</p>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept=".csv,.txt"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) handleFile(f)
              e.target.value = ''
            }}
          />
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 mt-4">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <p className="text-xs text-red-400">{error}</p>
            </div>
          )}
          <button
            onClick={handleDownloadSample}
            className="text-xs text-[#3b82f6] hover:text-[#3b82f6]/80 font-medium flex items-center gap-1 transition-colors mt-4"
          >
            <Download className="w-3.5 h-3.5" />
            Baixar CSV de exemplo
          </button>
        </>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 rounded-xl bg-[#12121a] border border-slate-700">
            <div className="w-10 h-10 rounded-lg bg-[#3b82f6]/20 text-[#3b82f6] flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{file.name}</p>
              <p className="text-xs text-slate-400">{formatFileSize(file.size)}</p>
            </div>
          </div>

          {header.length > 0 && (
            <div className="overflow-x-auto rounded-xl border border-slate-700 bg-[#12121a]">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-700">
                    {header.map((h, i) => (
                      <th
                        key={i}
                        className="px-3 py-2 text-left font-semibold text-[#3b82f6] whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {dataRows.map((row, ri) => (
                    <tr key={ri} className="border-b border-slate-800 last:border-0">
                      {row.map((cell, ci) => (
                        <td key={ci} className="px-3 py-2 text-slate-300 whitespace-nowrap">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <p className="text-xs text-slate-500">Pré-visualização: cabeçalho + 3 primeiras linhas</p>

          <Button
            onClick={() => rawContent && onAnalyze(rawContent, file.name)}
            className="w-full bg-[#3b82f6] hover:bg-[#3b82f6]/90 text-white rounded-xl gap-2 h-12 font-semibold transition-all hover:scale-[1.01] active:scale-[0.99]"
          >
            <Zap className="w-4 h-4" />
            ANALISAR COM A NORTIA
          </Button>
        </div>
      )}
    </div>
  )
}
