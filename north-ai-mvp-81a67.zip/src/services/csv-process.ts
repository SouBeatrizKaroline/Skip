import pb from '@/lib/pocketbase/client'

export interface DiagnosticoCsv {
  gargalo_principal: string
  etapa: string
  horas_por_dia: number
  custo_mensal: number
  manual: boolean
  metrica_antes: string
  metrica_depois: string
  relatorio: string
}

export interface AutomacaoCsv {
  nome: string
  descricao: string
  tipo: string
  status: string
}

export interface ProcessarCsvResponse {
  status: string
  resumo: string
  diagnostico: DiagnosticoCsv | null
  automacao: AutomacaoCsv | null
  error?: string
}

export async function processarCsv(rawCsv: string, title: string): Promise<ProcessarCsvResponse> {
  return pb.send('/backend/v1/north-ai/processar-csv', {
    method: 'POST',
    body: JSON.stringify({ raw_csv: rawCsv, title }),
    headers: { 'Content-Type': 'application/json' },
  })
}
