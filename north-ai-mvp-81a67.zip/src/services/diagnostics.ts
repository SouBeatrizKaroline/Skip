import pb from '@/lib/pocketbase/client'
import type { Diagnostic, Bottleneck, Solution, RoadmapItem } from '@/types'

export const getDiagnostics = async () => {
  return pb.collection('diagnostics').getFullList<Diagnostic>({
    sort: '-created',
  })
}

export const getDiagnostic = async (id: string) => {
  return pb.collection('diagnostics').getOne<Diagnostic>(id)
}

export const createDiagnostic = async (data: {
  company_name: string
  industry: string
  company_size?: string
  annual_revenue?: number
  process_description: string
  csv_filename?: string
  csv_data?: string
}) => {
  const user = pb.authStore.record
  if (!user) throw new Error('Usuário não autenticado.')
  return pb.collection('diagnostics').create<Diagnostic>({
    ...data,
    owner: user.id,
    status: 'queued',
  })
}

export const triggerAnalyzeDiagnostic = async (id: string) => {
  return pb.send(`/backend/v1/diagnostics/${id}/analyze`, {
    method: 'POST',
  })
}

export const deleteDiagnostic = async (id: string) => {
  return pb.collection('diagnostics').delete(id)
}

export const getBottlenecks = async (diagnosticId: string) => {
  return pb.collection('bottlenecks').getFullList<Bottleneck>({
    filter: `diagnostic = "${diagnosticId}"`,
    sort: '-priority_score',
  })
}

export const getSolutions = async (diagnosticId: string) => {
  return pb.collection('solutions').getFullList<Solution>({
    filter: `diagnostic = "${diagnosticId}"`,
    sort: 'priority',
  })
}

export const updateSolutionStatus = async (id: string, status: Solution['status']) => {
  return pb.collection('solutions').update<Solution>(id, { status })
}

export const getRoadmapItems = async (diagnosticId: string) => {
  return pb.collection('roadmap_items').getFullList<RoadmapItem>({
    filter: `diagnostic = "${diagnosticId}"`,
    sort: 'phase,priority',
  })
}

export const updateRoadmapItem = async (id: string, data: Partial<RoadmapItem>) => {
  return pb.collection('roadmap_items').update<RoadmapItem>(id, data)
}

export const createRoadmapItem = async (data: Omit<RoadmapItem, 'id' | 'created' | 'updated'>) => {
  return pb.collection('roadmap_items').create<RoadmapItem>(data)
}

export const deleteRoadmapItem = async (id: string) => {
  return pb.collection('roadmap_items').delete(id)
}

export const sendAssistantChat = async (
  message: string,
  conversationId?: string | null,
  diagnosticTitle?: string,
  diagnosticId?: string | null,
) => {
  return pb.send('/backend/v1/assistant/chat', {
    method: 'POST',
    body: JSON.stringify({
      message,
      conversation_id: conversationId,
      diagnostic_title: diagnosticTitle,
      diagnostic_id: diagnosticId,
    }),
    headers: { 'Content-Type': 'application/json' },
  })
}
