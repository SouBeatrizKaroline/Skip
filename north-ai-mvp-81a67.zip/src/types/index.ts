export type DiagnosticStatus = 'queued' | 'processing' | 'completed' | 'failed'

export interface Diagnostic {
  id: string
  owner: string
  company_name: string
  industry: string
  company_size?: string
  annual_revenue?: number
  process_description: string
  csv_filename?: string
  csv_data?: string
  status: DiagnosticStatus
  summary?: string
  total_financial_impact?: number
  total_labor_hours?: number
  total_labor_cost?: number
  avg_roi?: number
  error?: string
  created: string
  updated: string
}

export type BottleneckCategory =
  | 'Processo'
  | 'Tecnologia'
  | 'Pessoas'
  | 'Dados'
  | 'Comunicação'
  | 'Compliance'
export type BottleneckFrequency = 'constante' | 'alta' | 'média' | 'baixa'

export interface Bottleneck {
  id: string
  diagnostic: string
  title: string
  description?: string
  process_stage?: string
  category?: BottleneckCategory
  severity?: number
  frequency?: BottleneckFrequency
  financial_impact?: number
  labor_hours_lost?: number
  labor_cost?: number
  rework_percentage?: number
  roi_estimate?: number
  payback_months?: number
  priority_score?: number
  recommendation?: string
  created: string
  updated: string
}

export type SolutionType = 'app' | 'agente'
export type SolutionCategory = 'automação' | 'análise' | 'atendimento' | 'integração' | 'otimização'
export type ImplementationEffort = 'baixo' | 'médio' | 'alto'
export type SolutionStatus = 'proposto' | 'em_andamento' | 'concluído'

export interface Solution {
  id: string
  diagnostic: string
  type: SolutionType
  name: string
  description: string
  category?: SolutionCategory
  blueprint?: string
  features?: string[]
  expected_impact?: string
  roi_estimate?: number
  implementation_effort?: ImplementationEffort
  priority?: number
  status?: SolutionStatus
  created: string
  updated: string
}

export type RoadmapStatus = 'pendente' | 'em_andamento' | 'concluído' | 'bloqueado'

export interface RoadmapItem {
  id: string
  diagnostic: string
  title: string
  description?: string
  phase: number
  phase_name?: string
  solution?: string
  bottleneck?: string
  priority?: number
  timeline_weeks?: number
  status: RoadmapStatus
  created: string
  updated: string
}
