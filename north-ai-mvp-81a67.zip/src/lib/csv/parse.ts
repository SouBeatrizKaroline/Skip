export interface CsvRow {
  colunas: string[]
  valores: string[]
}

export type TipoGargalo = 'duplicata' | 'pendencia' | 'vazio' | 'padrao' | 'sobrecarga'

export interface GargaloDetectado {
  id: string
  titulo: string
  descricao: string
  horasSemana: number
  custoMes: number
  tipo: TipoGargalo
  fonte: string
}

export interface MetricasCsv {
  totalLinhas: number
  totalColunas: number
  pctDuplicatas: number
  pctPendentes: number
  pctVazios: number
  horasSemana: number
  custoMes: number
  gargalos: GargaloDetectado[]
}

export interface AutomacaoSugerida {
  nome: string
  passos: string[]
  horasEconomizadas: number
  custoEconomizado: number
}

export function parseCsv(texto: string, delimitador?: ';' | ','): CsvRow[] | { erro: string } {
  const trimmed = texto.trim()
  if (!trimmed) return { erro: 'Arquivo vazio.' }
  const delim = delimitador || (trimmed.includes(';') ? ';' : ',')
  const lines = trimmed.split(/\r?\n/).filter((l) => l.trim())
  if (lines.length < 2) return { erro: 'CSV precisa de cabeçalho e ao menos 1 linha de dados.' }

  const parseLine = (line: string): string[] => {
    const result: string[] = []
    let cur = ''
    let inQ = false
    for (let i = 0; i < line.length; i++) {
      const c = line[i]
      if (c === '"') {
        if (inQ && line[i + 1] === '"') {
          cur += '"'
          i++
        } else inQ = !inQ
      } else if (c === delim && !inQ) {
        result.push(cur.trim())
        cur = ''
      } else {
        cur += c
      }
    }
    result.push(cur.trim())
    return result
  }

  const colunas = parseLine(lines[0])
  const rows: CsvRow[] = []
  for (let i = 1; i < lines.length; i++) {
    const valores = parseLine(lines[i])
    if (valores.length === 1 && !valores[0]) continue
    rows.push({ colunas, valores })
  }
  if (!rows.length) return { erro: 'Nenhuma linha de dados após o cabeçalho.' }
  return rows
}
