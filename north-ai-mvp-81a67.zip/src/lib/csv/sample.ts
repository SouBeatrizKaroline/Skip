export function gerarCsvExemplo(): string {
  const header = 'produto,data,canal,responsavel,status,valor,tempo_min'
  const produtos = [
    'Arroz 5kg',
    'Feijão 1kg',
    'Óleo 900ml',
    'Açúcar 1kg',
    'Café 500g',
    'Leite 1L',
    'Pão Francês',
    'Detergente',
    'Sabão',
    'Macarrão',
  ]
  const canais = ['WhatsApp', 'Instagram', 'Facebook', 'Panfleto']
  const linhas: string[] = [header]

  for (let i = 0; i < 40; i++) {
    const produto = produtos[i % 10]
    const data = `2026-08-${String((i % 28) + 1).padStart(2, '0')}`
    const canal = canais[i % 4]
    const responsavel = i < 25 ? 'Maria' : i < 33 ? 'João' : 'Carlos'
    const status = i % 7 === 0 ? 'pendente' : i % 4 === 0 ? 'rascunho' : 'publicado'
    let valor: string
    if (i % 8 === 0) valor = ''
    else if (i % 11 === 0) valor = 'ND'
    else valor = String((((i * 7) % 45) + 5).toFixed(2)).replace('.', ',')
    const tempo = i % 6 === 0 ? '' : String((i % 25) + 10)
    linhas.push(`${produto},${data},${canal},${responsavel},${status},${valor},${tempo}`)
  }

  linhas[5] = linhas[1]
  linhas[10] = linhas[2]
  linhas[15] = linhas[3]

  return linhas.join('\n')
}
