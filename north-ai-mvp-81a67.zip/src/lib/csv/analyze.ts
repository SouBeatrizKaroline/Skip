import type { CsvRow, GargaloDetectado, MetricasCsv, TipoGargalo, AutomacaoSugerida } from './parse'

const CUSTO_HORA = 35
const SEMANAS_MES = 4.33
const MIN_POR_LINHA = 15

function findColuna(colunas: string[], nomes: string[]): number {
  for (const n of nomes) {
    const idx = colunas.findIndex((c) => c.toLowerCase().trim() === n)
    if (idx !== -1) return idx
  }
  return -1
}

export function detectarDuplicatas(rows: CsvRow[]): { linhas: number[]; qtd: number } {
  const seen = new Map<string, number>()
  const dupes: number[] = []
  rows.forEach((r, i) => {
    const key = r.valores.join('|').toLowerCase()
    if (seen.has(key)) dupes.push(i)
    else seen.set(key, i)
  })
  return { linhas: dupes, qtd: dupes.length }
}

export function detectarPendentes(rows: CsvRow[]): { linhas: number[]; qtd: number } {
  const idx = findColuna(rows[0]?.colunas || [], ['status', 'situação', 'situacao', 'estado'])
  if (idx === -1) return { linhas: [], qtd: 0 }
  const pend: number[] = []
  rows.forEach((r, i) => {
    if ((r.valores[idx] || '').toLowerCase().trim().includes('pendente')) pend.push(i)
  })
  return { linhas: pend, qtd: pend.length }
}

export function detectarVazios(rows: CsvRow[]): { linhas: number[]; qtd: number } {
  const vaz: number[] = []
  rows.forEach((r, i) => {
    if (r.valores.some((v) => !v?.trim())) vaz.push(i)
  })
  return { linhas: vaz, qtd: vaz.length }
}

export function detectarPadrao(rows: CsvRow[]): { linhas: number[]; qtd: number } {
  if (!rows.length) return { linhas: [], qtd: 0 }
  const cols = rows[0].colunas
  const numCols = cols.map((_, ci) => {
    let tot = 0,
      num = 0
    rows.forEach((r) => {
      const v = (r.valores[ci] || '').trim()
      if (v) {
        tot++
        if (!isNaN(Number(v.replace(',', '.')))) num++
      }
    })
    return tot > 0 && num / tot > 0.6
  })
  const issues: number[] = []
  rows.forEach((r, i) => {
    for (let ci = 0; ci < cols.length; ci++) {
      if (numCols[ci]) {
        const v = (r.valores[ci] || '').trim()
        if (v && isNaN(Number(v.replace(',', '.')))) {
          issues.push(i)
          break
        }
      }
    }
  })
  return { linhas: issues, qtd: issues.length }
}

export function detectarSobrecarga(rows: CsvRow[]): { porResponsavel: Record<string, number> } {
  const idx = findColuna(rows[0]?.colunas || [], ['responsavel', 'responsável', 'quem'])
  if (idx === -1) return { porResponsavel: {} }
  const counts: Record<string, number> = {}
  rows.forEach((r) => {
    const n = (r.valores[idx] || '').trim() || 'Não informado'
    counts[n] = (counts[n] || 0) + 1
  })
  return { porResponsavel: counts }
}

export function calcularHoras(rows: CsvRow[]): number {
  const idx = findColuna(rows[0]?.colunas || [], ['tempo_min', 'tempo', 'duracao_min', 'duracao'])
  if (idx !== -1) {
    const min = rows.reduce((s, r) => {
      const v = Number((r.valores[idx] || '').replace(',', '.'))
      return s + (isNaN(v) ? 0 : v)
    }, 0)
    return Math.round((min / 60) * 10) / 10
  }
  return Math.round(((rows.length * MIN_POR_LINHA) / 60) * 10) / 10
}

export function calcularCusto(horasSemana: number, custoHora = CUSTO_HORA): number {
  return Math.round(horasSemana * custoHora * SEMANAS_MES)
}

function horasFromIndices(rows: CsvRow[], indices: number[]): number {
  if (!indices.length) return 0
  const idx = findColuna(rows[0]?.colunas || [], ['tempo_min', 'tempo', 'duracao_min', 'duracao'])
  if (idx !== -1) {
    const min = indices.reduce((s, i) => {
      const v = Number((rows[i]?.valores[idx] || '').replace(',', '.'))
      return s + (isNaN(v) ? 0 : v)
    }, 0)
    return Math.round((min / 60) * 10) / 10
  }
  return Math.round(((indices.length * MIN_POR_LINHA) / 60) * 10) / 10
}

export function analisarCsv(rows: CsvRow[]): MetricasCsv {
  const total = rows.length
  const dups = detectarDuplicatas(rows)
  const pend = detectarPendentes(rows)
  const vaz = detectarVazios(rows)
  const pad = detectarPadrao(rows)
  const sob = detectarSobrecarga(rows)
  const horasTotal = calcularHoras(rows)
  let totalCells = 0,
    emptyCells = 0
  rows.forEach((r) =>
    r.valores.forEach((v) => {
      totalCells++
      if (!v?.trim()) emptyCells++
    }),
  )
  const gargalos: GargaloDetectado[] = []

  if (dups.qtd > 0) {
    const h = horasFromIndices(rows, dups.linhas)
    gargalos.push({
      id: 'dup',
      titulo: 'Publicação duplicada de ofertas',
      descricao: `${dups.qtd} linha(s) duplicada(s). Retrabalho de conferência manual.`,
      horasSemana: h,
      custoMes: calcularCusto(h),
      tipo: 'duplicata',
      fonte: 'CSV',
    })
  }
  if (pend.qtd > 0) {
    const h = horasFromIndices(rows, pend.linhas)
    gargalos.push({
      id: 'pend',
      titulo: 'Ofertas pendentes de publicação',
      descricao: `${pend.qtd} oferta(s) com status "pendente". Acompanhamento manual.`,
      horasSemana: h,
      custoMes: calcularCusto(h),
      tipo: 'pendencia',
      fonte: 'CSV',
    })
  }
  if (vaz.qtd > 0) {
    const h = Math.round(((vaz.qtd * MIN_POR_LINHA) / 60) * 10) / 10
    gargalos.push({
      id: 'vaz',
      titulo: 'Preenchimento incompleto da planilha',
      descricao: `${vaz.qtd} linha(s) com células vazias. Dados faltantes causam quebras.`,
      horasSemana: h,
      custoMes: calcularCusto(h),
      tipo: 'vazio',
      fonte: 'CSV',
    })
  }
  if (pad.qtd > 0) {
    const h = Math.round(((pad.qtd * MIN_POR_LINHA) / 60) * 10) / 10
    gargalos.push({
      id: 'pad',
      titulo: 'Dados com formato incorreto',
      descricao: `${pad.qtd} linha(s) com valores fora do padrão (ex.: "ND").`,
      horasSemana: h,
      custoMes: calcularCusto(h),
      tipo: 'padrao',
      fonte: 'CSV',
    })
  }
  const sobEntries = Object.entries(sob.porResponsavel).sort((a, b) => b[1] - a[1])
  if (sobEntries.length > 0 && sobEntries[0][1] / total > 0.6) {
    const h = Math.round(horasTotal * 0.1 * 10) / 10
    gargalos.push({
      id: 'sob',
      titulo: 'Publicação concentrada em 1 responsável',
      descricao: `"${sobEntries[0][0]}" concentra ${Math.round((sobEntries[0][1] / total) * 100)}% das tarefas.`,
      horasSemana: h,
      custoMes: calcularCusto(h),
      tipo: 'sobrecarga',
      fonte: 'CSV',
    })
  }

  return {
    totalLinhas: total,
    totalColunas: rows[0]?.colunas.length || 0,
    pctDuplicatas: total > 0 ? Math.round((dups.qtd / total) * 1000) / 10 : 0,
    pctPendentes: total > 0 ? Math.round((pend.qtd / total) * 1000) / 10 : 0,
    pctVazios: totalCells > 0 ? Math.round((emptyCells / totalCells) * 1000) / 10 : 0,
    horasSemana: horasTotal,
    custoMes: calcularCusto(horasTotal),
    gargalos,
  }
}

export function gerarAutomacao(gargalos: GargaloDetectado[]): AutomacaoSugerida {
  if (!gargalos.length)
    return {
      nome: 'Agente de Automação',
      passos: ['1. Analisa processo', '2. Executa tarefa', '3. Confirma conclusão'],
      horasEconomizadas: 0,
      custoEconomizado: 0,
    }
  const dom = gargalos.reduce((m, g) => (g.custoMes > m.custoMes ? g : m), gargalos[0])
  const map: Record<TipoGargalo, { nome: string; passos: string[] }> = {
    duplicata: {
      nome: 'Agente de Publicação de Ofertas',
      passos: [
        '1. Lê a planilha de ofertas',
        '2. Publica no canal certo no horário ideal',
        '3. Evita duplicidade automaticamente',
      ],
    },
    pendencia: {
      nome: 'Agente de Aprovação Automática',
      passos: [
        '1. Monitora ofertas pendentes',
        '2. Valida e aprova automaticamente',
        '3. Notifica conclusão via WhatsApp',
      ],
    },
    vazio: {
      nome: 'Agente de Preenchimento Inteligente',
      passos: [
        '1. Detecta campos vazios',
        '2. Sugere e preenche valores',
        '3. Valida antes de publicar',
      ],
    },
    padrao: {
      nome: 'Agente de Qualidade de Dados',
      passos: [
        '1. Valida formato dos dados',
        '2. Corrige valores fora do padrão',
        '3. Mantém planilha consistente',
      ],
    },
    sobrecarga: {
      nome: 'Agente de Distribuição de Tarefas',
      passos: [
        '1. Distribui tarefas entre responsáveis',
        '2. Balanceia carga de trabalho',
        '3. Acompanha progresso em tempo real',
      ],
    },
  }
  return { ...map[dom.tipo], horasEconomizadas: dom.horasSemana, custoEconomizado: dom.custoMes }
}
