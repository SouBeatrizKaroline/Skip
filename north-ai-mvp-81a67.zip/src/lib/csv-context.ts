export interface CsvDiagnostico {
  gargalo_principal: string
  etapa: string
  horas_por_dia: number
  custo_mensal: number
  manual: boolean
  metrica_antes: string
  metrica_depois: string
  relatorio: string
}

export interface CsvAutomacao {
  nome: string
  descricao: string
  tipo: string
  status: string
}

export interface ClientGargalo {
  titulo: string
  descricao: string
  horasSemana: number
  custoMes: number
  tipo: string
  fonte: string
}

export interface ClientMetricas {
  totalLinhas: number
  totalColunas: number
  pctDuplicatas: number
  pctPendentes: number
  pctVazios: number
  horasSemana: number
  custoMes: number
  gargalos: ClientGargalo[]
}

export interface ClientAutomacao {
  nome: string
  passos: string[]
  horasEconomizadas: number
  custoEconomizado: number
}

export interface CsvAnalysisContext {
  fileName: string
  resumo: string
  diagnostico: CsvDiagnostico | null
  automacao: CsvAutomacao | null
  metricas?: ClientMetricas
  automacaoClient?: ClientAutomacao
  rawCsv?: string
  diagnosticId?: string
  timestamp: number
}

const STORAGE_KEY = 'nortia.csvAnalysisContext'

export function saveCsvContext(context: CsvAnalysisContext): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(context))
}

export function getCsvContext(): CsvAnalysisContext | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    return JSON.parse(raw) as CsvAnalysisContext
  } catch {
    return null
  }
}

export function clearCsvContext(): void {
  localStorage.removeItem(STORAGE_KEY)
}

export function buildContextMessage(context: CsvAnalysisContext): string {
  let msg = `Acabei de analisar um arquivo CSV ("${context.fileName}") e recebi o seguinte resultado:\n\n`

  if (context.resumo) {
    msg += `Resumo da análise: ${context.resumo}\n`
  }

  const d = context.diagnostico
  if (d) {
    msg += `\nDiagnóstico do gargalo:\n`
    msg += `- Gargalo principal: ${d.gargalo_principal}\n`
    msg += `- Etapa afetada: ${d.etapa}\n`
    msg += `- Horas perdidas por dia: ${d.horas_por_dia}h\n`
    msg += `- Custo mensal estimado: R$ ${d.custo_mensal.toLocaleString('pt-BR')}\n`
    msg += `- Processo manual: ${d.manual ? 'Sim' : 'Não'}\n`
    msg += `- Métrica antes: ${d.metrica_antes}\n`
    msg += `- Métrica depois (com automação): ${d.metrica_depois}\n`
    if (d.relatorio) msg += `- Relatório: ${d.relatorio}\n`
  }

  const a = context.automacao
  if (a) {
    msg += `\nAutomação gerada:\n`
    msg += `- Nome: ${a.nome}\n`
    msg += `- Descrição: ${a.descricao}\n`
    msg += `- Tipo: ${a.tipo}\n`
    msg += `- Status: ${a.status}\n`
  }

  const m = context.metricas
  if (m) {
    msg += `\nMétricas da análise do arquivo:\n`
    msg += `- Total de linhas: ${m.totalLinhas}\n`
    msg += `- Total de colunas: ${m.totalColunas}\n`
    msg += `- Percentual de duplicatas: ${m.pctDuplicatas}%\n`
    msg += `- Percentual de pendentes: ${m.pctPendentes}%\n`
    msg += `- Percentual de vazios: ${m.pctVazios}%\n`
    msg += `- Horas por semana: ${m.horasSemana}h\n`
    msg += `- Custo mensal: R$ ${m.custoMes.toLocaleString('pt-BR')}\n`

    if (m.gargalos.length > 0) {
      msg += `\nGargalos detectados no arquivo:\n`
      m.gargalos.forEach((g, i) => {
        msg += `(${i + 1}) ${g.titulo}\n`
        msg += `     Descrição: ${g.descricao}\n`
        msg += `     Horas/semana: ${g.horasSemana}h | Custo/mês: R$ ${g.custoMes.toLocaleString('pt-BR')}\n`
        msg += `     Tipo: ${g.tipo} | Fonte: ${g.fonte}\n`
      })
    }
  }

  const ac = context.automacaoClient
  if (ac) {
    msg += `\nAutomação sugerida:\n`
    msg += `- Nome: ${ac.nome}\n`
    msg += `- Passos:\n`
    ac.passos.forEach((p) => {
      msg += `  ${p}\n`
    })
    msg += `- Horas economizadas: ${ac.horasEconomizadas}h/semana\n`
    msg += `- Custo economizado: R$ ${ac.custoEconomizado.toLocaleString('pt-BR')}/mês\n`
  }

  if (context.rawCsv) {
    const maxLen = 8000
    const csv =
      context.rawCsv.length > maxLen
        ? context.rawCsv.slice(0, maxLen) + '\n... (arquivo truncado)'
        : context.rawCsv
    msg += `\nCONTEÚDO COMPLETO DO ARQUIVO CSV ("${context.fileName}"):\n${csv}\n`
  }

  msg += `\nCom base EXCLUSIVAMENTE nos dados deste arquivo, me oriente sobre os próximos passos: revisar a automação gerada, ajustar escopo, definir cronograma de implementação, configurar acompanhamento de ROI e sugerir próximas análises.`
  msg += `\nIMPORTANTE: Use APENAS os dados apresentados acima como fonte de verdade. NÃO invente, assuma ou extrapole dados que não estão presentes no arquivo. Toda referência a valores, linhas, colunas ou categorias deve ser rastreável aos dados fornecidos.`

  return msg
}
