export type Segmento =
  | 'Farmácia'
  | 'Transporte'
  | 'Odontologia'
  | 'Locadora'
  | 'Varejo'
  | 'Condomínio'
  | 'Outro'

export interface ProcessStep {
  step: number
  label: string
}

export interface Gargalo {
  title: string
  hoursPerWeek: number
  costPerMonth: number
  source: string
}

export interface DataSourceCard {
  name: string
  description: string
  iconName: string
  note?: string
}

export const SEGMENTOS: Segmento[] = [
  'Farmácia',
  'Transporte',
  'Odontologia',
  'Locadora',
  'Varejo',
  'Condomínio',
  'Outro',
]

export function getSegmento(): Segmento {
  if (typeof localStorage === 'undefined') return 'Farmácia'
  return (localStorage.getItem('nortia.segment') as Segmento) || 'Farmácia'
}

export function setSegmento(s: Segmento): void {
  localStorage.setItem('nortia.segment', s)
}

export function buildProcessFlow(input: string): ProcessStep[] {
  const trimmed = input.trim().toLowerCase()
  if (
    !trimmed ||
    trimmed.includes('não tenho processo') ||
    trimmed.includes('nao tenho processo')
  ) {
    return [
      { step: 1, label: 'Cliente chega' },
      { step: 2, label: 'Sistema registra automaticamente' },
      { step: 3, label: 'Aprovação automática' },
      { step: 4, label: 'Sistema atualizado' },
      { step: 5, label: 'Cliente notificado por WhatsApp' },
    ]
  }
  return [
    { step: 1, label: 'Cliente chega' },
    { step: 2, label: 'Atendente registra' },
    { step: 3, label: 'Aprovação manual' },
    { step: 4, label: 'Planilha atualizada' },
    { step: 5, label: 'Cliente notificado' },
  ]
}

export function getGargalos(segmento: Segmento): Gargalo[] {
  const data: Record<Segmento, Gargalo[]> = {
    Farmácia: [
      {
        title: 'Conferência manual de estoque',
        hoursPerWeek: 5,
        costPerMonth: 2400,
        source: 'ERP+planilha',
      },
      { title: 'Retrabalho em dispensação', hoursPerWeek: 3, costPerMonth: 1800, source: 'CRM' },
    ],
    Transporte: [
      { title: 'Roteirização manual', hoursPerWeek: 8, costPerMonth: 4200, source: 'TMS' },
      {
        title: 'Confirmação por telefone',
        hoursPerWeek: 6,
        costPerMonth: 3100,
        source: 'WhatsApp',
      },
    ],
    Odontologia: [
      {
        title: 'Agendamento em planilha',
        hoursPerWeek: 4,
        costPerMonth: 1600,
        source: 'Planilha (Excel/CSV)',
      },
      {
        title: 'Confirmação manual de consulta',
        hoursPerWeek: 3,
        costPerMonth: 1200,
        source: 'WhatsApp',
      },
    ],
    Locadora: [
      {
        title: 'Contratos em papel',
        hoursPerWeek: 6,
        costPerMonth: 2800,
        source: 'Sistemas fechados (TMS/ATS)',
      },
      {
        title: 'Baixa de devolução manual',
        hoursPerWeek: 4,
        costPerMonth: 1900,
        source: 'ERP via API',
      },
    ],
    Varejo: [
      {
        title: 'Inventário em planilha',
        hoursPerWeek: 7,
        costPerMonth: 3500,
        source: 'Planilha (Excel/CSV)',
      },
      {
        title: 'Cadastro de produto manual',
        hoursPerWeek: 5,
        costPerMonth: 2200,
        source: 'ERP via API',
      },
    ],
    Condomínio: [
      {
        title: 'Controle de visitantes em livro',
        hoursPerWeek: 4,
        costPerMonth: 1400,
        source: 'Planilha (Excel/CSV)',
      },
      {
        title: 'Boletos gerados manualmente',
        hoursPerWeek: 6,
        costPerMonth: 2600,
        source: 'ERP via API',
      },
    ],
    Outro: [
      {
        title: 'Processo manual não mapeado',
        hoursPerWeek: 5,
        costPerMonth: 2000,
        source: 'Planilha (Excel/CSV)',
      },
    ],
  }
  return data[segmento] || data.Outro
}

export function getDataSources(): DataSourceCard[] {
  return [
    {
      name: 'Planilha (Excel/CSV)',
      description: 'Upload direto de planilhas para análise imediata de indicadores.',
      iconName: 'FileText',
    },
    {
      name: 'CRM',
      description: 'Integração com seu CRM para extrair dados de clientes e vendas.',
      iconName: 'Users',
    },
    {
      name: 'WhatsApp',
      description: 'Leitura de conversas para mapear atendimentos e fluxos de comunicação.',
      iconName: 'MessageCircle',
    },
    {
      name: 'ERP via API',
      description: 'Conexão direta com seu ERP para dados em tempo real.',
      iconName: 'Database',
    },
    {
      name: 'Sistemas fechados (TMS/ATS)',
      description: 'Sistemas legados sem API também são suportados via observação.',
      iconName: 'Lock',
      note: 'Não tem API? A Nortia observa em 2º plano e aprende o processo.',
    },
  ]
}
