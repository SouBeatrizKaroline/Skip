/* Main App Component - Handles routing (using react-router-dom), query client and other providers - use this file to add all routes */
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'
import Index from './pages/Index'
import NotFound from './pages/NotFound'
import Layout from './components/Layout'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import Dashboard from './pages/Dashboard'
import Roadmap from './pages/Roadmap'
import DiagnosticsList from './pages/DiagnosticsList'
import NewDiagnostic from './pages/NewDiagnostic'
import DiagnosticDetail from './pages/DiagnosticDetail'
import Assistant from './pages/Assistant'
import Settings from './pages/Settings'
import Pricing from './pages/Pricing'
import Fontes from './pages/Fontes'
import Onboarding from './pages/Onboarding'
// ONLY IMPORT AND RENDER WORKING PAGES, NEVER ADD PLACEHOLDER COMPONENTS OR PAGES IN THIS FILE
// AVOID REMOVING ANY CONTEXT PROVIDERS FROM THIS FILE (e.g. TooltipProvider, Toaster, Sonner)

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            {/* ADD ALL CUSTOM ROUTES MUST BE ADDED HERE */}
          </Route>
          <Route path="/app" element={<ProtectedRoute />}>
            <Route element={<Layout />}>
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="diagnostics" element={<DiagnosticsList />} />
              <Route path="diagnostics/new" element={<NewDiagnostic />} />
              <Route path="diagnostics/:id" element={<DiagnosticDetail />} />
              <Route path="assistant" element={<Assistant />} />
              <Route path="planos" element={<Pricing />} />
              <Route path="fontes" element={<Fontes />} />
              <Route path="roadmap" element={<Roadmap />} />
              <Route path="settings" element={<Settings />} />
            </Route>
          </Route>
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </TooltipProvider>
    </AuthProvider>
  </BrowserRouter>
)

export default App
