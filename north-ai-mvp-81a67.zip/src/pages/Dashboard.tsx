import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import { getDiagnostics, getRoadmapItems, updateRoadmapItem } from '@/services/diagnostics'
import type { Diagnostic, RoadmapItem } from '@/types'
import { getGargalos, getSegmento, type Gargalo, type Segmento } from '@/lib/demo-mocks'
import {
  FileSearch,
  DollarSign,
  Clock,
  TrendingUp,
  Plus,
  ArrowRight,
  Compass,
  CheckCircle2,
  Circle,
  AlertTriangle,
  RotateCw,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { CsvDemo } from '@/components/CsvDemo'

export default function Dashboard() {
  const { user } = useAuth()
  const navigate = useNavigate()

  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([])
  const [recentRoadmap, setRecentRoadmap] = useState<RoadmapItem[]>([])
  const [loading, setLoading] = useState(true)
  const [gargalos, setGargalos] = useState<Gargalo[]>([])
  const [segmento] = useState<Segmento>(() => getSegmento())

  const firstName = user?.name ? user.name.split(' ')[0] : 'Gestor'

  const loadData = async () => {
    try {
      const items = await getDiagnostics()
      setDiagnostics(items)
      setGargalos(getGargalos(segmento))
      if (items.length > 0) {
        const latestCompleted = items.find((d) => d.status === 'completed') || items[0]
        const rm = await getRoadmapItems(latestCompleted.id)
        setRecentRoadmap(rm.slice(0, 3))
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('diagnostics', () => {
    loadData()
  })

  useRealtime('roadmap_items', () => {
    loadData()
  })

  // Rollup KPI Calculations
  const completedDiags = diagnostics.filter((d) => d.status === 'completed')
  const totalFinancialImpact = completedDiags.reduce(
    (acc, curr) => acc + (curr.total_financial_impact || 0),
    0,
  )
  const totalLaborHours = completedDiags.reduce(
    (acc, curr) => acc + (curr.total_labor_hours || 0),
    0,
  )
  const avgRoi =
    completedDiags.length > 0
      ? Math.round(
          completedDiags.reduce((acc, curr) => acc + (curr.avg_roi || 0), 0) /
            completedDiags.length,
        )
      : 0

  const handleToggleRoadmap = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'concluído' ? 'pendente' : 'concluído'
    setRecentRoadmap((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: newStatus as any } : item)),
    )
    try {
      await updateRoadmapItem(id, { status: newStatus as any })
    } catch (_) {
      loadData()
    }
  }

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0,
    }).format(val)
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
            Olá, {firstName} 👋
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Aqui está o panorama estratégico da sua transformação.
          </p>
        </div>
        <Button
          onClick={() => navigate('/app/diagnostics/new')}
          className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md shadow-indigo-600/30 gap-2 h-11 px-5"
        >
          <Plus className="w-4 h-4" />
          <span>Novo diagnóstico</span>
        </Button>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Diagnósticos
            </span>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <FileSearch className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold font-display text-slate-900">
              {diagnostics.length}
            </span>
            <span className="text-xs text-slate-500 ml-2">realizados</span>
          </div>
        </Card>

        <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Impacto Potencial
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-extrabold font-display text-slate-900">
              {formatCurrency(totalFinancialImpact)}
            </span>
            <span className="text-xs text-slate-500 ml-1">/mês</span>
          </div>
        </Card>

        <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Horas Perdidas
            </span>
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold font-display text-slate-900">
              {totalLaborHours}h
            </span>
            <span className="text-xs text-slate-500 ml-2">/mês</span>
          </div>
        </Card>

        <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              ROI Médio Estimado
            </span>
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-display text-slate-900">{avgRoi}%</span>
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-0.5">
              ↑ Retorno
            </span>
          </div>
        </Card>
      </div>

      {/* Segment-aware Bottlenecks */}
      {gargalos.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold font-display text-slate-900">Gargalos Detectados</h2>
            <Badge variant="outline" className="text-xs text-slate-500">
              {segmento}
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gargalos.map((g, i) => (
              <Card key={i} className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
                <h3 className="font-bold text-sm text-slate-900 mb-2">{g.title}</h3>
                <div className="flex items-center gap-4 text-xs text-slate-600">
                  <span>
                    <strong className="text-slate-900">{g.hoursPerWeek}h/semana</strong>
                  </span>
                  <span>
                    <strong className="text-slate-900">
                      R$ {g.costPerMonth.toLocaleString('pt-BR')}/mês
                    </strong>
                  </span>
                </div>
                <Badge variant="outline" className="mt-3 text-[10px] bg-slate-50 text-slate-500">
                  detectado em: {g.source}
                </Badge>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* CSV Live Demo */}
      <CsvDemo />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Diagnostics List (2/3) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold font-display text-slate-900">Diagnósticos Recentes</h2>
            <Link
              to="/app/diagnostics"
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-500 flex items-center gap-1"
            >
              Ver todos ({diagnostics.length})
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {diagnostics.length === 0 && !loading ? (
            <Card className="p-12 text-center rounded-2xl border-dashed border-2 border-slate-200 bg-white space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                <Compass className="w-8 h-8 animate-pulse" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-display text-slate-900">
                  Nenhum diagnóstico realizado
                </h3>
                <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
                  Comece descrevendo o fluxo da sua empresa para calcular gargalos e ROI.
                </p>
              </div>
              <Button
                onClick={() => navigate('/app/diagnostics/new')}
                className="bg-indigo-600 text-white rounded-xl gap-2"
              >
                <Plus className="w-4 h-4" />
                Criar Primeiro Diagnóstico
              </Button>
            </Card>
          ) : (
            <div className="space-y-3">
              {diagnostics.slice(0, 5).map((diag) => (
                <Card
                  key={diag.id}
                  onClick={() => navigate(`/app/diagnostics/${diag.id}`)}
                  className="p-5 rounded-2xl border-slate-200/80 bg-white hover:border-indigo-200 shadow-soft hover:shadow-soft-hover transition-all duration-200 cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                          {diag.company_name}
                        </h3>
                        <Badge
                          variant="outline"
                          className="text-xs bg-slate-50 text-slate-600 border-slate-200"
                        >
                          {diag.industry}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1">
                        {diag.process_description}
                      </p>
                    </div>

                    {/* Status Chip */}
                    <div>
                      {diag.status === 'completed' && (
                        <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1.5 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          Concluído
                        </Badge>
                      )}
                      {diag.status === 'processing' && (
                        <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 gap-1.5 font-medium animate-pulse">
                          <RotateCw className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
                          Processando…
                        </Badge>
                      )}
                      {diag.status === 'queued' && (
                        <Badge className="bg-amber-50 text-amber-700 border-amber-200 gap-1.5 font-medium">
                          Na fila
                        </Badge>
                      )}
                      {diag.status === 'failed' && (
                        <Badge className="bg-rose-50 text-rose-700 border-rose-200 gap-1.5 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          Falhou
                        </Badge>
                      )}
                    </div>
                  </div>

                  {diag.status === 'completed' && (
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                      <div className="flex items-center gap-4">
                        <span>
                          Impacto:{' '}
                          <strong className="text-slate-900">
                            {formatCurrency(diag.total_financial_impact || 0)}
                          </strong>
                        </span>
                        <span>
                          Horas:{' '}
                          <strong className="text-slate-900">
                            {diag.total_labor_hours || 0}h/mês
                          </strong>
                        </span>
                      </div>
                      <span className="text-indigo-600 font-semibold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                        Ver resultados
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Next Steps / Roadmap Widget (1/3) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold font-display text-slate-900">Próximos Passos</h2>
            <Link
              to="/app/roadmap"
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-500"
            >
              Ver completo
            </Link>
          </div>

          <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft space-y-4">
            {recentRoadmap.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">
                Nenhuma ação no roadmap ainda.
              </p>
            ) : (
              <div className="space-y-3">
                {recentRoadmap.map((item) => {
                  const isDone = item.status === 'concluído'
                  return (
                    <div
                      key={item.id}
                      className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/80 transition-colors"
                    >
                      <Checkbox
                        id={`rm-${item.id}`}
                        checked={isDone}
                        onCheckedChange={() => handleToggleRoadmap(item.id, item.status)}
                        className="mt-0.5"
                      />
                      <div className="min-w-0 flex-1">
                        <label
                          htmlFor={`rm-${item.id}`}
                          className={`text-xs font-semibold block cursor-pointer leading-snug ${
                            isDone ? 'line-through text-slate-400' : 'text-slate-800'
                          }`}
                        >
                          {item.title}
                        </label>
                        <span className="text-[10px] text-indigo-600 font-medium">
                          {item.phase_name}
                        </span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            <Button
              asChild
              variant="outline"
              className="w-full text-xs font-semibold h-9 rounded-xl border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              <Link to="/app/roadmap">Gerenciar Roadmap Vivo</Link>
            </Button>
          </Card>
        </div>
      </div>
    </div>
  )
}
