import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import { Compass, ArrowLeft, Mail } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function ForgotPassword() {
  const { requestPasswordReset } = useAuth()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return
    setLoading(true)
    await requestPasswordReset(email)
    setLoading(false)
    setSent(true)
  }

  return (
    <div className="min-h-screen bg-[#F6F7FB] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-soft p-8 space-y-6 border border-slate-100">
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
            <Compass className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold font-display text-slate-900">Recuperar Senha</h1>
          <p className="text-sm text-slate-500">
            Digite seu e-mail para receber um link de redefinição de senha.
          </p>
        </div>

        {sent ? (
          <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-800 text-sm space-y-3">
            <div className="flex items-center gap-2 font-semibold">
              <Mail className="w-5 h-5 text-indigo-600" />
              <span>Link enviado!</span>
            </div>
            <p className="text-xs leading-relaxed text-indigo-700">
              Se existir uma conta associada ao e-mail <strong>{email}</strong>, enviamos as
              instruções de redefinição.
            </p>
            <Button
              asChild
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl mt-2"
            >
              <Link to="/">Voltar ao Login</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs font-semibold text-slate-700 uppercase">
                Seu E-mail
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu.email@empresa.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 rounded-xl"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold shadow-md shadow-indigo-600/30"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Enviar link de redefinição'
              )}
            </Button>
          </form>
        )}

        <div className="text-center pt-2">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar para o Login</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
