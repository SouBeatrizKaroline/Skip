import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { createDiagnostic, triggerAnalyzeDiagnostic } from '@/services/diagnostics'
import { sendAssistantChat } from '@/services/diagnostics'
import {
  Compass,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Upload,
  FileText,
  Bot,
  Send,
  Building2,
  AlignLeft,
  CheckCircle2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { toast } from '@/hooks/use-toast'

export default function NewDiagnostic() {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)

  // Step 1 Form
  const [companyName, setCompanyName] = useState('')
  const [industry, setIndustry] = useState('Tecnologia')
  const [companySize, setCompanySize] = useState('51–200')
  const [annualRevenue, setAnnualRevenue] = useState('')

  // Step 2 Form
  const [processDescription, setProcessDescription] = useState('')

  // CSV Integration
  const [csvFile, setCsvFile] = useState<{ name: string; data: string } | null>(null)

  const handleCsvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!/\.csv$/i.test(file.name)) {
      toast({
        title: 'Formato inválido',
        description: 'Envie um arquivo .csv.',
        variant: 'destructive',
      })
      return
    }
    if (file.size > 1024 * 1024) {
      toast({
        title: 'Arquivo muito grande',
        description: 'O CSV deve ter no máximo 1 MB.',
        variant: 'destructive',
      })
      return
    }
    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      setCsvFile({ name: file.name, data: content })
      toast({
        title: 'CSV importado com sucesso!',
        description: `${file.name} será usado na análise.`,
      })
    }
    reader.readAsText(file)
  }

  const handleRemoveCsv = () => {
    setCsvFile(null)
    const input = document.getElementById('csv-dropzone') as HTMLInputElement | null
    if (input) input.value = ''
  }

  const csvRows = csvFile
    ? csvFile.data
        .trim()
        .split('\n')
        .map((row) => row.split(','))
    : []

  const csvPreviewRows = csvRows.slice(0, 5)
  const csvExtraCount = Math.max(0, csvRows.length - 5)

  // Co-writer Assistant Sheet
  const [coWriterOpen, setCoWriterOpen] = useState(false)
  const [aiPrompt, setAiPrompt] = useState('')
  const [aiLoading, setAiLoading] = useState(false)
  const [coWriterMessages, setCoWriterMessages] = useState<
    Array<{ role: string; content: string }>
  >([
    {
      role: 'assistant',
      content:
        'Olá! Sou o North. Descreva brevemente o que sua equipe faz e quais são as principais dores para eu ajudar a redigir um fluxo de processo rico.',
    },
  ])

  const helperChips = [
    'Fluxo de aprovação em papel',
    'Planilha manual no Excel',
    'Retrabalho por erro de digitação',
    'Handoff demorado entre áreas',
  ]

  const handleInsertChip = (text: string) => {
    setProcessDescription((prev) => (prev ? `${prev}\n- ${text}` : `Obs: ${text}`))
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      setProcessDescription(
        (prev) => `${prev}\n\n--- Conteúdo do Arquivo (${file.name}) ---\n${content}`,
      )
      toast({ title: 'Arquivo importado com sucesso!' })
    }
    reader.readAsText(file)
  }

  const handleCoWriterSend = async () => {
    if (!aiPrompt.trim()) return
    const userMsg = aiPrompt
    setAiPrompt('')
    setCoWriterMessages((prev) => [...prev, { role: 'user', content: userMsg }])
    setAiLoading(true)

    try {
      const res = await sendAssistantChat(
        `Ajude-me a descrever o processo da empresa ${companyName}. Mensagem: ${userMsg}`,
        null,
        companyName,
      )
      setCoWriterMessages((prev) => [...prev, { role: 'assistant', content: res.content }])
    } catch (_) {
      setCoWriterMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: 'Desculpe, ocorreu um erro ao se comunicar com o assistente.',
        },
      ])
    } finally {
      setAiLoading(false)
    }
  }

  const handleUseAiText = (text: string) => {
    setProcessDescription(text)
    setCoWriterOpen(false)
    toast({ title: 'Texto do assistente copiado para o processo!' })
  }

  const handleSubmitDiagnostic = async () => {
    if (!companyName || !processDescription) {
      toast({ title: 'Preencha todos os campos obrigatórios.', variant: 'destructive' })
      return
    }
    setLoading(true)

    try {
      const diag = await createDiagnostic({
        company_name: companyName,
        industry,
        company_size: companySize,
        annual_revenue: annualRevenue ? parseFloat(annualRevenue) : undefined,
        process_description: processDescription,
        csv_filename: csvFile?.name,
        csv_data: csvFile?.data,
      })

      // Trigger server-side analysis pipeline
      triggerAnalyzeDiagnostic(diag.id).catch(console.error)

      toast({ title: 'Diagnóstico iniciado!', description: 'Analisando processo com IA…' })
      navigate(`/app/diagnostics/${diag.id}`)
    } catch (err: any) {
      toast({
        title: 'Erro ao criar diagnóstico',
        description: err.message,
        variant: 'destructive',
      })
      setLoading(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in pb-12">
      {/* Header */}
      <div>
        <Button
          variant="ghost"
          onClick={() => navigate('/app/diagnostics')}
          className="text-xs text-slate-500 hover:text-slate-900 gap-1 p-0 h-auto mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Voltar para diagnósticos
        </Button>
        <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
          Novo Diagnóstico
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Descreva o processo para calcular impactos e gerar o roadmap vivo.
        </p>
      </div>

      {/* Stepper Progress */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        {[
          { num: 1, label: 'Dados da Empresa', icon: Building2 },
          { num: 2, label: 'Descreva o Processo', icon: AlignLeft },
          { num: 3, label: 'Revisão & Análise', icon: CheckCircle2 },
        ].map((s) => {
          const isActive = step === s.num
          const isDone = step > s.num
          const Icon = s.icon
          return (
            <div key={s.num} className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : isDone
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isDone ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-4 h-4" />}
              </div>
              <span
                className={`text-xs font-semibold hidden sm:inline ${isActive ? 'text-indigo-600' : 'text-slate-500'}`}
              >
                {s.label}
              </span>
            </div>
          )
        })}
      </div>

      {/* Step 1: Dados da Empresa */}
      {step === 1 && (
        <Card className="p-6 sm:p-8 rounded-2xl bg-white border-slate-200/80 shadow-soft space-y-6 animate-fade-in">
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label
                htmlFor="companyName"
                className="text-xs font-semibold uppercase text-slate-700"
              >
                Nome da Empresa *
              </Label>
              <Input
                id="companyName"
                placeholder="Ex: Logística Farma S.A."
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="h-11 rounded-xl"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase text-slate-700">
                  Setor da Empresa
                </Label>
                <Select value={industry} onValueChange={setIndustry}>
                  <SelectTrigger className="h-11 rounded-xl">
                    <SelectValue placeholder="Selecione o setor" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {[
                      'Tecnologia',
                      'Varejo',
                      'Saúde',
                      'Indústria',
                      'Finanças',
                      'Educação',
                      'Logística',
                      'Serviços',
                      'Outro',
                    ].map((ind) => (
                      <SelectItem key={ind} value={ind}>
                        {ind}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase text-slate-700">
                  Porte (Funcionários)
                </Label>
                <Select value={companySize} onValueChange={setCompanySize}>
                  <SelectTrigger className="h-11 rounded-xl">
                    <SelectValue placeholder="Selecione o porte" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {['1–10', '11–50', '51–200', '201–500', '500+'].map((sz) => (
                      <SelectItem key={sz} value={sz}>
                        {sz} colaboradores
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="revenue" className="text-xs font-semibold uppercase text-slate-700">
                Faturamento Anual Estimado (R$)
              </Label>
              <Input
                id="revenue"
                type="number"
                placeholder="Ex: 18000000"
                value={annualRevenue}
                onChange={(e) => setAnnualRevenue(e.target.value)}
                className="h-11 rounded-xl"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100">
            <Button
              onClick={() => {
                if (!companyName) {
                  toast({ title: 'Informe o nome da empresa.', variant: 'destructive' })
                  return
                }
                setStep(2)
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 h-11 px-6 font-semibold"
            >
              <span>Continuar</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Step 2: Descreva o Processo */}
      {step === 2 && (
        <Card className="p-6 sm:p-8 rounded-2xl bg-white border-slate-200/80 shadow-soft space-y-6 animate-fade-in">
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <Label className="text-xs font-semibold uppercase text-slate-700">
                Descrição Detalhada do Processo *
              </Label>
              <Sheet open={coWriterOpen} onOpenChange={setCoWriterOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-indigo-600 border-indigo-200 rounded-xl gap-1.5 text-xs"
                  >
                    <Bot className="w-4 h-4" />
                    <span>Abrir Assistente Co-Writer</span>
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-md p-6 bg-slate-900 border-slate-800 text-slate-100 flex flex-col justify-between">
                  <SheetHeader>
                    <SheetTitle className="text-white flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-400" />
                      <span>Co-Writer Nortia</span>
                    </SheetTitle>
                  </SheetHeader>

                  <div className="flex-1 overflow-y-auto space-y-3 my-4 pr-1">
                    {coWriterMessages.map((m, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl text-xs leading-relaxed ${
                          m.role === 'user'
                            ? 'bg-indigo-600 text-white ml-6'
                            : 'bg-slate-800 text-slate-200 mr-6'
                        }`}
                      >
                        {m.content}
                        {m.role === 'assistant' && idx > 0 && (
                          <Button
                            onClick={() => handleUseAiText(m.content)}
                            size="sm"
                            className="mt-2 w-full bg-indigo-500 hover:bg-indigo-400 text-white text-[11px] h-7 rounded-lg"
                          >
                            Usar este texto no formulário
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                    <Input
                      placeholder="Descreva o que acontece..."
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleCoWriterSend()}
                      className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 h-10 rounded-xl text-xs"
                    />
                    <Button
                      onClick={handleCoWriterSend}
                      disabled={aiLoading}
                      className="bg-indigo-600 text-white h-10 w-10 p-0 rounded-xl"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            <Textarea
              placeholder="Descreva as etapas do processo, quem executa, onde há esperas, retrabalho, planilhas manuais, aprovações, integrações faltando..."
              value={processDescription}
              onChange={(e) => setProcessDescription(e.target.value)}
              className="min-h-[180px] rounded-xl border-slate-200 focus:ring-indigo-500 text-sm leading-relaxed"
            />

            {/* Helper Chips */}
            <div className="space-y-2">
              <span className="text-xs text-slate-500 font-medium">
                Atalhos rápidos para enriquecer a descrição:
              </span>
              <div className="flex flex-wrap gap-2">
                {helperChips.map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => handleInsertChip(chip)}
                    className="text-xs bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 border border-slate-200 rounded-lg px-2.5 py-1.5 transition-colors"
                  >
                    + {chip}
                  </button>
                ))}
              </div>
            </div>

            {/* File Dropzone */}
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-4 text-center hover:border-indigo-300 transition-colors bg-slate-50/50">
              <input
                type="file"
                id="dropzone"
                accept=".txt,.md,.csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <label htmlFor="dropzone" className="cursor-pointer flex flex-col items-center gap-1">
                <Upload className="w-6 h-6 text-indigo-500" />
                <span className="text-xs font-semibold text-slate-700">
                  Anexar documento ou relatório (.txt, .md, .csv)
                </span>
                <span className="text-[11px] text-slate-400">
                  O conteúdo será anexado automaticamente à descrição
                </span>
              </label>
            </div>

            {/* CSV Integration */}
            <div className="border-2 border-dashed border-indigo-200 rounded-2xl p-5 bg-indigo-50/30 hover:border-indigo-400 transition-colors">
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-4 h-4 text-indigo-500" />
                <span className="text-xs font-bold uppercase text-indigo-700">
                  Integração CSV (Planilha de Dados)
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mb-3">
                Envie uma planilha .csv com os dados do processo. A IA usará os indicadores (volume,
                tempo, erro, retrabalho) como fonte quantitativa do diagnóstico.
              </p>

              {!csvFile ? (
                <>
                  <input
                    type="file"
                    id="csv-dropzone"
                    accept=".csv,text/csv"
                    onChange={handleCsvUpload}
                    className="hidden"
                  />
                  <label
                    htmlFor="csv-dropzone"
                    className="cursor-pointer flex flex-col items-center gap-1 py-4 rounded-xl bg-white border border-indigo-100 hover:border-indigo-300 transition-colors"
                  >
                    <Upload className="w-6 h-6 text-indigo-500" />
                    <span className="text-xs font-semibold text-slate-700">
                      Procurar arquivo .csv no computador (browse)
                    </span>
                    <span className="text-[11px] text-slate-400">
                      máx. 1 MB · formatos: etapa, atividade, volume, tempo, erro, retrabalho
                    </span>
                  </label>
                </>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between bg-white border border-indigo-100 rounded-xl px-3 py-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-xs font-semibold text-slate-800 truncate">
                        {csvFile.name}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleRemoveCsv}
                      className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg px-2 py-1"
                    >
                      Remover
                    </button>
                  </div>

                  {csvRows.length > 1 && (
                    <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
                      <table className="w-full text-[11px]">
                        <thead>
                          <tr className="bg-slate-50 text-slate-500">
                            {csvRows[0].map((h, i) => (
                              <th key={i} className="px-2 py-1.5 text-left font-semibold uppercase">
                                {h.trim()}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {csvPreviewRows.slice(1).map((row, ri) => (
                            <tr key={ri} className="border-t border-slate-100">
                              {row.map((cell, ci) => (
                                <td key={ci} className="px-2 py-1 text-slate-600 whitespace-nowrap">
                                  {cell.trim()}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-medium">
                      {csvRows.length - 1} linha(s) de dados
                      {csvExtraCount > 0 && ` · exibindo as 5 primeiras`}
                    </span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <Button
              variant="ghost"
              onClick={() => setStep(1)}
              className="rounded-xl text-slate-600"
            >
              Voltar
            </Button>
            <Button
              onClick={() => {
                if (!processDescription) {
                  toast({ title: 'Descreva o processo para continuar.', variant: 'destructive' })
                  return
                }
                setStep(3)
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 h-11 px-6 font-semibold"
            >
              <span>Continuar</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Step 3: Revisão */}
      {step === 3 && (
        <Card className="p-6 sm:p-8 rounded-2xl bg-white border-slate-200/80 shadow-soft space-y-6 animate-fade-in">
          <div className="space-y-4">
            <h2 className="text-lg font-bold font-display text-slate-900">
              Revisão do Diagnóstico
            </h2>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">Empresa</span>
                <span className="text-sm font-bold text-slate-900">{companyName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">Setor</span>
                <span className="text-xs font-semibold text-slate-700">{industry}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">Porte</span>
                <span className="text-xs font-semibold text-slate-700">
                  {companySize} colaboradores
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
              <span className="text-xs font-semibold text-slate-500 uppercase block">
                Descrição do Processo
              </span>
              <p className="text-xs text-slate-700 line-clamp-4 leading-relaxed whitespace-pre-wrap">
                {processDescription}
              </p>
            </div>

            {csvFile && (
              <div className="p-4 rounded-xl bg-indigo-50/40 border border-indigo-100 space-y-1">
                <span className="text-xs font-semibold text-indigo-700 uppercase block flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  Planilha CSV anexada
                </span>
                <p className="text-xs text-slate-700 font-medium">
                  {csvFile.name} · {csvRows.length - 1} linha(s) de dados
                </p>
                <p className="text-[11px] text-slate-500">
                  Os indicadores da planilha serão usados como fonte quantitativa da análise.
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <Button
              variant="ghost"
              onClick={() => setStep(2)}
              className="rounded-xl text-slate-600"
            >
              Voltar
            </Button>
            <Button
              onClick={handleSubmitDiagnostic}
              disabled={loading}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 h-12 px-8 font-semibold shadow-lg shadow-indigo-600/30"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-indigo-200" />
                  <span>Iniciar Análise com IA</span>
                </>
              )}
            </Button>
          </div>
        </Card>
      )}
    </div>
  )
}
