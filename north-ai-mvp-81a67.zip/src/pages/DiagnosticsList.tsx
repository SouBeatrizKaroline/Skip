import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useRealtime } from '@/hooks/use-realtime'
import { getDiagnostics, deleteDiagnostic, triggerAnalyzeDiagnostic } from '@/services/diagnostics'
import type { Diagnostic } from '@/types'
import {
  Plus,
  Search,
  FileSearch,
  Trash2,
  RotateCw,
  MoreVertical,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from '@/hooks/use-toast'

export default function DiagnosticsList() {
  const navigate = useNavigate()
  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([])
  const [search, setSearch] = useState('')
  const [activeTab, setActiveTab] = useState('all')
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const loadData = async () => {
    try {
      const items = await getDiagnostics()
      setDiagnostics(items)
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('diagnostics', () => {
    loadData()
  })

  const handleDelete = async () => {
    if (!deleteId) return
    try {
      await deleteDiagnostic(deleteId)
      setDiagnostics((prev) => prev.filter((d) => d.id !== deleteId))
      toast({ title: 'Diagnóstico excluído com sucesso.' })
    } catch (_) {
      toast({ title: 'Erro ao excluir diagnóstico.', variant: 'destructive' })
    } finally {
      setDeleteId(null)
    }
  }

  const handleReanalyze = async (id: string) => {
    try {
      toast({ title: 'Reanalisando processo com IA…' })
      await triggerAnalyzeDiagnostic(id)
      loadData()
    } catch (err: any) {
      toast({ title: 'Erro ao reanalisar', description: err.message, variant: 'destructive' })
    }
  }

  const filteredDiagnostics = diagnostics.filter((d) => {
    const matchesSearch =
      d.company_name.toLowerCase().includes(search.toLowerCase()) ||
      d.industry.toLowerCase().includes(search.toLowerCase())
    if (activeTab === 'completed') return matchesSearch && d.status === 'completed'
    if (activeTab === 'processing')
      return matchesSearch && (d.status === 'processing' || d.status === 'queued')
    if (activeTab === 'failed') return matchesSearch && d.status === 'failed'
    return matchesSearch
  })

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0,
    }).format(val)
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
            Diagnósticos
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Gerencie e explore os diagnósticos operacionais realizados.
          </p>
        </div>
        <Button
          onClick={() => navigate('/app/diagnostics/new')}
          className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md shadow-indigo-600/30 gap-2 h-11 px-5"
        >
          <Plus className="w-4 h-4" />
          <span>Novo diagnóstico</span>
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
          <TabsList className="bg-slate-200/60 p-1 rounded-xl h-11">
            <TabsTrigger value="all" className="rounded-lg text-xs font-semibold px-4">
              Todos ({diagnostics.length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="rounded-lg text-xs font-semibold px-4">
              Concluídos ({diagnostics.filter((d) => d.status === 'completed').length})
            </TabsTrigger>
            <TabsTrigger value="processing" className="rounded-lg text-xs font-semibold px-4">
              Em Análise (
              {diagnostics.filter((d) => d.status === 'processing' || d.status === 'queued').length}
              )
            </TabsTrigger>
            <TabsTrigger value="failed" className="rounded-lg text-xs font-semibold px-4">
              Falhas ({diagnostics.filter((d) => d.status === 'failed').length})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
          <Input
            placeholder="Buscar por empresa ou setor…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-11 rounded-xl bg-white border-slate-200"
          />
        </div>
      </div>

      {/* Diagnostics Cards Grid */}
      {filteredDiagnostics.length === 0 ? (
        <Card className="p-12 text-center rounded-2xl bg-white border-slate-200">
          <FileSearch className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">Nenhum diagnóstico encontrado</h3>
          <p className="text-xs text-slate-500 mt-1">
            Tente ajustar a busca ou crie uma nova análise de processo.
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDiagnostics.map((diag) => (
            <Card
              key={diag.id}
              className="p-5 rounded-2xl border-slate-200/80 bg-white hover:border-indigo-200 shadow-soft hover:shadow-soft-hover transition-all duration-200 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-lg text-slate-900 leading-snug">
                      {diag.company_name}
                    </h3>
                    <Badge variant="outline" className="mt-1 text-xs bg-slate-50 text-slate-600">
                      {diag.industry}
                    </Badge>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400 hover:text-slate-600"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="end"
                      className="w-48 bg-white border-slate-200 rounded-xl shadow-lg"
                    >
                      <DropdownMenuItem
                        onClick={() => handleReanalyze(diag.id)}
                        className="cursor-pointer gap-2"
                      >
                        <RotateCw className="w-4 h-4 text-indigo-600" />
                        <span>Refazer análise</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => setDeleteId(diag.id)}
                        className="cursor-pointer text-rose-600 hover:bg-rose-50 gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Excluir</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {diag.process_description}
                </p>

                {diag.status === 'completed' && (
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 bg-slate-50 p-3 rounded-xl">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                        Impacto
                      </span>
                      <span className="text-sm font-bold text-slate-900">
                        {formatCurrency(diag.total_financial_impact || 0)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                        ROI Estimado
                      </span>
                      <span className="text-sm font-bold text-emerald-600">
                        {diag.avg_roi || 0}%
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  {diag.status === 'completed' && (
                    <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Concluído
                    </Badge>
                  )}
                  {diag.status === 'processing' && (
                    <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 gap-1 animate-pulse">
                      <RotateCw className="w-3.5 h-3.5 animate-spin" />
                      Analisando…
                    </Badge>
                  )}
                  {diag.status === 'failed' && (
                    <Badge className="bg-rose-50 text-rose-700 border-rose-200 gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Falhou
                    </Badge>
                  )}
                </div>

                <Button
                  onClick={() => navigate(`/app/diagnostics/${diag.id}`)}
                  variant="ghost"
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 p-0 h-auto gap-1"
                >
                  Ver Resultados
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Delete Modal */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Diagnóstico?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação removerá permanentemente este diagnóstico, seus gargalos, soluções e itens
              do roadmap.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-rose-600 hover:bg-rose-500 text-white rounded-xl"
            >
              Confirmar Exclusão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
