import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import { getDiagnostics, getRoadmapItems, updateRoadmapItem } from '@/services/diagnostics'
import type { Diagnostic, RoadmapItem, RoadmapStatus } from '@/types'
import {
  Kanban,
  Plus,
  ArrowRight,
  ChevronRight,
  Circle,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  Clock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'

const STATUS_CONFIG: Record<RoadmapStatus, { label: string; color: string; icon: typeof Circle }> =
  {
    pendente: {
      label: 'Pendente',
      color: 'bg-slate-100 text-slate-700 border-slate-200',
      icon: Circle,
    },
    em_andamento: {
      label: 'Em andamento',
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      icon: Loader2,
    },
    concluído: {
      label: 'Concluído',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      icon: CheckCircle2,
    },
    bloqueado: {
      label: 'Bloqueado',
      color: 'bg-rose-50 text-rose-700 border-rose-200',
      icon: AlertTriangle,
    },
  }

const PHASE_COLORS = [
  'border-indigo-300 bg-indigo-50/50',
  'border-purple-300 bg-purple-50/50',
  'border-emerald-300 bg-emerald-50/50',
  'border-amber-300 bg-amber-50/50',
]

export default function Roadmap() {
  const { user } = useAuth()
  const navigate = useNavigate()

  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([])
  const [selectedDiagId, setSelectedDiagId] = useState<string>('')
  const [roadmapItems, setRoadmapItems] = useState<RoadmapItem[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = async (diagId?: string) => {
    try {
      const diags = await getDiagnostics()
      setDiagnostics(diags)
      const completed = diags.filter((d) => d.status === 'completed')
      const target = diagId || selectedDiagId || completed[0]?.id || diags[0]?.id
      if (target) {
        if (!selectedDiagId) setSelectedDiagId(target)
        const rm = await getRoadmapItems(target)
        setRoadmapItems(rm)
      } else {
        setRoadmapItems([])
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('roadmap_items', () => {
    if (selectedDiagId) loadData(selectedDiagId)
  })

  useRealtime('diagnostics', () => {
    loadData(selectedDiagId)
  })

  const handleSelectDiag = (id: string) => {
    setSelectedDiagId(id)
    loadData(id)
  }

  const handleToggleDone = async (id: string, currentStatus: RoadmapStatus) => {
    const newStatus: RoadmapStatus = currentStatus === 'concluído' ? 'pendente' : 'concluído'
    setRoadmapItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item)),
    )
    try {
      await updateRoadmapItem(id, { status: newStatus })
    } catch (_) {
      loadData(selectedDiagId)
    }
  }

  const handleStatusChange = async (id: string, newStatus: RoadmapStatus) => {
    setRoadmapItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item)),
    )
    try {
      await updateRoadmapItem(id, { status: newStatus })
    } catch (_) {
      loadData(selectedDiagId)
    }
  }

  const phases = roadmapItems.reduce<Record<number, RoadmapItem[]>>((acc, item) => {
    const phase = item.phase || 1
    if (!acc[phase]) acc[phase] = []
    acc[phase].push(item)
    return acc
  }, {})

  const phaseNames: Record<number, string> = {}
  roadmapItems.forEach((item) => {
    if (item.phase_name) phaseNames[item.phase || 1] = item.phase_name
  })

  const firstName = user?.name ? user.name.split(' ')[0] : 'Gestor'

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
            Roadmap Vivo
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Acompanhe e gerencie as ações de transformação do {firstName}.
          </p>
        </div>
        <Button
          onClick={() => navigate('/app/diagnostics/new')}
          className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md shadow-indigo-600/30 gap-2 h-11 px-5"
        >
          <Plus className="w-4 h-4" />
          <span>Novo diagnóstico</span>
        </Button>
      </div>

      {diagnostics.length === 0 ? (
        <Card className="p-12 text-center rounded-2xl border-dashed border-2 border-slate-200 bg-white space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
            <Kanban className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold font-display text-slate-900">
              Nenhum roadmap disponível
            </h3>
            <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
              Crie um diagnóstico para gerar automaticamente seu roadmap de transformação.
            </p>
          </div>
          <Button
            onClick={() => navigate('/app/diagnostics/new')}
            className="bg-indigo-600 text-white rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" />
            Criar Diagnóstico
          </Button>
        </Card>
      ) : (
        <>
          {diagnostics.length > 1 && (
            <div className="flex items-center gap-3">
              <label className="text-sm font-semibold text-slate-600 whitespace-nowrap">
                Diagnóstico:
              </label>
              <Select value={selectedDiagId} onValueChange={handleSelectDiag}>
                <SelectTrigger className="w-full max-w-md bg-white rounded-xl">
                  <SelectValue placeholder="Selecione um diagnóstico" />
                </SelectTrigger>
                <SelectContent>
                  {diagnostics.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.company_name} — {d.industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {roadmapItems.length === 0 ? (
            <Card className="p-12 text-center rounded-2xl border-dashed border-2 border-slate-200 bg-white space-y-3">
              <Kanban className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold font-display text-slate-700">
                Este diagnóstico ainda não gerou roadmap
              </h3>
              <p className="text-sm text-slate-500 max-w-sm mx-auto">
                Aguarde a conclusão da análise ou verifique o status do diagnóstico.
              </p>
              <Button asChild variant="outline" className="rounded-xl gap-2">
                <Link to="/app/diagnostics">
                  Ver diagnósticos
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
            </Card>
          ) : (
            <div className="space-y-6">
              {Object.entries(phases)
                .sort(([a], [b]) => Number(a) - Number(b))
                .map(([phaseStr, items]) => {
                  const phase = Number(phaseStr)
                  const phaseName = phaseNames[phase] || `Fase ${phase}`
                  const phaseColor = PHASE_COLORS[(phase - 1) % PHASE_COLORS.length]
                  return (
                    <div key={phase} className="space-y-3">
                      <div className="flex items-center gap-2">
                        <div
                          className={cn(
                            'w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold border',
                            phaseColor,
                          )}
                        >
                          {phase}
                        </div>
                        <h2 className="text-lg font-bold font-display text-slate-900">
                          {phaseName}
                        </h2>
                        <Badge
                          variant="outline"
                          className="text-xs text-slate-500 border-slate-200"
                        >
                          {items.length} {items.length === 1 ? 'ação' : 'ações'}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        {items
                          .sort((a, b) => (a.priority || 0) - (b.priority || 0))
                          .map((item) => {
                            const config = STATUS_CONFIG[item.status]
                            const StatusIcon = config.icon
                            const isDone = item.status === 'concluído'
                            return (
                              <Card
                                key={item.id}
                                className={cn(
                                  'p-5 rounded-2xl border bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200',
                                  isDone && 'opacity-70',
                                )}
                              >
                                <div className="flex items-start gap-3">
                                  <Checkbox
                                    id={`roadmap-${item.id}`}
                                    checked={isDone}
                                    onCheckedChange={() => handleToggleDone(item.id, item.status)}
                                    className="mt-0.5"
                                  />
                                  <div className="min-w-0 flex-1 space-y-2">
                                    <label
                                      htmlFor={`roadmap-${item.id}`}
                                      className={cn(
                                        'text-sm font-semibold block cursor-pointer leading-snug',
                                        isDone ? 'line-through text-slate-400' : 'text-slate-800',
                                      )}
                                    >
                                      {item.title}
                                    </label>
                                    {item.description && (
                                      <p className="text-xs text-slate-500 line-clamp-2">
                                        {item.description}
                                      </p>
                                    )}
                                    <div className="flex items-center gap-3 flex-wrap pt-1">
                                      {item.timeline_weeks != null && (
                                        <span className="text-[11px] text-slate-500 flex items-center gap-1">
                                          <Clock className="w-3 h-3" />
                                          {item.timeline_weeks} sem
                                        </span>
                                      )}
                                      <Select
                                        value={item.status}
                                        onValueChange={(v) =>
                                          handleStatusChange(item.id, v as RoadmapStatus)
                                        }
                                      >
                                        <SelectTrigger className="h-7 w-auto text-[11px] gap-1 px-2 py-0 rounded-md border-slate-200">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          {(Object.keys(STATUS_CONFIG) as RoadmapStatus[]).map(
                                            (s) => (
                                              <SelectItem key={s} value={s} className="text-xs">
                                                {STATUS_CONFIG[s].label}
                                              </SelectItem>
                                            ),
                                          )}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </div>
                                </div>
                              </Card>
                            )
                          })}
                      </div>
                    </div>
                  )
                })}
            </div>
          )}
        </>
      )}
    </div>
  )
}
