import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import {
  Check,
  Sparkles,
  Zap,
  Building2,
  ArrowRight,
  ShieldCheck,
  HelpCircle,
  ChevronDown,
  CheckCircle2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

const PLANS = [
  {
    name: 'Start',
    tagline: 'Para quem quer começar a automatizar',
    price: 'R$ 97',
    period: '/mês',
    highlight: false,
    cta: 'Começar agora',
    features: [
      '1 processo diagnosticado',
      '1 automação incluída',
      'Dashboard com gargalos e impacto financeiro',
      'Roadmap vivo com priorização',
      'Suporte por e-mail',
    ],
  },
  {
    name: 'Crescimento',
    tagline: 'Para quem quer escalar com IA',
    price: 'R$ 397',
    period: '/mês',
    highlight: true,
    cta: 'Quero automatizar',
    features: [
      'Agentes ilimitados',
      'Automação extra: R$ 97/mês',
      'Assistente North (chat IA)',
      'Diagnósticos ilimitados',
      'Suporte prioritário via WhatsApp',
    ],
  },
  {
    name: 'Empresas',
    tagline: 'Para operações complexas',
    price: 'Sob consulta',
    period: '',
    highlight: false,
    cta: 'Falar com especialista',
    features: [
      'Manutenção dedicada',
      'Suporte prioritário 24/7',
      'Integrações customizadas',
      'Onboarding personalizado',
      'Segurança reforçada (LGPD)',
    ],
  },
]

const FAQS = [
  {
    q: 'Preciso ter meus processos já mapeados?',
    a: 'Não. A Nortia mapeia por você: você descreve o fluxo (ou sobe uma planilha CSV) e a IA identifica gargalos, impactos e oportunidades automaticamente.',
  },
  {
    q: 'Como a plataforma acompanha meu processo?',
    a: 'No modo shadow, a North AI observa sua operação em segundo plano — sem atrapalhar a rotina — e sugere onde otimizar e automatizar.',
  },
  {
    q: 'A plataforma só identifica ou também executa?',
    a: 'Ela identifica E executa: além do diagnóstico, a Nortia gera o blueprint do app ou agente de IA com roadmap de implantação.',
  },
  {
    q: 'Funciona para quem não tem ERP/sistema?',
    a: 'Sim. Você pode usar o upload de planilha (CSV) ou descrever o processo diretamente. Não é necessário ter sistema integrado.',
  },
]

export default function Pricing() {
  const { isAuthenticated } = useAuth()
  const [openFaq, setOpenFaq] = useState<number | null>(0)
  const [betaEmail, setBetaEmail] = useState('')
  const [betaSubmitted, setBetaSubmitted] = useState(false)

  const handleBetaSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(betaEmail)) return
    localStorage.setItem('nortia.betaEmail', betaEmail)
    setBetaSubmitted(true)
  }

  return (
    <div className="space-y-10 animate-fade-in pb-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          Precificação simples
        </Badge>
        <h1 className="text-3xl sm:text-4xl font-extrabold font-display text-slate-900 tracking-tight">
          Invista no que destrava seu negócio
        </h1>
        <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
          Você paga por automação, não por usuário. Comece com 1 e escale.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {PLANS.map((plan) => (
          <Card
            key={plan.name}
            className={cn(
              'p-6 rounded-2xl border bg-white shadow-soft flex flex-col relative',
              plan.highlight
                ? 'border-indigo-300 ring-2 ring-indigo-500/10 shadow-xl'
                : 'border-slate-200/80',
            )}
          >
            {plan.highlight && (
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-indigo-600 text-white gap-1 border-0">
                <Zap className="w-3 h-3" />
                Mais popular
              </Badge>
            )}

            <div className="flex items-center gap-2 mb-1">
              {plan.name === 'Start' && <Building2 className="w-4 h-4 text-slate-400" />}
              {plan.name === 'Crescimento' && <Zap className="w-4 h-4 text-indigo-600" />}
              {plan.name === 'Empresas' && <ShieldCheck className="w-4 h-4 text-slate-400" />}
              <h2 className="text-lg font-bold font-display text-slate-900">{plan.name}</h2>
            </div>
            <p className="text-xs text-slate-500 mb-4">{plan.tagline}</p>

            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-3xl font-extrabold font-display text-slate-900">
                {plan.price}
              </span>
              {plan.period && <span className="text-sm text-slate-500">{plan.period}</span>}
            </div>

            <ul className="space-y-2.5 flex-1 mb-6">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-slate-600">
                  <Check className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <Button
              asChild
              className={cn(
                'w-full rounded-xl h-11 font-semibold',
                plan.highlight
                  ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50',
              )}
              variant={plan.highlight ? 'default' : 'outline'}
            >
              <Link to={isAuthenticated ? '/app/diagnostics/new' : '/'} className="gap-2">
                {plan.cta}
                <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </Card>
        ))}
      </div>

      <Card className="p-6 rounded-2xl border-emerald-200 bg-emerald-50/50 max-w-5xl mx-auto">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-emerald-900">
              Nosso piloto identificou ROI médio de 318% e payback em ~3,5 meses
            </p>
            <p className="text-xs text-emerald-700 mt-0.5">
              Diagnóstico de indústria metalmecânica: R$ 61.350/mês de impacto e 1.212 horas/mês
              perdidas em atividades manuais — resolvíveis com automação.
            </p>
          </div>
        </div>
      </Card>

      <div className="max-w-3xl mx-auto space-y-3">
        <h2 className="text-xl font-bold font-display text-slate-900 text-center">
          Perguntas frequentes
        </h2>
        {FAQS.map((faq, i) => (
          <Card
            key={i}
            className="rounded-2xl border-slate-200/80 bg-white shadow-soft overflow-hidden"
          >
            <button
              type="button"
              onClick={() => setOpenFaq(openFaq === i ? null : i)}
              className="w-full flex items-center justify-between gap-4 p-4 text-left"
            >
              <span className="text-sm font-semibold text-slate-800 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-indigo-500 shrink-0" />
                {faq.q}
              </span>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-slate-400 transition-transform shrink-0',
                  openFaq === i && 'rotate-180',
                )}
              />
            </button>
            {openFaq === i && (
              <div className="px-4 pb-4 pr-10">
                <p className="text-xs text-slate-500 leading-relaxed">{faq.a}</p>
              </div>
            )}
          </Card>
        ))}
      </div>

      <Card className="p-8 rounded-2xl border-indigo-200 bg-gradient-to-br from-indigo-50 to-white max-w-3xl mx-auto text-center space-y-4">
        {betaSubmitted ? (
          <>
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <h2 className="text-xl font-bold font-display text-slate-900">Recebido!</h2>
            <p className="text-sm text-slate-500">
              Entramos em contato com <strong>{betaEmail}</strong> em breve.
            </p>
          </>
        ) : (
          <>
            <Sparkles className="w-8 h-8 text-indigo-500 mx-auto" />
            <h2 className="text-xl font-bold font-display text-slate-900">Quero ser beta</h2>
            <p className="text-sm text-slate-500">
              Seja um dos primeiros a experimentar a Nortia em modo shadow.
            </p>
            <form
              onSubmit={handleBetaSubmit}
              className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto"
            >
              <Input
                type="email"
                placeholder="seu@email.com"
                value={betaEmail}
                onChange={(e) => setBetaEmail(e.target.value)}
                className="h-11 rounded-xl"
                required
              />
              <Button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl h-11 px-6 gap-2"
              >
                Quero ser beta
                <ArrowRight className="w-4 h-4" />
              </Button>
            </form>
          </>
        )}
      </Card>
    </div>
  )
}
