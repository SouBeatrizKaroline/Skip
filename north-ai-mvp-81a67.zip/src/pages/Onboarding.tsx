import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Compass, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ProcessMapperChat } from '@/components/ProcessMapperChat'
import { SEGMENTOS, setSegmento, type Segmento } from '@/lib/demo-mocks'
import { cn } from '@/lib/utils'

export default function Onboarding() {
  const [selected, setSelected] = useState<Segmento | null>(null)
  const navigate = useNavigate()

  const handleSelect = (s: Segmento) => {
    setSelected(s)
    setSegmento(s)
  }

  return (
    <div className="min-h-screen bg-[#F6F7FB] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-6">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center mx-auto shadow-lg shadow-indigo-600/30">
            <Compass className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold font-display text-slate-900">Qual o seu segmento?</h1>
          <p className="text-sm text-slate-500">
            Isso ajuda a Nortia a personalizar a análise dos seus gargalos.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {SEGMENTOS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => handleSelect(s)}
              className={cn(
                'flex items-center justify-center gap-2 text-sm font-medium rounded-xl px-4 py-3 border-2 transition-all',
                selected === s
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300',
              )}
            >
              {selected === s && <Check className="w-4 h-4" />}
              {s}
            </button>
          ))}
        </div>

        {selected && (
          <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft text-center space-y-4 animate-fade-in">
            <p className="text-sm text-slate-600">
              Sem processos mapeados? Sem problema — a Nortia mapeia por você.
            </p>
            <ProcessMapperChat onSaved={() => navigate('/')} />
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="text-xs text-slate-500 hover:text-slate-900"
            >
              Pular por agora
            </Button>
          </Card>
        )}
      </div>
    </div>
  )
}
