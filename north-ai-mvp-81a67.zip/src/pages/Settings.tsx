import { useState } from 'react'
import { useAuth } from '@/hooks/use-auth'
import { useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import pb from '@/lib/pocketbase/client'
import { User, Mail, Shield, Bell, LogOut, Save } from 'lucide-react'

export default function Settings() {
  const { user, signOut } = useAuth()
  const navigate = useNavigate()
  const [name, setName] = useState(user?.name || '')
  const [saving, setSaving] = useState(false)

  const userInitial = user?.name
    ? user.name.charAt(0).toUpperCase()
    : user?.email
      ? user.email.charAt(0).toUpperCase()
      : 'U'

  const handleSaveProfile = async () => {
    setSaving(true)
    try {
      await pb.collection('users').update(user.id, { name })
      toast.success('Perfil atualizado com sucesso!')
    } catch (err) {
      toast.error('Erro ao atualizar perfil. Tente novamente.')
    } finally {
      setSaving(false)
    }
  }

  const handleSignOut = () => {
    signOut()
    navigate('/')
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
          Configurações
        </h1>
        <p className="text-sm text-slate-500 mt-1">Gerencie sua conta e preferências da Nortia.</p>
      </div>

      {/* Profile Section */}
      <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft space-y-5">
        <div className="flex items-center gap-2">
          <User className="w-5 h-5 text-indigo-600" />
          <h2 className="text-lg font-bold font-display text-slate-900">Perfil</h2>
        </div>
        <Separator className="bg-slate-100" />

        <div className="flex items-center gap-4">
          <Avatar className="w-16 h-16 border-2 border-indigo-500/30 bg-indigo-950">
            <AvatarFallback className="bg-indigo-600 text-white font-bold text-xl">
              {userInitial}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-semibold text-slate-900">{user?.name || 'Usuário'}</p>
            <p className="text-xs text-slate-500">{user?.email}</p>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="name" className="text-sm font-medium text-slate-700">
            Nome
          </Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Seu nome"
            className="rounded-xl border-slate-200 focus:border-indigo-400 focus:ring-indigo-400"
          />
        </div>

        <div className="space-y-2">
          <Label
            htmlFor="email"
            className="text-sm font-medium text-slate-700 flex items-center gap-2"
          >
            <Mail className="w-4 h-4 text-slate-400" />
            E-mail
          </Label>
          <Input
            id="email"
            value={user?.email || ''}
            disabled
            className="rounded-xl bg-slate-50 text-slate-500"
          />
          <p className="text-xs text-slate-400">O e-mail não pode ser alterado nesta versão.</p>
        </div>

        <Button
          onClick={handleSaveProfile}
          disabled={saving}
          className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl gap-2 h-10 px-5"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Salvando…' : 'Salvar alterações'}
        </Button>
      </Card>

      {/* Notifications Section */}
      <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft space-y-5">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-indigo-600" />
          <h2 className="text-lg font-bold font-display text-slate-900">Notificações</h2>
        </div>
        <Separator className="bg-slate-100" />
        <div className="space-y-3">
          {[
            {
              label: 'Diagnósticos concluídos',
              desc: 'Receba aviso quando um diagnóstico for finalizado.',
            },
            {
              label: 'Atualizações de roadmap',
              desc: 'Seja notificado sobre mudanças no roadmap.',
            },
            { label: 'Resumo semanal', desc: 'Relatório resumido toda segunda-feira.' },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100"
            >
              <div>
                <p className="text-sm font-semibold text-slate-800">{item.label}</p>
                <p className="text-xs text-slate-500">{item.desc}</p>
              </div>
              <span className="text-xs text-slate-400 bg-slate-200 px-2 py-1 rounded-full">
                Em breve
              </span>
            </div>
          ))}
        </div>
      </Card>

      {/* Security Section */}
      <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft space-y-5">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-indigo-600" />
          <h2 className="text-lg font-bold font-display text-slate-900">Segurança</h2>
        </div>
        <Separator className="bg-slate-100" />
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
          <div>
            <p className="text-sm font-semibold text-slate-800">Redefinir senha</p>
            <p className="text-xs text-slate-500">
              Enviamos um link de redefinição para seu e-mail.
            </p>
          </div>
          <Button
            variant="outline"
            className="rounded-xl border-slate-200 text-slate-700 hover:bg-slate-100 text-xs"
            onClick={async () => {
              try {
                await pb.collection('users').requestPasswordReset(user.email)
                toast.success('Link de redefinição enviado para seu e-mail!')
              } catch {
                toast.error('Erro ao enviar link. Tente novamente.')
              }
            }}
          >
            Enviar link
          </Button>
        </div>
      </Card>

      {/* Danger Zone */}
      <Card className="p-6 rounded-2xl border-rose-200/80 bg-white shadow-soft space-y-4">
        <div className="flex items-center gap-2">
          <LogOut className="w-5 h-5 text-rose-500" />
          <h2 className="text-lg font-bold font-display text-slate-900">Sair da conta</h2>
        </div>
        <Separator className="bg-slate-100" />
        <p className="text-sm text-slate-500">
          Você será desconectado e precisará fazer login novamente para acessar o North AI.
        </p>
        <Button
          onClick={handleSignOut}
          variant="outline"
          className="rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700 gap-2"
        >
          <LogOut className="w-4 h-4" />
          Sair
        </Button>
      </Card>
    </div>
  )
}
