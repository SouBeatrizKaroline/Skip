import { useState, useRef, useEffect } from 'react'
import { Send, Bot, Sparkles, User, Filter, X, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useAuth } from '@/hooks/use-auth'
import { sendAssistantChat, getDiagnostics } from '@/services/diagnostics'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import type { Diagnostic } from '@/types'
import {
  getCsvContext,
  clearCsvContext,
  buildContextMessage,
  type CsvAnalysisContext,
} from '@/lib/csv-context'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
}

export default function Assistant() {
  const { user } = useAuth()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([])
  const [activeDiagnosticId, setActiveDiagnosticId] = useState<string>('')
  const [csvContext, setCsvContext] = useState<CsvAnalysisContext | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const csvAutoSentRef = useRef(false)

  const firstName = user?.name ? user.name.split(' ')[0] : 'Gestor'

  // Carrega os diagnósticos do usuário para o filtro
  useEffect(() => {
    const load = async () => {
      try {
        const items = await getDiagnostics()
        setDiagnostics(items)
        if (items.length > 0) {
          setActiveDiagnosticId(items[0].id)
        }
      } catch (err) {
        console.error(err)
      }
    }
    load()
  }, [])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  useEffect(() => {
    if (csvAutoSentRef.current) return
    csvAutoSentRef.current = true

    const ctx = getCsvContext()
    if (!ctx) return

    setCsvContext(ctx)
    clearCsvContext()

    const msg = buildContextMessage(ctx)
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: msg,
    }
    setMessages([userMsg])
    setLoading(true)

    sendAssistantChat(msg, null, ctx.fileName, ctx.diagnosticId || null)
      .then((result) => {
        if (result.conversation_id) setConversationId(result.conversation_id)
        const assistantMsg: ChatMessage = {
          id: result.message_id || crypto.randomUUID(),
          role: 'assistant',
          content: result.content || 'Não foi possível gerar uma resposta no momento.',
        }
        setMessages((prev) => [...prev, assistantMsg])
      })
      .catch((err) => {
        toast({
          title: 'Erro',
          description: getErrorMessage(err),
          variant: 'destructive',
        })
      })
      .finally(() => setLoading(false))
  }, [])

  const handleSend = async () => {
    const trimmed = input.trim()
    if (!trimmed || loading) return

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: trimmed,
    }
    setMessages((prev) => [...prev, userMsg])
    setInput('')
    setLoading(true)

    const activeDiag = diagnostics.find((d) => d.id === activeDiagnosticId)

    try {
      const result = await sendAssistantChat(
        trimmed,
        conversationId,
        activeDiag?.company_name || 'Conversa de Diagnóstico',
        activeDiagnosticId || null,
      )

      if (result.conversation_id) {
        setConversationId(result.conversation_id)
      }

      const assistantMsg: ChatMessage = {
        id: result.message_id || crypto.randomUUID(),
        role: 'assistant',
        content: result.content || 'Não foi possível gerar uma resposta no momento.',
      }
      setMessages((prev) => [...prev, assistantMsg])
    } catch (err) {
      toast({
        title: 'Erro',
        description: getErrorMessage(err),
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  // Renderiza a resposta como texto real (remove markdown bruto residual)
  const renderContent = (content: string) => {
    return content
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/`(.+?)`/g, '$1')
      .replace(/^#{1,6}\s*/gm, '')
      .replace(/^\s*[-*]\s+/gm, '• ')
      .replace(/^\s*\|.*\|.*$/gm, '')
      .replace(/^>\s?/gm, '')
      .replace(/^---$/gm, '')
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
            Assistente North
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Converse com o assistente para analisar processos e obter recomendações.
          </p>
        </div>
      </div>

      {csvContext && (
        <Card className="p-3 rounded-2xl border-indigo-200/80 bg-indigo-50/50 shadow-soft animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center flex-shrink-0">
              <FileText className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-indigo-900 truncate">
                CSV em contexto: {csvContext.fileName}
              </p>
              <p className="text-[11px] text-indigo-600">
                O assistente está usando os dados deste arquivo como referência.
              </p>
            </div>
            <button
              onClick={() => setCsvContext(null)}
              className="text-indigo-400 hover:text-indigo-600 transition-colors p-1"
              aria-label="Remover contexto CSV"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </Card>
      )}

      {/* Filtro de diagnóstico ativo */}
      <Card className="p-4 rounded-2xl border-slate-200/80 bg-white shadow-soft">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex items-center gap-2 shrink-0">
            <Filter className="w-4 h-4 text-indigo-600" />
            <Label className="text-xs font-semibold uppercase text-slate-600">
              Diagnóstico ativo
            </Label>
          </div>
          <Select value={activeDiagnosticId} onValueChange={setActiveDiagnosticId}>
            <SelectTrigger className="w-full sm:max-w-md bg-white rounded-xl h-10">
              <SelectValue placeholder="Selecione um diagnóstico" />
            </SelectTrigger>
            <SelectContent className="rounded-xl">
              {diagnostics.length === 0 && (
                <div className="px-3 py-2 text-xs text-slate-500">
                  Nenhum diagnóstico disponível.
                </div>
              )}
              {diagnostics.map((d) => (
                <SelectItem key={d.id} value={d.id} className="text-xs">
                  {d.company_name} — {d.industry} ({d.status})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[11px] text-slate-400 sm:ml-auto">
            O assistente responde com base apenas neste diagnóstico.
          </p>
        </div>
      </Card>

      <Card className="flex flex-col h-[calc(100vh-340px)] min-h-[400px] rounded-2xl border-slate-200/80 bg-white shadow-soft overflow-hidden">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center shadow-md shadow-indigo-600/20">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900">North Assistant</p>
            <p className="text-[11px] text-slate-500">
              {activeDiagnosticId
                ? `Focado em: ${diagnostics.find((d) => d.id === activeDiagnosticId)?.company_name || 'diagnóstico selecionado'}`
                : 'Selecione um diagnóstico para começar'}
            </p>
          </div>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-12">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-display text-slate-900">Olá, {firstName}!</h3>
                <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
                  Selecione o diagnóstico no filtro acima e pergunte sobre gargalos, ROI, soluções
                  ou roadmap. O assistente responde com base apenas nos dados desse diagnóstico.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 justify-center max-w-md">
                {[
                  'Quais são os principais gargalos?',
                  'Qual o impacto financeiro total?',
                  'O que devo priorizar no roadmap?',
                ].map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setInput(suggestion)}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-indigo-50 text-xs font-medium text-slate-600 hover:text-indigo-700 transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn('flex gap-3', msg.role === 'user' ? 'justify-end' : 'justify-start')}
            >
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              <div
                className={cn(
                  'max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap',
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-sm'
                    : 'bg-slate-100 text-slate-800 rounded-tl-sm',
                )}
              >
                {msg.role === 'assistant' ? renderContent(msg.content) : msg.content}
              </div>
              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-200 flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-slate-600" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-slate-100 rounded-2xl rounded-tl-sm px-4 py-3">
                <div className="flex items-center gap-1.5">
                  <span
                    className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                    style={{ animationDelay: '0ms' }}
                  />
                  <span
                    className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                    style={{ animationDelay: '150ms' }}
                  />
                  <span
                    className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                    style={{ animationDelay: '300ms' }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-slate-100 p-4 bg-white">
          <div className="flex gap-3 items-end">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Digite sua pergunta..."
              className="resize-none rounded-xl border-slate-200 focus:border-indigo-600 focus:ring-indigo-600/20 min-h-[44px] max-h-[120px] text-sm"
              rows={1}
              disabled={loading}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md shadow-indigo-600/30 h-11 w-11 p-0 flex-shrink-0"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
