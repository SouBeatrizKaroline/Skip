import { Database, Users, MessageCircle, FileText, Lock } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { getDataSources } from '@/lib/demo-mocks'

const iconMap: Record<string, typeof FileText> = {
  FileText,
  Users,
  MessageCircle,
  Database,
  Lock,
}

export default function Fontes() {
  const sources = getDataSources()

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
          Fontes
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Conecte suas fontes de dados para a Nortia mapear seus processos.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {sources.map((src) => {
          const Icon = iconMap[src.iconName] || FileText
          return (
            <Card
              key={src.name}
              className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft hover:shadow-soft-hover transition-all duration-200"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-slate-900">{src.name}</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">{src.description}</p>
              {src.note && (
                <p className="text-[11px] text-indigo-600 font-medium mt-2 leading-relaxed">
                  {src.note}
                </p>
              )}
            </Card>
          )
        })}
      </div>

      <Card className="p-5 rounded-2xl border-emerald-200 bg-emerald-50/50 max-w-3xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <p className="text-sm text-emerald-800 font-medium">
            Acesso mínimo: só o necessário para mapear o processo. Dados criptografados.
          </p>
        </div>
      </Card>
    </div>
  )
}
