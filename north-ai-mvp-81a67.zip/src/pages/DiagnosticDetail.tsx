import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useRealtime } from '@/hooks/use-realtime'
import {
  getDiagnostic,
  getBottlenecks,
  getSolutions,
  getRoadmapItems,
  updateSolutionStatus,
  triggerAnalyzeDiagnostic,
} from '@/services/diagnostics'
import type { Diagnostic, Bottleneck, Solution, RoadmapItem } from '@/types'
import {
  ArrowLeft,
  RotateCw,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  TrendingUp,
  Zap,
  Lightbulb,
  MapPin,
  Loader2,
  Bot,
  AppWindow,
  FileText,
  Download,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { AutomationCreated } from '@/components/AutomationCreated'

const formatCurrency = (val: number) =>
  new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 0,
  }).format(val)

const categoryColors: Record<string, string> = {
  Processo: 'bg-blue-50 text-blue-700 border-blue-200',
  Tecnologia: 'bg-purple-50 text-purple-700 border-purple-200',
  Pessoas: 'bg-amber-50 text-amber-700 border-amber-200',
  Dados: 'bg-cyan-50 text-cyan-700 border-cyan-200',
  Comunicação: 'bg-pink-50 text-pink-700 border-pink-200',
  Compliance: 'bg-rose-50 text-rose-700 border-rose-200',
}

const effortLabels: Record<string, string> = {
  baixo: 'Baixo',
  médio: 'Médio',
  alto: 'Alto',
}

const solutionStatusLabels: Record<string, string> = {
  proposto: 'Proposto',
  em_andamento: 'Em andamento',
  concluído: 'Concluído',
}

export default function DiagnosticDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [diagnostic, setDiagnostic] = useState<Diagnostic | null>(null)
  const [bottlenecks, setBottlenecks] = useState<Bottleneck[]>([])
  const [solutions, setSolutions] = useState<Solution[]>([])
  const [roadmapItems, setRoadmapItems] = useState<RoadmapItem[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = async () => {
    if (!id) return
    try {
      const diag = await getDiagnostic(id)
      setDiagnostic(diag)
      const [bts, sols, rms] = await Promise.all([
        getBottlenecks(id),
        getSolutions(id),
        getRoadmapItems(id),
      ])
      setBottlenecks(bts)
      setSolutions(sols)
      setRoadmapItems(rms)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [id])

  useRealtime('diagnostics', () => loadData())
  useRealtime('bottlenecks', () => loadData())
  useRealtime('solutions', () => loadData())
  useRealtime('roadmap_items', () => loadData())

  const handleReanalyze = async () => {
    if (!id) return
    try {
      toast({ title: 'Reanalisando processo com IA…' })
      await triggerAnalyzeDiagnostic(id)
      loadData()
    } catch (err: any) {
      toast({ title: 'Erro ao reanalisar', description: err.message, variant: 'destructive' })
    }
  }

  const handleSolutionStatusChange = async (solId: string, status: string) => {
    setSolutions((prev) =>
      prev.map((s) => (s.id === solId ? { ...s, status: status as Solution['status'] } : s)),
    )
    try {
      await updateSolutionStatus(solId, status as Solution['status'])
    } catch (_) {
      loadData()
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    )
  }

  if (!diagnostic) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4">
        <AlertTriangle className="w-12 h-12 text-slate-300" />
        <p className="text-sm text-slate-500">Diagnóstico não encontrado.</p>
        <Button
          onClick={() => navigate('/app/diagnostics')}
          variant="outline"
          className="rounded-xl gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar para lista
        </Button>
      </div>
    )
  }

  const isProcessing = diagnostic.status === 'processing' || diagnostic.status === 'queued'

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div>
        <Button
          variant="ghost"
          onClick={() => navigate('/app/diagnostics')}
          className="text-xs text-slate-500 hover:text-slate-900 gap-1 p-0 h-auto mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Voltar para diagnósticos
        </Button>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 tracking-tight">
                {diagnostic.company_name}
              </h1>
              {diagnostic.status === 'completed' && (
                <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Concluído
                </Badge>
              )}
              {isProcessing && (
                <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 gap-1 animate-pulse">
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  Analisando…
                </Badge>
              )}
              {diagnostic.status === 'failed' && (
                <Badge className="bg-rose-50 text-rose-700 border-rose-200 gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Falhou
                </Badge>
              )}
            </div>
            <p className="text-sm text-slate-500 mt-1">
              {diagnostic.industry} · {diagnostic.company_size || '—'} colaboradores
            </p>
          </div>
          <Button onClick={handleReanalyze} variant="outline" className="rounded-xl gap-2 h-10">
            <RotateCw className="w-4 h-4 text-indigo-600" />
            <span>Refazer análise</span>
          </Button>
        </div>
      </div>

      {isProcessing && (
        <Card className="p-6 rounded-2xl border-indigo-200 bg-indigo-50/50 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center">
            <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />
          </div>
          <div>
            <p className="text-sm font-semibold text-indigo-900">Análise em andamento</p>
            <p className="text-xs text-indigo-600">
              A IA está processando o diagnóstico. Os resultados aparecerão automaticamente.
            </p>
          </div>
        </Card>
      )}

      {diagnostic.status === 'failed' && diagnostic.error && (
        <Card className="p-6 rounded-2xl border-rose-200 bg-rose-50/50 flex items-center gap-4">
          <AlertTriangle className="w-5 h-5 text-rose-600" />
          <div>
            <p className="text-sm font-semibold text-rose-900">Falha na análise</p>
            <p className="text-xs text-rose-600">{diagnostic.error}</p>
          </div>
        </Card>
      )}

      {diagnostic.status === 'completed' && (
        <>
          {diagnostic.summary && (
            <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft">
              <h2 className="text-sm font-bold uppercase text-slate-500 tracking-wider mb-2">
                Resumo Executivo
              </h2>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">
                {diagnostic.summary}
              </p>
            </Card>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">
                  Impacto Financeiro
                </span>
                <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <span className="text-2xl font-extrabold font-display text-slate-900 mt-2 block">
                {formatCurrency(diagnostic.total_financial_impact || 0)}
              </span>
              <span className="text-xs text-slate-400">/mês</span>
            </Card>
            <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">
                  Horas Perdidas
                </span>
                <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
              <span className="text-2xl font-extrabold font-display text-slate-900 mt-2 block">
                {diagnostic.total_labor_hours || 0}h
              </span>
              <span className="text-xs text-slate-400">/mês</span>
            </Card>
            <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">
                  Custo Trabalhista
                </span>
                <div className="w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <span className="text-2xl font-extrabold font-display text-slate-900 mt-2 block">
                {formatCurrency(diagnostic.total_labor_cost || 0)}
              </span>
              <span className="text-xs text-slate-400">/mês</span>
            </Card>
            <Card className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase">ROI Médio</span>
                <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <span className="text-2xl font-extrabold font-display text-slate-900 mt-2 block">
                {diagnostic.avg_roi || 0}%
              </span>
            </Card>
          </div>
        </>
      )}

      <Card className="p-6 rounded-2xl border-slate-200/80 bg-white shadow-soft">
        <h2 className="text-sm font-bold uppercase text-slate-500 tracking-wider mb-2">
          Descrição do Processo
        </h2>
        <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">
          {diagnostic.process_description}
        </p>
      </Card>

      {diagnostic.csv_filename && diagnostic.csv_data && (
        <Card className="p-6 rounded-2xl border-indigo-200/80 bg-white shadow-soft">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold uppercase text-slate-500 tracking-wider">
                  Planilha de Dados (CSV)
                </h2>
                <p className="text-xs text-slate-500">{diagnostic.csv_filename}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl gap-1.5 text-xs text-indigo-600 border-indigo-200"
              onClick={() => {
                const blob = new Blob([diagnostic.csv_data || ''], { type: 'text/csv' })
                const url = URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.href = url
                a.download = diagnostic.csv_filename || 'dados.csv'
                a.click()
                URL.revokeObjectURL(url)
              }}
            >
              <Download className="w-3.5 h-3.5" />
              Baixar CSV
            </Button>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white max-h-64 overflow-y-auto">
            <table className="w-full text-[11px]">
              <thead className="sticky top-0 bg-slate-50">
                <tr>
                  {diagnostic.csv_data
                    .trim()
                    .split('\n')[0]
                    .split(',')
                    .map((h, i) => (
                      <th
                        key={i}
                        className="px-2.5 py-2 text-left font-semibold uppercase text-slate-500 whitespace-nowrap"
                      >
                        {h.trim()}
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                {diagnostic.csv_data
                  .trim()
                  .split('\n')
                  .slice(1)
                  .slice(0, 8)
                  .map((row, ri) => (
                    <tr key={ri} className="border-t border-slate-100">
                      {row.split(',').map((cell, ci) => (
                        <td key={ci} className="px-2.5 py-1.5 text-slate-600 whitespace-nowrap">
                          {cell.trim()}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {diagnostic.csv_data.trim().split('\n').length - 1} linha(s) de dados · exibindo as 8
            primeiras
          </p>
        </Card>
      )}

      {bottlenecks.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold font-display text-slate-900">
              Gargalos Identificados
            </h2>
            <Badge variant="outline" className="text-xs text-slate-500">
              {bottlenecks.length}
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bottlenecks.map((bt) => (
              <Card
                key={bt.id}
                className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="font-bold text-base text-slate-900">{bt.title}</h3>
                  {bt.category && (
                    <Badge variant="outline" className={cn('text-xs', categoryColors[bt.category])}>
                      {bt.category}
                    </Badge>
                  )}
                </div>
                {bt.description && (
                  <p className="text-xs text-slate-500 leading-relaxed mb-3">{bt.description}</p>
                )}
                <div className="flex items-center gap-4 flex-wrap text-xs">
                  {bt.financial_impact != null && (
                    <span className="text-slate-600">
                      Impacto:{' '}
                      <strong className="text-slate-900">
                        {formatCurrency(bt.financial_impact)}
                      </strong>
                    </span>
                  )}
                  {bt.labor_hours_lost != null && (
                    <span className="text-slate-600">
                      Horas: <strong className="text-slate-900">{bt.labor_hours_lost}h</strong>
                    </span>
                  )}
                  {bt.roi_estimate != null && (
                    <span className="text-emerald-600 font-semibold">ROI: {bt.roi_estimate}%</span>
                  )}
                  {bt.payback_months != null && (
                    <span className="text-slate-600">Payback: {bt.payback_months}m</span>
                  )}
                </div>
                {bt.recommendation && (
                  <div className="mt-3 p-3 rounded-xl bg-amber-50 border border-amber-100">
                    <p className="text-xs text-amber-800 leading-relaxed">
                      <Lightbulb className="w-3.5 h-3.5 inline mr-1" />
                      {bt.recommendation}
                    </p>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>
      )}

      {solutions.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-indigo-500" />
            <h2 className="text-lg font-bold font-display text-slate-900">Soluções Propostas</h2>
            <Badge variant="outline" className="text-xs text-slate-500">
              {solutions.length}
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {solutions.map((sol) => (
              <Card
                key={sol.id}
                className="p-5 rounded-2xl border-slate-200/80 bg-white shadow-soft"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {sol.type === 'agente' ? (
                      <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                        <Bot className="w-4 h-4" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                        <AppWindow className="w-4 h-4" />
                      </div>
                    )}
                    <h3 className="font-bold text-base text-slate-900">{sol.name}</h3>
                  </div>
                  <Badge variant="outline" className="text-xs capitalize">
                    {sol.type}
                  </Badge>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">{sol.description}</p>
                {sol.expected_impact && (
                  <p className="text-xs text-emerald-700 font-medium mb-2">
                    Impacto: {sol.expected_impact}
                  </p>
                )}
                <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-3 text-xs text-slate-600">
                    {sol.roi_estimate != null && (
                      <span className="text-emerald-600 font-semibold">
                        ROI: {sol.roi_estimate}%
                      </span>
                    )}
                    {sol.implementation_effort && (
                      <span>Esforço: {effortLabels[sol.implementation_effort]}</span>
                    )}
                  </div>
                  <Select
                    value={sol.status || 'proposto'}
                    onValueChange={(v) => handleSolutionStatusChange(sol.id, v)}
                  >
                    <SelectTrigger className="h-7 w-auto text-[11px] gap-1 px-2 py-0 rounded-md border-slate-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="proposto" className="text-xs">
                        Proposto
                      </SelectItem>
                      <SelectItem value="em_andamento" className="text-xs">
                        Em andamento
                      </SelectItem>
                      <SelectItem value="concluído" className="text-xs">
                        Concluído
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {diagnostic.status === 'completed' && <AutomationCreated diagnosticId={diagnostic.id} />}

      {roadmapItems.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-500" />
            <h2 className="text-lg font-bold font-display text-slate-900">Roadmap</h2>
            <Badge variant="outline" className="text-xs text-slate-500">
              {roadmapItems.length}
            </Badge>
          </div>
          <div className="space-y-3">
            {roadmapItems.map((item) => (
              <Card
                key={item.id}
                className="p-4 rounded-2xl border-slate-200/80 bg-white shadow-soft flex items-center gap-4"
              >
                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                  {item.phase}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900">{item.title}</p>
                  {item.description && (
                    <p className="text-xs text-slate-500 line-clamp-1">{item.description}</p>
                  )}
                </div>
                {item.timeline_weeks != null && (
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {item.timeline_weeks} sem
                  </span>
                )}
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
