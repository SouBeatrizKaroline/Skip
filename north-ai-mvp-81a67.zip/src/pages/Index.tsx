import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import { Compass, Eye, EyeOff, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from '@/hooks/use-toast'

export default function Index() {
  const { signIn, signInDemo, isAuthenticated } = useAuth()
  const navigate = useNavigate()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [demoLoading, setDemoLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/app/dashboard')
    }
  }, [isAuthenticated, navigate])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) {
      setErrorMsg('Preencha e-mail e senha para continuar.')
      return
    }
    setErrorMsg('')
    setLoading(true)

    const { error } = await signIn(email, password)
    setLoading(false)

    if (error) {
      setErrorMsg(getErrorMessage(error))
    } else {
      toast({
        title: 'Bem-vindo ao Nortia!',
        description: 'Login realizado com sucesso.',
      })
      navigate('/app/dashboard')
    }
  }

  const handleDemo = async () => {
    setDemoLoading(true)
    const { error } = await signInDemo()
    setDemoLoading(false)

    if (error) {
      toast({
        title: 'Aviso da Demo',
        description: 'Não foi possível entrar no modo demo. ' + getErrorMessage(error),
        variant: 'destructive',
      })
    } else {
      toast({
        title: 'Modo Demo Ativado',
        description: 'Carregando ambiente com dados de demonstração completos.',
      })
      navigate('/app/dashboard')
    }
  }

  return (
    <div className="min-h-screen w-full flex bg-[#0B1220]">
      {/* Left Brand Panel (Desktop) */}
      <div className="hidden lg:flex lg:w-1/2 bg-navy-gradient relative overflow-hidden flex-col justify-between p-12 text-white border-r border-slate-800">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -right-32 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />

        {/* Top Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 flex items-center justify-center backdrop-blur-md shadow-lg shadow-indigo-500/20">
            <Compass className="w-7 h-7 text-indigo-300 animate-pulse" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight text-white">Nortia</span>
        </div>

        {/* Center Content & Signal Graphic */}
        <div className="relative z-10 max-w-md my-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Process Intelligence Platform</span>
          </div>

          <h1 className="text-4xl font-extrabold tracking-tight leading-tight font-display text-white">
            A plataforma mapeia por você. Você decide o que automatizar.
          </h1>

          <p className="text-slate-300 text-base leading-relaxed">
            Identifique gargalos operacionais, calcule impactos financeiros e horas perdidas e gere
            aplicativos e agentes de IA com um roadmap estratégico completo — sem precisar de
            processos já mapeados ou integração complexa.
          </p>

          {/* Social Proof */}
          <div className="flex items-center gap-3 pt-2">
            <div className="flex -space-x-2">
              {['bg-indigo-500', 'bg-purple-500', 'bg-emerald-500', 'bg-amber-500'].map((c) => (
                <div
                  key={c}
                  className={`w-8 h-8 rounded-full ${c} border-2 border-[#0B1220] flex items-center justify-center text-[10px] font-bold text-white`}
                >
                  {
                    ['F', 'T', 'L', 'V'][
                      ['bg-indigo-500', 'bg-purple-500', 'bg-emerald-500', 'bg-amber-500'].indexOf(
                        c,
                      )
                    ]
                  }
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-400">
              Validado com <strong className="text-white">14 empresários</strong> no Adapta Summit ·{' '}
              <strong className="text-emerald-400">12/14</strong> resolveriam a dor
            </p>
          </div>

          {/* Animated Signal Rings */}
          <div className="pt-2 flex items-center gap-4">
            <div className="relative flex items-center justify-center w-12 h-12">
              <span className="absolute w-12 h-12 bg-indigo-500/30 rounded-full animate-ping opacity-75" />
              <span className="relative w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
                <Compass className="w-5 h-5 text-white" />
              </span>
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Análise inteligente em segundos</p>
              <p className="text-xs text-slate-400">
                Estimativas de ROI e roadmap dinâmico de execução
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="relative z-10 flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Plataforma segura para diagnóstico empresarial.</span>
        </div>
      </div>

      {/* Right Login Form Panel */}
      <div className="w-full lg:w-1/2 bg-white flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md space-y-8">
          {/* Mobile Logo */}
          <div className="lg:hidden flex flex-col items-center text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
              <Compass className="w-7 h-7 text-white" />
            </div>
            <span className="font-display font-bold text-2xl text-slate-900">Nortia</span>
          </div>

          <div className="space-y-2 text-center lg:text-left">
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
              Bem-vindo de volta
            </h2>
            <p className="text-sm text-slate-500">
              Acesse sua conta para continuar seus diagnósticos.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium animate-slide-down">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label
                htmlFor="email"
                className="text-xs font-semibold text-slate-700 uppercase tracking-wider"
              >
                E-mail
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu.email@empresa.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 rounded-xl border-slate-200 focus:border-indigo-600 focus:ring-indigo-600/20"
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label
                  htmlFor="password"
                  className="text-xs font-semibold text-slate-700 uppercase tracking-wider"
                >
                  Senha
                </Label>
                <Link
                  to="/forgot-password"
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-500"
                >
                  Esqueci minha senha
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 rounded-xl border-slate-200 focus:border-indigo-600 focus:ring-indigo-600/20 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading || demoLoading}
              className="w-full h-11 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold shadow-md shadow-indigo-600/30 gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Entrar</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </Button>
          </form>

          <div className="relative flex items-center justify-center my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <span className="relative px-3 bg-white text-xs font-medium text-slate-400 uppercase">
              ou
            </span>
          </div>

          {/* Demo Button */}
          <Button
            type="button"
            variant="outline"
            onClick={handleDemo}
            disabled={loading || demoLoading}
            className="w-full h-11 border-indigo-200 text-indigo-700 hover:bg-indigo-50/80 hover:border-indigo-300 rounded-xl font-semibold gap-2"
          >
            {demoLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                <span>Preparando ambiente demo…</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>Experimentar Demo Instantânea</span>
              </>
            )}
          </Button>

          <p className="text-center text-xs text-slate-500 pt-4">
            Não tem uma conta?{' '}
            <Link to="/signup" className="font-semibold text-indigo-600 hover:text-indigo-500">
              Criar conta gratuitamente
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
