import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/use-auth'
import { Compass, Eye, EyeOff, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from '@/hooks/use-toast'
import { ProcessMapperChat } from '@/components/ProcessMapperChat'
import { SEGMENTOS, setSegmento, type Segmento } from '@/lib/demo-mocks'
import { cn } from '@/lib/utils'

export default function Signup() {
  const { signUp } = useAuth()
  const navigate = useNavigate()

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [segment, setSegment] = useState<Segmento | null>(null)

  const getPasswordStrength = () => {
    if (!password) return 0
    let score = 0
    if (password.length >= 8) score += 1
    if (/[A-Z]/.test(password)) score += 1
    if (/[0-9]/.test(password)) score += 1
    if (/[^A-Za-z0-9]/.test(password)) score += 1
    return score
  }

  const strength = getPasswordStrength()

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password || password.length < 8) {
      setErrorMsg('Preencha os campos. A senha precisa ter pelo menos 8 caracteres.')
      return
    }
    setErrorMsg('')
    setLoading(true)

    const { error } = await signUp(email, password, name)
    setLoading(false)

    if (error) {
      setErrorMsg(getErrorMessage(error))
    } else {
      if (segment) setSegmento(segment)
      toast({
        title: 'Conta criada com sucesso!',
        description: 'Enviamos um e-mail de verificação para você.',
      })
      navigate('/app/dashboard')
    }
  }

  return (
    <div className="min-h-screen bg-[#F6F7FB] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-soft p-8 space-y-6 border border-slate-100">
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
            <Compass className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold font-display text-slate-900">Criar conta no Nortia</h1>
          <p className="text-sm text-slate-500">
            Comece a analisar seus processos de negócios hoje.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSignup} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="name" className="text-xs font-semibold text-slate-700 uppercase">
              Nome Completo
            </Label>
            <Input
              id="name"
              placeholder="Ex: Carlos Silva"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-11 rounded-xl"
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="email" className="text-xs font-semibold text-slate-700 uppercase">
              E-mail corporativo
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="seu.email@empresa.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-11 rounded-xl"
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs font-semibold text-slate-700 uppercase">
              Senha (mínimo 8 caracteres)
            </Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 rounded-xl pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {/* Strength Bar */}
            {password && (
              <div className="space-y-1 pt-1">
                <div className="flex gap-1 h-1.5 w-full">
                  {[1, 2, 3, 4].map((step) => (
                    <div
                      key={step}
                      className={`flex-1 rounded-full transition-all ${
                        strength >= step
                          ? strength === 1
                            ? 'bg-rose-500'
                            : strength === 2
                              ? 'bg-amber-500'
                              : strength === 3
                                ? 'bg-indigo-500'
                                : 'bg-emerald-500'
                          : 'bg-slate-200'
                      }`}
                    />
                  ))}
                </div>
                <p className="text-[11px] text-slate-500 text-right">
                  {strength <= 1
                    ? 'Fraca'
                    : strength === 2
                      ? 'Média'
                      : strength === 3
                        ? 'Boa'
                        : 'Forte'}
                </p>
              </div>
            )}
          </div>

          {/* Segment Selection */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <Label className="text-xs font-semibold text-slate-700 uppercase">
              Qual o seu segmento?
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {SEGMENTOS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSegment(s)}
                  className={cn(
                    'text-xs font-medium rounded-lg px-3 py-2 border transition-all',
                    segment === s
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300',
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
            {segment && (
              <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 space-y-2 text-center">
                <p className="text-xs text-slate-600">
                  Sem processos mapeados? Sem problema — a Nortia mapeia por você.
                </p>
                <ProcessMapperChat />
              </div>
            )}
          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full h-11 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold shadow-md shadow-indigo-600/30 gap-2 mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Criar conta</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </Button>
        </form>

        <p className="text-center text-xs text-slate-500">
          Já tem uma conta?{' '}
          <Link to="/" className="font-semibold text-indigo-600 hover:text-indigo-500">
            Fazer login
          </Link>
        </p>
      </div>
    </div>
  )
}
