routerAdd(
  'POST',
  '/backend/v1/north-ai/processar-csv',
  (e) => {
    const body = e.requestInfo().body || {}
    const rawCsv = body.raw_csv || ''
    const title = body.title || 'CSV Importado'

    if (!rawCsv || !rawCsv.trim()) {
      return e.badRequestError('CSV vazio.')
    }

    try {
      var lines = rawCsv
        .trim()
        .split(/\r?\n/)
        .filter(function (l) {
          return l.trim()
        })
      if (lines.length < 2) {
        return e.badRequestError('CSV precisa de cabeçalho e ao menos 1 linha de dados.')
      }

      var csvPreview = lines.slice(0, 40).join('\n')

      var prompt = 'Você é um analista especialista em otimização de processos de negócios.\n'
      prompt += 'Analise o seguinte CSV de processos (título: ' + title + '):\n\n'
      prompt += csvPreview + '\n\n'
      prompt +=
        'Identifique o principal gargalo, calcule horas perdidas por dia e custo mensal estimado (em R$).\n'
      prompt += 'Gere também uma automação (app ou agente IA) que resolve o gargalo.\n\n'
      prompt += 'Retorne um JSON válido com EXATAMENTE esta estrutura:\n'
      prompt += '{\n'
      prompt += '  "resumo": "Resumo executivo em 2 frases sobre os gargalos",\n'
      prompt += '  "diagnostico": {\n'
      prompt += '    "gargalo_principal": "Nome do gargalo mais crítico",\n'
      prompt += '    "etapa": "Etapa do processo afetada",\n'
      prompt += '    "horas_por_dia": 3.5,\n'
      prompt += '    "custo_mensal": 15000,\n'
      prompt += '    "manual": true,\n'
      prompt += '    "metrica_antes": "3h/dia",\n'
      prompt += '    "metrica_depois": "3 min",\n'
      prompt += '    "relatorio": "Breve relatório do impacto e solução"\n'
      prompt += '  },\n'
      prompt += '  "automacao": {\n'
      prompt += '    "nome": "Nome da automação sugerida",\n'
      prompt += '    "descricao": "Descrição funcional da automação",\n'
      prompt += '    "tipo": "agente",\n'
      prompt += '    "status": "pronta"\n'
      prompt += '  }\n'
      prompt += '}\n'
      prompt += 'Responda APENAS o JSON, sem markdown, sem texto adicional.'

      var aiRes = $ai.chat({
        model: 'fast',
        messages: [{ role: 'user', content: prompt }],
      })

      var content = aiRes.choices[0].message.content.trim()
      if (content.startsWith('```json')) {
        content = content.replace(/^```json\s*/, '').replace(/\s*```$/, '')
      } else if (content.startsWith('```')) {
        content = content.replace(/^```\s*/, '').replace(/\s*```$/, '')
      }

      var data = JSON.parse(content)

      return e.json(200, {
        status: 'ok',
        resumo: data.resumo || 'Análise concluída.',
        diagnostico: data.diagnostico || null,
        automacao: data.automacao || null,
      })
    } catch (err) {
      return e.json(500, {
        status: 'erro',
        error:
          'Não conseguimos analisar o CSV. Confira se o arquivo tem cabeçalho e linhas de dados.',
      })
    }
  },
  $apis.requireAuth(),
)
