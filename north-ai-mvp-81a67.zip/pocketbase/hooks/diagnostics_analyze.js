routerAdd(
  'POST',
  '/backend/v1/diagnostics/{id}/analyze',
  (e) => {
    const diagId = e.request.pathValue('id')
    const userId = e.auth?.id
    if (!userId) return e.unauthorizedError('Autenticação necessária.')

    const diag = $app.findRecordById('diagnostics', diagId)
    if (diag.getString('owner') !== userId) {
      return e.forbiddenError('Acesso negado ao diagnóstico.')
    }

    diag.set('status', 'processing')
    diag.set('error', '')
    $app.save(diag)

    try {
      const processDesc = diag.getString('process_description')
      const companyName = diag.getString('company_name')
      const industry = diag.getString('industry')
      const companySize = diag.getString('company_size')
      const csvFilename = diag.getString('csv_filename')
      const csvData = diag.getString('csv_data')

      let csvSection = ''
      if (csvFilename && csvData) {
        csvSection = `
DADOS IMPORTADOS DE PLANILHA CSV (${csvFilename}):
Colunas: etapa, atividade, responsavel, volume_mensal, tempo_medio_min, taxa_erro_pct, retrabalho_pct, custo_hora_rs, ferramenta

${csvData}

Use ESTES dados como a principal fonte quantitativa da análise. Calcule:
- volume_mensal x tempo_medio_min = minutos/mês por atividade (converta para horas).
- Impacto financeiro = horas gastas x custo_hora_rs + custo de retrabalho (retrabalho_pct x volume x custo por unidade).
- Identifique as atividades com maior taxa_erro_pct e retrabalho_pct como gargalos prioritários.
- Considere também o custo de espera (ex.: análise de crédito com 240-480 min por ciclo).`
      }

      const prompt = `Você é um analista especialista em otimização de processos de negócios.
Analise a seguinte descrição de processo da empresa "${companyName}" (Setor: ${industry}, Porte: ${companySize || 'N/A'}):
${csvSection}

"${processDesc}"

Gere uma análise completa em formato JSON rigorosamente válido com a seguinte estrutura exata:
{
  "summary": "Resumo executivo completo em 2 parágrafos enfatizando gargalos, horas perdidas e ganho de eficiência.",
  "total_financial_impact": 35000,
  "total_labor_hours": 150,
  "total_labor_cost": 18000,
  "avg_roi": 310,
  "bottlenecks": [
    {
      "title": "Nome do Gargalo 1",
      "description": "Explicação detalhada da causa e sintoma",
      "process_stage": "Etapa do processo",
      "category": "Processo",
      "severity": 8,
      "frequency": "alta",
      "financial_impact": 15000,
      "labor_hours_lost": 60,
      "labor_cost": 7200,
      "rework_percentage": 25,
      "roi_estimate": 350,
      "payback_months": 3,
      "priority_score": 88,
      "recommendation": "Ação imediata recomendada"
    }
  ],
  "solutions": [
    {
      "type": "app",
      "name": "Nome da Solução App",
      "description": "Descrição funcional da solução",
      "category": "automação",
      "blueprint": "Especificação técnica e funcional do sistema",
      "features": ["Funcionalidade 1", "Funcionalidade 2"],
      "expected_impact": "Economia estimada e ganho de tempo",
      "roi_estimate": 350,
      "implementation_effort": "médio",
      "priority": 1
    },
    {
      "type": "agente",
      "name": "Nome do Agente IA",
      "description": "Descrição funcional do agente",
      "category": "atendimento",
      "blueprint": "Especificação técnica e conversacional do agente",
      "features": ["Atendimento 24/7", "Consulta a banco de dados"],
      "expected_impact": "Redução de chamados e tempo de resposta",
      "roi_estimate": 280,
      "implementation_effort": "baixo",
      "priority": 2
    }
  ],
  "roadmap": [
    {
      "title": "Título da tarefa 1",
      "description": "Descrição do item do roadmap",
      "phase": 1,
      "phase_name": "Fase 1 — Quick Wins",
      "priority": 1,
      "timeline_weeks": 3
    }
  ]
}

Categorias válidas para gargalos: Processo, Tecnologia, Pessoas, Dados, Comunicação, Compliance.
Frequências válidas: constante, alta, média, baixa.
Tipos válidos para soluções: app, agente.
Esforços válidos: baixo, médio, alto.
Responda APENAS o JSON.`

      const aiRes = $ai.chat({
        model: 'fast',
        messages: [{ role: 'user', content: prompt }],
      })

      let content = aiRes.choices[0].message.content.trim()
      if (content.startsWith('```json')) {
        content = content.replace(/^```json\s*/, '').replace(/\s*```$/, '')
      } else if (content.startsWith('```')) {
        content = content.replace(/^```\s*/, '').replace(/\s*```$/, '')
      }

      const data = JSON.parse(content)

      // Delete existing child records if re-analyzing
      const oldB = $app.findRecordsByFilter('bottlenecks', 'diagnostic = {:d}', '', 100, 0, {
        d: diagId,
      })
      for (let i = 0; i < oldB.length; i++) {
        $app.delete(oldB[i])
      }

      const oldS = $app.findRecordsByFilter('solutions', 'diagnostic = {:d}', '', 100, 0, {
        d: diagId,
      })
      for (let i = 0; i < oldS.length; i++) {
        $app.delete(oldS[i])
      }

      const oldR = $app.findRecordsByFilter('roadmap_items', 'diagnostic = {:d}', '', 100, 0, {
        d: diagId,
      })
      for (let i = 0; i < oldR.length; i++) {
        $app.delete(oldR[i])
      }

      // Insert Bottlenecks
      const bCol = $app.findCollectionByNameOrId('bottlenecks')
      const createdBottlenecks = []
      if (Array.isArray(data.bottlenecks)) {
        for (let i = 0; i < data.bottlenecks.length; i++) {
          const item = data.bottlenecks[i]
          const rec = new Record(bCol)
          rec.set('diagnostic', diagId)
          rec.set('title', item.title || 'Gargalo identificado')
          rec.set('description', item.description || '')
          rec.set('process_stage', item.process_stage || 'Geral')
          rec.set('category', item.category || 'Processo')
          rec.set('severity', item.severity || 5)
          rec.set('frequency', item.frequency || 'alta')
          rec.set('financial_impact', item.financial_impact || 0)
          rec.set('labor_hours_lost', item.labor_hours_lost || 0)
          rec.set('labor_cost', item.labor_cost || 0)
          rec.set('rework_percentage', item.rework_percentage || 0)
          rec.set('roi_estimate', item.roi_estimate || 200)
          rec.set('payback_months', item.payback_months || 3)
          rec.set('priority_score', item.priority_score || 70)
          rec.set('recommendation', item.recommendation || '')
          $app.save(rec)
          createdBottlenecks.push(rec)
        }
      }

      // Insert Solutions
      const sCol = $app.findCollectionByNameOrId('solutions')
      const createdSolutions = []
      if (Array.isArray(data.solutions)) {
        for (let i = 0; i < data.solutions.length; i++) {
          const item = data.solutions[i]
          const rec = new Record(sCol)
          rec.set('diagnostic', diagId)
          rec.set('type', item.type || 'app')
          rec.set('name', item.name || 'Solução Proposta')
          rec.set('description', item.description || '')
          rec.set('category', item.category || 'automação')
          rec.set('blueprint', item.blueprint || '')
          rec.set('features', item.features || [])
          rec.set('expected_impact', item.expected_impact || '')
          rec.set('roi_estimate', item.roi_estimate || 250)
          rec.set('implementation_effort', item.implementation_effort || 'médio')
          rec.set('priority', item.priority || i + 1)
          rec.set('status', 'proposto')
          $app.save(rec)
          createdSolutions.push(rec)
        }
      }

      // Insert Roadmap Items
      const rCol = $app.findCollectionByNameOrId('roadmap_items')
      if (Array.isArray(data.roadmap)) {
        for (let i = 0; i < data.roadmap.length; i++) {
          const item = data.roadmap[i]
          const rec = new Record(rCol)
          rec.set('diagnostic', diagId)
          rec.set('title', item.title || 'Ação de Otimização')
          rec.set('description', item.description || '')
          rec.set('phase', item.phase || 1)
          rec.set('phase_name', item.phase_name || `Fase ${item.phase || 1}`)
          if (createdSolutions[i]) rec.set('solution', createdSolutions[i].id)
          if (createdBottlenecks[i]) rec.set('bottleneck', createdBottlenecks[i].id)
          rec.set('priority', item.priority || i + 1)
          rec.set('timeline_weeks', item.timeline_weeks || 4)
          rec.set('status', 'pendente')
          $app.save(rec)
        }
      }

      diag.set('summary', data.summary || 'Análise concluída com sucesso.')
      diag.set('total_financial_impact', data.total_financial_impact || 0)
      diag.set('total_labor_hours', data.total_labor_hours || 0)
      diag.set('total_labor_cost', data.total_labor_cost || 0)
      diag.set('avg_roi', data.avg_roi || 0)
      diag.set('status', 'completed')
      $app.save(diag)

      return e.json(200, { success: true, diagnostic_id: diagId })
    } catch (err) {
      diag.set('status', 'failed')
      diag.set('error', String(err.message || err))
      $app.save(diag)
      return e.json(500, { error: String(err.message || err) })
    }
  },
  $apis.requireAuth(),
)
