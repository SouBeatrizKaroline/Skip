routerAdd(
  'POST',
  '/backend/v1/assistant/chat',
  (e) => {
    const userId = e.auth?.id
    if (!userId) return e.unauthorizedError('Autenticação necessária.')

    const body = e.requestInfo().body || {}
    const message = body.message
    if (!message || typeof message !== 'string') {
      return e.badRequestError("O campo 'message' é obrigatório.")
    }

    try {
      let activeContext = ''
      const diagnosticId = body.diagnostic_id

      if (diagnosticId) {
        try {
          const diag = $app.findRecordById('diagnostics', diagnosticId)
          if (diag && diag.get('owner') === userId) {
            activeContext =
              '\nCONTEXTO DO DIAGNÓSTICO ATIVO (use SOMENTE estes dados — NÃO misture com outros diagnósticos):\n' +
              'Empresa: ' +
              diag.get('company_name') +
              ' (' +
              diag.get('industry') +
              ', ' +
              diag.get('company_size') +
              ')\n' +
              'Resumo: ' +
              diag.get('summary') +
              '\n' +
              'Impacto financeiro total: R$ ' +
              diag.get('total_financial_impact') +
              '/mês\n' +
              'Horas perdidas: ' +
              diag.get('total_labor_hours') +
              'h/mês\n' +
              'Custo trabalhista: R$ ' +
              diag.get('total_labor_cost') +
              '/mês\n' +
              'ROI médio: ' +
              diag.get('avg_roi') +
              '%\n'

            try {
              const bts = $app.findRecordsByFilter(
                'bottlenecks',
                'diagnostic = {:d}',
                '-priority_score',
                50,
                0,
                { d: diagnosticId },
              )
              const btLines = bts.map(function (b) {
                return (
                  '- ' +
                  b.get('title') +
                  ' | impacto: ' +
                  b.get('financial_impact') +
                  ' | horas/mês: ' +
                  b.get('labor_hours_lost') +
                  ' | ROI: ' +
                  b.get('roi_estimate') +
                  '%' +
                  ' | recomendação: ' +
                  b.get('recommendation')
                )
              })
              activeContext +=
                '\nGargalos:\n' + (btLines.join('\n') || '- Nenhum gargalo registrado.') + '\n'
            } catch (btErr) {
              console.log(
                '[assistant_chat] gargalos lookup failed:',
                String((btErr && btErr.message) || btErr),
              )
            }

            try {
              const sols = $app.findRecordsByFilter(
                'solutions',
                'diagnostic = {:d}',
                'priority',
                50,
                0,
                { d: diagnosticId },
              )
              const solLines = sols.map(function (s) {
                return (
                  '- ' +
                  s.get('name') +
                  ' (' +
                  s.get('type') +
                  ') | impacto: ' +
                  s.get('expected_impact') +
                  ' | ROI: ' +
                  s.get('roi_estimate') +
                  '% | esforço: ' +
                  s.get('implementation_effort')
                )
              })
              activeContext +=
                '\nSoluções propostas:\n' +
                (solLines.join('\n') || '- Nenhuma solução registrada.') +
                '\n'
            } catch (solErr) {
              console.log(
                '[assistant_chat] solutions lookup failed:',
                String((solErr && solErr.message) || solErr),
              )
            }

            try {
              const rms = $app.findRecordsByFilter(
                'roadmap_items',
                'diagnostic = {:d}',
                'phase,priority',
                50,
                0,
                { d: diagnosticId },
              )
              const rmLines = rms.map(function (r) {
                return (
                  '- [Fase ' +
                  r.get('phase') +
                  '] ' +
                  r.get('title') +
                  ' | ' +
                  r.get('timeline_weeks') +
                  ' semanas | status: ' +
                  r.get('status')
                )
              })
              activeContext +=
                '\nRoadmap:\n' + (rmLines.join('\n') || '- Nenhum item de roadmap.') + '\n'
            } catch (rmErr) {}

            var csvData = diag.get('csv_data')
            var csvFilename = diag.get('csv_filename')
            if (csvData) {
              var maxLen = 8000
              var csvStr = String(csvData)
              var csv =
                csvStr.length > maxLen
                  ? csvStr.slice(0, maxLen) + '\n... (arquivo truncado)'
                  : csvStr
              activeContext +=
                '\nDADOS COMPLETOS DO ARQUIVO CSV ("' +
                (csvFilename || 'arquivo.csv') +
                '"):\n' +
                csv +
                '\n'
            }

            activeContext +=
              '\nIMPORTANTE: Use APENAS os dados apresentados acima como fonte de verdade. NÃO invente, assuma ou extrapole dados que não estão presentes no arquivo ou no diagnóstico. Toda referência a valores, linhas, colunas ou categorias deve ser rastreável aos dados fornecidos.\n'
          } else {
            console.log('[assistant_chat] diagnóstico não pertence ao usuário ou não encontrado')
          }
        } catch (ctxErr) {
          console.log(
            '[assistant_chat] ERRO ao montar contexto:',
            String((ctxErr && ctxErr.message) || ctxErr),
          )
        }
      }

      var conv = $ai.agent('north-assistant').getOrCreateConversation({
        user_id: userId,
        id: body.conversation_id || null,
        title: body.diagnostic_title || 'Conversa de Diagnóstico',
      })

      var finalMessage = activeContext
        ? activeContext + '\n\nPergunta do usuário:\n' + message
        : message

      var result = $ai.agent('north-assistant').chat({
        user_id: userId,
        conversation_id: conv.id,
        message: finalMessage,
      })

      return e.json(200, {
        conversation_id: result.conversation_id,
        content: result.content,
        citations: result.citations || [],
        message_id: result.message_id,
      })
    } catch (err) {
      return e.json(500, { error: (err && err.message) || 'Erro no processamento do assistente.' })
    }
  },
  $apis.requireAuth(),
)

routerAdd(
  'GET',
  '/backend/v1/assistant/conversations',
  (e) => {
    const userId = e.auth?.id
    if (!userId) return e.unauthorizedError('Autenticação necessária.')

    const list = $ai.agent('north-assistant').listConversations({ user_id: userId, limit: 20 })
    return e.json(200, list)
  },
  $apis.requireAuth(),
)

routerAdd(
  'GET',
  '/backend/v1/assistant/messages/{conversationId}',
  (e) => {
    const userId = e.auth?.id
    if (!userId) return e.unauthorizedError('Autenticação necessária.')

    const convId = e.request.pathValue('conversationId')
    const msgs = $ai
      .agent('north-assistant')
      .listMessages({ conversation_id: convId, user_id: userId })
    return e.json(200, msgs)
  },
  $apis.requireAuth(),
)
