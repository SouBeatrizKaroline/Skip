migrate(
  (app) => {
    const col = app.findCollectionByNameOrId('diagnostics')
    if (!col.fields.getByName('csv_filename')) {
      col.fields.add(new TextField({ name: 'csv_filename' }))
    }
    if (!col.fields.getByName('csv_data')) {
      col.fields.add(new TextField({ name: 'csv_data' }))
    }
    app.save(col)
  },
  (app) => {
    const col = app.findCollectionByNameOrId('diagnostics')
    try {
      if (col.fields.getByName('csv_data')) col.fields.remove('csv_data')
    } catch (_) {}
    try {
      if (col.fields.getByName('csv_filename')) col.fields.remove('csv_filename')
    } catch (_) {}
    app.save(col)
  },
)
