migrate(
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')

    let adminUser
    try {
      adminUser = app.findAuthRecordByEmail('_pb_users_auth_', 'jhay.dev@outlook.com')
    } catch (_) {
      adminUser = new Record(usersCol)
      adminUser.setEmail('jhay.dev@outlook.com')
      adminUser.setPassword('Skip@Pass')
      adminUser.setVerified(true)
      adminUser.set('name', 'Admin Dev')
      app.save(adminUser)
    }

    let demoUser
    try {
      demoUser = app.findAuthRecordByEmail('_pb_users_auth_', 'demo@north.ai')
    } catch (_) {
      demoUser = new Record(usersCol)
      demoUser.setEmail('demo@north.ai')
      demoUser.setPassword('Demo@12345')
      demoUser.setVerified(true)
      demoUser.set('name', 'Demo User')
      app.save(demoUser)
    }

    const diagCol = app.findCollectionByNameOrId('diagnostics')
    let demoDiag
    try {
      demoDiag = app.findFirstRecordByData('diagnostics', 'company_name', 'Logística Farma S.A.')
    } catch (_) {
      demoDiag = new Record(diagCol)
      demoDiag.set('owner', demoUser.id)
      demoDiag.set('company_name', 'Logística Farma S.A.')
      demoDiag.set('industry', 'Logística')
      demoDiag.set('company_size', '51–200')
      demoDiag.set('annual_revenue', 18000000)
      demoDiag.set(
        'process_description',
        'Processo de recebimento de cargas refrigera, triagem de pedidos de farmácias parceiras via e-mail e arquivos TXT, checagem fiscal manual de alíquotas estaduais de ICMS, aprovação de crédito de novos pedidos com formulários em papel e agendamento manual com transportadoras terceirizadas.',
      )
      demoDiag.set('status', 'completed')
      demoDiag.set(
        'summary',
        'Diagnóstico completo da operação de logística e distribuição farmacêutica. Identificamos 4 gargalos operacionais e tecnológicos críticos que hoje geram desperdício mensal estimado em R$ 42.500 e 180 horas operacionais em tarefas manuais, retrabalho fiscal e atrasos em aprovação de crédito.',
      )
      demoDiag.set('total_financial_impact', 42500)
      demoDiag.set('total_labor_hours', 180)
      demoDiag.set('total_labor_cost', 21600)
      demoDiag.set('avg_roi', 320)
      app.save(demoDiag)

      const bCol = app.findCollectionByNameOrId('bottlenecks')
      const bottlenecksData = [
        {
          title: 'Dupla digitação de pedidos entre CRM e ERP',
          description:
            'Os pedidos recebidos no portal comercial são impressos ou copiados manualmente para o sistema ERP TOTVS, gerando atraso e erros de digitação de código de barras.',
          process_stage: 'Recebimento & Triagem',
          category: 'Tecnologia',
          severity: 9,
          frequency: 'constante',
          financial_impact: 18500,
          labor_hours_lost: 75,
          labor_cost: 9000,
          rework_percentage: 35,
          roi_estimate: 410,
          payback_months: 2,
          priority_score: 95,
          recommendation:
            'Implantar barramento de integração automatizado via API Webhook entre CRM e ERP TOTVS para eliminar 100% da redigitação.',
        },
        {
          title: 'Aprovação de crédito com espera média de 3 dias',
          description:
            'Análise manual de limite de crédito para novos pedidos e farmácias pendentes exige checagem de formulários físicos pelo financeiro.',
          process_stage: 'Análise de Crédito',
          category: 'Processo',
          severity: 8,
          frequency: 'alta',
          financial_impact: 12000,
          labor_hours_lost: 45,
          labor_cost: 5400,
          rework_percentage: 20,
          roi_estimate: 310,
          payback_months: 3,
          priority_score: 82,
          recommendation:
            'Criar motor de regras de crédito automático com Scoring Serasa integrado para concessão de crédito em até 15 minutos.',
        },
        {
          title: 'Retrabalho em NFe por divergência fiscal estaduais',
          description:
            'Notas fiscais emitidas com substituição tributária errada exigem cancelamento e reemissão de guia de transporte refrigero.',
          process_stage: 'Faturamento',
          category: 'Dados',
          severity: 7,
          frequency: 'média',
          financial_impact: 8000,
          labor_hours_lost: 35,
          labor_cost: 4200,
          rework_percentage: 28,
          roi_estimate: 280,
          payback_months: 4,
          priority_score: 74,
          recommendation:
            'Validação prévia automatizada de alíquotas fiscais e regras de ICMS antes da emissão da NFe no faturamento.',
        },
        {
          title: 'Follow-up manual de entregas refrig e ocorrências',
          description:
            'Atendentes gastam horas ligando para motoristas e farmácias para responder perguntas sobre horário estimado de entrega.',
          process_stage: 'Expedição & Transporte',
          category: 'Comunicação',
          severity: 6,
          frequency: 'alta',
          financial_impact: 4000,
          labor_hours_lost: 25,
          labor_cost: 3000,
          rework_percentage: 15,
          roi_estimate: 240,
          payback_months: 5,
          priority_score: 65,
          recommendation:
            'Agente inteligente de IA via WhatsApp para consulta de status de entregas e telemetria de temperatura em tempo real.',
        },
      ]

      const bRecords = []
      for (const bData of bottlenecksData) {
        const rec = new Record(bCol)
        rec.set('diagnostic', demoDiag.id)
        for (const key in bData) {
          rec.set(key, bData[key])
        }
        app.save(rec)
        bRecords.push(rec)
      }

      const sCol = app.findCollectionByNameOrId('solutions')
      const solutionsData = [
        {
          type: 'app',
          name: 'Automação de Pedidos CRM/ERP',
          description:
            'Aplicativo web de integração contínua de pedidos com esteira de validação automática e fila de sincronização.',
          category: 'automação',
          blueprint:
            'Objetivo: Eliminar redigitação manual de pedidos.\nFuncionalidades:\n- Barramento de entrada de pedidos JSON/TXT\n- Validação de regras de negócio e estoque em tempo real\n- Fila de re-tentativa automatizada em falha de conexão\nModelo de dados: Orders, OrderItems, SyncLogs.\nTelas: Painel de Monitoramento de Pedidos, Ajustes Fiscais, Configuração de Integradores.\nCritérios de Aceite: Tempo de sync < 2 segundos, zero erros de digitação.',
          features: [
            'Sincronização bidirecional em tempo real',
            'Validação de CNPJ e inscrição estadual',
            'Logs de auditoria e re-tentativa automática',
          ],
          expected_impact: 'Redução de 100% da redigitação manual e economia de R$ 18.500/mês.',
          roi_estimate: 410,
          implementation_effort: 'médio',
          priority: 1,
          status: 'em_andamento',
        },
        {
          type: 'app',
          name: 'Painel de Aprovações de Crédito Rápido',
          description:
            'Esteira digital de decisão financeira de crédito com scoring Serasa automático para clientes farmácia.',
          category: 'análise',
          blueprint:
            'Objetivo: Reduzir tempo de aprovação de crédito de 3 dias para 15 minutos.\nFuncionalidades:\n- Análise automática de Score de crédito via API\n- Regras configuráveis de limite por porte de farmácia\n- Assinatura digital do termo de limite de crédito\nTelas: Fila de Análise, Ficha Completa do Cliente, Painel de Gestão de Riscos.\nCritérios de Aceite: Aprovação em < 15min para limites de até R$ 50.000.',
          features: [
            'Motor de regras de crédito customizável',
            'Consulta Serasa/Boa Vista em 1 clique',
            'Notificações instantâneas via WhatsApp/E-mail',
          ],
          expected_impact:
            'Redução do ciclo de venda em 80% e economia de 45h/mês do time financeiro.',
          roi_estimate: 310,
          implementation_effort: 'baixo',
          priority: 2,
          status: 'proposto',
        },
        {
          type: 'agente',
          name: 'Agente Suporte Logístico & Tracking',
          description:
            'Agente conversacional de IA para respostas automáticas de localização de carga e temperatura de transporte.',
          category: 'atendimento',
          blueprint:
            'Objetivo: Responder chamados de motoristas e farmácias 24/7 sem intervenção humana.\nFuncionalidades:\n- Rastreamento por código do pedido ou CNPJ\n- Leitura de sensores de temperatura IoT das vans refrigeradas\n- Transbordo para operador humano em caso de sinistro ou avaria\nTelas: Chat Integrado, Dashboard de Satisfação do Agente.\nCritérios de Aceite: Resolutividade de 90% das chamadas sem transbordo.',
          features: [
            'Integração com telemetria GPS e sensores de temperatura',
            'Atendimento conversacional humanizado 24/7',
            'Escalação inteligente para operador de plantão',
          ],
          expected_impact:
            'Economia de 25h/mês do time de atendimento e satisfação do cliente > 95%.',
          roi_estimate: 240,
          implementation_effort: 'baixo',
          priority: 3,
          status: 'proposto',
        },
      ]

      const sRecords = []
      for (const sData of solutionsData) {
        const rec = new Record(sCol)
        rec.set('diagnostic', demoDiag.id)
        for (const key in sData) {
          rec.set(key, sData[key])
        }
        app.save(rec)
        sRecords.push(rec)
      }

      const rmCol = app.findCollectionByNameOrId('roadmap_items')
      const roadmapData = [
        {
          title: 'Implantação do Barramento de Pedidos (CRM/ERP)',
          description: 'Desenvolvimento da API e integrador de pedidos em tempo real',
          phase: 1,
          phase_name: 'Fase 1 — Quick Wins',
          solution: sRecords[0].id,
          bottleneck: bRecords[0].id,
          priority: 1,
          timeline_weeks: 3,
          status: 'em_andamento',
        },
        {
          title: 'Configuração do Motor de Crédito Automático',
          description: 'Integração Serasa e regras de limites rápidos',
          phase: 1,
          phase_name: 'Fase 1 — Quick Wins',
          solution: sRecords[1].id,
          bottleneck: bRecords[1].id,
          priority: 2,
          timeline_weeks: 2,
          status: 'pendente',
        },
        {
          title: 'Validador de Alíquotas NFe com IA',
          description: 'Módulo fiscal para prevenção de divergência em NFe',
          phase: 2,
          phase_name: 'Fase 2 — Estrutural',
          bottleneck: bRecords[2].id,
          priority: 3,
          timeline_weeks: 6,
          status: 'pendente',
        },
        {
          title: 'Lançamento do Agente Suporte Logístico',
          description: 'Implantação do bot WhatsApp para motoristas e farmácias',
          phase: 2,
          phase_name: 'Fase 2 — Estrutural',
          solution: sRecords[2].id,
          bottleneck: bRecords[3].id,
          priority: 4,
          timeline_weeks: 4,
          status: 'pendente',
        },
        {
          title: 'Portal do Cliente Farmácia com Self-Service',
          description: 'Portal completo de pedidos e segunda via de boletos',
          phase: 3,
          phase_name: 'Fase 3 — Transformação',
          priority: 5,
          timeline_weeks: 8,
          status: 'pendente',
        },
        {
          title: 'Otimização de Rotas e Telemetria Integrada',
          description: 'Roteirização inteligente e sensores frigoríficos em tempo real',
          phase: 3,
          phase_name: 'Fase 3 — Transformação',
          priority: 6,
          timeline_weeks: 10,
          status: 'pendente',
        },
      ]

      for (const rmData of roadmapData) {
        const rec = new Record(rmCol)
        rec.set('diagnostic', demoDiag.id)
        for (const key in rmData) {
          rec.set(key, rmData[key])
        }
        app.save(rec)
      }
    }
  },
  (app) => {},
)
