migrate(
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')

    const diagnostics = new Collection({
      name: 'diagnostics',
      type: 'base',
      listRule: "@request.auth.id != '' && owner = @request.auth.id",
      viewRule: "@request.auth.id != '' && owner = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && owner = @request.auth.id",
      deleteRule: "@request.auth.id != '' && owner = @request.auth.id",
      fields: [
        {
          name: 'owner',
          type: 'relation',
          required: true,
          collectionId: usersCol.id,
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'company_name', type: 'text', required: true },
        {
          name: 'industry',
          type: 'select',
          required: true,
          values: [
            'Tecnologia',
            'Varejo',
            'Saúde',
            'Indústria',
            'Finanças',
            'Educação',
            'Logística',
            'Serviços',
            'Outro',
          ],
          maxSelect: 1,
        },
        {
          name: 'company_size',
          type: 'select',
          values: ['1–10', '11–50', '51–200', '201–500', '500+'],
          maxSelect: 1,
        },
        { name: 'annual_revenue', type: 'number' },
        { name: 'process_description', type: 'text', required: true },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['queued', 'processing', 'completed', 'failed'],
          maxSelect: 1,
        },
        { name: 'summary', type: 'text' },
        { name: 'total_financial_impact', type: 'number' },
        { name: 'total_labor_hours', type: 'number' },
        { name: 'total_labor_cost', type: 'number' },
        { name: 'avg_roi', type: 'number' },
        { name: 'error', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_diag_owner ON diagnostics (owner)',
        'CREATE INDEX idx_diag_status ON diagnostics (status)',
        'CREATE INDEX idx_diag_created ON diagnostics (created DESC)',
      ],
    })
    app.save(diagnostics)

    const bottlenecks = new Collection({
      name: 'bottlenecks',
      type: 'base',
      listRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      viewRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      deleteRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      fields: [
        {
          name: 'diagnostic',
          type: 'relation',
          required: true,
          collectionId: diagnostics.id,
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'process_stage', type: 'text' },
        {
          name: 'category',
          type: 'select',
          values: ['Processo', 'Tecnologia', 'Pessoas', 'Dados', 'Comunicação', 'Compliance'],
          maxSelect: 1,
        },
        { name: 'severity', type: 'number', min: 1, max: 10 },
        {
          name: 'frequency',
          type: 'select',
          values: ['constante', 'alta', 'média', 'baixa'],
          maxSelect: 1,
        },
        { name: 'financial_impact', type: 'number' },
        { name: 'labor_hours_lost', type: 'number' },
        { name: 'labor_cost', type: 'number' },
        { name: 'rework_percentage', type: 'number' },
        { name: 'roi_estimate', type: 'number' },
        { name: 'payback_months', type: 'number' },
        { name: 'priority_score', type: 'number' },
        { name: 'recommendation', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_bt_diag ON bottlenecks (diagnostic)',
        'CREATE INDEX idx_bt_prio ON bottlenecks (priority_score DESC)',
      ],
    })
    app.save(bottlenecks)

    const solutions = new Collection({
      name: 'solutions',
      type: 'base',
      listRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      viewRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      deleteRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      fields: [
        {
          name: 'diagnostic',
          type: 'relation',
          required: true,
          collectionId: diagnostics.id,
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'type', type: 'select', required: true, values: ['app', 'agente'], maxSelect: 1 },
        { name: 'name', type: 'text', required: true },
        { name: 'description', type: 'text', required: true },
        {
          name: 'category',
          type: 'select',
          values: ['automação', 'análise', 'atendimento', 'integração', 'otimização'],
          maxSelect: 1,
        },
        { name: 'blueprint', type: 'text' },
        { name: 'features', type: 'json' },
        { name: 'expected_impact', type: 'text' },
        { name: 'roi_estimate', type: 'number' },
        {
          name: 'implementation_effort',
          type: 'select',
          values: ['baixo', 'médio', 'alto'],
          maxSelect: 1,
        },
        { name: 'priority', type: 'number' },
        {
          name: 'status',
          type: 'select',
          values: ['proposto', 'em_andamento', 'concluído'],
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_sol_diag ON solutions (diagnostic)',
        'CREATE INDEX idx_sol_type ON solutions (type)',
      ],
    })
    app.save(solutions)

    const roadmapItems = new Collection({
      name: 'roadmap_items',
      type: 'base',
      listRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      viewRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      deleteRule: "@request.auth.id != '' && diagnostic.owner = @request.auth.id",
      fields: [
        {
          name: 'diagnostic',
          type: 'relation',
          required: true,
          collectionId: diagnostics.id,
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'phase', type: 'number' },
        { name: 'phase_name', type: 'text' },
        {
          name: 'solution',
          type: 'relation',
          collectionId: solutions.id,
          cascadeDelete: false,
          maxSelect: 1,
        },
        {
          name: 'bottleneck',
          type: 'relation',
          collectionId: bottlenecks.id,
          cascadeDelete: false,
          maxSelect: 1,
        },
        { name: 'priority', type: 'number' },
        { name: 'timeline_weeks', type: 'number' },
        {
          name: 'status',
          type: 'select',
          values: ['pendente', 'em_andamento', 'concluído', 'bloqueado'],
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_rm_diag ON roadmap_items (diagnostic)',
        'CREATE INDEX idx_rm_phase ON roadmap_items (phase)',
        'CREATE INDEX idx_rm_status ON roadmap_items (status)',
      ],
    })
    app.save(roadmapItems)
  },
  (app) => {
    const collections = ['roadmap_items', 'solutions', 'bottlenecks', 'diagnostics']
    for (const colName of collections) {
      try {
        const col = app.findCollectionByNameOrId(colName)
        app.delete(col)
      } catch (_) {}
    }
  },
)
