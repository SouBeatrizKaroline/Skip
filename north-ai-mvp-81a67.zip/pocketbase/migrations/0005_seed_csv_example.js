migrate(
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')

    let demoUser
    try {
      demoUser = app.findAuthRecordByEmail('_pb_users_auth_', 'demo@north.ai')
    } catch (_) {
      demoUser = new Record(usersCol)
      demoUser.setEmail('demo@north.ai')
      demoUser.setPassword('Demo@12345')
      demoUser.setVerified(true)
      demoUser.set('name', 'Demo User')
      app.save(demoUser)
    }

    // Diagnóstico já existe (seed da migração 0002)?
    let diag
    try {
      diag = app.findFirstRecordByData(
        'diagnostics',
        'company_name',
        'Indústria Metalmecânica Ltda.',
      )
    } catch (_) {
      diag = null
    }
    if (diag) return

    const diagCol = app.findCollectionByNameOrId('diagnostics')
    diag = new Record(diagCol)
    diag.set('owner', demoUser.id)
    diag.set('company_name', 'Indústria Metalmecânica Ltda.')
    diag.set('industry', 'Indústria')
    diag.set('company_size', '201–500')
    diag.set('annual_revenue', 52000000)
    diag.set('status', 'completed')
    diag.set('csv_filename', 'processos-industria-metalurgica.csv')
    diag.set(
      'csv_data',
      `etapa,atividade,responsavel,volume_mensal,tempo_medio_min,taxa_erro_pct,retrabalho_pct,custo_hora_rs,ferramenta
Recebimento,Conferência de nota fiscal,Conferente,450,12,8,15,32,ERP
Recebimento,Registro manual de entrada no sistema,Auxiliar,450,18,6,10,28,Excel manual
Triagem,Classificação de pedidos por prioridade,Analista,680,9,4,8,38,Planilha manual
Triagem,Digitação de pedidos no ERP,Assistente,680,22,12,25,30,Digitação manual
Crédito,Análise de limite de crédito,Financeiro,180,240,10,20,55,Formulário em papel
Crédito,Aprovação com assinatura manual,Gerente,180,480,8,15,85,Assinatura física
Faturamento,Emissão de NFe,Analista fiscal,450,15,9,28,48,ERP + digitação
Faturamento,Validação de alíquotas ICMS,Fiscal,450,25,7,22,52,Consulta manual
Expedição,Separação de pedidos,Separador,450,35,5,12,26,WMS
Expedição,Conferência de avarias,Conferente,450,10,4,8,32,Inspeção visual
Transporte,Agendamento com transportadoras,Auxiliar,320,20,6,10,28,Telefone e e-mail
Transporte,Follow-up de entregas,Atendente,320,40,9,15,30,Ligações manuais
Retrabalho,NFe cancelada por divergência fiscal,Analista fiscal,126,60,100,100,48,ERP
Retrabalho,Cadastro de cliente pendente de crédito,Assistente,36,45,100,100,30,Cadastro manual`,
    )
    diag.set(
      'process_description',
      `Processo de recebimento, triagem, análise de crédito, faturamento, expedição e transporte de uma indústria metalmecânica com 201–500 colaboradores.
O time executa tarefas manuais e repetitivas: digitação de pedidos no ERP, análise de crédito em formulário de papel com assinatura manual do gerente (espera de 3 dias), emissão e validação manual de alíquotas de ICMS em NFe, separação e conferência de pedidos no WMS, e follow-up de entregas por telefone.
Dados importados via CSV (processos-industria-metalurgica.csv) com 14 atividades e indicadores de volume, tempo médio, taxa de erro e retrabalho.`,
    )
    diag.set(
      'summary',
      'Diagnóstico completo da operação industrial. A análise do CSV revelou 4 gargalos críticos que consomem 1.212 horas/mês em atividades manuais, gerando impacto financeiro estimado de R$ 61.350/mês (retrabalho fiscal, crédito travado e redigitação). O ROI médio das soluções propostas é de 318%, com payback médio de 3,5 meses.',
    )
    diag.set('total_financial_impact', 61350)
    diag.set('total_labor_hours', 1212)
    diag.set('total_labor_cost', 52000)
    diag.set('avg_roi', 318)
    app.save(diag)

    const bCol = app.findCollectionByNameOrId('bottlenecks')
    const bottlenecksData = [
      {
        title: 'Digitação manual de pedidos no ERP (triagem)',
        description:
          '680 pedidos/mês digitados à mão, com taxa de erro de 12% e retrabalho de 25%, gerando ~1.496h/ano de redigitação e conferência duplicada.',
        process_stage: 'Triagem',
        category: 'Tecnologia',
        severity: 9,
        frequency: 'constante',
        financial_impact: 21500,
        labor_hours_lost: 410,
        labor_cost: 17500,
        rework_percentage: 25,
        roi_estimate: 420,
        payback_months: 2,
        priority_score: 96,
        recommendation:
          'Implantar barramento de integração de pedidos via API/EDI entre o portal comercial e o ERP, eliminando 100% da redigitação.',
      },
      {
        title: 'Análise de crédito com formulário em papel e assinatura manual',
        description:
          '180 análises/mês com espera média de 3 dias (240 a 480 min por ciclo) e retrabalho de 20%, travando vendas e aumentando o ciclo financeiro.',
        process_stage: 'Análise de Crédito',
        category: 'Processo',
        severity: 8,
        frequency: 'alta',
        financial_impact: 15800,
        labor_hours_lost: 380,
        labor_cost: 16500,
        rework_percentage: 20,
        roi_estimate: 340,
        payback_months: 3,
        priority_score: 84,
        recommendation:
          'Esteira digital de aprovação de crédito com scoring automático, regras por limite e assinatura eletrônica para reduzir o ciclo de 3 dias para 15 minutos.',
      },
      {
        title: 'Retrabalho fiscal em NFe por divergência de alíquotas ICMS',
        description:
          '126 NFe canceladas/mês (28% de retrabalho) por alíquotas estaduais incorretas, com reemissão e risco de multas; custo de R$ 0,80/hora extra de fiscal dedicado à correção.',
        process_stage: 'Faturamento',
        category: 'Dados',
        severity: 7,
        frequency: 'média',
        financial_impact: 14200,
        labor_hours_lost: 265,
        labor_cost: 12800,
        rework_percentage: 28,
        roi_estimate: 300,
        payback_months: 4,
        priority_score: 78,
        recommendation:
          'Validador fiscal automatizado de alíquotas ICMS/ST antes da emissão da NFe, com base de regras atualizada por UF.',
      },
      {
        title: 'Follow-up manual de entregas e agendamento de transportadoras',
        description:
          '320 entregas/mês com follow-up por telefone (40 min cada) e agendamento manual, gerando ~80h/mês de atendimento improdutivo e atrasos de comunicação.',
        process_stage: 'Transporte',
        category: 'Comunicação',
        severity: 6,
        frequency: 'alta',
        financial_impact: 9850,
        labor_hours_lost: 157,
        labor_cost: 7200,
        rework_percentage: 15,
        roi_estimate: 250,
        payback_months: 5,
        priority_score: 68,
        recommendation:
          'Agente de IA via WhatsApp para tracking de entregas e agendamento automático de transportadoras, com transbordo para humano em ocorrências.',
      },
    ]

    const bRecords = []
    for (const bData of bottlenecksData) {
      const rec = new Record(bCol)
      rec.set('diagnostic', diag.id)
      for (const key in bData) {
        rec.set(key, bData[key])
      }
      app.save(rec)
      bRecords.push(rec)
    }

    const sCol = app.findCollectionByNameOrId('solutions')
    const solutionsData = [
      {
        type: 'app',
        name: 'Automação de Pedidos com Integração ERP (EDI/API)',
        description:
          'Aplicativo de barramento de pedidos com validação automática, fila de sincronização e auditoria, conectando portal comercial ao ERP sem digitação.',
        category: 'automação',
        blueprint:
          'Objetivo: Eliminar redigitação de 680 pedidos/mês.\\nFuncionalidades:\\n- Importação de pedidos via API/EDI/planilha\\n- Validação de CNPJ, estoque e regras de negócio\\n- Fila de re-tentativa e dashboard de monitoramento\\nModelo: Orders, OrderItems, SyncLogs.\\nCritérios de Aceite: sync < 2s, 0 erros de digitação.',
        features: [
          'Sincronização bidirecional em tempo real',
          'Validação automática de pedidos e estoque',
          'Logs de auditoria e re-tentativa em falha',
        ],
        expected_impact: 'Eliminação de 410h/mês de digitação e R$ 21.500/mês de retrabalho.',
        roi_estimate: 420,
        implementation_effort: 'médio',
        priority: 1,
        status: 'em_andamento',
      },
      {
        type: 'app',
        name: 'Painel de Crédito Rápido com Assinatura Digital',
        description:
          'Esteira digital de decisão de crédito com scoring automático, regras por perfil e assinatura eletrônica para aprovar limites em minutos.',
        category: 'análise',
        blueprint:
          'Objetivo: Reduzir ciclo de crédito de 3 dias para 15 min.\\nFuncionalidades:\\n- Scoring automático (Serasa/Boa Vista)\\n- Regras configuráveis por limite e porte\\n- Assinatura digital e trilha de auditoria\\nTelas: Fila de Análise, Ficha do Cliente, Gestão de Riscos.\\nCritérios: Aprovação < 15min para limites até R$ 50k.',
        features: [
          'Motor de regras de crédito customizável',
          'Consulta a bureaus em 1 clique',
          'Notificações via WhatsApp/E-mail',
        ],
        expected_impact: 'Redução de 80% do ciclo de venda e 380h/mês liberadas.',
        roi_estimate: 340,
        implementation_effort: 'baixo',
        priority: 2,
        status: 'proposto',
      },
      {
        type: 'agente',
        name: 'Agente Fiscal de Validação NFe',
        description:
          'Agente de IA que valida alíquotas ICMS/ST por UF antes da emissão, prevenindo cancelamento e retrabalho de NFe.',
        category: 'integração',
        blueprint:
          'Objetivo: Zero NFe cancelada por divergência fiscal.\\nFuncionalidades:\\n- Consulta automática de alíquotas por UF e NCM\\n- Regras de ST e benefícios fiscais\\n- Sugestão de correção antes da emissão\\nIntegração: ERP → API Fiscal.\\nCritérios: 100% das NFe validadas, 0 cancelamentos.',
        features: [
          'Base de alíquotas ICMS/ST atualizada por UF',
          'Validação em tempo real no faturamento',
          'Relatório de conformidade fiscal',
        ],
        expected_impact: 'Eliminação de 265h/mês de retrabalho e R$ 14.200/mês.',
        roi_estimate: 300,
        implementation_effort: 'médio',
        priority: 3,
        status: 'proposto',
      },
      {
        type: 'agente',
        name: 'Agente Logístico & Tracking WhatsApp',
        description:
          'Agente conversacional para consulta de entregas, agendamento de transportadoras e aviso de ocorrências 24/7.',
        category: 'atendimento',
        blueprint:
          'Objetivo: Eliminar follow-up telefônico de 320 entregas/mês.\\nFuncionalidades:\\n- Tracking por pedido/CNPJ no WhatsApp\\n- Agendamento automático de transportadoras\\n- Transbordo para humano em avarias/sinistros\\nTelas: Chat, Dashboard de Satisfação.\\nCritérios: 90% de resolutividade sem transbordo.',
        features: [
          'Tracking de entregas em tempo real',
          'Agendamento automático de coleta',
          'Escalação inteligente para operador',
        ],
        expected_impact: 'Economia de 157h/mês e satisfação do cliente > 95%.',
        roi_estimate: 250,
        implementation_effort: 'baixo',
        priority: 4,
        status: 'proposto',
      },
    ]

    const sRecords = []
    for (const sData of solutionsData) {
      const rec = new Record(sCol)
      rec.set('diagnostic', diag.id)
      for (const key in sData) {
        rec.set(key, sData[key])
      }
      app.save(rec)
      sRecords.push(rec)
    }

    const rmCol = app.findCollectionByNameOrId('roadmap_items')
    const roadmapData = [
      {
        title: 'Implantação do Barramento de Pedidos (EDI/API)',
        description: 'Integração do portal comercial com o ERP e esteira de validação',
        phase: 1,
        phase_name: 'Fase 1 — Quick Wins',
        solution: sRecords[0].id,
        bottleneck: bRecords[0].id,
        priority: 1,
        timeline_weeks: 3,
        status: 'em_andamento',
      },
      {
        title: 'Configuração do Motor de Crédito Automático',
        description: 'Scoring Serasa e regras de limites com assinatura digital',
        phase: 1,
        phase_name: 'Fase 1 — Quick Wins',
        solution: sRecords[1].id,
        bottleneck: bRecords[1].id,
        priority: 2,
        timeline_weeks: 2,
        status: 'pendente',
      },
      {
        title: 'Validador Fiscal NFe com IA',
        description: 'Módulo de alíquotas ICMS/ST antes da emissão',
        phase: 2,
        phase_name: 'Fase 2 — Estrutural',
        solution: sRecords[2].id,
        bottleneck: bRecords[2].id,
        priority: 3,
        timeline_weeks: 6,
        status: 'pendente',
      },
      {
        title: 'Lançamento do Agente Logístico WhatsApp',
        description: 'Bot de tracking e agendamento de transportadoras',
        phase: 2,
        phase_name: 'Fase 2 — Estrutural',
        solution: sRecords[3].id,
        bottleneck: bRecords[3].id,
        priority: 4,
        timeline_weeks: 4,
        status: 'pendente',
      },
      {
        title: 'Portal do Cliente com Self-Service',
        description: 'Portal de pedidos, notas e segunda via de boletos',
        phase: 3,
        phase_name: 'Fase 3 — Transformação',
        priority: 5,
        timeline_weeks: 8,
        status: 'pendente',
      },
      {
        title: 'Otimização de Rotas e Telemetria',
        description: 'Roteirização inteligente e sensores de temperatura',
        phase: 3,
        phase_name: 'Fase 3 — Transformação',
        priority: 6,
        timeline_weeks: 10,
        status: 'pendente',
      },
    ]

    for (const rmData of roadmapData) {
      const rec = new Record(rmCol)
      rec.set('diagnostic', diag.id)
      for (const key in rmData) {
        rec.set(key, rmData[key])
      }
      app.save(rec)
    }
  },
  (app) => {},
)
