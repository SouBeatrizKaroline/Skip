import { Link, useLocation } from 'react-router-dom'
import {
  Shield,
  LayoutDashboard,
  FileCheck,
  History,
  Cpu,
  Settings,
  Scale,
  FileText,
  Puzzle,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/validate', label: 'Validar Documento', icon: FileCheck },
  { to: '/history', label: 'Historico', icon: History },
  { to: '/engine', label: 'API/Motor AI', icon: Cpu },
  { to: '/settings', label: 'Configuracoes', icon: Settings },
  { to: '/compliance', label: 'Compliance', icon: Scale },
  { to: '/terms', label: 'Termos & LGPD', icon: FileText },
  { to: '/extension', label: 'Extensao', icon: Puzzle },
]

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation()

  return (
    <div className="flex flex-col h-full">
      <div className="h-14 flex items-center gap-2 px-4 border-b border-sidebar-border shrink-0">
        <Shield className="h-6 w-6 text-primary" />
        <span className="font-bold text-foreground">ShadowGuard</span>
      </div>
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive =
            location.pathname === item.to || location.pathname.startsWith(item.to + '/')
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors',
                isActive
                  ? 'bg-primary/10 text-primary font-medium'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent',
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
