import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { STATUS_COLORS, STATUS_LABELS } from '@/lib/format'

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const colorClass = STATUS_COLORS[status] || 'bg-gray-500/15 text-gray-400 border-gray-500/30'
  const label = STATUS_LABELS[status] || status
  return (
    <Badge variant="outline" className={cn('border font-medium', colorClass, className)}>
      {label}
    </Badge>
  )
}
