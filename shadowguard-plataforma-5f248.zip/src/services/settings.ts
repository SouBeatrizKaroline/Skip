const STORAGE_KEY = 'shadowguard_settings'

export interface UserSettings {
  notifications: { email: boolean; webhook: string }
  dataRetention: number
  preferences: { language: string; timezone: string; theme: string }
}

const defaultSettings: UserSettings = {
  notifications: { email: true, webhook: '' },
  dataRetention: 30,
  preferences: { language: 'pt-BR', timezone: 'America/Sao_Paulo', theme: 'dark' },
}

export const getSettings = (): UserSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? { ...defaultSettings, ...JSON.parse(raw) } : defaultSettings
  } catch {
    return defaultSettings
  }
}

export const saveSettings = (settings: UserSettings) =>
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))

export const generateApiKey = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(16)))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
