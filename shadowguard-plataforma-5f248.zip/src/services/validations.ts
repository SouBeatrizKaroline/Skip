import pb from '@/lib/pocketbase/client'

export const DOC_TYPES = ['CPF', 'RG', 'CNH', 'Passaporte', 'Comprovante', 'Contrato', 'Outro']

export const CHECK_LABELS = [
  { key: 'check_structure', label: 'Estrutura' },
  { key: 'check_format', label: 'Formato' },
  { key: 'check_ocr', label: 'OCR' },
  { key: 'check_consistency', label: 'Consistência' },
  { key: 'check_fraud', label: 'Fraude' },
  { key: 'check_database', label: 'Base de Dados' },
]

export interface ValidationRecord {
  id: string
  created: string
  updated: string
  owner: string
  document_type: string
  title_cpf: string
  extracted_content: string
  check_structure: string
  check_format: string
  check_ocr: string
  check_consistency: string
  check_fraud: string
  check_database: string
  confidence_score: number
  status: string
  engine_version: string
  processing_time: number
  document_file?: string
}

export interface ValidationResult {
  extracted_content: string
  check_structure: string
  check_format: string
  check_ocr: string
  check_consistency: string
  check_fraud: string
  check_database: string
  confidence_score: number
  status: string
  engine_version: string
  processing_time: number
}

const mapRecord = (r: any): ValidationRecord => ({
  id: r.id,
  created: r.created,
  updated: r.updated,
  owner: r.owner || '',
  document_type: r.document_type || '',
  title_cpf: r.title_cpf || '',
  extracted_content: r.extracted_content || '',
  check_structure: r.check_structure || 'WARN',
  check_format: r.check_format || 'WARN',
  check_ocr: r.check_ocr || 'WARN',
  check_consistency: r.check_consistency || 'WARN',
  check_fraud: r.check_fraud || 'WARN',
  check_database: r.check_database || 'WARN',
  confidence_score: r.confidence_score || 0,
  status: r.status || 'ATENCAO',
  engine_version: r.engine_version || 'ShadowGuard AI v2.1',
  processing_time: r.processing_time || 0,
  document_file: r.document_file,
})

export const getApiStatus = async () => {
  return pb.send('/backend/v1/status', { method: 'GET' })
}

export const deleteAllValidations = async (ownerId: string) => {
  const records = await pb.collection('validations').getFullList({
    filter: `owner = "${ownerId}"`,
  })
  await Promise.all(records.map((r) => pb.collection('validations').delete(r.id)))
}

export const getValidations = async (page: number, perPage: number, filter?: string) => {
  const res = await pb.collection('validations').getList(page, perPage, {
    filter: filter || '',
    sort: '-created',
  })
  return {
    items: res.items.map(mapRecord),
    totalPages: res.totalPages,
  }
}

export const getAllValidations = async (filter?: string): Promise<ValidationRecord[]> => {
  const records = await pb.collection('validations').getFullList({
    filter: filter || '',
    sort: '-created',
  })
  return records.map(mapRecord)
}

export const getValidation = async (id: string): Promise<ValidationRecord> => {
  const record = await pb.collection('validations').getOne(id)
  return mapRecord(record)
}

export const createValidation = async (data: FormData | Record<string, any>) => {
  return pb.collection('validations').create(data)
}

export const deleteValidation = async (id: string) => {
  return pb.collection('validations').delete(id)
}

export const validateDocument = async (data: {
  document_type: string
  content: string
}): Promise<ValidationResult> => {
  return pb.send('/backend/v1/validate-document', {
    method: 'POST',
    body: JSON.stringify(data),
    headers: { 'Content-Type': 'application/json' },
  })
}
