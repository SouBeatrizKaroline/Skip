import { Link } from 'react-router-dom'
import { Shield, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Terms() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Shield className="h-7 w-7 text-primary" />
          <span className="text-xl font-bold">ShadowGuard</span>
        </div>
        <Button variant="ghost" asChild>
          <Link to="/">
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Link>
        </Button>
      </nav>

      <article className="max-w-3xl mx-auto px-6 py-12 space-y-8">
        <header className="space-y-2">
          <h1 className="text-3xl font-bold">Termos de Serviço</h1>
          <p className="text-sm text-muted-foreground">
            Última atualização: {new Date().toLocaleDateString('pt-BR')}
          </p>
        </header>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">1. Aceitação dos Termos</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Ao acessar e utilizar a plataforma ShadowGuard, você concorda com os termos e condições
            descritos neste documento. Caso não concorde com qualquer parte destes termos, não
            utilize a plataforma.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">2. Descrição do Serviço</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A ShadowGuard é uma plataforma de validação e auditoria de documentos com inteligência
            artificial, incluindo extensão Chrome, motor de API e dashboard web, com conformidade
            legal e foco em MVP testável. O serviço analisa documentos em múltiplas camadas:
            estrutura, formato, OCR, consistência, fraude e base de dados.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">3. Uso Permitido</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Você concorda em utilizar a plataforma apenas para fins legítimos e em conformidade com
            todas as leis e regulamentos aplicáveis, incluindo a LGPD (Lei Geral de Proteção de
            Dados), o Marco Civil da Internet e o Código de Defesa do Consumidor. É proibido
            utilizar a plataforma para qualquer atividade ilegal ou não autorizada.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">4. Privacidade e Proteção de Dados</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A ShadowGuard está em conformidade com a LGPD, ISO 27001 e demais frameworks de proteção
            de dados. Seus dados pessoais são tratados de acordo com nossa Política de Privacidade.
            Não compartilhamos seus dados com terceiros sem seu consentimento explícito.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">5. Limitação de Responsabilidade</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A ShadowGuard fornece a plataforma "como está" sem garantias de qualquer tipo. A análise
            de documentos é realizada por inteligência artificial e pode conter imprecisões. A
            responsabilidade final pela validação e decisão sobre qualquer documento reside
            exclusivamente com o usuário. A ShadowGuard não se responsabiliza por danos diretos ou
            indiretos resultantes do uso da plataforma.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">6. Propriedade Intelectual</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Todo o conteúdo, código, design e recursos da plataforma ShadowGuard são protegidos por
            direitos autorais e outras leis de propriedade intelectual. Você não pode copiar,
            modificar ou distribuir qualquer parte da plataforma sem autorização prévia por escrito.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">7. Encerramento de Conta</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Você pode encerrar sua conta a qualquer momento. A ShadowGuard reserva-se o direito de
            suspender ou encerrar contas que violem estes Termos de Serviço ou que apresentem
            atividades suspeitas ou fraudulentas.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">8. Alterações dos Termos</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A ShadowGuard pode atualizar estes Termos de Serviço periodicamente. Notificaremos os
            usuários sobre alterações significativas. O uso continuado da plataforma após as
            alterações constitui aceitação dos novos termos.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">9. Contato</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Para questões sobre estes Termos de Serviço, entre em contato através do email de
            suporte da plataforma.
          </p>
        </section>

        <footer className="border-t border-border pt-6 text-center text-sm text-muted-foreground">
          <Link to="/" className="text-primary hover:underline">
            Voltar para a página inicial
          </Link>
        </footer>
      </article>
    </div>
  )
}
