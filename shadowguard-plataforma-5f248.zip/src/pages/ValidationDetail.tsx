import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Trash2, Loader2, ShieldCheck } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { StatusBadge } from '@/components/StatusBadge'
import { getValidation, deleteValidation, CHECK_LABELS } from '@/services/validations'
import { formatDate, maskSensitiveData } from '@/lib/format'
import { useToast } from '@/hooks/use-toast'
import type { ValidationRecord } from '@/services/validations'

export default function ValidationDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [record, setRecord] = useState<ValidationRecord | null>(null)
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    if (!id) return
    getValidation(id)
      .then((r) => setRecord(r))
      .catch(() => setRecord(null))
      .finally(() => setLoading(false))
  }, [id])

  const handleDelete = async () => {
    if (!id) return
    setDeleting(true)
    try {
      await deleteValidation(id)
      toast({ title: 'Validacao excluida' })
      navigate('/history')
    } catch {
      toast({ title: 'Erro ao excluir', variant: 'destructive' })
    } finally {
      setDeleting(false)
    }
  }

  if (loading)
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  if (!record)
    return (
      <div className="text-center py-12 space-y-4">
        <p className="text-muted-foreground">Validacao nao encontrada</p>
        <Button variant="outline" asChild>
          <Link to="/history">Voltar</Link>
        </Button>
      </div>
    )

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate('/history')}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
        <Button variant="destructive" size="sm" onClick={handleDelete} disabled={deleting}>
          {deleting ? (
            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
          ) : (
            <Trash2 className="h-4 w-4 mr-1" />
          )}{' '}
          Excluir
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>{record.title_cpf}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {record.document_type} | {formatDate(record.created)}
              </p>
            </div>
            <StatusBadge status={record.status} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Score de Confianca</span>
              <span className="font-medium">{record.confidence_score}/100</span>
            </div>
            <Progress value={record.confidence_score} className="h-2" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {CHECK_LABELS.map((check) => (
              <div
                key={check.key}
                className="flex items-center justify-between p-3 rounded-lg border border-border"
              >
                <span className="text-sm">{check.label}</span>
                <StatusBadge status={(record as any)[check.key]} />
              </div>
            ))}
          </div>

          {record.extracted_content && (
            <div>
              <h3 className="text-sm font-medium mb-2">Conteudo Extraido (dados mascarados)</h3>
              <div className="p-3 rounded-lg border border-border bg-muted/30 text-sm text-muted-foreground max-h-48 overflow-y-auto">
                {maskSensitiveData(record.extracted_content)}
              </div>
            </div>
          )}

          <div className="pt-2 border-t border-border flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-primary" />
            <p className="text-xs text-muted-foreground">
              {record.engine_version} | Analise em {record.processing_time?.toFixed(1)}s |
              Framework: LGPD + ISO 27001
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
