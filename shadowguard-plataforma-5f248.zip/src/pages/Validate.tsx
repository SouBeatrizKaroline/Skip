import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Upload, FileText, Link2, Loader2, CloudUpload } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Card, CardContent } from '@/components/ui/card'
import { StatusBadge } from '@/components/StatusBadge'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/hooks/use-auth'
import { validateDocument, createValidation, CHECK_LABELS, DOC_TYPES } from '@/services/validations'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import type { ValidationResult } from '@/services/validations'

export default function Validate() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { user } = useAuth()
  const [docType, setDocType] = useState('CPF')
  const [title, setTitle] = useState('')
  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<(ValidationResult & { id: string }) | null>(null)

  const handleSubmit = async () => {
    let content = text
    if (file) {
      content = file.type.startsWith('text/') ? await file.text() : `Arquivo: ${file.name}`
    } else if (url) {
      content = url
    }
    if (!content.trim() || !title.trim()) {
      toast({
        title: 'Campos obrigatorios',
        description: 'Preencha o titulo e o conteudo.',
        variant: 'destructive',
      })
      return
    }
    setLoading(true)
    try {
      const res = await validateDocument({ document_type: docType, content })
      const formData = new FormData()
      formData.append('owner', user?.id || '')
      formData.append('document_type', docType)
      formData.append('title_cpf', title)
      formData.append('extracted_content', res.extracted_content || content.substring(0, 500))
      formData.append('check_structure', res.check_structure)
      formData.append('check_format', res.check_format)
      formData.append('check_ocr', res.check_ocr)
      formData.append('check_consistency', res.check_consistency)
      formData.append('check_fraud', res.check_fraud)
      formData.append('check_database', res.check_database)
      formData.append('confidence_score', String(res.confidence_score))
      formData.append('status', res.status)
      formData.append('engine_version', res.engine_version)
      formData.append('processing_time', String(res.processing_time))
      if (file) formData.append('document_file', file)
      const record = await createValidation(formData)
      setResult({ ...res, id: record.id })
      toast({ title: 'Validacao concluida', description: 'Documento analisado com sucesso.' })
    } catch (error) {
      toast({
        title: 'Erro na validacao',
        description: getErrorMessage(error),
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Validar Documento</h1>
        <p className="text-sm text-muted-foreground">Analise em 6 camadas com IA</p>
      </div>

      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Tipo de Documento</Label>
              <Select value={docType} onValueChange={setDocType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DOC_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Titulo / CPF</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Joao Silva ou 123.456.789-00"
              />
            </div>
          </div>

          <Tabs defaultValue="file">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="file">
                <Upload className="h-4 w-4 mr-1" /> Arquivo
              </TabsTrigger>
              <TabsTrigger value="text">
                <FileText className="h-4 w-4 mr-1" /> Texto
              </TabsTrigger>
              <TabsTrigger value="url">
                <Link2 className="h-4 w-4 mr-1" /> URL
              </TabsTrigger>
            </TabsList>
            <TabsContent value="file" className="mt-4">
              <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-lg p-8 cursor-pointer hover:border-primary transition-colors">
                <CloudUpload className="h-10 w-10 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  {file ? file.name : 'Clique ou arraste um arquivo'}
                </span>
                <input
                  type="file"
                  className="hidden"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  accept="image/*,.txt,.pdf"
                />
              </label>
            </TabsContent>
            <TabsContent value="text" className="mt-4">
              <Textarea
                rows={6}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Cole o conteudo do documento aqui..."
              />
            </TabsContent>
            <TabsContent value="url" className="mt-4">
              <Input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://exemplo.com/documento.pdf"
              />
            </TabsContent>
          </Tabs>

          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold"
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {loading ? 'Validando...' : 'VALIDAR DOCUMENTO'}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className="animate-fade-in-up">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Resultados da Analise</h2>
              <StatusBadge status={result.status} />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Score de Confianca</span>
                <span className="font-medium">{result.confidence_score}/100</span>
              </div>
              <Progress value={result.confidence_score} className="h-2" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CHECK_LABELS.map((check) => (
                <div
                  key={check.key}
                  className="flex items-center justify-between p-3 rounded-lg border border-border"
                >
                  <span className="text-sm">{check.label}</span>
                  <StatusBadge status={(result as any)[check.key]} />
                </div>
              ))}
            </div>
            <div className="pt-2 border-t border-border space-y-2">
              <p className="text-xs text-muted-foreground">
                Analise realizada em {result.processing_time?.toFixed(1)}s | Framework: LGPD + ISO
                27001
              </p>
              <Button variant="outline" size="sm" onClick={() => navigate(`/history/${result.id}`)}>
                Ver Detalhes no Historico
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
