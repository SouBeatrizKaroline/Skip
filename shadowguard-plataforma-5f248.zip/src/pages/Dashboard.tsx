import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { FileCheck, AlertTriangle, XCircle, TrendingUp, Plus, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { StatusBadge } from '@/components/StatusBadge'
import { getValidations } from '@/services/validations'
import { useRealtime } from '@/hooks/use-realtime'
import { formatDate } from '@/lib/format'
import type { ValidationRecord } from '@/services/validations'

export default function Dashboard() {
  const [records, setRecords] = useState<ValidationRecord[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    try {
      const res = await getValidations(1, 5)
      setRecords(res.items as unknown as ValidationRecord[])
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])
  useRealtime('validations', () => {
    loadData()
  })

  const stats = {
    total: records.length,
    valid: records.filter((r) => r.status === 'VALIDO').length,
    attention: records.filter((r) => r.status === 'ATENCAO').length,
    invalid: records.filter((r) => r.status === 'INVALIDO').length,
  }

  const statCards = [
    { label: 'Total', value: stats.total, icon: FileCheck, color: 'text-blue-400' },
    { label: 'Validos', value: stats.valid, icon: TrendingUp, color: 'text-green-400' },
    { label: 'Atencao', value: stats.attention, icon: AlertTriangle, color: 'text-yellow-400' },
    { label: 'Invalidos', value: stats.invalid, icon: XCircle, color: 'text-red-400' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Visao geral das validacoes</p>
        </div>
        <Button asChild>
          <Link to="/validate">
            <Plus className="h-4 w-4 mr-2" />
            Nova Validacao
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                  <p className="text-2xl font-bold">{s.value}</p>
                </div>
                <s.icon className={`h-8 w-8 ${s.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" /> Ultimas Validacoes
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-sm text-muted-foreground text-center py-8">Carregando...</p>
          ) : records.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground mb-3">Nenhuma validacao encontrada</p>
              <Button asChild variant="outline">
                <Link to="/validate">Criar primeira validacao</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {records.map((r) => (
                <Link
                  key={r.id}
                  to={`/history/${r.id}`}
                  className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{r.title_cpf}</p>
                      <p className="text-xs text-muted-foreground">
                        {r.document_type} - {formatDate(r.created)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm text-muted-foreground hidden sm:inline">
                      {r.confidence_score}/100
                    </span>
                    <StatusBadge status={r.status} />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
