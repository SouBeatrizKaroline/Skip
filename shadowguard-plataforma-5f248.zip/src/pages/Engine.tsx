import { useState, useEffect } from 'react'
import { Activity, Cpu, Clock, Zap, Play, Loader2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { getApiStatus } from '@/services/validations'
import { useToast } from '@/hooks/use-toast'
import pb from '@/lib/pocketbase/client'

const ENDPOINTS = [
  {
    method: 'POST',
    path: '/validate',
    desc: 'Valida documento e retorna 6 camadas de analise',
    auth: 'Token API',
  },
  { method: 'GET', path: '/history', desc: 'Lista historico de validacoes', auth: 'Token API' },
  { method: 'POST', path: '/ocr', desc: 'Extrai texto de imagem/documento', auth: 'Token API' },
  { method: 'GET', path: '/status', desc: 'Status do motor de IA', auth: 'Token API' },
]

export default function Engine() {
  const { toast } = useToast()
  const [status, setStatus] = useState<any>(null)
  const [testInput, setTestInput] = useState('')
  const [testResult, setTestResult] = useState<any>(null)
  const [testing, setTesting] = useState(false)

  useEffect(() => {
    getApiStatus()
      .then(setStatus)
      .catch(() => setStatus(null))
  }, [])

  const handleTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const res = await pb.send('/backend/v1/status', { method: 'GET' })
      setTestResult({ success: true, data: res })
    } catch (err: any) {
      setTestResult({ success: false, error: err.message || 'Erro ao testar endpoint' })
    } finally {
      setTesting(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">API / Motor AI</h1>
        <p className="text-sm text-muted-foreground">Status e documentacao da API</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Status do Motor</span>
              <Badge
                variant="outline"
                className={
                  status
                    ? 'bg-green-500/15 text-green-400 border-green-500/30'
                    : 'bg-red-500/15 text-red-400 border-red-500/30'
                }
              >
                {status ? 'Online' : 'Offline'}
              </Badge>
            </div>
            <Activity className="h-8 w-8 text-primary" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Versao</p>
            <p className="text-lg font-bold">{status?.version || 'ShadowGuard v1.0'}</p>
            <Cpu className="h-6 w-6 text-muted-foreground mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Latencia Media</p>
            <p className="text-lg font-bold">{status?.avg_latency_ms || 245}ms</p>
            <Clock className="h-6 w-6 text-muted-foreground mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Documentacao da API</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {ENDPOINTS.map((ep) => (
                <div
                  key={ep.path}
                  className="flex items-center gap-3 p-2 rounded-lg border border-border"
                >
                  <Badge
                    variant="outline"
                    className={
                      ep.method === 'GET'
                        ? 'bg-blue-500/15 text-blue-400'
                        : 'bg-green-500/15 text-green-400'
                    }
                  >
                    {ep.method}
                  </Badge>
                  <code className="text-sm flex-1">{ep.path}</code>
                  <span className="text-xs text-muted-foreground hidden sm:inline">{ep.desc}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Playground de Teste</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              rows={4}
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="Digite o payload JSON para testar..."
            />
            <Button onClick={handleTest} disabled={testing} className="w-full">
              {testing ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              {testing ? 'Testando...' : 'Testar Endpoint'}
            </Button>
            {testResult && (
              <div className="p-3 rounded-lg border border-border bg-muted/30 text-sm overflow-x-auto">
                <pre className="text-xs">{JSON.stringify(testResult, null, 2)}</pre>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Metricas de Performance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Documentos/dia</span>
              <span>{status?.docs_per_day || 1247}</span>
            </div>
            <Progress value={75} className="h-2" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Taxa de Erro</span>
              <span>{status?.error_rate || 0.3}%</span>
            </div>
            <Progress value={3} className="h-2" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Tempo Medio de Processamento</span>
              <span>{status?.avg_processing_time || 1.8}s</span>
            </div>
            <Progress value={60} className="h-2" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
