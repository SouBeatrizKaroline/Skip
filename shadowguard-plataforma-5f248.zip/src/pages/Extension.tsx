import { Link } from 'react-router-dom'
import { Shield, ArrowLeft, Chrome, CheckCircle2, Download, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Extension() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Shield className="h-7 w-7 text-primary" />
          <span className="text-xl font-bold">ShadowGuard</span>
        </div>
        <Button variant="ghost" asChild>
          <Link to="/">
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Link>
        </Button>
      </nav>

      <section className="max-w-3xl mx-auto px-6 py-12 space-y-8">
        <header className="space-y-3 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm animate-fade-in">
            <Chrome className="h-4 w-4" /> Extensão para Navegador
          </div>
          <h1 className="text-3xl font-bold animate-fade-in-up">Extensão ShadowGuard</h1>
          <p className="text-sm text-muted-foreground max-w-xl mx-auto">
            A extensão oficial do ShadowGuard para Google Chrome permite validar e audir documentos
            diretamente do seu navegador, sem precisar abrir uma nova aba. Analise documentos em
            tempo real com o motor de IA de 6 camadas do ShadowGuard.
          </p>
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            {
              icon: Zap,
              title: 'Validação Instantânea',
              desc: 'Analise documentos com um clique diretamente na página que você está visualizando.',
            },
            {
              icon: CheckCircle2,
              title: '6 Camadas de Análise',
              desc: 'Estrutura, formato, OCR, consistência, fraude e base de dados — tudo no navegador.',
            },
            {
              icon: Shield,
              title: 'Conformidade LGPD',
              desc: 'Todos os dados são processados em conformidade com a LGPD e ISO 27001.',
            },
          ].map((f) => (
            <div key={f.title} className="p-6 rounded-xl border border-border bg-card text-left">
              <f.icon className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
          <Button size="lg" asChild>
            <span>
              <Download className="h-4 w-4 mr-2" /> Em breve na Chrome Web Store
            </span>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/signup">Criar Conta ShadowGuard</Link>
          </Button>
        </div>

        <div className="rounded-xl border border-border bg-muted/30 p-6 space-y-2">
          <h2 className="text-lg font-semibold">Como funciona</h2>
          <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
            <li>Instale a extensão ShadowGuard na Chrome Web Store</li>
            <li>Faça login com sua conta ShadowGuard</li>
            <li>Clique no ícone do ShadowGuard enquanto visualiza um documento</li>
            <li>Receba o resultado da análise com score de confiança em segundos</li>
          </ol>
        </div>

        <footer className="border-t border-border pt-6 text-center text-sm text-muted-foreground">
          <Link to="/" className="text-primary hover:underline">
            Voltar para a página inicial
          </Link>
        </footer>
      </section>
    </div>
  )
}
