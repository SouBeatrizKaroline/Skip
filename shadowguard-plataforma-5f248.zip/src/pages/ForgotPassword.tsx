import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Shield, Loader2, MailCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import { getErrorMessage } from '@/lib/pocketbase/errors'

export default function ForgotPassword() {
  const { requestPasswordReset } = useAuth()
  const { toast } = useToast()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await requestPasswordReset(email)
    setLoading(false)
    if (error) {
      toast({ title: 'Erro', description: getErrorMessage(error), variant: 'destructive' })
    } else {
      setSent(true)
      toast({ title: 'E-mail enviado', description: 'Verifique sua caixa de entrada.' })
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <Shield className="h-12 w-12 text-primary mx-auto mb-3" />
          <h1 className="text-2xl font-bold">Recuperar Senha</h1>
          <p className="text-sm text-muted-foreground mt-1">Enviaremos um link para seu e-mail</p>
        </div>
        {sent ? (
          <div className="text-center space-y-4">
            <MailCheck className="h-12 w-12 text-green-500 mx-auto" />
            <p className="text-muted-foreground">
              Um e-mail com instrucoes foi enviado para{' '}
              <span className="text-foreground font-medium">{email}</span>
            </p>
            <Button variant="outline" asChild>
              <Link to="/login">Voltar para Login</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {loading ? 'Enviando...' : 'Enviar Link'}
            </Button>
          </form>
        )}
        <p className="text-center text-sm text-muted-foreground">
          <Link to="/login" className="text-primary hover:underline">
            Voltar para Login
          </Link>
        </p>
      </div>
    </div>
  )
}
