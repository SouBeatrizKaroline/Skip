import { Shield, FileDown } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'

interface Framework {
  name: string
  articles: string
  status: 'Total' | 'Parcial' | 'N/A'
  lastAudit: string
}

const FRAMEWORKS: Framework[] = [
  { name: 'LGPD', articles: 'Art. 7, 18, 20', status: 'Total', lastAudit: '15/07/2026' },
  { name: 'Marco Civil', articles: 'Art. 7, 11', status: 'Total', lastAudit: '10/07/2026' },
  { name: 'CDC', articles: 'Art. 6, 51', status: 'Total', lastAudit: '12/07/2026' },
  { name: 'ISO 27001', articles: 'A.5-A.18', status: 'Total', lastAudit: '01/07/2026' },
  { name: 'ISO 27701', articles: 'A.1-A.8', status: 'Parcial', lastAudit: '05/07/2026' },
  { name: 'COPPA', articles: '15 U.S.C. 6501', status: 'N/A', lastAudit: 'N/A' },
  { name: 'CCPA', articles: '1798.100-1798.199', status: 'Parcial', lastAudit: '08/07/2026' },
  { name: 'GDPR', articles: 'Art. 5-49', status: 'Parcial', lastAudit: '08/07/2026' },
  {
    name: 'Chrome Web Store',
    articles: 'Developer Policy',
    status: 'Total',
    lastAudit: '20/07/2026',
  },
  { name: 'ICP-Brasil', articles: 'ITI Prov. 01', status: 'Total', lastAudit: '18/07/2026' },
  { name: 'CVM', articles: 'Instrucao 481', status: 'Parcial', lastAudit: '14/07/2026' },
  { name: 'COAF', articles: 'Lei 9.613/98', status: 'Total', lastAudit: '16/07/2026' },
]

const STATUS_BADGE: Record<string, string> = {
  Total: 'bg-green-500/15 text-green-400 border-green-500/30',
  Parcial: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  'N/A': 'bg-gray-500/15 text-gray-400 border-gray-500/30',
}

const STATUS_LABEL: Record<string, string> = {
  Total: 'Conformidade Total',
  Parcial: 'Conformidade Parcial',
  'N/A': 'Nao Aplicavel',
}

export default function Compliance() {
  const compliant = FRAMEWORKS.filter((f) => f.status === 'Total').length
  const percentage = Math.round((compliant / FRAMEWORKS.length) * 100)

  const generateReport = () => {
    const win = window.open('', '_blank')
    if (!win) return
    const rows = FRAMEWORKS.map(
      (f) =>
        `<tr><td>${f.name}</td><td>${STATUS_LABEL[f.status]}</td><td>${f.articles}</td><td>${f.status === 'Parcial' ? 'Adequar controles pendentes' : f.status === 'N/A' ? 'N/A' : 'Manter conformidade'}</td><td>${f.lastAudit}</td></tr>`,
    ).join('')
    win.document.write(
      `<html><head><title>ShadowGuard - Relatorio de Compliance</title><style>body{font-family:sans-serif;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#f4f4f4}</style></head><body><h1>Relatorio de Compliance - ShadowGuard</h1><p>Data: ${new Date().toLocaleDateString('pt-BR')}</p><table><tr><th>Framework</th><th>Status</th><th>Artigos</th><th>Acao Necessaria</th><th>Ultima Auditoria</th></tr>${rows}</table></body></html>`,
    )
    win.document.close()
    setTimeout(() => win.print(), 500)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Compliance</h1>
          <p className="text-sm text-muted-foreground">Conformidade legal e regulatoria</p>
        </div>
        <Button onClick={generateReport}>
          <FileDown className="h-4 w-4 mr-2" /> Gerar Relatorio de Compliance
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-medium">Conformidade Geral</span>
            </div>
            <span className="text-2xl font-bold text-primary">{percentage}%</span>
          </div>
          <Progress value={percentage} className="h-3" />
          <p className="text-xs text-muted-foreground mt-2">
            {compliant} de {FRAMEWORKS.length} frameworks em conformidade total
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {FRAMEWORKS.map((f) => (
          <Card key={f.name}>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{f.name}</h3>
                <Badge variant="outline" className={STATUS_BADGE[f.status]}>
                  {STATUS_LABEL[f.status]}
                </Badge>
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>Artigos: {f.articles}</p>
                <p>Ultima auditoria: {f.lastAudit}</p>
              </div>
              <Button variant="outline" size="sm" className="w-full">
                Ver Detalhes
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
