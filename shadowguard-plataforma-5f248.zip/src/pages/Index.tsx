import { Navigate, Link } from 'react-router-dom'
import { Shield, ArrowRight, CheckCircle2, Lock, Zap, FileSearch } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/hooks/use-auth'

export default function Index() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) return null
  if (isAuthenticated) return <Navigate to="/dashboard" replace />

  return (
    <div className="min-h-screen bg-background text-foreground">
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Shield className="h-7 w-7 text-primary" />
          <span className="text-xl font-bold">ShadowGuard</span>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" asChild>
            <Link to="/login">Entrar</Link>
          </Button>
          <Button asChild>
            <Link to="/signup">Criar Conta</Link>
          </Button>
        </div>
      </nav>

      <section className="max-w-4xl mx-auto px-6 py-20 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm mb-6 animate-fade-in">
          <CheckCircle2 className="h-4 w-4" /> Plataforma de Auditoria de Documentos com IA
        </div>
        <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in-up">
          Validacao de documentos com <span className="text-primary">IA</span> e conformidade legal
        </h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          ShadowGuard analisa documentos em 6 camadas: estrutura, formato, OCR, consistencia, fraude
          e base de dados. Conformidade LGPD, ISO 27001 e mais.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button size="lg" asChild>
            <Link to="/signup">
              Comecar Agora <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/login">Ja tenho conta</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-16">
          {[
            {
              icon: FileSearch,
              title: '6 Camadas de Analise',
              desc: 'Estrutura, formato, OCR, consistencia, fraude e base de dados',
            },
            {
              icon: Lock,
              title: 'Conformidade Total',
              desc: 'LGPD, ISO 27001, Marco Civil, CDC e mais',
            },
            {
              icon: Zap,
              title: 'Resultados em Segundos',
              desc: 'Motor de IA com score de confianca de 0-100',
            },
          ].map((f) => (
            <div key={f.title} className="p-6 rounded-xl border border-border bg-card text-left">
              <f.icon className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-6 text-center text-sm text-muted-foreground">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4">
          <span>ShadowGuard v1.0 | LGPD + ISO 27001 | {new Date().getFullYear()}</span>
          <Link to="/extension" className="text-primary hover:underline">
            Extensão
          </Link>
          <Link to="/terms" className="text-primary hover:underline">
            Termos de Serviço
          </Link>
        </div>
      </footer>
    </div>
  )
}
