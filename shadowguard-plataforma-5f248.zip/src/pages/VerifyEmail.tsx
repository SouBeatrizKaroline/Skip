import { useState, useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Shield, Loader2, CheckCircle2, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/hooks/use-auth'

export default function VerifyEmail() {
  const { confirmEmailVerification } = useAuth()
  const [params] = useSearchParams()
  const token = params.get('token') || ''
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading')

  useEffect(() => {
    if (!token) {
      setStatus('error')
      return
    }
    confirmEmailVerification(token).then(({ error }) => {
      setStatus(error ? 'error' : 'success')
    })
  }, [token])

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-6 text-center">
        <Shield className="h-12 w-12 text-primary mx-auto" />
        {status === 'loading' && (
          <>
            <Loader2 className="h-10 w-10 text-primary mx-auto animate-spin" />
            <p className="text-muted-foreground">Verificando e-mail...</p>
          </>
        )}
        {status === 'success' && (
          <>
            <CheckCircle2 className="h-10 w-10 text-green-500 mx-auto" />
            <h1 className="text-xl font-bold">E-mail verificado!</h1>
            <p className="text-muted-foreground">Sua conta foi confirmada com sucesso.</p>
            <Button asChild>
              <Link to="/dashboard">Ir para Dashboard</Link>
            </Button>
          </>
        )}
        {status === 'error' && (
          <>
            <XCircle className="h-10 w-10 text-red-500 mx-auto" />
            <h1 className="text-xl font-bold">Erro na verificacao</h1>
            <p className="text-muted-foreground">O token pode ter expirado ou ser invalido.</p>
            <Button variant="outline" asChild>
              <Link to="/login">Voltar para Login</Link>
            </Button>
          </>
        )}
      </div>
    </div>
  )
}
