import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Loader2, Copy, RefreshCw, Trash2, Shield } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import { getSettings, saveSettings, generateApiKey } from '@/services/settings'
import { deleteAllValidations } from '@/services/validations'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import pb from '@/lib/pocketbase/client'

export default function Settings() {
  const { user, signOut, refreshUser } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()
  const [name, setName] = useState(user?.name || '')
  const [company, setCompany] = useState(user?.company || '')
  const [email, setEmail] = useState(user?.email || '')
  const [loading, setLoading] = useState(false)
  const [apiKey, setApiKey] = useState(user?.api_key || '')
  const [settings, setSettings] = useState(getSettings())
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')

  useEffect(() => {
    if (!user?.api_key) {
      const key = generateApiKey()
      pb.collection('users')
        .update(user.id, { api_key: key })
        .then(() => {
          setApiKey(key)
          refreshUser()
        })
        .catch(() => {})
    }
  }, [user, refreshUser])

  const handleSaveProfile = async () => {
    setLoading(true)
    try {
      await pb.collection('users').update(user.id, { name, company })
      await refreshUser()
      toast({ title: 'Perfil salvo!' })
    } catch (err) {
      toast({ title: 'Erro', description: getErrorMessage(err), variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleEmailChange = async () => {
    setLoading(true)
    try {
      await pb.collection('users').requestEmailChange(email)
      toast({
        title: 'Confirmacao enviada',
        description: 'Verifique o novo e-mail para confirmar.',
      })
    } catch (err) {
      toast({ title: 'Erro', description: getErrorMessage(err), variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleChangePassword = async () => {
    setLoading(true)
    try {
      await pb.collection('users').authWithPassword(user.email, currentPassword)
      await pb
        .collection('users')
        .update(user.id, { password: newPassword, passwordConfirm: newPassword })
      toast({ title: 'Senha alterada!' })
      setCurrentPassword('')
      setNewPassword('')
    } catch (err) {
      toast({ title: 'Erro', description: getErrorMessage(err), variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSettings = (newSettings: typeof settings) => {
    setSettings(newSettings)
    saveSettings(newSettings)
    toast({ title: 'Configuracoes salvas!' })
  }

  const handleRegenerateKey = async () => {
    const key = generateApiKey()
    await pb.collection('users').update(user.id, { api_key: key })
    setApiKey(key)
    toast({ title: 'Chave regenerada!' })
  }

  const handleDeleteAccount = async () => {
    await deleteAllValidations(user.id)
    await pb.collection('users').delete(user.id)
    signOut()
    navigate('/')
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Configuracoes</h1>
        <p className="text-sm text-muted-foreground">Gerencie sua conta</p>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="security">Seguranca</TabsTrigger>
          <TabsTrigger value="notifications">Notif.</TabsTrigger>
          <TabsTrigger value="data">Dados</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
          <TabsTrigger value="prefs">Prefer.</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Nome</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Empresa</Label>
                <Input value={company} onChange={(e) => setCompany(e.target.value)} />
              </div>
              <Button onClick={handleSaveProfile} disabled={loading}>
                {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Salvar Perfil
              </Button>
              <div className="pt-4 border-t border-border space-y-2">
                <Label>E-mail (requer confirmacao)</Label>
                <div className="flex gap-2">
                  <Input value={email} onChange={(e) => setEmail(e.target.value)} />
                  <Button variant="outline" onClick={handleEmailChange} disabled={loading}>
                    Trocar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Senha Atual</Label>
                <Input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Nova Senha</Label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              <Button
                onClick={handleChangePassword}
                disabled={loading || !currentPassword || !newPassword}
              >
                {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Alterar Senha
              </Button>
              <div className="pt-4 border-t border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Autenticacao 2FA</Label>
                    <p className="text-xs text-muted-foreground">
                      Em breve / nao disponivel nesta versao
                    </p>
                  </div>
                  <Switch disabled />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Notificacoes por E-mail</Label>
                  <p className="text-xs text-muted-foreground">Receber alertas de validacao</p>
                </div>
                <Switch
                  checked={settings.notifications.email}
                  onCheckedChange={(v) =>
                    handleSaveSettings({
                      ...settings,
                      notifications: { ...settings.notifications, email: v },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Webhook URL</Label>
                <Input
                  value={settings.notifications.webhook}
                  onChange={(e) =>
                    handleSaveSettings({
                      ...settings,
                      notifications: { ...settings.notifications, webhook: e.target.value },
                    })
                  }
                  placeholder="https://..."
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Periodo de Retencao</Label>
                <Select
                  value={String(settings.dataRetention)}
                  onValueChange={(v) =>
                    handleSaveSettings({ ...settings, dataRetention: Number(v) })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 dias</SelectItem>
                    <SelectItem value="60">60 dias</SelectItem>
                    <SelectItem value="90">90 dias</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Apagar Meus Dados
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Isso ira excluir sua conta e todas as validacoes permanentemente.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteAccount}>
                      Confirmar Exclusao
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Chave API</Label>
                <div className="flex gap-2">
                  <Input readOnly value={apiKey} className="font-mono text-sm" />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      navigator.clipboard.writeText(apiKey)
                      toast({ title: 'Copiado!' })
                    }}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" onClick={handleRegenerateKey}>
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prefs">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Idioma</Label>
                <Select
                  value={settings.preferences.language}
                  onValueChange={(v) =>
                    handleSaveSettings({
                      ...settings,
                      preferences: { ...settings.preferences, language: v },
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pt-BR">Portugues (BR)</SelectItem>
                    <SelectItem value="en-US">English (US)</SelectItem>
                    <SelectItem value="es-ES">Espanol</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Fuso Horario</Label>
                <Select
                  value={settings.preferences.timezone}
                  onValueChange={(v) =>
                    handleSaveSettings({
                      ...settings,
                      preferences: { ...settings.preferences, timezone: v },
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/Sao_Paulo">America/Sao_Paulo</SelectItem>
                    <SelectItem value="America/New_York">America/New_York</SelectItem>
                    <SelectItem value="Europe/Lisbon">Europe/Lisbon</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Tema</Label>
                <Select
                  value={settings.preferences.theme}
                  onValueChange={(v) =>
                    handleSaveSettings({
                      ...settings,
                      preferences: { ...settings.preferences, theme: v },
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dark">Escuro</SelectItem>
                    <SelectItem value="light">Claro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
