import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  FileText,
  FileJson,
  FileType,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from '@/components/ui/table'
import { StatusBadge } from '@/components/StatusBadge'
import { getAllValidations, getValidations, DOC_TYPES } from '@/services/validations'
import { useRealtime } from '@/hooks/use-realtime'
import { formatDate, exportCSV, exportJSON, exportPDF } from '@/lib/format'
import type { ValidationRecord } from '@/services/validations'

const STATUS_OPTIONS = ['VALIDO', 'ATENCAO', 'INVALIDO']

export default function History() {
  const navigate = useNavigate()
  const [records, setRecords] = useState<ValidationRecord[]>([])
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterType, setFilterType] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  const buildFilter = useCallback(() => {
    const parts: string[] = []
    if (search) parts.push(`(title_cpf ~ "${search}" || document_type ~ "${search}")`)
    if (filterType) parts.push(`document_type = "${filterType}"`)
    if (filterStatus) parts.push(`status = "${filterStatus}"`)
    return parts.join(' && ')
  }, [search, filterType, filterStatus])

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const res = await getValidations(page, 10, buildFilter())
      setRecords(res.items as unknown as ValidationRecord[])
      setTotalPages(res.totalPages)
    } catch {
      setRecords([])
    } finally {
      setLoading(false)
    }
  }, [page, buildFilter])

  useEffect(() => {
    loadData()
  }, [loadData])
  useRealtime('validations', () => {
    loadData()
  })

  const handleExport = async (format: 'csv' | 'json' | 'pdf') => {
    const all = await getAllValidations(buildFilter())
    if (format === 'csv') exportCSV(all)
    else if (format === 'json') exportJSON(all)
    else exportPDF(all)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Historico</h1>
          <p className="text-sm text-muted-foreground">Todas as validacoes realizadas</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => handleExport('pdf')}>
            <FileText className="h-4 w-4 mr-1" /> PDF
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
            <FileType className="h-4 w-4 mr-1" /> CSV
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('json')}>
            <FileJson className="h-4 w-4 mr-1" /> JSON
          </Button>
          <Button size="sm" onClick={() => handleExport('csv')}>
            <Download className="h-4 w-4 mr-1" /> Exportar Todos
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Buscar por titulo, CPF, tipo..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(1)
                }}
              />
            </div>
            <Select
              value={filterType}
              onValueChange={(v) => {
                setFilterType(v === 'all' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                {DOC_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={filterStatus}
              onValueChange={(v) => {
                setFilterStatus(v === 'all' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                {STATUS_OPTIONS.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Titulo/CPF</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Motor AI</TableHead>
                  <TableHead>Acoes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : records.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      Nenhuma validacao encontrada
                    </TableCell>
                  </TableRow>
                ) : (
                  records.map((r) => (
                    <TableRow
                      key={r.id}
                      className="cursor-pointer hover:bg-accent"
                      onClick={() => navigate(`/history/${r.id}`)}
                    >
                      <TableCell className="whitespace-nowrap text-sm">
                        {formatDate(r.created)}
                      </TableCell>
                      <TableCell className="text-sm">{r.document_type}</TableCell>
                      <TableCell className="text-sm font-medium">{r.title_cpf}</TableCell>
                      <TableCell>
                        <StatusBadge status={r.status} />
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {r.engine_version}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            navigate(`/history/${r.id}`)
                          }}
                        >
                          Ver
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Pagina {page} de {totalPages}
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page <= 1}
                  onClick={() => setPage(page - 1)}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page >= totalPages}
                  onClick={() => setPage(page + 1)}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
