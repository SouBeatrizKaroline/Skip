import type { ValidationRecord } from '@/services/validations'

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr)
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatDateShort(dateStr: string): string {
  const d = new Date(dateStr)
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' })
}

export const STATUS_LABELS: Record<string, string> = {
  VALIDO: 'Valido',
  ATENCAO: 'Atencao',
  INVALIDO: 'Invalido',
}

export const STATUS_COLORS: Record<string, string> = {
  VALIDO: 'bg-green-500/15 text-green-400 border-green-500/30',
  ATENCAO: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  INVALIDO: 'bg-red-500/15 text-red-400 border-red-500/30',
}

export function maskSensitiveData(text: string): string {
  if (!text) return ''
  return text
    .replace(/\d{3}\.\d{3}\.\d{3}-\d{2}/g, '***.***.***-**')
    .replace(/\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}/g, '**.***.***/****-**')
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

export function exportCSV(data: ValidationRecord[]) {
  const headers = ['Data/Hora', 'Tipo', 'Titulo/CPF', 'Status', 'Motor AI', 'Score']
  const rows = data.map((v) => [
    formatDate(v.created),
    v.document_type,
    v.title_cpf,
    v.status,
    v.engine_version,
    String(v.confidence_score),
  ])
  const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n')
  downloadBlob(
    new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }),
    'validacoes_shadowguard.csv',
  )
}

export function exportJSON(data: ValidationRecord[]) {
  downloadBlob(
    new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }),
    'validacoes_shadowguard.json',
  )
}

export function exportPDF(data: ValidationRecord[]) {
  const win = window.open('', '_blank')
  if (!win) return
  const rows = data
    .map(
      (v) =>
        `<tr><td>${formatDate(v.created)}</td><td>${v.document_type}</td><td>${v.title_cpf}</td><td>${v.status}</td><td>${v.confidence_score}</td></tr>`,
    )
    .join('')
  win.document.write(
    `<html><head><title>ShadowGuard - Relatorio de Validacoes</title><style>body{font-family:sans-serif;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#f4f4f4}h1{color:#333}</style></head><body><h1>ShadowGuard - Relatorio de Validacoes</h1><table><tr><th>Data/Hora</th><th>Tipo</th><th>Titulo/CPF</th><th>Status</th><th>Score</th></tr>${rows}</table></body></html>`,
  )
  win.document.close()
  setTimeout(() => win.print(), 500)
}
