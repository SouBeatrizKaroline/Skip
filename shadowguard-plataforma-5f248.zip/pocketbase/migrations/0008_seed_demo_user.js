migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')

    let existing
    try {
      existing = app.findFirstRecordByData('users', 'email', 'jhay.dev@outlook.com')
    } catch (_) {
      existing = null
    }

    if (existing) {
      existing.setPassword('Skip@Pass')
      existing.setVerified(true)
      existing.set('name', 'Usuário Demo')
      app.save(existing)
      return
    }

    const record = new Record(users)
    record.setEmail('jhay.dev@outlook.com')
    record.setPassword('Skip@Pass')
    record.setVerified(true)
    record.set('name', 'Usuário Demo')
    app.save(record)
  },
  (app) => {
    try {
      const record = app.findFirstRecordByData('users', 'email', 'jhay.dev@outlook.com')
      app.delete(record)
    } catch (_) {}
  },
)
