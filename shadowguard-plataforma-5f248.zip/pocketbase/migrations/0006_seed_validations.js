migrate(
  (app) => {
    let adminUser
    try {
      adminUser = app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com')
    } catch (_) {
      return
    }

    const validations = app.findCollectionByNameOrId('validations')

    const seeds = [
      {
        document_title: 'Contrato de Prestação de Serviços - TechCorp Ltda',
        document_type: 'contract',
        source_url: '',
        status: 'approved',
        confidence_score: 94,
        summary:
          'Documento validado com sucesso. Todas as cláusulas estão conformes. Assinaturas digitais verificadas e integridade do documento confirmada.',
        risk_flags: '[]',
      },
      {
        document_title: 'Nota Fiscal Eletrônica #2024-01567',
        document_type: 'invoice',
        source_url: '',
        status: 'approved',
        confidence_score: 88,
        summary:
          'Nota fiscal validada. CNPJ emissor confirmado na base da Receita Federal. Valores e impostos conferidos.',
        risk_flags: '["data_emissão_recente"]',
      },
      {
        document_title: 'CPF - João da Silva Santos',
        document_type: 'cpf',
        source_url: '',
        status: 'rejected',
        confidence_score: 32,
        summary:
          'Documento rejeitado. Dígitos verificadores não conferem. Possível falsificação detectada.',
        risk_flags: '["digitos_inconsistentes", "padrao_suspeito"]',
      },
      {
        document_title: 'Carteira Nacional de Habilitação - Maria Oliveira',
        document_type: 'cnh',
        source_url: '',
        status: 'under_review',
        confidence_score: 67,
        summary:
          'Documento em revisão. Foto com baixa resolução dificulta a verificação biométrica. Aguardando reenvio.',
        risk_flags: '["baixa_resolucao"]',
      },
      {
        document_title: 'Passaporte Diplomático - Pedro Almeida',
        document_type: 'passport',
        source_url: '',
        status: 'approved',
        confidence_score: 91,
        summary:
          'Passaporte validado contra base internacional. MRZ conferido e dados biométricos consistentes.',
        risk_flags: '[]',
      },
      {
        document_title: 'RG - Ana Carolina Ferreira',
        document_type: 'rg',
        source_url: '',
        status: 'pending',
        confidence_score: 0,
        summary: 'Documento na fila de validação. Será processado em breve pelo motor de IA.',
        risk_flags: '[]',
      },
    ]

    seeds.forEach((seed) => {
      try {
        app.findFirstRecordByData('validations', 'document_title', seed.document_title)
      } catch (_) {
        const record = new Record(validations)
        record.set('user_id', adminUser.id)
        record.set('document_title', seed.document_title)
        record.set('document_type', seed.document_type)
        record.set('source_url', seed.source_url)
        record.set('status', seed.status)
        record.set('confidence_score', seed.confidence_score)
        record.set('summary', seed.summary)
        record.set('risk_flags', seed.risk_flags)
        app.save(record)
      }
    })
  },
  (app) => {
    try {
      const records = app.findRecordsByFilter('validations', '1=1', '', 100, 0)
      records.forEach((r) => app.delete(r))
    } catch (_) {}
  },
)
