migrate(
  (app) => {
    const collection = new Collection({
      name: 'validations',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'document_title', type: 'text', required: true, min: 1, max: 255 },
        {
          name: 'document_type',
          type: 'select',
          required: true,
          values: ['cpf', 'rg', 'cnh', 'passport', 'contract', 'invoice', 'other'],
          maxSelect: 1,
        },
        { name: 'source_url', type: 'url' },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['pending', 'approved', 'rejected', 'under_review'],
          maxSelect: 1,
        },
        { name: 'confidence_score', type: 'number', min: 0, max: 100, onlyInt: true },
        { name: 'summary', type: 'text', max: 2000 },
        { name: 'risk_flags', type: 'text', max: 2000 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_validations_user_created ON validations (user_id, created DESC)',
        'CREATE INDEX idx_validations_status ON validations (status)',
      ],
    })
    app.save(collection)
  },
  (app) => {
    const collection = app.findCollectionByNameOrId('validations')
    app.delete(collection)
  },
)
