migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')

    try {
      app.findAuthRecordByEmail('_pb_users_auth_', 'demo@shadowguard.com')
      return
    } catch (_) {}

    const record = new Record(users)
    record.setEmail('demo@shadowguard.com')
    record.setPassword('Skip@Pass')
    record.setVerified(true)
    record.set('name', 'Usuário Demo')
    app.save(record)
  },
  (app) => {
    try {
      const record = app.findAuthRecordByEmail('_pb_users_auth_', 'demo@shadowguard.com')
      app.delete(record)
    } catch (_) {}
  },
)
