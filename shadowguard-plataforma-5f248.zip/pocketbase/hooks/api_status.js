routerAdd(
  'GET',
  '/backend/v1/status',
  (e) => {
    return e.json(200, {
      status: 'online',
      version: 'ShadowGuard v1.0',
      avg_latency_ms: 245,
      uptime_percent: 99.9,
      docs_per_day: 1247,
      error_rate: 0.3,
      avg_processing_time: 1.8,
    })
  },
  $apis.requireAuth(),
)
