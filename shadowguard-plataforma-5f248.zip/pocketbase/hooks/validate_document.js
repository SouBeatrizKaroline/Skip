routerAdd(
  'POST',
  '/backend/v1/validate-document',
  (e) => {
    var body = e.requestInfo().body || {}
    var userId = e.auth?.id

    if (!userId) return e.unauthorizedError('Autenticacao necessaria')
    if (!body.content || !body.content.trim()) {
      return e.badRequestError('Conteudo do documento e obrigatorio')
    }

    var documentType = body.document_type || 'Outro'
    var content = body.content.trim()
    var startTime = Date.now()

    var analysisResult = {
      extracted_content: content.substring(0, 500),
      check_structure: 'PASS',
      check_format: 'PASS',
      check_ocr: 'PASS',
      check_consistency: 'PASS',
      check_fraud: 'PASS',
      check_database: 'PASS',
      confidence_score: 85,
      status: 'VALIDO',
      engine_version: 'ShadowGuard AI v2.1',
      processing_time: 0,
    }

    try {
      var reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Voce e um especialista em validacao e auditoria de documentos brasileiros. Analise o documento fornecido e retorne APENAS um JSON valido com os campos: status (VALIDO/ATENCAO/INVALIDO), confidence_score (0-100 inteiro), check_structure (PASS/WARN/FAIL), check_format (PASS/WARN/FAIL), check_ocr (PASS/WARN/FAIL), check_consistency (PASS/WARN/FAIL), check_fraud (PASS/WARN/FAIL), check_database (PASS/WARN/FAIL), extracted_content (resumo do conteudo em portugues). Nao adicione texto fora do JSON.',
          },
          {
            role: 'user',
            content: 'Analise este documento do tipo ' + documentType + '. Conteudo: ' + content,
          },
        ],
      })

      var aiContent = reply.choices[0].message.content.trim()
      var jsonMatch = aiContent.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        var parsed = JSON.parse(jsonMatch[0])
        analysisResult.status = parsed.status || 'ATENCAO'
        analysisResult.confidence_score = Math.min(
          100,
          Math.max(0, parseInt(parsed.confidence_score) || 50),
        )
        analysisResult.check_structure = parsed.check_structure || 'WARN'
        analysisResult.check_format = parsed.check_format || 'WARN'
        analysisResult.check_ocr = parsed.check_ocr || 'WARN'
        analysisResult.check_consistency = parsed.check_consistency || 'WARN'
        analysisResult.check_fraud = parsed.check_fraud || 'WARN'
        analysisResult.check_database = parsed.check_database || 'WARN'
        analysisResult.extracted_content = parsed.extracted_content || content.substring(0, 500)
      }
    } catch (err) {
      analysisResult.status = 'ATENCAO'
      analysisResult.confidence_score = 50
      analysisResult.check_fraud = 'WARN'
      analysisResult.check_consistency = 'WARN'
    }

    analysisResult.processing_time = (Date.now() - startTime) / 1000

    return e.json(200, analysisResult)
  },
  $apis.requireAuth(),
)
