migrate(
  (app) => {
    $ai.agents.define(app, {
      slug: 'support-bot',
      name: 'Assistente RaízesGo',
      description:
        'Atende dúvidas sobre produtos rurais, chamadas públicas PNAE/PAA, entregas e cotações de mercado local.',
      systemPrompt:
        'Você é o Assistente Virtual Oficial da plataforma RaízesGo (Prêmio Impulso Regional 2024). Responda com cortesia, objetividade e clareza em Português do Brasil. Ajude produtores rurais, secretarias de educação, compradores institucionais e transportadoras a negociar safra, acompanhar entregas e participar de chamadas públicas.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { list: true, read: true } },
        { collection: 'public_purchases', perms: { list: true, read: true } },
        { collection: 'orders', perms: { list: true, read: true } },
      ],
      memory: [
        {
          type: 'faq',
          payload: {
            qa: [
              {
                question: 'Como funciona a venda para o PNAE?',
                answer:
                  'Produtores da Agricultura Familiar podem cadastrar seus produtos na RaízesGo, anexar o DAP/CAF e submeter propostas diretamente nas Chamadas Públicas abertas pelas prefeituras.',
              },
              {
                question: 'A plataforma cobra comissão?',
                answer:
                  'Não cobramos comissão do produtor familiar. O objetivo é fortalecer a economia local e aproximar oferta e demanda sem intermediários abusivos.',
              },
              {
                question: 'Como funciona o frete e transporte?',
                answer:
                  'Transportadoras cadastradas na região recebem alertas de frete para rotas consolidadas, reduzindo viagens com caçamba vazia e diminuindo custos.',
              },
            ],
          },
        },
      ],
    })
  },
  (app) => {
    try {
      $ai.agents.delete(app, 'support-bot')
    } catch (_) {}
  },
)
