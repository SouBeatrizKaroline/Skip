migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')
    const categoriesCol = app.findCollectionByNameOrId('categories')
    const productsCol = app.findCollectionByNameOrId('products')
    const publicCol = app.findCollectionByNameOrId('public_purchases')

    // 1. Seed Main Admin / Producer User
    let adminId = ''
    try {
      const adminRec = app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com')
      adminRec.set('role', 'admin')
      adminRec.set('name', 'Sítio Raízes do Vale')
      adminRec.set('city', 'São José dos Campos')
      adminRec.set('state', 'SP')
      adminRec.set('verified', true)
      adminRec.set('cpf_cnpj', '12.345.678/0001-90')
      adminRec.set(
        'bio',
        'Produtor familiar certificado orgânico especializado em hortifrúti fresco e agroecológico.',
      )
      adminRec.set('rating_avg', 4.9)
      adminRec.set('rating_count', 38)
      app.save(adminRec)
      adminId = adminRec.id
    } catch (_) {
      const rec = new Record(users)
      rec.setEmail('1aspiraqualquer@gmail.com')
      rec.setPassword('Skip@Pass')
      rec.setVerified(true)
      rec.set('name', 'Sítio Raízes do Vale')
      rec.set('role', 'admin')
      rec.set('city', 'São José dos Campos')
      rec.set('state', 'SP')
      rec.set('cpf_cnpj', '12.345.678/0001-90')
      rec.set('bio', 'Produtor familiar certificado orgânico.')
      rec.set('rating_avg', 4.9)
      rec.set('rating_count', 38)
      app.save(rec)
      adminId = rec.id
    }

    // 2. Seed Categories
    const categoriesData = [
      {
        name: 'Hortifrúti',
        slug: 'hortifruti',
        icon: 'Apple',
        color: 'text-emerald-600 bg-emerald-50',
      },
      {
        name: 'Grãos e Cereais',
        slug: 'graos-cereais',
        icon: 'Wheat',
        color: 'text-amber-600 bg-amber-50',
      },
      {
        name: 'Laticínios e Queijos',
        slug: 'laticinios',
        icon: 'Milk',
        color: 'text-blue-600 bg-blue-50',
      },
      {
        name: 'Mel e Apicultura',
        slug: 'mel',
        icon: 'Honey',
        color: 'text-yellow-600 bg-yellow-50',
      },
      { name: 'Carnes e Aves', slug: 'carnes-aves', icon: 'Beef', color: 'text-red-600 bg-red-50' },
      {
        name: 'Processados e Artesanais',
        slug: 'processados',
        icon: 'Package',
        color: 'text-purple-600 bg-purple-50',
      },
    ]

    const catMap = {}
    categoriesData.forEach((c) => {
      try {
        const existing = app.findFirstRecordByData('categories', 'slug', c.slug)
        catMap[c.slug] = existing.id
      } catch (_) {
        const rec = new Record(categoriesCol)
        rec.set('name', c.name)
        rec.set('slug', c.slug)
        rec.set('icon', c.icon)
        rec.set('color', c.color)
        app.save(rec)
        catMap[c.slug] = rec.id
      }
    })

    // 3. Seed Sample Products
    const sampleProducts = [
      {
        name: 'Tomate Orgânico Manteiga',
        slugCat: 'hortifruti',
        price: 6.5,
        unit: 'kg',
        quantity: 500,
        min_order: 10,
        is_organic: true,
        certs: 'Certificado IBD Orgânico',
        city: 'São José dos Campos',
        state: 'SP',
      },
      {
        name: 'Alface Americana Hidropônica',
        slugCat: 'hortifruti',
        price: 3.2,
        unit: 'unidade',
        quantity: 1000,
        min_order: 20,
        is_organic: true,
        certs: 'Agricultura Familiar SIF',
        city: 'Jacareí',
        state: 'SP',
      },
      {
        name: 'Feijão Carioca Tipo 1 Safra Nova',
        slugCat: 'graos-cereais',
        price: 8.9,
        unit: 'kg',
        quantity: 2000,
        min_order: 50,
        is_organic: false,
        certs: 'Selo Quilombola',
        city: 'Taubaté',
        state: 'SP',
      },
      {
        name: 'Milho Verde Fresco na Palha',
        slugCat: 'graos-cereais',
        price: 1.8,
        unit: 'unidade',
        quantity: 1500,
        min_order: 100,
        is_organic: false,
        certs: 'Selo Agroecológico',
        city: 'Caçapava',
        state: 'SP',
      },
      {
        name: 'Queijo Minas Artesanal Meia Cura',
        slugCat: 'laticinios',
        price: 38.0,
        unit: 'kg',
        quantity: 150,
        min_order: 2,
        is_organic: false,
        certs: 'SIM / SIF Regional',
        city: 'São Luiz do Paraitinga',
        state: 'SP',
      },
      {
        name: 'Mel Silvestre 100% Puro Pote 1kg',
        slugCat: 'mel',
        price: 32.0,
        unit: 'kg',
        quantity: 200,
        min_order: 5,
        is_organic: true,
        certs: 'Selo Mel da Terra',
        city: 'Campos do Jordão',
        state: 'SP',
      },
    ]

    sampleProducts.forEach((p) => {
      try {
        app.findFirstRecordByData('products', 'name', p.name)
      } catch (_) {
        const rec = new Record(productsCol)
        rec.set('producer', adminId)
        rec.set('name', p.name)
        rec.set(
          'description',
          p.name +
            ' colhido direto do produtor com altíssimo padrão de qualidade, ideal para merenda escolar, restaurantes e feiras livres.',
        )
        rec.set('category', catMap[p.slugCat])
        rec.set('price', p.price)
        rec.set('unit', p.unit)
        rec.set('quantity', p.quantity)
        rec.set('min_order', p.min_order)
        rec.set('stock', p.quantity)
        rec.set('available', true)
        rec.set('is_organic', p.is_organic)
        rec.set('certifications', p.certs)
        rec.set('city', p.city)
        rec.set('state', p.state)
        rec.set('latitude', -23.18)
        rec.set('longitude', -45.88)
        app.save(rec)
      }
    })

    // 4. Seed Public Purchases (Edital PNAE / Chamada Pública)
    const samplePurchases = [
      {
        title: 'Chamada Pública PNAE 01/2025 - Merenda Escolar Municipal',
        type: 'pnae',
        number: 'CP-01/2025',
        budget: 145000.0,
        city: 'São José dos Campos',
        state: 'SP',
        reqs: 'Aquisição de hortifrúti e grãos direto da Agricultura Familiar para 45 escolas municipais.',
      },
      {
        title: 'Edital PAA - Abastecimento de Restaurantes Populares e CRAS',
        type: 'paa',
        number: 'PAA-03/2025',
        budget: 82000.0,
        city: 'Jacareí',
        state: 'SP',
        reqs: 'Fornecimento de leguminosas, tubérculos e laticínios artesanais para rede de assistência social.',
      },
    ]

    samplePurchases.forEach((pub) => {
      try {
        app.findFirstRecordByData('public_purchases', 'number', pub.number)
      } catch (_) {
        const rec = new Record(publicCol)
        rec.set('title', pub.title)
        rec.set('description', pub.reqs)
        rec.set('institution', adminId)
        rec.set('type', pub.type)
        rec.set('number', pub.number)
        rec.set('status', 'aberta')
        rec.set('budget', pub.budget)
        rec.set('city', pub.city)
        rec.set('state', pub.state)
        rec.set('requirements', pub.reqs)
        rec.set('deadline', '2025-12-30 23:59:59.000Z')
        app.save(rec)
      }
    })
  },
  (app) => {},
)
