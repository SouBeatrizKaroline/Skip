migrate(
  (app) => {
    // Update users collection with extra profile fields
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    if (!usersCol.fields.getByName('role')) {
      usersCol.fields.add(
        new SelectField({
          name: 'role',
          values: [
            'admin',
            'produtor',
            'comprador',
            'transportadora',
            'instituicao',
            'cooperativa',
          ],
          maxSelect: 1,
        }),
      )
    }
    if (!usersCol.fields.getByName('cpf_cnpj')) {
      usersCol.fields.add(new TextField({ name: 'cpf_cnpj' }))
    }
    if (!usersCol.fields.getByName('phone')) {
      usersCol.fields.add(new TextField({ name: 'phone' }))
    }
    if (!usersCol.fields.getByName('whatsapp')) {
      usersCol.fields.add(new TextField({ name: 'whatsapp' }))
    }
    if (!usersCol.fields.getByName('city')) {
      usersCol.fields.add(new TextField({ name: 'city' }))
    }
    if (!usersCol.fields.getByName('state')) {
      usersCol.fields.add(new TextField({ name: 'state' }))
    }
    if (!usersCol.fields.getByName('address')) {
      usersCol.fields.add(new TextField({ name: 'address' }))
    }
    if (!usersCol.fields.getByName('latitude')) {
      usersCol.fields.add(new NumberField({ name: 'latitude' }))
    }
    if (!usersCol.fields.getByName('longitude')) {
      usersCol.fields.add(new NumberField({ name: 'longitude' }))
    }
    if (!usersCol.fields.getByName('bio')) {
      usersCol.fields.add(new TextField({ name: 'bio' }))
    }
    if (!usersCol.fields.getByName('verified')) {
      usersCol.fields.add(new BoolField({ name: 'verified' }))
    }
    if (!usersCol.fields.getByName('rating_avg')) {
      usersCol.fields.add(new NumberField({ name: 'rating_avg', min: 0, max: 5 }))
    }
    if (!usersCol.fields.getByName('rating_count')) {
      usersCol.fields.add(new NumberField({ name: 'rating_count', min: 0 }))
    }
    app.save(usersCol)

    // 1. Categories
    const categories = new Collection({
      name: 'categories',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.role = 'admin'",
      updateRule: "@request.auth.role = 'admin'",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'slug', type: 'text', required: true },
        { name: 'icon', type: 'text' },
        { name: 'color', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_categories_slug ON categories (slug)'],
    })
    app.save(categories)

    // 2. Products
    const products = new Collection({
      name: 'products',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule:
        "@request.auth.id != '' && (producer = @request.auth.id || @request.auth.role = 'admin')",
      deleteRule:
        "@request.auth.id != '' && (producer = @request.auth.id || @request.auth.role = 'admin')",
      fields: [
        {
          name: 'producer',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'name', type: 'text', required: true },
        { name: 'description', type: 'text' },
        {
          name: 'category',
          type: 'relation',
          collectionId: categories.id,
          required: true,
          maxSelect: 1,
        },
        { name: 'price', type: 'number', required: true, min: 0 },
        {
          name: 'unit',
          type: 'select',
          required: true,
          values: ['kg', 'unidade', 'caixa', 'saca', 'litro', 'duzia', 'tonelada'],
          maxSelect: 1,
        },
        { name: 'quantity', type: 'number', min: 0 },
        { name: 'min_order', type: 'number', min: 0 },
        {
          name: 'images',
          type: 'file',
          maxSelect: 8,
          maxSize: 5242880,
          mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
        },
        { name: 'is_organic', type: 'bool' },
        { name: 'certifications', type: 'text' },
        { name: 'stock', type: 'number', min: 0 },
        { name: 'available', type: 'bool' },
        { name: 'harvest_date', type: 'date' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'embedding', type: 'vector', dimensions: 1536, distance: 'cosine' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_products_producer ON products (producer)',
        'CREATE INDEX idx_products_category ON products (category)',
        'CREATE INDEX idx_products_available ON products (available)',
      ],
    })
    app.save(products)

    // 3. Favorites
    const favorites = new Collection({
      name: 'favorites',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        {
          name: 'product',
          type: 'relation',
          collectionId: products.id,
          required: true,
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_favorites_user_prod ON favorites (user, product)'],
    })
    app.save(favorites)

    // 4. Public Purchases (Licitações / PNAE / PAA)
    const publicPurchases = new Collection({
      name: 'public_purchases',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule:
        "@request.auth.id != '' && (institution = @request.auth.id || @request.auth.role = 'admin')",
      deleteRule:
        "@request.auth.id != '' && (institution = @request.auth.id || @request.auth.role = 'admin')",
      fields: [
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        {
          name: 'institution',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        {
          name: 'type',
          type: 'select',
          required: true,
          values: ['licitacao', 'chamada_publica', 'pnae', 'paa', 'edital', 'pregao'],
          maxSelect: 1,
        },
        { name: 'number', type: 'text' },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['aberta', 'em_analise', 'encerrada', 'adjudicada', 'cancelada'],
          maxSelect: 1,
        },
        { name: 'budget', type: 'number', min: 0 },
        { name: 'deadline', type: 'date' },
        { name: 'requirements', type: 'text' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        { name: 'documents', type: 'file', maxSelect: 5, maxSize: 10485760 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(publicPurchases)

    // 5. Orders
    const orders = new Collection({
      name: 'orders',
      type: 'base',
      listRule:
        "@request.auth.id != '' && (buyer = @request.auth.id || seller = @request.auth.id || @request.auth.role = 'admin')",
      viewRule:
        "@request.auth.id != '' && (buyer = @request.auth.id || seller = @request.auth.id || @request.auth.role = 'admin')",
      createRule: "@request.auth.id != ''",
      updateRule:
        "@request.auth.id != '' && (buyer = @request.auth.id || seller = @request.auth.id || @request.auth.role = 'admin')",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'code', type: 'text', required: true },
        {
          name: 'buyer',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        {
          name: 'seller',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'total', type: 'number', required: true, min: 0 },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: [
            'aguardando_pagamento',
            'em_negociacao',
            'confirmado',
            'em_preparo',
            'enviado',
            'entregue',
            'cancelado',
          ],
          maxSelect: 1,
        },
        {
          name: 'purchase_type',
          type: 'select',
          values: ['marketplace', 'compra_publica'],
          maxSelect: 1,
        },
        { name: 'bid', type: 'relation', collectionId: publicPurchases.id, maxSelect: 1 },
        { name: 'delivery_address', type: 'text' },
        { name: 'delivery_city', type: 'text' },
        { name: 'delivery_state', type: 'text' },
        { name: 'delivery_lat', type: 'number' },
        { name: 'delivery_lng', type: 'number' },
        { name: 'notes', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_orders_code ON orders (code)'],
    })
    app.save(orders)

    // 6. Order Items
    const orderItems = new Collection({
      name: 'order_items',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.role = 'admin'",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'order', type: 'relation', collectionId: orders.id, required: true, maxSelect: 1 },
        {
          name: 'product',
          type: 'relation',
          collectionId: products.id,
          required: true,
          maxSelect: 1,
        },
        { name: 'product_name', type: 'text', required: true },
        { name: 'quantity', type: 'number', required: true, min: 1 },
        { name: 'unit_price', type: 'number', required: true, min: 0 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(orderItems)

    // 7. Conversations & Messages
    const conversations = new Collection({
      name: 'conversations',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'type', type: 'select', values: ['direct', 'order'], maxSelect: 1 },
        {
          name: 'participants',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 10,
        },
        { name: 'order', type: 'relation', collectionId: orders.id, maxSelect: 1 },
        { name: 'last_message', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(conversations)

    const messages = new Collection({
      name: 'messages',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && sender = @request.auth.id",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        {
          name: 'conversation',
          type: 'relation',
          collectionId: conversations.id,
          required: true,
          maxSelect: 1,
        },
        {
          name: 'sender',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'content', type: 'text', required: true },
        { name: 'attachment', type: 'file', maxSelect: 1, maxSize: 10485760 },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'read', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(messages)

    // 8. Shipments
    const shipments = new Collection({
      name: 'shipments',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'order', type: 'relation', collectionId: orders.id, required: true, maxSelect: 1 },
        { name: 'transporter', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['aguardando_coleta', 'em_transito', 'entregue', 'cancelada'],
          maxSelect: 1,
        },
        { name: 'origin_address', type: 'text' },
        { name: 'origin_lat', type: 'number' },
        { name: 'origin_lng', type: 'number' },
        { name: 'destination_address', type: 'text' },
        { name: 'destination_lat', type: 'number' },
        { name: 'destination_lng', type: 'number' },
        { name: 'current_lat', type: 'number' },
        { name: 'current_lng', type: 'number' },
        { name: 'cost', type: 'number', min: 0 },
        { name: 'estimated_delivery', type: 'date' },
        { name: 'delivery_photo', type: 'file', maxSelect: 1, maxSize: 5242880 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(shipments)

    // 9. Participations in Public Purchases
    const participations = new Collection({
      name: 'participations',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        {
          name: 'purchase',
          type: 'relation',
          collectionId: publicPurchases.id,
          required: true,
          maxSelect: 1,
        },
        {
          name: 'participant',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'proposal_value', type: 'number', required: true, min: 0 },
        { name: 'notes', type: 'text' },
        { name: 'documents', type: 'file', maxSelect: 5, maxSize: 10485760 },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['enviada', 'em_analise', 'aceita', 'rejeitada', 'vencedora'],
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(participations)

    // 10. Documents Vault
    const documents = new Collection({
      name: 'documents',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'title', type: 'text', required: true },
        {
          name: 'category',
          type: 'select',
          required: true,
          values: ['Certificados', 'Notas Fiscais', 'Contratos', 'Relatorios', 'Outros'],
          maxSelect: 1,
        },
        { name: 'file', type: 'file', required: true, maxSelect: 1, maxSize: 10485760 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(documents)

    // 11. In-App Notifications
    const notifications = new Collection({
      name: 'notifications',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'title', type: 'text', required: true },
        { name: 'message', type: 'text', required: true },
        {
          name: 'type',
          type: 'select',
          values: ['pedido', 'mensagem', 'licitacao', 'logistica', 'sistema'],
          maxSelect: 1,
        },
        { name: 'link', type: 'text' },
        { name: 'read', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(notifications)

    // 12. Reviews & Ratings
    const reviews = new Collection({
      name: 'reviews',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && reviewer = @request.auth.id",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        { name: 'order', type: 'relation', collectionId: orders.id, maxSelect: 1 },
        {
          name: 'reviewer',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          required: true,
          maxSelect: 1,
        },
        { name: 'reviewed_user', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'product', type: 'relation', collectionId: products.id, maxSelect: 1 },
        { name: 'rating', type: 'number', required: true, min: 1, max: 5 },
        { name: 'comment', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(reviews)
  },
  (app) => {
    const names = [
      'reviews',
      'notifications',
      'documents',
      'participations',
      'shipments',
      'messages',
      'conversations',
      'order_items',
      'orders',
      'public_purchases',
      'favorites',
      'products',
      'categories',
    ]
    names.forEach((n) => {
      try {
        const c = app.findCollectionByNameOrId(n)
        app.delete(c)
      } catch (_) {}
    })
  },
)
