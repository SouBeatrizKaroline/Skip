routerAdd('POST', '/backend/v1/search/products', (e) => {
  const body = e.requestInfo().body || {}
  const query = (body.query || '').trim()
  if (!query) return e.badRequestError('Query de busca vazia')

  try {
    const embedRes = $ai.embed({ input: query })
    const vector = embedRes.data[0].embedding

    const results = $vectors.search(e, 'products', {
      field: 'embedding',
      query: vector,
      k: body.k || 12,
      expand: ['producer', 'category'],
    })

    return e.json(200, results)
  } catch (err) {
    const records = $app.findRecordsByFilter(
      'products',
      `name ~ '${query}' || description ~ '${query}'`,
      '-created',
      body.k || 12,
      0,
    )
    return e.json(200, { items: records })
  }
})
