routerAdd(
  'POST',
  '/backend/v1/insights',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const role = body.role || 'produtor'

      const prompt = `Gere 3 conselhos práticos e curtos de inteligência de mercado e logística para um ${role} rural no Brasil. Foque em precificação justa, desperdício zero e chamadas públicas PNAE. Responda em formato JSON com a estrutura: {"insights": [{"title": "...", "description": "...", "impact": "alto"|"medio"}]}`

      const res = $ai.chat({
        model: 'fast',
        messages: [
          { role: 'system', content: 'Você é um especialista em economia agrária da RaízesGo.' },
          { role: 'user', content: prompt },
        ],
      })

      const text = res.choices[0].message.content || ''
      let jsonRes = { insights: [] }
      try {
        const match = text.match(/\{[\s\S]*\}/)
        if (match) {
          jsonRes = JSON.parse(match[0])
        }
      } catch (_) {
        jsonRes = {
          insights: [
            {
              title: 'Demanda aquecida em Hortifrúti',
              description:
                'Prefeituras da região estão abrindo chamadas PNAE para merenda escolar nesta semana.',
              impact: 'alto',
            },
            {
              title: 'Otimização de Rotas',
              description:
                'Consolide cargas com produtores vizinhos para reduzir frete em até 22%.',
              impact: 'medio',
            },
          ],
        }
      }

      return e.json(200, jsonRes)
    } catch (err) {
      return e.json(500, { error: 'Não foi possível gerar insights no momento.' })
    }
  },
  $apis.requireAuth(),
)
