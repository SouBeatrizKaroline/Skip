import { useState } from 'react'
import { MapPin, Navigation, Compass, Layers } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface MarkerItem {
  id: string
  title: string
  type?: 'offer' | 'demand' | 'transporter'
  lat: number
  lng: number
  price?: string
  city?: string
}

interface InteractiveMapProps {
  markers?: MarkerItem[]
  height?: string
  onMarkerClick?: (marker: MarkerItem) => void
}

export function InteractiveMap({
  markers = [],
  height = 'h-80',
  onMarkerClick,
}: InteractiveMapProps) {
  const [selected, setSelected] = useState<MarkerItem | null>(null)

  const getMarkerColor = (type?: string) => {
    if (type === 'demand') return 'bg-amber-500 border-white text-white'
    if (type === 'transporter') return 'bg-blue-600 border-white text-white'
    return 'bg-emerald-600 border-white text-white'
  }

  return (
    <div
      className={`relative w-full ${height} rounded-xl overflow-hidden bg-slate-900 border border-slate-800 shadow-inner flex flex-col justify-between p-4 group`}
    >
      {/* Map Graphic Overlay Background */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>

      {/* Top Map Controls */}
      <div className="relative z-10 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-xs text-slate-200 font-medium">
          <Compass
            className="w-3.5 h-3.5 text-emerald-400 animate-spin"
            style={{ animationDuration: '10s' }}
          />
          <span>Vale do Paraíba & Região</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Button
            size="icon"
            variant="secondary"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white"
          >
            <Layers className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white"
          >
            <Navigation className="w-4 h-4 text-emerald-400" />
          </Button>
        </div>
      </div>

      {/* Interactive Markers Container */}
      <div className="relative z-10 flex-1 my-4 flex items-center justify-center">
        <div className="relative w-full h-full max-w-lg mx-auto flex items-center justify-center">
          {markers.length === 0 ? (
            <div className="text-center text-slate-400 text-xs flex flex-col items-center gap-1">
              <MapPin className="w-6 h-6 text-emerald-500 animate-bounce" />
              <span>Mapa em tempo real ativado</span>
            </div>
          ) : (
            markers.slice(0, 6).map((m, idx) => {
              // Standardize visual position grid for demo overlay
              const top = 20 + ((idx * 25) % 60)
              const left = 15 + ((idx * 30) % 70)
              return (
                <div
                  key={m.id}
                  style={{ top: `${top}%`, left: `${left}%` }}
                  onClick={() => {
                    setSelected(m)
                    if (onMarkerClick) onMarkerClick(m)
                  }}
                  className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-transform hover:scale-125 z-20"
                >
                  <div
                    className={`p-2 rounded-full border-2 shadow-lg flex items-center justify-center ${getMarkerColor(m.type)}`}
                  >
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="mt-1 bg-slate-950/90 text-white text-[10px] px-2 py-0.5 rounded shadow border border-slate-700 font-semibold whitespace-nowrap">
                    {m.title} {m.price ? `• ${m.price}` : ''}
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>

      {/* Bottom Information Card */}
      {selected && (
        <div className="relative z-20 bg-slate-950/90 backdrop-blur border border-slate-800 p-3 rounded-lg text-white flex items-center justify-between animate-fade-in-up">
          <div>
            <div className="font-semibold text-xs text-emerald-400">{selected.title}</div>
            <div className="text-[11px] text-slate-400">
              {selected.city || 'São José dos Campos'}
            </div>
          </div>
          {selected.price && (
            <div className="text-sm font-bold text-white bg-emerald-600/30 px-2 py-1 rounded border border-emerald-500/40">
              {selected.price}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
