import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  Sprout,
  Search,
  Bell,
  ShoppingCart,
  User,
  LogOut,
  Menu,
  X,
  FileText,
  Heart,
  Settings,
  LayoutDashboard,
  Globe,
  MessageSquare,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useAuth } from '@/hooks/use-auth'
import { useCartStore } from '@/stores/cart-store'
import { searchProductsSemantic } from '@/services/products'

export function Navbar() {
  const { user, isAuthenticated, signOut } = useAuth()
  const navigate = useNavigate()
  const itemCount = useCartStore((s) => s.getItemCount())

  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [searchOpen, setSearchOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      setSearchOpen(false)
      return
    }
    const timer = setTimeout(async () => {
      try {
        const res: any = await searchProductsSemantic(searchQuery, 5)
        if (res?.items) setSearchResults(res.items)
        setSearchOpen(true)
      } catch (_) {
        setSearchResults([])
      }
    }, 300)

    return () => clearTimeout(timer)
  }, [searchQuery])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-2.5 border-b border-slate-100' : 'bg-white py-3.5 border-b border-slate-100'}`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <Link to={isAuthenticated ? '/dashboard' : '/'} className="flex items-center gap-2.5 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white flex items-center justify-center shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
            <Sprout className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900 font-display">
              Raízes<span className="text-emerald-600">Go</span>
            </span>
            <span className="block text-[10px] font-semibold text-emerald-700 tracking-wider uppercase -mt-1">
              Agro Ecossistema
            </span>
          </div>
        </Link>

        {/* Search Bar / Public Navigation */}
        {isAuthenticated ? (
          <div className="relative flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Buscar produtos, insumos ou produtores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 bg-slate-50 border-slate-200 focus:bg-white text-xs h-9 rounded-full"
              />
            </div>
            {/* Search Dropdown */}
            {searchOpen && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl p-2 z-50 animate-fade-in-up">
                {searchResults.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      navigate(`/produtos/${item.id}`)
                      setSearchOpen(false)
                      setSearchQuery('')
                    }}
                    className="p-2 hover:bg-slate-50 rounded-lg cursor-pointer flex items-center gap-3"
                  >
                    <div className="w-8 h-8 bg-emerald-100 rounded-md flex items-center justify-center text-emerald-700 font-bold text-xs">
                      {item.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-800">{item.name}</p>
                      <p className="text-[10px] text-slate-500">
                        R$ {item.price?.toFixed(2)} / {item.unit}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-600">
            <a href="#inicio" className="hover:text-emerald-600 transition-colors">
              Início
            </a>
            <Link to="/marketplace" className="hover:text-emerald-600 transition-colors">
              Marketplace
            </Link>
            <Link to="/produtores" className="hover:text-emerald-600 transition-colors">
              Produtores
            </Link>
            <Link to="/compras-publicas" className="hover:text-emerald-600 transition-colors">
              Compras Públicas
            </Link>
            <a href="#como-funciona" className="hover:text-emerald-600 transition-colors">
              Como Funciona
            </a>
            <a href="#faq" className="hover:text-emerald-600 transition-colors">
              FAQ
            </a>
          </nav>
        )}

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <Link to="/carrinho">
                <Button
                  size="icon"
                  variant="ghost"
                  className="relative text-slate-700 hover:text-emerald-600"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Button>
              </Link>

              <Link to="/notificacoes">
                <Button
                  size="icon"
                  variant="ghost"
                  className="relative text-slate-700 hover:text-emerald-600"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
                </Button>
              </Link>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center gap-2 p-1 pl-2 hover:bg-slate-100 rounded-full"
                  >
                    <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shadow-sm">
                      {user?.name?.charAt(0) || 'U'}
                    </div>
                    <span className="text-xs font-semibold text-slate-800 hidden md:inline">
                      {user?.name || 'Minha Conta'}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 p-1 text-xs">
                  <DropdownMenuItem
                    onClick={() => navigate('/perfil')}
                    className="cursor-pointer gap-2"
                  >
                    <User className="w-4 h-4 text-emerald-600" /> Meu Perfil
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('/pedidos')}
                    className="cursor-pointer gap-2"
                  >
                    <LayoutDashboard className="w-4 h-4 text-emerald-600" /> Meus Pedidos
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('/favoritos')}
                    className="cursor-pointer gap-2"
                  >
                    <Heart className="w-4 h-4 text-emerald-600" /> Favoritos
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('/documentos')}
                    className="cursor-pointer gap-2"
                  >
                    <FileText className="w-4 h-4 text-emerald-600" /> Documentos LGPD
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => navigate('/configuracoes')}
                    className="cursor-pointer gap-2"
                  >
                    <Settings className="w-4 h-4 text-emerald-600" /> Configurações
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => {
                      signOut()
                      navigate('/entrar')
                    }}
                    className="cursor-pointer gap-2 text-red-600 font-semibold"
                  >
                    <LogOut className="w-4 h-4" /> Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center gap-2.5">
              <Link to="/entrar">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-slate-700 hover:text-emerald-600 text-xs font-semibold"
                >
                  Entrar
                </Button>
              </Link>
              <Link to="/cadastro">
                <Button
                  size="sm"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm"
                >
                  Criar conta
                </Button>
              </Link>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden text-slate-700"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>
    </header>
  )
}
