import { Outlet, useLocation } from 'react-router-dom'
import { Navbar } from '@/components/Navbar'
import { Sidebar } from '@/components/Sidebar'
import { Footer } from '@/components/Footer'
import { useAuth } from '@/hooks/use-auth'

export function Layout() {
  const { isAuthenticated } = useAuth()
  const location = useLocation()

  const isPublicPage = [
    '/',
    '/entrar',
    '/cadastro',
    '/recuperar-senha',
    '/redefinir-senha',
  ].includes(location.pathname)

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar />

      <div className="flex-1 flex pt-[61px]">
        {isAuthenticated && !isPublicPage && <Sidebar />}

        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>

      {(isPublicPage || !isAuthenticated) && <Footer />}
    </div>
  )
}

export default Layout
