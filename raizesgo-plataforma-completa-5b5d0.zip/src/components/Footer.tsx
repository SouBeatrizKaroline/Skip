import { Sprout, Instagram, Linkedin, Youtube, PhoneCall } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-6 border-t border-slate-900">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
        {/* Col 1 */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
              <Sprout className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold text-white font-display">
              Raízes<span className="text-emerald-500">Go</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
            Plataforma premiada (Impulso Regional 2024) para conectar produtores rurais, compradores
            institucionais e logística sem desperdício.
          </p>
          <div className="flex items-center gap-3 pt-2">
            <a
              href="#"
              className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-colors"
            >
              <Instagram className="w-4 h-4" />
            </a>
            <a
              href="#"
              className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-colors"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <a
              href="#"
              className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-colors"
            >
              <Youtube className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Col 2 */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Plataforma</h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>
              <a href="/marketplace" className="hover:text-white transition-colors">
                Marketplace
              </a>
            </li>
            <li>
              <a href="/produtores" className="hover:text-white transition-colors">
                Produtores Rurais
              </a>
            </li>
            <li>
              <a href="/compras-publicas" className="hover:text-white transition-colors">
                Compras Públicas (PNAE)
              </a>
            </li>
            <li>
              <a href="/logistica" className="hover:text-white transition-colors">
                Logística e Fretes
              </a>
            </li>
          </ul>
        </div>

        {/* Col 3 */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Suporte & Legal
          </h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>
              <a href="#faq" className="hover:text-white transition-colors">
                Perguntas Frequentes
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-white transition-colors">
                Termos de Uso
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-white transition-colors">
                Política de Privacidade (LGPD)
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-white transition-colors">
                Contato & Suporte
              </a>
            </li>
          </ul>
        </div>

        {/* Col 4 */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Boletim do Agro
          </h4>
          <p className="text-xs text-slate-400">
            Receba cotações e relatórios quinzenais do setor.
          </p>
          <div className="flex gap-2">
            <Input
              type="email"
              placeholder="Seu e-mail"
              className="bg-slate-900 border-slate-800 text-xs h-9 text-white"
            />
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs">
              Assinar
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 pt-6 border-t border-slate-900 flex flex-col md:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
        <p>
          © 2025 RaízesGo — Vencedor do Prêmio Impulso Regional 2024. Todos os direitos reservados.
        </p>
        <p>Conforme LGPD & Regulamentação Agrária Brasileira.</p>
      </div>
    </footer>
  )
}
