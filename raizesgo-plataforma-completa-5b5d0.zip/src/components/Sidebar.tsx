import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  ShoppingBag,
  Sparkles,
  Package,
  Truck,
  Building2,
  MessageSquare,
  FileText,
  Heart,
  ShieldCheck,
  Settings,
  Users,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'

export function Sidebar() {
  const location = useLocation()
  const { user } = useAuth()

  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Marketplace', path: '/marketplace', icon: ShoppingBag },
    { label: 'Para Você (IA)', path: '/recomendacoes', icon: Sparkles },
    { label: 'Pedidos', path: '/pedidos', icon: Package },
    { label: 'Logística', path: '/logistica', icon: Truck },
    { label: 'Compras Públicas', path: '/compras-publicas', icon: Building2 },
    { label: 'Chat & Assistente', path: '/chat', icon: MessageSquare },
    { label: 'Documentos', path: '/documentos', icon: FileText },
    { label: 'Favoritos', path: '/favoritos', icon: Heart },
  ]

  if (user?.role === 'admin') {
    navItems.push({ label: 'Administração', path: '/admin', icon: ShieldCheck })
  }

  navItems.push({ label: 'Configurações', path: '/configuracoes', icon: Settings })

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between hidden lg:flex min-h-[calc(100vh-61px)] p-3 text-slate-300">
      <div className="space-y-1">
        <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          Menu Principal
        </div>
        {navItems.map((item) => {
          const active = location.pathname === item.path
          const Icon = item.icon
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                active
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-emerald-400'}`} />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </div>

      <div className="p-3 bg-slate-800/60 border border-slate-700/50 rounded-xl">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></div>
          <span className="text-[11px] font-bold text-white">Sua Conta Verificada</span>
        </div>
        <p className="text-[10px] text-slate-400 leading-tight">
          Sua propriedade está ativa na rede agroecológica regional.
        </p>
      </div>
    </aside>
  )
}
