import { useState, useEffect } from 'react'
import { Sparkles, RefreshCw, TrendingUp, AlertTriangle, Lightbulb } from 'lucide-react'
import { Button } from '@/components/ui/button'
import pb from '@/lib/pocketbase/client'

interface InsightItem {
  title: string
  description: string
  impact: 'alto' | 'medio' | 'baixo'
}

export function AIInsightsWidget({ role = 'produtor' }: { role?: string }) {
  const [insights, setInsights] = useState<InsightItem[]>([])
  const [loading, setLoading] = useState(false)

  const fetchInsights = async () => {
    setLoading(true)
    try {
      const res = await pb.send('/backend/v1/insights', {
        method: 'POST',
        body: JSON.stringify({ role }),
      })
      if (res?.insights) {
        setInsights(res.insights)
      }
    } catch (_) {
      setInsights([
        {
          title: 'Oportunidade PNAE em alta',
          description:
            'Duas prefeituras regionais abriram editais para fornecimento de hortifrúti nesta semana.',
          impact: 'alto',
        },
        {
          title: 'Redução de Custo de Frete',
          description:
            'Combine entregas de grãos com a cooperativa vizinha para economizar até 20%.',
          impact: 'medio',
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchInsights()
  }, [role])

  return (
    <div className="bg-gradient-to-br from-emerald-900/10 via-slate-900 to-slate-900 border border-emerald-500/20 rounded-xl p-5 text-white shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/30">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">Insights Inteligentes da Safra</h3>
            <p className="text-xs text-slate-400">
              Inteligência de mercado gerada pela IA RaízesGo
            </p>
          </div>
        </div>

        <Button
          size="sm"
          variant="outline"
          onClick={fetchInsights}
          disabled={loading}
          className="border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3 py-2">
          <div className="h-14 bg-slate-800/60 rounded-lg animate-pulse"></div>
          <div className="h-14 bg-slate-800/60 rounded-lg animate-pulse"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {insights.map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-800/70 border border-slate-700/60 p-3.5 rounded-lg flex items-start gap-3 hover:border-emerald-500/40 transition-colors"
            >
              <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded mt-0.5">
                {item.impact === 'alto' ? (
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Lightbulb className="w-4 h-4 text-amber-400" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-xs text-slate-100">{item.title}</h4>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${item.impact === 'alto' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}
                  >
                    Impacto {item.impact}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
