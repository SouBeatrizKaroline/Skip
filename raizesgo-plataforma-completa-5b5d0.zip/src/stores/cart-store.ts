import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface CartItem {
  id: string
  name: string
  price: number
  unit: string
  quantity: number
  producerId: string
  producerName: string
  image?: string
  stock: number
}

interface CartStore {
  items: CartItem[]
  addItem: (item: Omit<CartItem, 'quantity'>, qty?: number) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, qty: number) => void
  clearCart: () => void
  getSubtotal: () => number
  getItemCount: () => number
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (newItem, qty = 1) => {
        set((state) => {
          const existing = state.items.find((i) => i.id === newItem.id)
          if (existing) {
            return {
              items: state.items.map((i) =>
                i.id === newItem.id ? { ...i, quantity: i.quantity + qty } : i,
              ),
            }
          }
          return { items: [...state.items, { ...newItem, quantity: qty }] }
        })
      },
      removeItem: (id) => {
        set((state) => ({ items: state.items.filter((i) => i.id !== id) }))
      },
      updateQuantity: (id, qty) => {
        set((state) => ({
          items: state.items
            .map((i) => (i.id === id ? { ...i, quantity: Math.max(1, qty) } : i))
            .filter((i) => i.quantity > 0),
        }))
      },
      clearCart: () => set({ items: [] }),
      getSubtotal: () => {
        return get().items.reduce((acc, i) => acc + i.price * i.quantity, 0)
      },
      getItemCount: () => {
        return get().items.reduce((acc, i) => acc + i.quantity, 0)
      },
    }),
    { name: 'raizesgo-cart' },
  ),
)

export default useCartStore
