import pb from '@/lib/pocketbase/client'

export const getConversations = () =>
  pb.collection('conversations').getFullList({
    expand: 'participants,order',
    sort: '-updated',
  })

export const getMessages = (conversationId: string) =>
  pb.collection('messages').getFullList({
    filter: `conversation = "${conversationId}"`,
    expand: 'sender',
    sort: 'created',
  })

export const sendMessage = (data: {
  conversationId: string
  content: string
  attachment?: File
  latitude?: number
  longitude?: number
}) => {
  const formData = new FormData()
  formData.append('conversation', data.conversationId)
  formData.append('sender', pb.authStore.record?.id || '')
  formData.append('content', data.content)
  if (data.attachment) formData.append('attachment', data.attachment)
  if (data.latitude) formData.append('latitude', data.latitude.toString())
  if (data.longitude) formData.append('longitude', data.longitude.toString())

  // Update conversation last message timestamp
  pb.collection('conversations').update(data.conversationId, {
    last_message: data.content,
  })

  return pb.collection('messages').create(formData)
}

export const createDirectConversation = async (otherUserId: string) => {
  const myId = pb.authStore.record?.id
  if (!myId) throw new Error('Não autenticado')

  return pb.collection('conversations').create({
    type: 'direct',
    participants: [myId, otherUserId],
    last_message: 'Início da conversa',
  })
}
