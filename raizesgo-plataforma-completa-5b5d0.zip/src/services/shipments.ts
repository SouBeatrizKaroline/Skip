import pb from '@/lib/pocketbase/client'

export const getShipments = () =>
  pb.collection('shipments').getFullList({
    expand: 'order,transporter,order.buyer,order.seller',
    sort: '-created',
  })

export const getShipmentByOrder = (orderId: string) =>
  pb.collection('shipments').getFirstListItem(`order = "${orderId}"`, {
    expand: 'transporter,order',
  })

export const updateShipmentLocation = (id: string, lat: number, lng: number) =>
  pb.collection('shipments').update(id, {
    current_lat: lat,
    current_lng: lng,
    status: 'em_transito',
  })

export const markShipmentDelivered = (id: string, photoFile?: File) => {
  const formData = new FormData()
  formData.append('status', 'entregue')
  if (photoFile) {
    formData.append('delivery_photo', photoFile)
  }
  return pb.collection('shipments').update(id, formData)
}
