import pb from '@/lib/pocketbase/client'

export interface ProductFilter {
  category?: string
  search?: string
  isOrganic?: boolean
  minPrice?: number
  maxPrice?: number
  city?: string
  availableOnly?: boolean
}

export const getCategories = () => pb.collection('categories').getFullList({ sort: 'name' })

export const getProducts = async (filters?: ProductFilter, page = 1, perPage = 24) => {
  const filterParts: string[] = []

  if (filters?.availableOnly !== false) {
    filterParts.push('available = true')
  }
  if (filters?.category) {
    filterParts.push(`category = "${filters.category}"`)
  }
  if (filters?.isOrganic) {
    filterParts.push('is_organic = true')
  }
  if (filters?.minPrice !== undefined) {
    filterParts.push(`price >= ${filters.minPrice}`)
  }
  if (filters?.maxPrice !== undefined) {
    filterParts.push(`price <= ${filters.maxPrice}`)
  }
  if (filters?.search) {
    filterParts.push(`(name ~ "${filters.search}" || description ~ "${filters.search}")`)
  }

  return pb.collection('products').getList(page, perPage, {
    filter: filterParts.join(' && '),
    expand: 'producer,category',
    sort: '-created',
  })
}

export const getProductBySlug = (id: string) =>
  pb.collection('products').getOne(id, { expand: 'producer,category' })

export const searchProductsSemantic = (query: string, k = 12) =>
  pb.send('/backend/v1/search/products', {
    method: 'POST',
    body: JSON.stringify({ query, k }),
  })

export const createProduct = (data: FormData | Record<string, unknown>) =>
  pb.collection('products').create(data)

export const updateProduct = (id: string, data: FormData | Record<string, unknown>) =>
  pb.collection('products').update(id, data)

export const deleteProduct = (id: string) => pb.collection('products').delete(id)
