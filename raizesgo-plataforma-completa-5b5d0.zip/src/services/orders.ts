import pb from '@/lib/pocketbase/client'

export const getOrders = (role?: string) =>
  pb.collection('orders').getFullList({
    expand: 'buyer,seller,bid',
    sort: '-created',
  })

export const getOrderDetails = async (orderId: string) => {
  const order = await pb.collection('orders').getOne(orderId, {
    expand: 'buyer,seller,bid',
  })
  const items = await pb.collection('order_items').getFullList({
    filter: `order = "${orderId}"`,
    expand: 'product',
  })
  return { order, items }
}

export const createOrder = async (data: {
  sellerId: string
  items: Array<{ id: string; name: string; price: number; quantity: number }>
  deliveryAddress: string
  deliveryCity: string
  deliveryState: string
  notes?: string
}) => {
  const code = 'PED-' + Math.floor(100000 + Math.random() * 900000)
  const total = data.items.reduce((acc, item) => acc + item.price * item.quantity, 0)

  const newOrder = await pb.collection('orders').create({
    code,
    buyer: pb.authStore.record?.id,
    seller: data.sellerId,
    total,
    status: 'aguardando_pagamento',
    purchase_type: 'marketplace',
    delivery_address: data.deliveryAddress,
    delivery_city: data.deliveryCity,
    delivery_state: data.deliveryState,
    notes: data.notes || '',
  })

  for (const item of data.items) {
    await pb.collection('order_items').create({
      order: newOrder.id,
      product: item.id,
      product_name: item.name,
      quantity: item.quantity,
      unit_price: item.price,
    })
  }

  // Create initial order conversation
  await pb.collection('conversations').create({
    type: 'order',
    participants: [pb.authStore.record?.id, data.sellerId],
    order: newOrder.id,
    last_message: `Pedido ${code} criado no valor de R$ ${total.toFixed(2)}`,
  })

  return newOrder
}

export const updateOrderStatus = (id: string, status: string) =>
  pb.collection('orders').update(id, { status })
