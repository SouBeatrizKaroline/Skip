import pb from '@/lib/pocketbase/client'

export const getNotifications = () =>
  pb.collection('notifications').getFullList({
    sort: '-created',
  })

export const markNotificationRead = (id: string) =>
  pb.collection('notifications').update(id, { read: true })

export const markAllNotificationsRead = async () => {
  const unread = await pb.collection('notifications').getFullList({ filter: 'read = false' })
  for (const n of unread) {
    await pb.collection('notifications').update(n.id, { read: true })
  }
}
