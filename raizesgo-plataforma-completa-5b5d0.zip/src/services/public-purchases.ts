import pb from '@/lib/pocketbase/client'

export const getPublicPurchases = () =>
  pb.collection('public_purchases').getFullList({
    expand: 'institution',
    sort: '-created',
  })

export const getPublicPurchaseById = (id: string) =>
  pb.collection('public_purchases').getOne(id, { expand: 'institution' })

export const getParticipations = (purchaseId: string) =>
  pb.collection('participations').getFullList({
    filter: `purchase = "${purchaseId}"`,
    expand: 'participant',
  })

export const submitParticipation = (data: {
  purchaseId: string
  proposalValue: number
  notes?: string
  files?: File[]
}) => {
  const formData = new FormData()
  formData.append('purchase', data.purchaseId)
  formData.append('participant', pb.authStore.record?.id || '')
  formData.append('proposal_value', data.proposalValue.toString())
  formData.append('notes', data.notes || '')
  formData.append('status', 'enviada')

  if (data.files) {
    data.files.forEach((f) => formData.append('documents', f))
  }

  return pb.collection('participations').create(formData)
}
