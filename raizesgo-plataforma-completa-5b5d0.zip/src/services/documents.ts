import pb from '@/lib/pocketbase/client'

export const getDocuments = () => pb.collection('documents').getFullList({ sort: '-created' })

export const uploadDocument = (title: string, category: string, file: File) => {
  const formData = new FormData()
  formData.append('user', pb.authStore.record?.id || '')
  formData.append('title', title)
  formData.append('category', category)
  formData.append('file', file)
  return pb.collection('documents').create(formData)
}

export const deleteDocument = (id: string) => pb.collection('documents').delete(id)
