import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import {
  TrendingUp,
  ShoppingBag,
  Package,
  Users,
  Truck,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  MapPin,
  Sparkles,
  Building2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { AIInsightsWidget } from '@/components/AIInsightsWidget'
import { InteractiveMap } from '@/components/InteractiveMap'
import { useAuth } from '@/hooks/use-auth'
import { getProducts } from '@/services/products'
import { getPublicPurchases } from '@/services/public-purchases'

export default function Dashboard() {
  const { user } = useAuth()
  const [products, setProducts] = useState<any[]>([])
  const [purchases, setPurchases] = useState<any[]>([])

  useEffect(() => {
    getProducts({}, 1, 6)
      .then((res) => setProducts(res.items))
      .catch(() => {})
    getPublicPurchases()
      .then((res) => setPurchases(res))
      .catch(() => {})
  }, [])

  const mapMarkers = products.map((p) => ({
    id: p.id,
    title: p.name,
    type: 'offer' as const,
    lat: p.latitude || -23.18,
    lng: p.longitude || -45.88,
    price: `R$ ${p.price?.toFixed(2)}`,
    city: p.city,
  }))

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 font-display">
            Olá, {user?.name || 'Produtor Rural'} 👋
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Painel Agroecológico Regional • {user?.city || 'São José dos Campos'},{' '}
            {user?.state || 'SP'}
          </p>
        </div>

        <div className="flex gap-2">
          <Link to="/marketplace">
            <Button
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold gap-1.5"
            >
              <ShoppingBag className="w-4 h-4" /> Ver Marketplace
            </Button>
          </Link>
          <Link to="/compras-publicas">
            <Button
              size="sm"
              variant="outline"
              className="border-slate-300 text-xs font-semibold gap-1.5"
            >
              <Building2 className="w-4 h-4 text-emerald-600" /> Chamadas PNAE
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: 'Faturamento do Mês',
            val: 'R$ 14.850,00',
            change: '+12.5%',
            isUp: true,
            icon: TrendingUp,
          },
          {
            label: 'Pedidos em Aberto',
            val: '8 Pedidos',
            change: '2 PNAE',
            isUp: true,
            icon: Package,
          },
          {
            label: 'Capacidade de Carga',
            val: '1.200 kg',
            change: '85% reservado',
            isUp: true,
            icon: Truck,
          },
          {
            label: 'Avaliação da Safra',
            val: '4.9 ★★★★★',
            change: '38 avaliações',
            isUp: true,
            icon: Users,
          },
        ].map((kpi, idx) => {
          const Icon = kpi.icon
          return (
            <div
              key={idx}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3"
            >
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-slate-500">{kpi.label}</span>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="text-xl font-bold text-slate-900">{kpi.val}</div>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>{kpi.change}</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* AI Insights Widget */}
      <AIInsightsWidget role={user?.role || 'produtor'} />

      {/* Map & Offers Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              Oferta e Demanda na Sua Região
            </h3>
            <span className="text-[11px] text-slate-400">Vale do Paraíba</span>
          </div>
          <InteractiveMap markers={mapMarkers} height="h-72" />
        </div>

        {/* Recent Bids Feed */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-600" />
            Editais PNAE Abertos
          </h3>
          <div className="space-y-3">
            {purchases.slice(0, 3).map((pub) => (
              <div
                key={pub.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-emerald-500/40 transition-colors"
              >
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  {pub.type?.toUpperCase()}
                </span>
                <p className="font-bold text-xs text-slate-900 mt-1 line-clamp-1">{pub.title}</p>
                <div className="flex justify-between text-[11px] text-slate-500 mt-2">
                  <span>Orc.: R$ {pub.budget?.toLocaleString('pt-BR')}</span>
                  <Link
                    to={`/compras-publicas/${pub.id}`}
                    className="text-emerald-600 font-semibold hover:underline"
                  >
                    Ver Detalhes →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
