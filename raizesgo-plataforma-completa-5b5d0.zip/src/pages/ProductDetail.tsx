import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  ShoppingCart,
  Leaf,
  MapPin,
  User,
  ArrowLeft,
  ShieldCheck,
  MessageSquare,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getProductBySlug } from '@/services/products'
import { useCartStore } from '@/stores/cart-store'
import { createDirectConversation } from '@/services/messages'
import { useToast } from '@/hooks/use-toast'

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()
  const addItem = useCartStore((s) => s.addItem)

  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [qty, setQty] = useState(1)

  useEffect(() => {
    if (id) {
      getProductBySlug(id)
        .then((res) => {
          setProduct(res)
          if (res.min_order) setQty(res.min_order)
        })
        .finally(() => setLoading(false))
    }
  }, [id])

  const handleStartChat = async () => {
    if (!product?.producer) return
    try {
      const conv = await createDirectConversation(product.producer)
      navigate('/chat')
    } catch (_) {
      toast({
        title: 'Atenção',
        description: 'Não foi possível abrir o chat.',
        variant: 'destructive',
      })
    }
  }

  if (loading)
    return <div className="p-12 text-center text-xs text-slate-500">Carregando produto...</div>
  if (!product)
    return <div className="p-12 text-center text-xs text-slate-500">Produto não encontrado.</div>

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <Button variant="ghost" onClick={() => navigate(-1)} className="text-xs gap-1 text-slate-600">
        <ArrowLeft className="w-4 h-4" /> Voltar ao Marketplace
      </Button>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-100 rounded-xl h-72 flex items-center justify-center font-bold text-slate-400 text-3xl">
          {product.name.charAt(0)}
        </div>

        <div className="space-y-4">
          <div>
            {product.is_organic && (
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full inline-flex items-center gap-1 mb-2">
                <Leaf className="w-3 h-3" /> Certificado Orgânico
              </span>
            )}
            <h1 className="text-2xl font-extrabold text-slate-900 font-display">{product.name}</h1>
            <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" /> {product.city}, {product.state}
            </p>
          </div>

          <div className="text-3xl font-black text-slate-900">
            R$ {product.price?.toFixed(2)}{' '}
            <span className="text-xs font-semibold text-slate-400">/ {product.unit}</span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">{product.description}</p>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">
                {product.expand?.producer?.name || 'Produtor Rural'}
              </p>
              <p className="text-[11px] text-slate-500">Vendedor Verificado • SIF/DAP</p>
            </div>
            <Button
              onClick={handleStartChat}
              size="sm"
              variant="outline"
              className="text-xs gap-1.5"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-600" /> Conversar
            </Button>
          </div>

          <div className="flex gap-3 pt-4 border-t border-slate-100">
            <Button
              onClick={() => {
                addItem(
                  {
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    unit: product.unit,
                    producerId: product.producer,
                    producerName: product.expand?.producer?.name || 'Produtor Local',
                    stock: product.stock || 100,
                  },
                  qty,
                )
                toast({ title: 'Adicionado!', description: `${qty}x ${product.name} no carrinho.` })
              }}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-11 gap-2"
            >
              <ShoppingCart className="w-4 h-4" /> Adicionar ao Carrinho
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
