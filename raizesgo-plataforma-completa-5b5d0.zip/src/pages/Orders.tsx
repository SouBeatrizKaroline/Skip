import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Package, Clock, CheckCircle2, ChevronRight } from 'lucide-react'
import { getOrders } from '@/services/orders'

export default function Orders() {
  const [orders, setOrders] = useState<any[]>([])

  useEffect(() => {
    getOrders()
      .then(setOrders)
      .catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">Meus Pedidos</h1>
        <p className="text-xs text-slate-500">Acompanhe negociações e status de entrega.</p>
      </div>

      <div className="space-y-3">
        {orders.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
            Nenhum pedido cadastrado ainda.
          </div>
        ) : (
          orders.map((ord) => (
            <Link key={ord.id} to={`/pedidos/${ord.id}`} className="block">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-emerald-500 transition-colors shadow-sm flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-900">{ord.code}</span>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      {ord.status?.replace('_', ' ')?.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Total: R$ {ord.total?.toFixed(2)}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  )
}
