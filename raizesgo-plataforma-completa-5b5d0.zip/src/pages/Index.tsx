import { Link } from 'react-router-dom'
import {
  Sprout,
  ArrowRight,
  ShieldCheck,
  Truck,
  ShoppingBag,
  Users,
  Award,
  CheckCircle2,
  ChevronRight,
  MessageCircle,
  BarChart3,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion'

export default function Index() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section
        id="inicio"
        className="relative min-h-[90vh] flex items-center justify-center bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950 text-white overflow-hidden py-16"
      >
        <div className="absolute inset-0 bg-[radial-gradient(#059669_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none"></div>

        <div className="container mx-auto px-4 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Vencedor Impulso Regional 2024</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight font-display leading-tight">
              Do campo à mesa, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300">
                sem desperdício.
              </span>
            </h1>

            <p className="text-base md:text-lg text-slate-300 max-w-xl leading-relaxed">
              O ecossistema digital que conecta produtores rurais, merenda escolar (PNAE),
              feirantes, restaurantes e transportadoras em um único ambiente sustentável.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <Link to="/cadastro">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 gap-2"
                >
                  Start Gratuitamente <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <a href="#como-funciona">
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto border-slate-700 bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-sm font-semibold"
                >
                  Como Funciona
                </Button>
              </a>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800">
              <div>
                <div className="text-2xl font-bold text-emerald-400">500+</div>
                <div className="text-xs text-slate-400">Produtores Locais</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-amber-400">40+</div>
                <div className="text-xs text-slate-400">Municípios Atendidos</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-emerald-400">98%</div>
                <div className="text-xs text-slate-400">Satisfação no PNAE</div>
              </div>
            </div>
          </div>

          {/* Hero Visual Mockup */}
          <div className="relative">
            <div className="relative mx-auto max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4 animate-float">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <span className="text-[10px] font-mono text-emerald-400">
                  Painel RaízesGo ao Vivo
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-[10px] text-slate-400">Oferta Regional</span>
                  <div className="text-lg font-bold text-white">4.2 Toneladas</div>
                </div>
                <div className="bg-emerald-950/80 p-3 rounded-xl border border-emerald-800/50">
                  <span className="text-[10px] text-emerald-300">Economia em Frete</span>
                  <div className="text-lg font-bold text-emerald-400">R$ 18.400</div>
                </div>
              </div>

              <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700 space-y-2">
                <div className="flex justify-between text-xs text-slate-300 font-semibold">
                  <span>Tomate Orgânico Manteiga</span>
                  <span className="text-emerald-400">R$ 6,50/kg</span>
                </div>
                <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[80%]"></div>
                </div>
                <span className="text-[10px] text-slate-400">
                  Sítio Raízes do Vale • São José dos Campos
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona Section */}
      <section id="como-funciona" className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <h2 className="text-3xl font-extrabold text-slate-900 font-display">
              Como Funciona a Plataforma
            </h2>
            <p className="text-sm text-slate-600">
              Simplicidade e transparência para o agro em 4 passos práticos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: '01',
                title: 'Cadastre-se',
                desc: 'Registre sua propriedade ou instituição de forma 100% gratuita.',
                icon: Users,
              },
              {
                step: '02',
                title: 'Anuncie ou Busque',
                desc: 'Publique lotes de safra ou busque chamadas públicas PNAE.',
                icon: ShoppingBag,
              },
              {
                step: '03',
                title: 'Negocie Direto',
                desc: 'Ajuste quantidades e preços via chat transparente com contrato seguro.',
                icon: MessageCircle,
              },
              {
                step: '04',
                title: 'Entregue com Agilidade',
                desc: 'Rastreie frete e transporte consolidado até o destino final.',
                icon: Truck,
              },
            ].map((s, idx) => {
              const Icon = s.icon
              return (
                <div
                  key={idx}
                  className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-emerald-500 hover:shadow-md transition-all"
                >
                  <span className="text-3xl font-black text-slate-200 group-hover:text-emerald-600 transition-colors">
                    {s.step}
                  </span>
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center my-4">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-base text-slate-900 mb-1">{s.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{s.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefícios Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-2">
            <h2 className="text-3xl font-extrabold text-slate-900 font-display">
              Por que escolher a RaízesGo?
            </h2>
            <p className="text-sm text-slate-600">
              Tecnologia desenvolvida pensando na realidade do produtor e do comprador local.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Venda sem intermediários',
                desc: 'Garanta margens de lucro mais justas comercializando direto com prefeituras, escolas e restaurantes.',
              },
              {
                title: 'Compras Públicas Práticas',
                desc: 'Submita propostas e documentos para editais PNAE/PAA com apoio da IA.',
              },
              {
                title: 'Logística Inteligente',
                desc: 'Aproveite rotas de transporte que já passam na sua região para reduzir o custo do frete.',
              },
              {
                title: 'Menos Desperdício',
                desc: 'Aproximação instantânea entre safras prontas e a demanda de consumo.',
              },
              {
                title: 'Produtos Certificados',
                desc: 'Validação de selos orgânicos, agricultura familiar e registro sanitário.',
              },
              {
                title: 'Fortalecimento Regional',
                desc: 'O capital circula e fortalece a economia da própria comunidade.',
              },
            ].map((b, i) => (
              <div
                key={i}
                className="p-6 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:border-emerald-500/30 hover:shadow-md transition-all flex items-start gap-4"
              >
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-sm text-slate-900 mb-1">{b.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{b.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-20 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12 space-y-2">
            <h2 className="text-3xl font-extrabold text-slate-900 font-display">
              Dúvidas Frequentes
            </h2>
            <p className="text-sm text-slate-600">Respostas claras para perguntas do dia a dia.</p>
          </div>

          <Accordion type="single" collapsible className="w-full space-y-3">
            <AccordionItem
              value="item-1"
              className="border border-slate-200 bg-white rounded-xl px-4"
            >
              <AccordionTrigger className="text-xs font-bold text-slate-900">
                Como pequenos produtores podem participar do PNAE?
              </AccordionTrigger>
              <AccordionContent className="text-xs text-slate-600 leading-relaxed">
                Produtores rurais familiares com DAP/CAF podem se cadastrar na plataforma,
                visualizar chamadas públicas abertas em sua cidade e enviar a documentação de forma
                simples.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem
              value="item-2"
              className="border border-slate-200 bg-white rounded-xl px-4"
            >
              <AccordionTrigger className="text-xs font-bold text-slate-900">
                Como funciona o pagamento das compras?
              </AccordionTrigger>
              <AccordionContent className="text-xs text-slate-600 leading-relaxed">
                As compras geram um pedido formal com termos negociados. O pagamento ocorre via
                transferência ou faturamento acordado diretamente entre as partes.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem
              value="item-3"
              className="border border-slate-200 bg-white rounded-xl px-4"
            >
              <AccordionTrigger className="text-xs font-bold text-slate-900">
                Quais regiões são atendidas?
              </AccordionTrigger>
              <AccordionContent className="text-xs text-slate-600 leading-relaxed">
                Iniciamos pelo Vale do Paraíba e São Paulo, com capacidade de atendimento em todo o
                território nacional.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Final CTA Banner */}
      <section className="py-16 bg-gradient-to-r from-emerald-800 to-emerald-950 text-white text-center">
        <div className="container mx-auto px-4 max-w-2xl space-y-6">
          <h2 className="text-3xl font-extrabold font-display">
            Pronto para transformar o agro da sua região?
          </h2>
          <p className="text-xs md:text-sm text-emerald-100">
            Junte-se a centenas de produtores, escolas e transportadoras na maior rede agroecológica
            regional.
          </p>
          <Link to="/cadastro">
            <Button
              size="lg"
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider px-8 shadow-xl"
            >
              Criar Conta Gratuita
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
