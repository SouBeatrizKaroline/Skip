import { useState, useEffect, useRef } from 'react'
import { Send, Bot, User, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { streamAgentChat } from '@/lib/skipAi'
import pb from '@/lib/pocketbase/client'

export default function Chat() {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    {
      role: 'assistant',
      content:
        'Olá! Sou o Assistente RaízesGo. Como posso ajudar nas suas vendas ou chamadas PNAE hoje?',
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [convId, setConvId] = useState<string | null>(null)

  const handleSendAI = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || loading) return

    const userMsg = input.trim()
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }])
    setLoading(true)

    try {
      const res = await fetch(`${import.meta.env.VITE_POCKETBASE_URL}/backend/v1/ask-stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: pb.authStore.token },
        body: JSON.stringify({ message: userMsg, conversation_id: convId }),
      })

      let assistantText = ''
      setMessages((prev) => [...prev, { role: 'assistant', content: '' }])

      const result = await streamAgentChat(res, {
        onChunk: (_delta, full) => {
          assistantText = full
          setMessages((prev) => {
            const next = [...prev]
            next[next.length - 1] = { role: 'assistant', content: full }
            return next
          })
        },
      })

      if (result.conversation_id) setConvId(result.conversation_id)
    } catch (_) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Ocorreu um erro ao consultar o assistente.' },
      ])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-4">
      <div className="flex items-center gap-2">
        <div className="p-2 bg-emerald-600 text-white rounded-xl">
          <Bot className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Atendimento & Assistente IA</h1>
          <p className="text-xs text-slate-500">Tire dúvidas sobre cotações, fretes e PNAE.</p>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl h-[500px] flex flex-col justify-between p-4 shadow-sm">
        <div className="flex-1 overflow-y-auto space-y-3 p-2">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`p-3 rounded-2xl max-w-md text-xs leading-relaxed ${m.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-800'}`}
              >
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={handleSendAI} className="flex gap-2 pt-2 border-t border-slate-100">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Pergunte sobre produtos, preços ou editais..."
            className="text-xs h-10 bg-slate-50"
          />
          <Button
            type="submit"
            disabled={loading}
            className="bg-emerald-600 text-white text-xs font-bold h-10 px-4"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}
