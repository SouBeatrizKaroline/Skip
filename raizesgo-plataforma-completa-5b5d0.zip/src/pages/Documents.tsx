import { useState, useEffect } from 'react'
import { FileText, Upload, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getDocuments, uploadDocument, deleteDocument } from '@/services/documents'
import { useToast } from '@/hooks/use-toast'

export default function Documents() {
  const [docs, setDocs] = useState<any[]>([])
  const { toast } = useToast()

  const loadDocs = () => {
    getDocuments()
      .then(setDocs)
      .catch(() => {})
  }

  useEffect(() => {
    loadDocs()
  }, [])

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      await uploadDocument(file.name, 'Certificados', file)
      toast({ title: 'Documento Anexado', description: file.name })
      loadDocs()
    } catch (_) {
      toast({ title: 'Erro ao enviar', variant: 'destructive' })
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 font-display">
            Cofre de Documentos (LGPD)
          </h1>
          <p className="text-xs text-slate-500">
            Certificados DAP/CAF, notas fiscais e licenças sanitárias.
          </p>
        </div>
        <label className="bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 hover:bg-emerald-700">
          <Upload className="w-4 h-4" /> Anexar Arquivo
          <input type="file" onChange={handleFileUpload} className="hidden" />
        </label>
      </div>

      <div className="space-y-3">
        {docs.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
            Nenhum documento armazenado.
          </div>
        ) : (
          docs.map((d) => (
            <div
              key={d.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-emerald-600" />
                <div>
                  <p className="font-bold text-xs text-slate-900">{d.title}</p>
                  <p className="text-[10px] text-slate-400">{d.category}</p>
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                onClick={async () => {
                  await deleteDocument(d.id)
                  loadDocs()
                }}
                className="text-red-500"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
