import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Mail, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const { requestPasswordReset } = useAuth()
  const { toast } = useToast()

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault()
    await requestPasswordReset(email)
    setSent(true)
    toast({ title: 'Link enviado', description: 'Verifique sua caixa de entrada.' })
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-slate-50 py-12 px-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-8 space-y-4">
        <h1 className="text-xl font-bold text-slate-900">Recuperação de Senha</h1>
        {sent ? (
          <p className="text-xs text-slate-600">
            Instruções enviadas para <strong>{email}</strong>.
          </p>
        ) : (
          <form onSubmit={handleReset} className="space-y-4">
            <Input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Seu e-mail"
              className="text-xs h-10"
            />
            <Button type="submit" className="w-full bg-emerald-600 text-white font-bold text-xs">
              Enviar Link
            </Button>
          </form>
        )}
        <div className="pt-2">
          <Link
            to="/entrar"
            className="text-xs text-emerald-600 font-bold inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Voltar ao Login
          </Link>
        </div>
      </div>
    </div>
  )
}
