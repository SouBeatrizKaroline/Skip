import { ShieldCheck, Users, Package } from 'lucide-react'

export default function Admin() {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <ShieldCheck className="w-6 h-6 text-emerald-600" />
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">
          Painel Administrativo RaízesGo
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500">Usuários Ativos</span>
          <p className="text-2xl font-bold text-slate-900">128</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500">Produtos Moderados</span>
          <p className="text-2xl font-bold text-slate-900">452</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500">Volume GMV</span>
          <p className="text-2xl font-bold text-emerald-600">R$ 284.500</p>
        </div>
      </div>
    </div>
  )
}
