import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Building2, Calendar, FileText, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getPublicPurchases } from '@/services/public-purchases'

export default function PublicPurchases() {
  const [purchases, setPurchases] = useState<any[]>([])

  useEffect(() => {
    getPublicPurchases()
      .then(setPurchases)
      .catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">
          Chamadas Públicas e PNAE
        </h1>
        <p className="text-xs text-slate-500">
          Oportunidades de vendas diretas para prefeituras e escolas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {purchases.map((pub) => (
          <div
            key={pub.id}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full uppercase">
                {pub.type}
              </span>
              <h3 className="font-bold text-base text-slate-900">{pub.title}</h3>
              <p className="text-xs text-slate-600 line-clamp-2">{pub.description}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block">Orçamento Estimado</span>
                <span className="text-base font-bold text-slate-900">
                  R$ {pub.budget?.toLocaleString('pt-BR')}
                </span>
              </div>
              <Link to={`/compras-publicas/${pub.id}`}>
                <Button size="sm" className="bg-emerald-600 text-white text-xs gap-1">
                  Participar <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
