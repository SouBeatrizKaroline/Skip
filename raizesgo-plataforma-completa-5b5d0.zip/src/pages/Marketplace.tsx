import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Search, Filter, ShoppingCart, Heart, Leaf, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { getProducts, getCategories } from '@/services/products'
import { useCartStore } from '@/stores/cart-store'
import { useToast } from '@/hooks/use-toast'

export default function Marketplace() {
  const [products, setProducts] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [selectedCat, setSelectedCat] = useState<string>('')
  const [search, setSearch] = useState<string>('')
  const [organicOnly, setOrganicOnly] = useState(false)
  const [loading, setLoading] = useState(true)

  const addItem = useCartStore((s) => s.addItem)
  const { toast } = useToast()

  const loadData = async () => {
    setLoading(true)
    try {
      const [prodRes, catRes] = await Promise.all([
        getProducts({
          category: selectedCat || undefined,
          search,
          isOrganic: organicOnly || undefined,
        }),
        getCategories(),
      ])
      setProducts(prodRes.items)
      setCategories(catRes)
    } catch {
      /* intentionally ignored */
    }
    setLoading(false)
  }

  useEffect(() => {
    loadData()
  }, [selectedCat, organicOnly])

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 font-display">
            Marketplace Agrícola
          </h1>
          <p className="text-xs text-slate-500">
            Produtos frescos direto do produtor rural regional.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1 md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadData()}
              placeholder="Buscar tomate, queijo, feijão..."
              className="pl-9 text-xs h-9 bg-white"
            />
          </div>
          <Button onClick={loadData} className="bg-emerald-600 text-white text-xs h-9">
            Buscar
          </Button>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <Button
          size="sm"
          variant={selectedCat === '' ? 'default' : 'outline'}
          onClick={() => setSelectedCat('')}
          className={`text-xs rounded-full ${selectedCat === '' ? 'bg-emerald-600 text-white' : ''}`}
        >
          Todos
        </Button>
        {categories.map((c) => (
          <Button
            key={c.id}
            size="sm"
            variant={selectedCat === c.id ? 'default' : 'outline'}
            onClick={() => setSelectedCat(c.id)}
            className={`text-xs rounded-full whitespace-nowrap ${selectedCat === c.id ? 'bg-emerald-600 text-white' : ''}`}
          >
            {c.name}
          </Button>
        ))}
        <Button
          size="sm"
          variant={organicOnly ? 'default' : 'outline'}
          onClick={() => setOrganicOnly(!organicOnly)}
          className={`text-xs rounded-full gap-1.5 ${organicOnly ? 'bg-emerald-700 text-white' : 'border-emerald-300 text-emerald-700'}`}
        >
          <Leaf className="w-3.5 h-3.5" /> Orgânicos
        </Button>
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="h-64 bg-slate-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
          <p className="text-sm font-semibold text-slate-600">Nenhum produto encontrado.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((p) => (
            <div
              key={p.id}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
            >
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  {p.is_organic ? (
                    <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Leaf className="w-3 h-3" /> Orgânico
                    </span>
                  ) : (
                    <span className="text-[10px] font-semibold text-slate-500 uppercase">
                      {p.unit}
                    </span>
                  )}
                  <span className="text-[10px] font-semibold text-slate-400">
                    {p.city || 'Regional'}
                  </span>
                </div>

                <Link to={`/produtos/${p.id}`}>
                  <h3 className="font-bold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors line-clamp-1">
                    {p.name}
                  </h3>
                </Link>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {p.description}
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-baseline justify-between">
                  <div>
                    <span className="text-lg font-black text-slate-900">
                      R$ {p.price?.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-400"> / {p.unit}</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-semibold">
                    Min. {p.min_order || 1} {p.unit}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border-t border-slate-100 flex gap-2">
                <Button
                  onClick={() => {
                    addItem({
                      id: p.id,
                      name: p.name,
                      price: p.price,
                      unit: p.unit,
                      producerId: p.producer,
                      producerName: p.expand?.producer?.name || 'Produtor Local',
                      stock: p.stock || 100,
                    })
                    toast({
                      title: 'Adicionado!',
                      description: `${p.name} adicionado ao carrinho.`,
                    })
                  }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold gap-1.5 h-9"
                >
                  <ShoppingCart className="w-3.5 h-3.5" /> Adicionar
                </Button>
                <Link to={`/produtos/${p.id}`}>
                  <Button variant="outline" size="sm" className="text-xs h-9">
                    Ver
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
