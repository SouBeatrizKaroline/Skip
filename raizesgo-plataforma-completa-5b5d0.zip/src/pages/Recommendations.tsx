import { Sparkles, CheckCircle2, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Recommendations() {
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-6 rounded-2xl shadow-lg space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
          <Sparkles className="w-4 h-4" /> Recomendação por Inteligência Artificial
        </div>
        <h1 className="text-2xl font-extrabold font-display">Oportunidades "Para Você"</h1>
        <p className="text-xs text-slate-300">
          Matchmaking baseado em proximidade geográfica, capacidade de safra e demanda de chamadas
          públicas PNAE.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          {
            title: 'Chamada PNAE Merenda Escolar - Jacareí',
            match: '94% Match',
            desc: 'Prefeitura busca fornecedores de Alface e Tomate a menos de 30km do seu sítio.',
          },
          {
            title: 'Cooperativa de Transportes Vale Verde',
            match: '89% Match',
            desc: 'Rota de frete consolidada passa no seu município todas as terças-feiras.',
          },
        ].map((rec, i) => (
          <div
            key={i}
            className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3"
          >
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                {rec.match}
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <h3 className="font-bold text-sm text-slate-900">{rec.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{rec.desc}</p>
            <Button
              size="sm"
              className="w-full bg-emerald-600 text-white text-xs font-bold gap-1 mt-2"
            >
              Aproveitar Oportunidade <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}
