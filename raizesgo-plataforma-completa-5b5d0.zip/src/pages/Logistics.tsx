import { useState, useEffect } from 'react'
import { Truck, MapPin, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { InteractiveMap } from '@/components/InteractiveMap'
import { getShipments, updateShipmentLocation } from '@/services/shipments'

export default function Logistics() {
  const [shipments, setShipments] = useState<any[]>([])

  useEffect(() => {
    getShipments()
      .then(setShipments)
      .catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">
          Módulo de Logística e Fretes
        </h1>
        <p className="text-xs text-slate-500">Gestão de transporte e rotas agroecológicas.</p>
      </div>

      <InteractiveMap height="h-80" />

      <div className="space-y-3">
        <h3 className="font-bold text-sm text-slate-900">Entregas em Andamento</h3>
        {shipments.length === 0 ? (
          <div className="p-8 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-500">
            Nenhuma entrega ativa no momento.
          </div>
        ) : (
          shipments.map((s) => (
            <div
              key={s.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center"
            >
              <div>
                <p className="font-bold text-xs text-slate-900">Status: {s.status}</p>
                <p className="text-[11px] text-slate-500">
                  {s.origin_address} → {s.destination_address}
                </p>
              </div>
              <Button size="sm" variant="outline" className="text-xs">
                Atualizar Posição GPS
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
