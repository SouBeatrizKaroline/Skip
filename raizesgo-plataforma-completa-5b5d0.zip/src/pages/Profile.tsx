import { useAuth } from '@/hooks/use-auth'
import { User, MapPin, Award } from 'lucide-react'

export default function Profile() {
  const { user } = useAuth()

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-emerald-600 text-white font-bold text-2xl flex items-center justify-center">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-slate-900">
              {user?.name || 'Sítio Raízes'}
            </h1>
            <p className="text-xs text-slate-500">{user?.email}</p>
            <span className="inline-block mt-1 text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
              {user?.role?.toUpperCase() || 'PRODUTOR'}
            </span>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
          {user?.bio ||
            'Produtor rural engajado no fortalecimento da agricultura familiar sustentável.'}
        </div>
      </div>
    </div>
  )
}
