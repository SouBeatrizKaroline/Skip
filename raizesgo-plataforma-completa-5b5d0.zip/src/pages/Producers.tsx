import { useState, useEffect } from 'react'
import { MapPin, ShieldCheck, Star, MessageSquare } from 'lucide-react'
import { Button } from '@/components/ui/button'
import pb from '@/lib/pocketbase/client'

export default function Producers() {
  const [producers, setProducers] = useState<any[]>([])

  useEffect(() => {
    pb.collection('users')
      .getFullList({ filter: 'role = "produtor" || role = "admin"' })
      .then(setProducers)
      .catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">
          Produtores Rurais Cadastrados
        </h1>
        <p className="text-xs text-slate-500">
          Conheça os agricultores familiares e cooperativas da sua região.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {producers.map((prod) => (
          <div
            key={prod.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-emerald-600 text-white font-bold text-lg flex items-center justify-center">
                {prod.name?.charAt(0) || 'P'}
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">{prod.name}</h3>
                <p className="text-[11px] text-slate-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-emerald-600" />{' '}
                  {prod.city || 'São José dos Campos'}, {prod.state || 'SP'}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
              {prod.bio || 'Produtor rural focado no cultivo ecológico e sustentável.'}
            </p>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                ★ {prod.rating_avg || '4.9'}
              </span>
              <Button size="sm" variant="outline" className="text-xs gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" /> Conversar
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
