import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Building2, ArrowLeft, Send } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { getPublicPurchaseById, submitParticipation } from '@/services/public-purchases'
import { useToast } from '@/hooks/use-toast'

export default function PublicPurchaseDetail() {
  const { id } = useParams()
  const { toast } = useToast()
  const [pub, setPub] = useState<any>(null)
  const [proposalVal, setProposalVal] = useState('')

  useEffect(() => {
    if (id)
      getPublicPurchaseById(id)
        .then(setPub)
        .catch(() => {})
  }, [id])

  const handleSubmitProposal = async () => {
    if (!id || !proposalVal) return
    try {
      await submitParticipation({
        purchaseId: id,
        proposalValue: parseFloat(proposalVal),
      })
      toast({ title: 'Proposta Enviada!', description: 'Sua proposta foi gravada no edital.' })
    } catch (_) {
      toast({ title: 'Erro ao enviar', description: 'Tente novamente.', variant: 'destructive' })
    }
  }

  if (!pub)
    return <div className="p-12 text-center text-xs text-slate-500">Carregando chamada...</div>

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <Link
        to="/compras-publicas"
        className="text-xs font-bold text-emerald-600 inline-flex items-center gap-1"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Voltar
      </Link>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">{pub.title}</h1>
        <p className="text-xs text-slate-600">{pub.description}</p>

        <div className="p-4 bg-slate-50 rounded-xl space-y-3 border border-slate-200">
          <h3 className="font-bold text-xs text-slate-800">Enviar Proposta de Fornecimento</h3>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Valor total da proposta (R$)"
              value={proposalVal}
              onChange={(e) => setProposalVal(e.target.value)}
              className="text-xs h-10 bg-white"
            />
            <Button
              onClick={handleSubmitProposal}
              className="bg-emerald-600 text-white text-xs font-bold gap-1.5 h-10"
            >
              <Send className="w-4 h-4" /> Enviar
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
