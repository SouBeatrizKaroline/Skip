import { useState, useEffect } from 'react'
import { Bell, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getNotifications, markAllNotificationsRead } from '@/services/notifications'

export default function Notifications() {
  const [notifs, setNotifs] = useState<any[]>([])

  useEffect(() => {
    getNotifications()
      .then(setNotifs)
      .catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-extrabold text-slate-900 font-display">
          Central de Notificações
        </h1>
        <Button
          onClick={() => markAllNotificationsRead()}
          size="sm"
          variant="outline"
          className="text-xs gap-1"
        >
          <Check className="w-3.5 h-3.5" /> Marcar lidas
        </Button>
      </div>

      <div className="space-y-3">
        {notifs.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
            Você não possui notificações pendentes.
          </div>
        ) : (
          notifs.map((n) => (
            <div
              key={n.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex items-center gap-3"
            >
              <Bell className="w-4 h-4 text-emerald-600" />
              <div>
                <p className="font-bold text-xs text-slate-900">{n.title}</p>
                <p className="text-xs text-slate-600">{n.message}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
