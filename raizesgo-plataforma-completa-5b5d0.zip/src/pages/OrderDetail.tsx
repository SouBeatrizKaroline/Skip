import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Package, CheckCircle2, Truck, ArrowLeft, MessageSquare } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getOrderDetails } from '@/services/orders'

export default function OrderDetail() {
  const { id } = useParams()
  const [data, setData] = useState<any>(null)

  useEffect(() => {
    if (id)
      getOrderDetails(id)
        .then(setData)
        .catch(() => {})
  }, [id])

  if (!data)
    return <div className="p-12 text-center text-xs text-slate-500">Carregando detalhes...</div>

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <Link
        to="/pedidos"
        className="text-xs font-bold text-emerald-600 inline-flex items-center gap-1"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Voltar aos Pedidos
      </Link>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900">{data.order.code}</h1>
            <p className="text-xs text-slate-500">Status: {data.order.status}</p>
          </div>
          <Link to="/chat">
            <Button size="sm" className="bg-emerald-600 text-white text-xs gap-1.5">
              <MessageSquare className="w-4 h-4" /> Abrir Chat do Pedido
            </Button>
          </Link>
        </div>

        <div className="space-y-2">
          <h3 className="font-bold text-xs text-slate-800">Itens Comprados</h3>
          {data.items.map((item: any) => (
            <div
              key={item.id}
              className="p-3 bg-slate-50 rounded-xl flex justify-between text-xs text-slate-700"
            >
              <span>
                {item.quantity}x {item.product_name}
              </span>
              <span className="font-bold">R$ {(item.unit_price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
