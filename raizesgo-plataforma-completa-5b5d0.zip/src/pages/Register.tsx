import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Sprout, CheckCircle, User, MapPin, Building, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'

export default function Register() {
  const [step, setStep] = useState(1)
  const [role, setRole] = useState('produtor')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [city, setCity] = useState('São José dos Campos')
  const [state, setState] = useState('SP')
  const [cpfCnpj, setCpfCnpj] = useState('')
  const [loading, setLoading] = useState(false)

  const { signUp } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleFinish = async () => {
    setLoading(true)
    const { error } = await signUp(email, password)
    setLoading(false)

    if (error) {
      toast({
        title: 'Erro ao criar conta',
        description: error.message || 'Verifique os dados.',
        variant: 'destructive',
      })
    } else {
      toast({
        title: 'Conta criada com sucesso!',
        description: 'Acesse o sistema e complete seu perfil.',
      })
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-[85vh] flex items-center justify-center bg-slate-50 py-12 px-4">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-xl p-8 space-y-6">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 font-display">
            Cadastro no Ecossistema
          </h1>
          <p className="text-xs text-slate-500">Passo {step} de 3</p>
        </div>

        {/* Stepper progress */}
        <div className="flex gap-2">
          <div
            className={`h-1.5 flex-1 rounded-full ${step >= 1 ? 'bg-emerald-600' : 'bg-slate-200'}`}
          ></div>
          <div
            className={`h-1.5 flex-1 rounded-full ${step >= 2 ? 'bg-emerald-600' : 'bg-slate-200'}`}
          ></div>
          <div
            className={`h-1.5 flex-1 rounded-full ${step >= 3 ? 'bg-emerald-600' : 'bg-slate-200'}`}
          ></div>
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Qual seu papel no agro?
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                {
                  id: 'produtor',
                  label: 'Produtor Rural',
                  desc: 'Agricultor familiar ou cooperativa',
                },
                {
                  id: 'comprador',
                  label: 'Comprador / Restaurante',
                  desc: 'Feiras, mercados e alimentação',
                },
                {
                  id: 'instituicao',
                  label: 'Instituição Pública / PNAE',
                  desc: 'Escolas e Secretarias',
                },
                {
                  id: 'transportadora',
                  label: 'Transportadora',
                  desc: 'Fretes e logística de carga',
                },
              ].map((r) => (
                <div
                  key={r.id}
                  onClick={() => setRole(r.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    role === r.id
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <p className="font-bold text-xs text-slate-900">{r.label}</p>
                  <p className="text-[10px] text-slate-500 mt-1">{r.desc}</p>
                </div>
              ))}
            </div>
            <Button
              onClick={() => setStep(2)}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10"
            >
              Avançar
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Nome completo / Razão Social
              </label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Sítio Raízes"
                className="text-xs h-10"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">E-mail</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="contato@agro.com"
                className="text-xs h-10"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Senha (mínimo 8 caracteres)
              </label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="text-xs h-10"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1 text-xs">
                Voltar
              </Button>
              <Button
                onClick={() => setStep(3)}
                className="flex-1 bg-emerald-600 text-white text-xs"
              >
                Avançar
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">CPF ou CNPJ</label>
              <Input
                value={cpfCnpj}
                onChange={(e) => setCpfCnpj(e.target.value)}
                placeholder="00.000.000/0001-00"
                className="text-xs h-10"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Município</label>
                <Input
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="text-xs h-10"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">UF</label>
                <Input
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="text-xs h-10"
                />
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1 text-xs">
                Voltar
              </Button>
              <Button
                onClick={handleFinish}
                disabled={loading}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10"
              >
                {loading ? 'Criando...' : 'Finalizar Cadastro'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
