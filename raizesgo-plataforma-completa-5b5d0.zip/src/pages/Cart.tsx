import { useNavigate } from 'react-router-dom'
import { Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCartStore } from '@/stores/cart-store'
import { createOrder } from '@/services/orders'
import { useToast } from '@/hooks/use-toast'

export default function Cart() {
  const { items, removeItem, updateQuantity, clearCart, getSubtotal } = useCartStore()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleCheckout = async () => {
    if (items.length === 0) return
    try {
      const sellerId = items[0].producerId
      await createOrder({
        sellerId,
        items: items.map((i) => ({ id: i.id, name: i.name, price: i.price, quantity: i.quantity })),
        deliveryAddress: 'Rua das Palmeiras, 100',
        deliveryCity: 'São José dos Campos',
        deliveryState: 'SP',
      })
      clearCart()
      toast({ title: 'Pedido Criado!', description: 'Seu pedido foi encaminhado para o produtor.' })
      navigate('/pedidos')
    } catch (_) {
      toast({
        title: 'Erro ao criar pedido',
        description: 'Tente novamente.',
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-extrabold text-slate-900 font-display">
        Meu Carrinho de Compras
      </h1>

      {items.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 space-y-3">
          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="text-sm font-semibold text-slate-600">Seu carrinho está vazio.</p>
          <Button
            onClick={() => navigate('/marketplace')}
            className="bg-emerald-600 text-white text-xs"
          >
            Ir ao Marketplace
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-3">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between gap-4"
              >
                <div>
                  <h3 className="font-bold text-xs text-slate-900">{item.name}</h3>
                  <p className="text-[11px] text-slate-500">
                    {item.producerName} • R$ {item.price?.toFixed(2)} / {item.unit}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                    className="w-14 text-xs h-8 border border-slate-200 rounded text-center"
                  />
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => removeItem(item.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4 h-fit">
            <h3 className="font-bold text-sm text-slate-900">Resumo do Pedido</h3>
            <div className="flex justify-between text-xs text-slate-600 border-b border-slate-100 pb-2">
              <span>Subtotal</span>
              <span className="font-bold text-slate-900">R$ {getSubtotal().toFixed(2)}</span>
            </div>
            <Button
              onClick={handleCheckout}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10 gap-2"
            >
              Finalizar Pedido <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
