import { Heart } from 'lucide-react'

export default function Favorites() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-4">
      <h1 className="text-2xl font-extrabold text-slate-900 font-display">Produtos Favoritados</h1>
      <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 space-y-2">
        <Heart className="w-10 h-10 text-slate-300 mx-auto" />
        <p className="text-xs text-slate-500">Você ainda não possui produtos favoritados.</p>
      </div>
    </div>
  )
}
