import { useAuth } from '@/hooks/use-auth'
import { Button } from '@/components/ui/button'

export default function Settings() {
  const { signOut } = useAuth()

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-extrabold text-slate-900 font-display">
        Configurações da Conta
      </h1>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
        <h3 className="font-bold text-sm text-slate-900">Privacidade & LGPD</h3>
        <p className="text-xs text-slate-600">
          Exportação e gerenciamento dos seus dados na plataforma.
        </p>
        <Button variant="outline" className="text-xs">
          Exportar Meus Dados (JSON)
        </Button>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
        <h3 className="font-bold text-sm font-slate-900 text-red-600">Sessão</h3>
        <Button onClick={signOut} variant="destructive" className="text-xs">
          Encerrar Sessão
        </Button>
      </div>
    </div>
  )
}
