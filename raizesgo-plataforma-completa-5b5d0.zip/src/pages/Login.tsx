import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Sprout, Lock, Mail, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'

export default function Login() {
  const [email, setEmail] = useState('1aspiraqualquer@gmail.com')
  const [password, setPassword] = useState('Skip@Pass')
  const [loading, setLoading] = useState(false)

  const { signIn } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await signIn(email, password)
    setLoading(false)

    if (error) {
      toast({
        title: 'Erro ao entrar',
        description: 'Credenciais inválidas. Tente novamente.',
        variant: 'destructive',
      })
    } else {
      toast({ title: 'Bem-vindo de volta!', description: 'Acesso realizado com sucesso.' })
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-[85vh] flex items-center justify-center bg-slate-50 py-12 px-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex w-12 h-12 rounded-xl bg-emerald-600 text-white items-center justify-center mb-2 shadow-md">
            <Sprout className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 font-display">Acessar RaízesGo</h1>
          <p className="text-xs text-slate-500">
            Entre na sua conta para gerenciar safras, fretes e licitações.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">
              E-mail corporativo ou pessoal
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-9 text-xs h-10 border-slate-200"
                placeholder="seu.email@exemplo.com"
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-700">Senha</label>
              <Link
                to="/recuperar-senha"
                className="text-[11px] font-semibold text-emerald-600 hover:underline"
              >
                Esqueceu a senha?
              </Link>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-9 text-xs h-10 border-slate-200"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10 gap-2"
          >
            {loading ? 'Acessando...' : 'Entrar no Sistema'} <ArrowRight className="w-4 h-4" />
          </Button>
        </form>

        <div className="text-center pt-4 border-t border-slate-100 text-xs text-slate-600">
          Ainda não tem conta?{' '}
          <Link to="/cadastro" className="font-bold text-emerald-600 hover:underline">
            Criar conta gratuita
          </Link>
        </div>
      </div>
    </div>
  )
}
