import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'

import Layout from './components/Layout'
import Index from './pages/Index'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import Dashboard from './pages/Dashboard'
import Marketplace from './pages/Marketplace'
import ProductDetail from './pages/ProductDetail'
import Producers from './pages/Producers'
import Recommendations from './pages/Recommendations'
import Cart from './pages/Cart'
import Orders from './pages/Orders'
import OrderDetail from './pages/OrderDetail'
import Logistics from './pages/Logistics'
import PublicPurchases from './pages/PublicPurchases'
import PublicPurchaseDetail from './pages/PublicPurchaseDetail'
import Chat from './pages/Chat'
import Favorites from './pages/Favorites'
import Documents from './pages/Documents'
import Notifications from './pages/Notifications'
import Profile from './pages/Profile'
import Settings from './pages/Settings'
import Admin from './pages/Admin'
import NotFound from './pages/NotFound'

const App = () => (
  <BrowserRouter>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/entrar" element={<Login />} />
            <Route path="/cadastro" element={<Register />} />
            <Route path="/recuperar-senha" element={<ForgotPassword />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/marketplace" element={<Marketplace />} />
            <Route path="/produtos/:id" element={<ProductDetail />} />
            <Route path="/produtores" element={<Producers />} />
            <Route path="/recomendacoes" element={<Recommendations />} />
            <Route path="/carrinho" element={<Cart />} />
            <Route path="/pedidos" element={<Orders />} />
            <Route path="/pedidos/:id" element={<OrderDetail />} />
            <Route path="/logistica" element={<Logistics />} />
            <Route path="/compras-publicas" element={<PublicPurchases />} />
            <Route path="/compras-publicas/:id" element={<PublicPurchaseDetail />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/favoritos" element={<Favorites />} />
            <Route path="/documentos" element={<Documents />} />
            <Route path="/notificacoes" element={<Notifications />} />
            <Route path="/perfil" element={<Profile />} />
            <Route path="/configuracoes" element={<Settings />} />
            <Route path="/admin" element={<Admin />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AuthProvider>
    </TooltipProvider>
  </BrowserRouter>
)

export default App
