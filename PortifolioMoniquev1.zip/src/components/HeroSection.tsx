import { useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowDown, FolderGit2, Linkedin, Github } from 'lucide-react'

const LINKEDIN_URL = 'https://www.linkedin.com/in/monique-cardoso21/'
const GITHUB_URL = 'https://github.com/moniquecardoso25'

export function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let w = (canvas.width = canvas.offsetWidth)
    let h = (canvas.height = canvas.offsetHeight)
    const onResize = () => {
      w = canvas.width = canvas.offsetWidth
      h = canvas.height = canvas.offsetHeight
    }
    window.addEventListener('resize', onResize)

    const N = 100
    const particles = Array.from({ length: N }, (_, i) => {
      const angle = i * 137.508 * (Math.PI / 180)
      const r = Math.sqrt(i / N) * Math.min(w, h) * 0.35
      return {
        x: Math.random() * w,
        y: Math.random() * h,
        tx: w / 2 + r * Math.cos(angle),
        ty: h / 2 + r * Math.sin(angle),
        r: 1.5 + Math.random() * 2,
        phase: Math.random() * Math.PI * 2,
        i,
      }
    })

    let raf = 0
    let time = 0

    const draw = () => {
      time += 0.008
      ctx.fillStyle = 'rgba(26, 20, 16, 0.12)'
      ctx.fillRect(0, 0, w, h)

      const lerp = Math.min(time / 3, 1)
      particles.forEach((p) => {
        const wobble = Math.sin(time + p.phase) * 0.5
        p.x += (p.tx - p.x) * 0.025 * lerp + wobble * 0.08
        p.y += (p.ty - p.y) * 0.025 * lerp + Math.cos(time + p.phase) * 0.08
      })

      const cx = w / 2,
        cy = h / 2,
        range = 130
      for (let i = 0; i < N; i++) {
        const p = particles[i]
        if (Math.abs(p.x - cx) < range && Math.abs(p.y - cy) < range) {
          for (let j = i + 1; j < N; j++) {
            const q = particles[j]
            if (Math.abs(q.x - cx) < range && Math.abs(q.y - cy) < range) {
              const d = Math.hypot(p.x - q.x, p.y - q.y)
              if (d < 50) {
                ctx.strokeStyle = `rgba(245, 158, 11, ${0.25 * (1 - d / 50)})`
                ctx.lineWidth = 0.6
                ctx.beginPath()
                ctx.moveTo(p.x, p.y)
                ctx.lineTo(q.x, q.y)
                ctx.stroke()
              }
            }
          }
        }
      }

      particles.forEach((p) => {
        const dist = Math.hypot(p.x - cx, p.y - cy)
        const isCenter = dist < 120
        if (isCenter) {
          ctx.fillStyle = `rgba(16, 185, 129, ${0.7 + Math.sin(time + p.phase) * 0.15})`
        } else {
          ctx.fillStyle = `rgba(245, 158, 11, ${0.6 + Math.sin(time + p.phase) * 0.15})`
        }
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fill()
      })

      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#1a1410]"
    >
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#1a1410]/40 via-transparent to-[#1a1410]/80" />
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto py-20">
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-amber-50 mb-4 animate-fade-in-up">
          Monique <span className="text-amber-400">Cardoso</span>
        </h1>
        <p className="text-base sm:text-xl text-emerald-300/80 font-medium mb-3 animate-fade-in-up">
          Cientista de Dados • IA Generativa • LLMs • Machine Learning
        </p>
        <p className="text-sm sm:text-lg text-stone-400 max-w-2xl mx-auto mb-8 animate-fade-in-up">
          Transformando dados em inteligência, curiosidade em inovação e ideias em soluções reais.
        </p>
        <div className="flex flex-wrap gap-3 justify-center animate-fade-in-up">
          <Button asChild className="bg-amber-500 hover:bg-amber-600 text-stone-900 font-semibold">
            <a href="#sobre">
              <ArrowDown className="w-4 h-4 mr-2" /> Explorar Portfólio
            </a>
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-amber-500/30 text-amber-50 hover:bg-amber-500/10"
          >
            <a href="#projetos">
              <FolderGit2 className="w-4 h-4 mr-2" /> Projetos
            </a>
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-amber-500/30 text-amber-50 hover:bg-amber-500/10"
          >
            <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer">
              <Linkedin className="w-4 h-4 mr-2" /> LinkedIn
            </a>
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-amber-500/30 text-amber-50 hover:bg-amber-500/10"
          >
            <a href={GITHUB_URL} target="_blank" rel="noopener noreferrer">
              <Github className="w-4 h-4 mr-2" /> GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
