migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')
    if (!users.fields.getByName('role')) {
      users.fields.add(
        new SelectField({
          name: 'role',
          values: [
            'community',
            'cooperative',
            'administrator',
            'partner',
            'government',
            'researcher',
          ],
          maxSelect: 1,
        }),
      )
    }
    app.save(users)

    app.save(
      new Collection({
        name: 'communities',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'name', type: 'text', required: true },
          { name: 'slug', type: 'text' },
          { name: 'description', type: 'text' },
          { name: 'history', type: 'text' },
          { name: 'city', type: 'text' },
          { name: 'state', type: 'text' },
          { name: 'region', type: 'text' },
          { name: 'leader_name', type: 'text' },
          { name: 'members_count', type: 'number' },
          {
            name: 'type',
            type: 'select',
            values: ['quilombola', 'indigenous', 'extractivist', 'ribeirinho', 'family_farming'],
            maxSelect: 1,
          },
          { name: 'certifications', type: 'text' },
          { name: 'contact_phone', type: 'text' },
          { name: 'contact_email', type: 'email' },
          { name: 'website', type: 'url' },
          {
            name: 'photos',
            type: 'file',
            maxSelect: 10,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          },
          {
            name: 'logo',
            type: 'file',
            maxSelect: 1,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE INDEX idx_communities_slug ON communities (slug)',
          'CREATE INDEX idx_communities_region ON communities (region)',
        ],
      }),
    )

    const cId = app.findCollectionByNameOrId('communities').id

    app.save(
      new Collection({
        name: 'products',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          { name: 'name', type: 'text', required: true },
          { name: 'slug', type: 'text' },
          { name: 'description', type: 'text' },
          { name: 'story', type: 'text' },
          {
            name: 'category',
            type: 'select',
            required: true,
            values: [
              'frutos_nativos',
              'artesanato',
              'biojoias',
              'alimentos',
              'cosmeticos_naturais',
              'fitoterapicos',
              'produtos_culturais',
            ],
            maxSelect: 1,
          },
          { name: 'subcategory', type: 'text' },
          { name: 'price', type: 'number', min: 0 },
          { name: 'origin', type: 'text' },
          {
            name: 'availability',
            type: 'select',
            values: ['available', 'limited', 'out_of_stock'],
            maxSelect: 1,
          },
          { name: 'certifications', type: 'text' },
          { name: 'featured', type: 'bool' },
          {
            name: 'photos',
            type: 'file',
            maxSelect: 8,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          },
          { name: 'embedding', type: 'vector', dimensions: 1536, distance: 'cosine' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE INDEX idx_products_slug ON products (slug)',
          'CREATE INDEX idx_products_category ON products (category)',
          'CREATE INDEX idx_products_community ON products (community_id)',
        ],
      }),
    )

    const pId = app.findCollectionByNameOrId('products').id

    app.save(
      new Collection({
        name: 'traceability_events',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          {
            name: 'product_id',
            type: 'relation',
            required: true,
            collectionId: pId,
            maxSelect: 1,
            cascadeDelete: true,
          },
          {
            name: 'event_type',
            type: 'select',
            values: ['harvest', 'processing', 'transport', 'sale', 'certification'],
            maxSelect: 1,
          },
          { name: 'description', type: 'text' },
          { name: 'event_date', type: 'date' },
          { name: 'location', type: 'text' },
          { name: 'method', type: 'text' },
          { name: 'environmental_impact', type: 'text' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_trace_product ON traceability_events (product_id)'],
      }),
    )

    app.save(
      new Collection({
        name: 'orders',
        type: 'base',
        listRule: "@request.auth.id != '' && buyer_id = @request.auth.id",
        viewRule: "@request.auth.id != '' && buyer_id = @request.auth.id",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && buyer_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && buyer_id = @request.auth.id",
        fields: [
          {
            name: 'buyer_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          {
            name: 'status',
            type: 'select',
            values: ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'],
            maxSelect: 1,
          },
          { name: 'total', type: 'number', min: 0 },
          { name: 'contact_phone', type: 'text' },
          { name: 'notes', type: 'text' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_orders_buyer ON orders (buyer_id)'],
      }),
    )

    const oId = app.findCollectionByNameOrId('orders').id

    app.save(
      new Collection({
        name: 'order_items',
        type: 'base',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          {
            name: 'order_id',
            type: 'relation',
            required: true,
            collectionId: oId,
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'product_id', type: 'relation', required: true, collectionId: pId, maxSelect: 1 },
          { name: 'quantity', type: 'number', min: 1, onlyInt: true },
          { name: 'price', type: 'number', min: 0 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_order_items_order ON order_items (order_id)'],
      }),
    )

    app.save(
      new Collection({
        name: 'favorites',
        type: 'base',
        listRule: "@request.auth.id != '' && user_id = @request.auth.id",
        viewRule: "@request.auth.id != '' && user_id = @request.auth.id",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          {
            name: 'product_id',
            type: 'relation',
            required: true,
            collectionId: pId,
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE UNIQUE INDEX idx_fav_user_product ON favorites (user_id, product_id)'],
      }),
    )
  },
  (app) => {
    ;[
      'favorites',
      'order_items',
      'orders',
      'traceability_events',
      'products',
      'communities',
    ].forEach((n) => {
      try {
        app.delete(app.findCollectionByNameOrId(n))
      } catch (_) {}
    })
  },
)
