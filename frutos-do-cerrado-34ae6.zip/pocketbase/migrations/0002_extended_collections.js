migrate(
  (app) => {
    const cId = app.findCollectionByNameOrId('communities').id
    const pId = app.findCollectionByNameOrId('products').id

    app.save(
      new Collection({
        name: 'projects',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          { name: 'name', type: 'text', required: true },
          { name: 'slug', type: 'text' },
          { name: 'description', type: 'text' },
          {
            name: 'status',
            type: 'select',
            values: ['planning', 'active', 'completed', 'paused'],
            maxSelect: 1,
          },
          { name: 'budget', type: 'number', min: 0 },
          { name: 'spent', type: 'number', min: 0 },
          { name: 'start_date', type: 'date' },
          { name: 'end_date', type: 'date' },
          { name: 'sdgs', type: 'text' },
          { name: 'progress', type: 'number', min: 0, max: 100 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE INDEX idx_projects_slug ON projects (slug)',
          'CREATE INDEX idx_projects_status ON projects (status)',
        ],
      }),
    )

    app.save(
      new Collection({
        name: 'events',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          { name: 'title', type: 'text', required: true },
          { name: 'description', type: 'text' },
          { name: 'date', type: 'date' },
          { name: 'location', type: 'text' },
          {
            name: 'type',
            type: 'select',
            values: ['cultural', 'educational', 'environmental', 'commercial'],
            maxSelect: 1,
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_events_date ON events (date)'],
      }),
    )

    app.save(
      new Collection({
        name: 'partners',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: 'name', type: 'text', required: true },
          { name: 'description', type: 'text' },
          {
            name: 'type',
            type: 'select',
            values: ['ngo', 'university', 'government', 'company', 'cooperative'],
            maxSelect: 1,
          },
          {
            name: 'logo',
            type: 'file',
            maxSelect: 1,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          },
          { name: 'website', type: 'url' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_partners_type ON partners (type)'],
      }),
    )

    app.save(
      new Collection({
        name: 'documents',
        type: 'base',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: 'title', type: 'text', required: true },
          {
            name: 'type',
            type: 'select',
            values: ['certification', 'project_report', 'license', 'other'],
            maxSelect: 1,
          },
          {
            name: 'file',
            type: 'file',
            maxSelect: 5,
            mimeTypes: ['application/pdf', 'image/jpeg', 'image/png'],
          },
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          {
            name: 'project_id',
            type: 'relation',
            collectionId: app.findCollectionByNameOrId('projects').id,
            maxSelect: 1,
          },
          { name: 'product_id', type: 'relation', collectionId: pId, maxSelect: 1 },
          { name: 'user_id', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_docs_community ON documents (community_id)'],
      }),
    )

    app.save(
      new Collection({
        name: 'messages',
        type: 'base',
        listRule:
          "@request.auth.id != '' && (sender_id = @request.auth.id || receiver_id = @request.auth.id)",
        viewRule:
          "@request.auth.id != '' && (sender_id = @request.auth.id || receiver_id = @request.auth.id)",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && sender_id = @request.auth.id",
        deleteRule:
          "@request.auth.id != '' && (sender_id = @request.auth.id || receiver_id = @request.auth.id)",
        fields: [
          {
            name: 'sender_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          {
            name: 'receiver_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          { name: 'content', type: 'text', required: true },
          { name: 'read', type: 'bool' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE INDEX idx_messages_receiver ON messages (receiver_id)',
          'CREATE INDEX idx_messages_sender ON messages (sender_id)',
        ],
      }),
    )

    app.save(
      new Collection({
        name: 'reviews',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'product_id',
            type: 'relation',
            required: true,
            collectionId: pId,
            maxSelect: 1,
            cascadeDelete: true,
          },
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          { name: 'rating', type: 'number', min: 1, max: 5, onlyInt: true },
          { name: 'comment', type: 'text' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_reviews_product ON reviews (product_id)'],
      }),
    )
  },
  (app) => {
    ;['reviews', 'messages', 'documents', 'partners', 'events', 'projects'].forEach((n) => {
      try {
        app.delete(app.findCollectionByNameOrId(n))
      } catch (_) {}
    })
  },
)
