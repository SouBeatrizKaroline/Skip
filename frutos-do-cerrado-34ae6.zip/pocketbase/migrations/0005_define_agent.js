migrate(
  (app) => {
    $ai.agents.define(app, {
      slug: 'cerrado-assistente',
      name: 'Assistente Cerrado',
      description:
        'Assistente virtual da plataforma Frutos do Cerrado que responde sobre comunidades, produtos, preservação, rastreabilidade e ODS.',
      systemPrompt:
        'Você é o Assistente Cerrado, da plataforma Frutos do Cerrado. Responda com tom caloroso e institucional sobre comunidades tradicionais, produtos do Cerrado, preservação ambiental, rastreabilidade, ODS da ONU e programas parceiros. Se não souber, diga que não tem essa informação. Use linguagem acessível e respeitosa.',
      tier: 'fast',
      tools: [
        { collection: 'communities', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
      ],
      memory: [
        {
          type: 'faq',
          payload: {
            qa: [
              {
                question: 'Como cadastro minha comunidade?',
                answer:
                  "Acesse a plataforma, crie uma conta com perfil de Comunidade, e no dashboard clique em 'Cadastrar Comunidade'.",
              },
              {
                question: 'O que é rastreabilidade?',
                answer:
                  'Rastreabilidade é o registro completo da jornada do produto: origem, comunidade, data de coleta, método sustentável e impacto ambiental.',
              },
              {
                question: 'Como comprar produtos?',
                answer:
                  'Navegue no catálogo de produtos, adicione ao carrinho e finalize o pedido. O contato com o produtor é direto, sem intermediários.',
              },
              {
                question: 'Quais são os ODS atendidos?',
                answer:
                  'A plataforma contribui com ODS 1 (Erradicação da Pobreza), 8 (Trabalho Decente), 12 (Consumo Sustentável), 13 (Ação Climática) e 15 (Vida Terrestre).',
              },
            ],
          },
        },
        {
          type: 'text',
          payload: {
            text: 'O Cerrado é o segundo maior bioma do Brasil, com mais de 11 mil espécies de plantas nativas. Abriga comunidades quilombolas, indígenas, extrativistas e agricultores familiares que dependem da sua preservação.',
          },
        },
      ],
    })
  },
  (app) => {
    $ai.agents.delete(app, 'cerrado-assistente')
  },
)
