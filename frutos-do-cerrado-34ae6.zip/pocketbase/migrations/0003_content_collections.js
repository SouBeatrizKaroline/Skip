migrate(
  (app) => {
    const cId = app.findCollectionByNameOrId('communities').id

    app.save(
      new Collection({
        name: 'logs',
        type: 'base',
        listRule: "@request.auth.id != '' && @request.auth.role = 'administrator'",
        viewRule: "@request.auth.id != '' && @request.auth.role = 'administrator'",
        createRule: "@request.auth.id != ''",
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: 'user_id', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
          { name: 'action', type: 'text', required: true },
          { name: 'entity_type', type: 'text' },
          { name: 'entity_id', type: 'text' },
          { name: 'details', type: 'json' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE INDEX idx_logs_user ON logs (user_id)',
          'CREATE INDEX idx_logs_created ON logs (created DESC)',
        ],
      }),
    )

    app.save(
      new Collection({
        name: 'esg_indicators',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: 'year', type: 'number', required: true, onlyInt: true },
          { name: 'month', type: 'number', onlyInt: true },
          { name: 'communities_count', type: 'number', onlyInt: true },
          { name: 'preserved_area_ha', type: 'number' },
          { name: 'beneficiary_families', type: 'number', onlyInt: true },
          { name: 'generated_income', type: 'number' },
          { name: 'commercialized_products', type: 'number', onlyInt: true },
          { name: 'co2_avoided', type: 'number' },
          { name: 'preserved_trees', type: 'number', onlyInt: true },
          { name: 'active_projects', type: 'number', onlyInt: true },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_esg_year_month ON esg_indicators (year, month)'],
      }),
    )

    app.save(
      new Collection({
        name: 'cultural_items',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          { name: 'title', type: 'text', required: true },
          { name: 'description', type: 'text' },
          { name: 'content', type: 'text' },
          {
            name: 'type',
            type: 'select',
            required: true,
            values: [
              'stories',
              'documentaries',
              'recipes',
              'traditional_knowledge',
              'medicinal_plants',
              'festivities',
              'music',
              'handicrafts',
              'languages',
            ],
            maxSelect: 1,
          },
          {
            name: 'media',
            type: 'file',
            maxSelect: 5,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'video/mp4'],
          },
          { name: 'embedding', type: 'vector', dimensions: 1536, distance: 'cosine' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_cultural_type ON cultural_items (type)'],
      }),
    )

    app.save(
      new Collection({
        name: 'learning_tracks',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: 'title', type: 'text', required: true },
          { name: 'description', type: 'text' },
          {
            name: 'type',
            type: 'select',
            values: ['course', 'booklet', 'video', 'infographic'],
            maxSelect: 1,
          },
          { name: 'duration_hours', type: 'number' },
          { name: 'content', type: 'text' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_learning_type ON learning_tracks (type)'],
      }),
    )

    app.save(
      new Collection({
        name: 'tourism_experiences',
        type: 'base',
        listRule: '',
        viewRule: '',
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
        deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
          },
          { name: 'community_id', type: 'relation', collectionId: cId, maxSelect: 1 },
          { name: 'title', type: 'text', required: true },
          { name: 'description', type: 'text' },
          {
            name: 'type',
            type: 'select',
            values: ['experience', 'lodging', 'guide', 'trail', 'event'],
            maxSelect: 1,
          },
          { name: 'price', type: 'number', min: 0 },
          { name: 'location', type: 'text' },
          { name: 'duration', type: 'text' },
          { name: 'max_participants', type: 'number', onlyInt: true },
          {
            name: 'photos',
            type: 'file',
            maxSelect: 8,
            mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_tourism_type ON tourism_experiences (type)'],
      }),
    )
  },
  (app) => {
    ;['tourism_experiences', 'learning_tracks', 'cultural_items', 'esg_indicators', 'logs'].forEach(
      (n) => {
        try {
          app.delete(app.findCollectionByNameOrId(n))
        } catch (_) {}
      },
    )
  },
)
