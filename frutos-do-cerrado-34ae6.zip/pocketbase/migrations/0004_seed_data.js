migrate(
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    try {
      app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com')
    } catch (_) {
      const admin = new Record(usersCol)
      admin.setEmail('1aspiraqualquer@gmail.com')
      admin.setPassword('Skip@Pass')
      admin.setVerified(true)
      admin.set('name', 'Administrador')
      admin.set('role', 'administrator')
      app.save(admin)
    }
    const adminId = app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com').id

    const commCol = app.findCollectionByNameOrId('communities')
    const communities = [
      {
        name: 'Comunidade Quilombola Kalunga',
        slug: 'quilombola-kalunga',
        description: 'Maior comunidade quilombola do Brasil',
        history:
          'O povo Kalunga habita o Cerrado há mais de 300 anos, preservando tradições e saberes ancestrais.',
        city: 'Cavalcante',
        state: 'GO',
        region: 'Norte',
        leader_name: 'Donizete Kalunga',
        members_count: 1500,
        type: 'quilombola',
        certifications: 'Orgânico, Comércio Justo',
        contact_phone: '+55 62 99999-0001',
        contact_email: 'kalunga@frutosdocerrado.org',
      },
      {
        name: 'Associação Extrativista Buriti',
        slug: 'associacao-buriti',
        description: 'Extrativismo sustentável do buriti',
        history: 'Famílias extrativistas que preservam as veredas e buritizais do Tocantins.',
        city: 'Porto Nacional',
        state: 'TO',
        region: 'Centro',
        leader_name: 'Maria das Dores',
        members_count: 85,
        type: 'extractivist',
        certifications: 'Orgânico',
        contact_phone: '+55 63 99999-0002',
        contact_email: 'buriti@frutosdocerrado.org',
      },
      {
        name: 'Cooperativa de Baru do Cerrado',
        slug: 'cooperativa-baru',
        description: 'Cooperativa de produtores de castanha de baru',
        history:
          'Cooperativa formada por agricultores familiares que transformam o baru em produtos sustentáveis.',
        city: 'Cristalina',
        state: 'MG',
        region: 'Sudeste',
        leader_name: 'João Pereira',
        members_count: 120,
        type: 'family_farming',
        certifications: 'Orgânico, Comércio Justo, FSC',
        contact_phone: '+55 38 99999-0003',
        contact_email: 'baru@frutosdocerrado.org',
      },
    ]
    const commIds = {}
    communities.forEach((c) => {
      try {
        app.findFirstRecordByData('communities', 'slug', c.slug)
      } catch (_) {
        const rec = new Record(commCol)
        Object.entries(c).forEach(([k, v]) => rec.set(k, v))
        rec.set('user_id', adminId)
        app.save(rec)
      }
      commIds[c.slug] = app.findFirstRecordByData('communities', 'slug', c.slug).id
    })

    const prodCol = app.findCollectionByNameOrId('products')
    const products = [
      {
        name: 'Pequi Desidratado',
        slug: 'pequi-desidratado',
        description: 'Pequi selecionado e desidratado artesanalmente',
        story: 'O pequi é fruto sagrado do Cerrado, coletado por comunidades tradicionais.',
        category: 'frutos_nativos',
        subcategory: 'Pequi',
        price: 45.9,
        origin: 'Cavalcante, GO',
        availability: 'available',
        certifications: 'Orgânico',
        featured: true,
        community_id: commIds['quilombola-kalunga'],
      },
      {
        name: 'Castanha de Baru Torrada',
        slug: 'castanha-baru-torrada',
        description: 'Castanha de baru torrada, rica em proteínas',
        story: 'O baru é uma árvore nativa do Cerrado, sua castanha é superalimento.',
        category: 'frutos_nativos',
        subcategory: 'Baru',
        price: 38.5,
        origin: 'Cristalina, MG',
        availability: 'available',
        certifications: 'Orgânico, Comércio Justo',
        featured: true,
        community_id: commIds['cooperativa-baru'],
      },
      {
        name: 'Óleo de Buriti Puro',
        slug: 'oleo-buriti-puro',
        description: 'Óleo de buriti prensado a frio',
        story: 'O buriti é a árvore da vida nas veredas do Cerrado.',
        category: 'cosmeticos_naturais',
        subcategory: 'Buriti',
        price: 52.0,
        origin: 'Porto Nacional, TO',
        availability: 'limited',
        certifications: 'Orgânico',
        featured: true,
        community_id: commIds['associacao-buriti'],
      },
      {
        name: 'Polpa de Cagaita Congelada',
        slug: 'polpa-cagaita',
        description: 'Polpa de cagaita congelada para sucos e sobremesas',
        story: 'A cagaita é um fruto doce e refrescante do Cerrado.',
        category: 'frutos_nativos',
        subcategory: 'Cagaita',
        price: 18.0,
        origin: 'Cavalcante, GO',
        availability: 'available',
        certifications: 'Orgânico',
        featured: false,
        community_id: commIds['quilombola-kalunga'],
      },
      {
        name: 'Biojoia de Semente de Pequi',
        slug: 'biojoia-pequi',
        description: 'Colar artesanal com sementes de pequi',
        story: 'Arte que transforma sementes em joias únicas do Cerrado.',
        category: 'biojoias',
        subcategory: '',
        price: 75.0,
        origin: 'Cavalcante, GO',
        availability: 'available',
        certifications: '',
        featured: false,
        community_id: commIds['quilombola-kalunga'],
      },
      {
        name: 'Farinha de Baru',
        slug: 'farinha-baru',
        description: 'Farinha de baru sem glúten, rica em nutrientes',
        story: 'A farinha de baru é versátil e nutritiva.',
        category: 'alimentos',
        subcategory: 'Baru',
        price: 28.0,
        origin: 'Cristalina, MG',
        availability: 'available',
        certifications: 'Orgânico',
        featured: false,
        community_id: commIds['cooperativa-baru'],
      },
    ]
    products.forEach((p) => {
      try {
        app.findFirstRecordByData('products', 'slug', p.slug)
      } catch (_) {
        const rec = new Record(prodCol)
        Object.entries(p).forEach(([k, v]) => rec.set(k, v))
        rec.set('user_id', adminId)
        app.save(rec)
      }
    })

    const projCol = app.findCollectionByNameOrId('projects')
    const projects = [
      {
        name: 'Reflorestamento do Cerrado',
        slug: 'reflorestamento-cerrado',
        description: 'Plantio de mudas nativas para recuperação de áreas degradadas',
        status: 'active',
        budget: 250000,
        spent: 85000,
        start_date: '2026-01-01',
        end_date: '2026-12-31',
        sdgs: '13,15',
        progress: 35,
        community_id: commIds['quilombola-kalunga'],
      },
      {
        name: 'Capacitação de Jovens Extrativistas',
        slug: 'capacizacao-extrativistas',
        description: 'Formação técnica para jovens em práticas de extrativismo sustentável',
        status: 'active',
        budget: 120000,
        spent: 45000,
        start_date: '2026-02-01',
        end_date: '2026-11-30',
        sdgs: '4,8',
        progress: 50,
        community_id: commIds['associacao-buriti'],
      },
    ]
    projects.forEach((p) => {
      try {
        app.findFirstRecordByData('projects', 'slug', p.slug)
      } catch (_) {
        const rec = new Record(projCol)
        Object.entries(p).forEach(([k, v]) => rec.set(k, v))
        rec.set('user_id', adminId)
        app.save(rec)
      }
    })

    const partCol = app.findCollectionByNameOrId('partners')
    const partners = [
      {
        name: 'Universidade de Brasília',
        description: 'Pesquisa e extensão no Cerrado',
        type: 'university',
        website: 'https://unb.br',
      },
      {
        name: 'Instituto Socioambiental',
        description: 'Defesa de direitos socioambientais',
        type: 'ngo',
        website: 'https://socioambiental.org',
      },
      {
        name: 'WWF Brasil',
        description: 'Conservação da biodiversidade',
        type: 'ngo',
        website: 'https://wwf.org.br',
      },
    ]
    partners.forEach((p) => {
      try {
        app.findFirstRecordByData('partners', 'name', p.name)
      } catch (_) {
        const rec = new Record(partCol)
        Object.entries(p).forEach(([k, v]) => rec.set(k, v))
        app.save(rec)
      }
    })

    const esgCol = app.findCollectionByNameOrId('esg_indicators')
    try {
      app.findFirstRecordByData('esg_indicators', 'year', 2026)
    } catch (_) {
      const esg = new Record(esgCol)
      esg.set('year', 2026)
      esg.set('month', 7)
      esg.set('communities_count', 48)
      esg.set('preserved_area_ha', 12500)
      esg.set('beneficiary_families', 320)
      esg.set('generated_income', 850000)
      esg.set('commercialized_products', 2400)
      esg.set('co2_avoided', 1800)
      esg.set('preserved_trees', 45000)
      esg.set('active_projects', 12)
      app.save(esg)
    }
  },
  (app) => {},
)
