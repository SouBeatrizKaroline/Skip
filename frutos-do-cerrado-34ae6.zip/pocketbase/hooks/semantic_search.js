routerAdd(
  'POST',
  '/backend/v1/search',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const query = (body.query || '').trim()
      if (!query) return e.badRequestError('missing query')
      const collection = body.collection || 'products'
      const embedRes = $ai.embed({ input: query })
      const results = $vectors.search(e, collection, {
        field: 'embedding',
        query: embedRes.data[0].embedding,
        k: body.k || 10,
        expand: ['community_id'],
      })
      return e.json(200, results)
    } catch (err) {
      if (err instanceof SkipAiConfigError) return e.json(503, { error: 'AI indisponível' })
      if (err instanceof SkipAiError) return e.json(502, { error: 'busca semântica indisponível' })
      throw err
    }
  },
  $apis.requireAuth(),
)
