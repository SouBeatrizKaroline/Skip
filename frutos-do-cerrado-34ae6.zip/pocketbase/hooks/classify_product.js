routerAdd(
  'POST',
  '/backend/v1/classify-product',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const name = (body.name || '').trim()
      const description = (body.description || '').trim()
      if (!name) return e.badRequestError('name is required')

      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você classifica produtos do Cerrado. Responda APENAS com um JSON: {"category": "frutos_nativos|artesanato|biojoias|alimentos|cosmeticos_naturais|fitoterapicos|produtos_culturais", "subcategory": "string"}. Categorias de frutos: Pequi, Baru, Buriti, Cagaita.',
          },
          { role: 'user', content: 'Nome: ' + name + '\nDescrição: ' + description },
        ],
      })

      let parsed = null
      try {
        parsed = JSON.parse(reply.choices[0].message.content)
      } catch (_) {}
      return e.json(200, { suggestion: parsed })
    } catch (err) {
      if (err instanceof SkipAiError) return e.json(502, { error: 'classificação indisponível' })
      throw err
    }
  },
  $apis.requireAuth(),
)
