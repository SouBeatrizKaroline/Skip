onRecordAfterUpdateSuccess((e) => {
  const titleChanged = e.record.getString('title') !== e.record.original().getString('title')
  const descChanged =
    e.record.getString('description') !== e.record.original().getString('description')
  if (!titleChanged && !descChanged) return e.next()
  const text = (e.record.getString('title') + ' ' + e.record.getString('description')).trim()
  if (!text) return e.next()
  try {
    const res = $ai.embed({ input: text })
    const record = $app.findRecordById('cultural_items', e.record.id)
    record.set('embedding', res.data[0].embedding)
    $app.save(record)
  } catch (err) {
    console.log('embed failed for cultural item ' + e.record.id)
  }
  return e.next()
}, 'cultural_items')
