import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import { MapPin, Target, Calendar } from 'lucide-react'
import { getProjects } from '@/services/projects'
import type { Project } from '@/types'

export function MapSection() {
  return (
    <section className="bg-white py-20">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center mb-10">
          <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
            Mapa do Cerrado
          </span>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
            Explore o território
          </h2>
          <p className="mt-4 text-stone-500">
            Visualize comunidades, projetos, áreas preservadas, nascentes e muito mais no mapa
            interativo do Cerrado.
          </p>
        </div>
        <div className="overflow-hidden rounded-2xl border border-stone-200 shadow-subtle">
          <iframe
            title="Mapa do Cerrado"
            src="https://www.openstreetmap.org/export/embed.html?bbox=-55%2C-20%2C-40%2C-10&layer=mapnik"
            className="h-[400px] w-full"
            loading="lazy"
          />
        </div>
        <div className="mt-6 text-center">
          <Link to="/mapa">
            <Button className="bg-emerald-700 hover:bg-emerald-800 text-white">
              Abrir mapa interativo <MapPin className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

export function ProjectsPreview() {
  const [items, setItems] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getProjects()
      .then((d) => {
        setItems(d.slice(0, 2))
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <section className="bg-stone-50 py-20">
      <div className="container">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
              Projetos
            </span>
            <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
              Projetos em ação
            </h2>
          </div>
          <Link to="/projetos">
            <Button variant="ghost" className="text-emerald-700">
              Ver todos
            </Button>
          </Link>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {loading
            ? Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-48 rounded-2xl" />
              ))
            : items.map((p) => (
                <Link key={p.id} to={`/projetos/${p.slug}`}>
                  <Card className="h-full border-stone-200 transition-all hover:shadow-elevation hover:border-emerald-200">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <Badge
                          className={
                            p.status === 'active'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-amber-100 text-amber-800'
                          }
                        >
                          {p.status === 'active'
                            ? 'Ativo'
                            : p.status === 'completed'
                              ? 'Concluído'
                              : 'Planejamento'}
                        </Badge>
                        <span className="text-xs text-stone-400">ODS: {p.sdgs}</span>
                      </div>
                      <h3 className="font-display text-lg font-semibold text-emerald-900">
                        {p.name}
                      </h3>
                      <p className="mt-1 text-sm text-stone-500 line-clamp-2">{p.description}</p>
                      <div className="mt-4 space-y-2">
                        <div className="flex items-center justify-between text-xs text-stone-500">
                          <span>Progresso</span>
                          <span>{p.progress}%</span>
                        </div>
                        <Progress value={p.progress} className="h-2" />
                      </div>
                      <div className="mt-4 flex items-center gap-4 text-xs text-stone-400">
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3" /> R$ {p.budget.toLocaleString('pt-BR')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {p.start_date?.slice(0, 7)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
        </div>
      </div>
    </section>
  )
}
