import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { ArrowRight, MapPin } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-emerald-900 via-green-800 to-emerald-950">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(251,146,60,0.15),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(34,197,94,0.1),transparent_50%)]" />
      <div className="container relative py-20 md:py-32">
        <div className="max-w-3xl animate-fade-in-up">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm text-emerald-100 backdrop-blur-sm">
            <MapPin className="h-4 w-4" />
            Plataforma GovTech do Cerrado Brasileiro
          </div>
          <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight text-white">
            Tecnologia preservando culturas, fortalecendo comunidades e protegendo o Cerrado.
          </h1>
          <p className="mt-6 text-lg text-emerald-100/80 max-w-2xl">
            Conectamos comunidades tradicionais, produtores e consumidores para promover
            sustentabilidade, comércio justo e preservação do bioma mais ameaçado do Brasil.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <Link to="/produtos">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-orange-600 hover:bg-orange-700 text-white"
              >
                Conhecer Plataforma <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link to="/comunidades">
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto border-white/30 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              >
                Explorar Comunidades
              </Button>
            </Link>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-stone-50 to-transparent" />
    </section>
  )
}
