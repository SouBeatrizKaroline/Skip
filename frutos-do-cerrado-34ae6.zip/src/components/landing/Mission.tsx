import { Sprout, Heart, Globe } from 'lucide-react'

const VALUES = [
  {
    icon: Sprout,
    title: 'Sustentabilidade',
    desc: 'Práticas que preservam o Cerrado e garantem renda às comunidades.',
  },
  {
    icon: Heart,
    title: 'Comércio Justo',
    desc: 'Conexão direta entre produtores e consumidores, sem intermediários.',
  },
  {
    icon: Globe,
    title: 'Impacto Social',
    desc: 'Fortalecimento cultural, econômico e ambiental das comunidades tradicionais.',
  },
]

export function Mission() {
  return (
    <section className="bg-stone-50 py-20">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center mb-12">
          <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
            Nossa Missão
          </span>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
            Conectar para preservar e prosperar
          </h2>
          <p className="mt-4 text-stone-500">
            Acreditamos que a tecnologia pode ser uma ponte entre tradição e inovação, garantindo
            que as comunidades do Cerrado floresçam com dignidade e respeito.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {VALUES.map((v) => (
            <div
              key={v.title}
              className="group rounded-2xl border border-stone-200 bg-white p-8 transition-all hover:shadow-elevation hover:border-emerald-200"
            >
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 transition-colors group-hover:bg-emerald-700 group-hover:text-white">
                <v.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 font-display text-xl font-semibold text-emerald-900">
                {v.title}
              </h3>
              <p className="text-sm text-stone-500 leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

const IMPACT_STATS = [
  { value: '48', label: 'Comunidades participantes' },
  { value: '12.500 ha', label: 'Área preservada' },
  { value: '320', label: 'Famílias beneficiadas' },
  { value: 'R$ 850K', label: 'Renda gerada' },
  { value: '1.800 t', label: 'CO₂ evitado' },
  { value: '45.000', label: 'Árvores preservadas' },
]

export function Impact() {
  return (
    <section className="bg-emerald-900 py-20">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
            Impacto em números
          </h2>
          <p className="mt-2 text-emerald-100/70">
            Resultados reais do trabalho conjunto com as comunidades do Cerrado
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {IMPACT_STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold text-orange-400">
                {s.value}
              </div>
              <div className="mt-1 text-xs text-emerald-100/60">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
