import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { MapPin, ArrowRight } from 'lucide-react'
import { getCommunities } from '@/services/communities'
import { getProducts } from '@/services/products'
import type { Community, Product } from '@/types'

export function CommunitiesPreview() {
  const [items, setItems] = useState<Community[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getCommunities()
      .then((d) => {
        setItems(d.slice(0, 3))
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <section className="bg-white py-20">
      <div className="container">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
              Comunidades
            </span>
            <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
              Comunidades do Cerrado
            </h2>
          </div>
          <Link to="/comunidades">
            <Button variant="ghost" className="text-emerald-700">
              Ver todas <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {loading
            ? Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-64 rounded-2xl" />
              ))
            : items.map((c) => (
                <Link key={c.id} to={`/comunidades/${c.slug}`}>
                  <Card className="group overflow-hidden border-stone-200 transition-all hover:shadow-elevation hover:border-emerald-200">
                    <div className="h-40 bg-gradient-to-br from-emerald-700 to-green-900 flex items-center justify-center">
                      <MapPin className="h-10 w-10 text-white/40" />
                    </div>
                    <CardContent className="p-5">
                      <Badge className="mb-2 bg-emerald-100 text-emerald-800">{c.type}</Badge>
                      <h3 className="font-display text-lg font-semibold text-emerald-900 group-hover:text-emerald-700">
                        {c.name}
                      </h3>
                      <p className="mt-1 text-sm text-stone-500">
                        {c.city}, {c.state} • {c.members_count} famílias
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
        </div>
      </div>
    </section>
  )
}

const CATEGORY_LABELS: Record<string, string> = {
  frutos_nativos: 'Frutos Nativos',
  artesanato: 'Artesanato',
  biojoias: 'Biojoias',
  alimentos: 'Alimentos',
  cosmeticos_naturais: 'Cosméticos Naturais',
  fitoterapicos: 'Fitoterápicos',
  produtos_culturais: 'Produtos Culturais',
}

export function ProductsPreview() {
  const [items, setItems] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getProducts({ filter: 'featured = true', perPage: 4 })
      .then((r) => {
        setItems(r.items || [])
        setLoading(false)
      })
      .catch(() => {
        setLoading(false)
        setItems([])
      })
  }, [])

  return (
    <section className="bg-stone-50 py-20">
      <div className="container">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
              Produtos
            </span>
            <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
              Do Cerrado para você
            </h2>
          </div>
          <Link to="/produtos">
            <Button variant="ghost" className="text-emerald-700">
              Ver catálogo <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-72 rounded-2xl" />
              ))
            : items.map((p) => (
                <Link key={p.id} to={`/produtos/${p.slug}`}>
                  <Card className="group overflow-hidden border-stone-200 transition-all hover:shadow-elevation">
                    <div className="h-44 bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center">
                      <span className="text-4xl">🌿</span>
                    </div>
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="mb-2 text-xs">
                        {CATEGORY_LABELS[p.category] || p.category}
                      </Badge>
                      <h3 className="font-semibold text-emerald-900 group-hover:text-emerald-700 text-sm">
                        {p.name}
                      </h3>
                      <p className="mt-1 text-xs text-stone-500">{p.origin}</p>
                      <p className="mt-2 font-bold text-orange-700">R$ {p.price.toFixed(2)}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
        </div>
      </div>
    </section>
  )
}
