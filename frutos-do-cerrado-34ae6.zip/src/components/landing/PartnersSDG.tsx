import { useEffect, useState } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { Building2 } from 'lucide-react'
import { getPartners } from '@/services/projects'
import type { Partner } from '@/types'

const SDGS = [
  { num: 1, title: 'Erradicação da Pobreza', color: 'bg-rose-500' },
  { num: 8, title: 'Trabalho Decente', color: 'bg-amber-500' },
  { num: 12, title: 'Consumo Sustentável', color: 'bg-yellow-600' },
  { num: 13, title: 'Ação Climática', color: 'bg-green-600' },
  { num: 15, title: 'Vida Terrestre', color: 'bg-emerald-700' },
]

export function Partners() {
  const [items, setItems] = useState<Partner[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getPartners()
      .then((d) => {
        setItems(d)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <section className="bg-white py-20">
      <div className="container">
        <div className="text-center mb-10">
          <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
            Parceiros
          </span>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
            Juntos pelo Cerrado
          </h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))
            : items.map((p) => (
                <div
                  key={p.id}
                  className="flex flex-col items-center justify-center rounded-xl border border-stone-200 p-6 transition-colors hover:border-emerald-200 hover:bg-emerald-50/30"
                >
                  <Building2 className="h-8 w-8 text-emerald-600 mb-2" />
                  <p className="text-sm font-medium text-stone-700 text-center">{p.name}</p>
                  <p className="text-xs text-stone-400 capitalize">{p.type}</p>
                </div>
              ))}
        </div>
      </div>
    </section>
  )
}

export function SDG() {
  return (
    <section className="bg-stone-50 py-20">
      <div className="container">
        <div className="text-center mb-10">
          <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
            ODS da ONU
          </span>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
            Objetivos de Desenvolvimento Sustentável
          </h2>
          <p className="mt-4 text-stone-500 max-w-2xl mx-auto">
            Nossas ações contribuem diretamente para os Objetivos de Desenvolvimento Sustentável da
            ONU.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {SDGS.map((sdg) => (
            <div
              key={sdg.num}
              className="group flex flex-col items-center rounded-2xl border border-stone-200 bg-white p-6 transition-all hover:shadow-elevation"
            >
              <div
                className={`flex h-14 w-14 items-center justify-center rounded-full ${sdg.color} text-white font-bold text-lg transition-transform group-hover:scale-110`}
              >
                {sdg.num}
              </div>
              <p className="mt-3 text-center text-xs font-medium text-stone-600">{sdg.title}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
