import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Mail, Phone, MapPin, ArrowRight } from 'lucide-react'

export function ContactCTA() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-emerald-900 via-green-800 to-emerald-950 py-20">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(251,146,60,0.1),transparent_60%)]" />
      <div className="container relative">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
            Faça parte dessa rede de transformação
          </h2>
          <p className="mt-4 text-emerald-100/80">
            Junte-se a comunidades, produtores e consumidores que estão construindo um futuro mais
            sustentável para o Cerrado brasileiro.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/signup">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-orange-600 hover:bg-orange-700 text-white"
              >
                Criar conta <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link to="/comunidades">
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto border-white/30 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              >
                Explorar comunidades
              </Button>
            </Link>
          </div>
          <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-emerald-100/70">
            <span className="flex items-center gap-2">
              <Mail className="h-4 w-4" /> contato@frutosdocerrado.org
            </span>
            <span className="flex items-center gap-2">
              <Phone className="h-4 w-4" /> +55 61 3000-0000
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="h-4 w-4" /> Brasília, DF
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
