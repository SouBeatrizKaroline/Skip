import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

const FAQ_ITEMS = [
  {
    q: 'O que é a plataforma Frutos do Cerrado?',
    a: 'É uma plataforma digital que conecta comunidades tradicionais, produtores e consumidores para promover sustentabilidade, comércio justo e preservação do bioma Cerrado.',
  },
  {
    q: 'Como posso comprar produtos das comunidades?',
    a: 'Acesse a página de Produtos, navegue pelo catálogo por categoria ou comunidade, e adicione os itens ao carrinho. Após finalizar, sua compra é registrada e você acompanha o status do pedido.',
  },
  {
    q: 'O que é a rastreabilidade dos produtos?',
    a: 'Cada produto possui um histórico completo de eventos — colheita, processamento, transporte, venda e certificação — que garante transparência sobre origem e impacto ambiental.',
  },
  {
    q: 'Como minha comunidade pode participar?',
    a: 'Crie uma conta, cadastre sua comunidade com informações sobre história, localização e tipo. Após o cadastro, você poderá publicar produtos, projetos e experiências de turismo.',
  },
  {
    q: 'O que são os indicadores ESG?',
    a: 'São métricas de impacto ambiental, social e de governança: área preservada, famílias beneficiadas, renda gerada, CO₂ evitado e árvores preservadas, disponíveis no dashboard ESG.',
  },
  {
    q: 'Como funciona o Assistente IA?',
    a: 'O assistente virtual responde perguntas sobre comunidades, produtos, preservação, rastreabilidade e ODS, utilizando inteligência artificial com base nos dados da plataforma.',
  },
]

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="bg-white py-20">
      <div className="container max-w-3xl">
        <div className="text-center mb-10">
          <span className="text-sm font-semibold uppercase tracking-wider text-orange-600">
            Dúvidas Frequentes
          </span>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold text-emerald-900">
            Perguntas e respostas
          </h2>
        </div>
        <div className="space-y-3">
          {FAQ_ITEMS.map((item, i) => (
            <div
              key={i}
              className="rounded-xl border border-stone-200 bg-stone-50/50 overflow-hidden transition-colors hover:border-emerald-200"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="flex w-full items-center justify-between gap-4 p-5 text-left"
              >
                <span className="font-medium text-stone-800">{item.q}</span>
                <ChevronDown
                  className={cn(
                    'h-5 w-5 shrink-0 text-emerald-600 transition-transform duration-300',
                    openIndex === i && 'rotate-180',
                  )}
                />
              </button>
              <div
                className={cn(
                  'grid transition-all duration-300',
                  openIndex === i ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
                )}
              >
                <div className="overflow-hidden">
                  <p className="px-5 pb-5 text-sm text-stone-500 leading-relaxed">{item.a}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
