import { Link } from 'react-router-dom'
import { Leaf, Mail, Phone, MapPin } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-stone-200 bg-stone-50">
      <div className="container py-12">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-600 to-green-800">
                <Leaf className="h-4 w-4 text-white" />
              </div>
              <span className="font-display font-bold text-emerald-900">Frutos do Cerrado</span>
            </div>
            <p className="text-sm text-stone-500 leading-relaxed">
              Plataforma digital que conecta comunidades tradicionais, produtores e consumidores
              para promover sustentabilidade e preservação do Cerrado.
            </p>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-stone-800">Navegação</h3>
            <ul className="space-y-2 text-sm text-stone-500">
              <li>
                <Link to="/comunidades" className="hover:text-emerald-700">
                  Comunidades
                </Link>
              </li>
              <li>
                <Link to="/produtos" className="hover:text-emerald-700">
                  Produtos
                </Link>
              </li>
              <li>
                <Link to="/projetos" className="hover:text-emerald-700">
                  Projetos
                </Link>
              </li>
              <li>
                <Link to="/cultura" className="hover:text-emerald-700">
                  Cultura
                </Link>
              </li>
              <li>
                <Link to="/esg" className="hover:text-emerald-700">
                  Dashboard ESG
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-stone-800">Plataforma</h3>
            <ul className="space-y-2 text-sm text-stone-500">
              <li>
                <Link to="/mapa" className="hover:text-emerald-700">
                  Mapa do Cerrado
                </Link>
              </li>
              <li>
                <Link to="/turismo" className="hover:text-emerald-700">
                  Turismo Comunitário
                </Link>
              </li>
              <li>
                <Link to="/chat" className="hover:text-emerald-700">
                  Assistente IA
                </Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-emerald-700">
                  Entrar
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-stone-800">Contato</h3>
            <ul className="space-y-2 text-sm text-stone-500">
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4" /> contato@frutosdocerrado.org
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4" /> +55 61 3000-0000
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4" /> Brasília, DF
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-stone-200 pt-6 text-center text-sm text-stone-400">
          © 2026 Frutos do Cerrado. Tecnologia preservando culturas.
        </div>
      </div>
    </footer>
  )
}
