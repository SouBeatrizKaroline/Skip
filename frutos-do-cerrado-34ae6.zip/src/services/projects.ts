import pb from '@/lib/pocketbase/client'
import type { Project, Partner } from '@/types'

export const getProjects = (): Promise<Project[]> =>
  pb.collection('projects').getFullList({ sort: '-created', expand: 'community_id' })

export const getProject = (id: string): Promise<Project> =>
  pb.collection('projects').getOne(id, { expand: 'community_id' })

export const getProjectBySlug = (slug: string): Promise<Project> =>
  pb.collection('projects').getFirstListItem(`slug="${slug}"`, { expand: 'community_id' })

export const createProject = (data: any) => pb.collection('projects').create(data)

export const getPartners = (): Promise<Partner[]> =>
  pb.collection('partners').getFullList({ sort: 'name' })
