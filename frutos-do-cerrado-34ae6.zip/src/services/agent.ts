import pb from '@/lib/pocketbase/client'

export const askAgent = (message: string, conversationId?: string) =>
  pb.send('/backend/v1/ask', {
    method: 'POST',
    body: JSON.stringify({ message, conversation_id: conversationId }),
    headers: { 'Content-Type': 'application/json' },
  })

export const semanticSearch = (query: string, collection: string = 'products', k?: number) =>
  pb.send('/backend/v1/search', {
    method: 'POST',
    body: JSON.stringify({ query, collection, k }),
    headers: { 'Content-Type': 'application/json' },
  })

export const classifyProduct = (name: string, description: string) =>
  pb.send('/backend/v1/classify-product', {
    method: 'POST',
    body: JSON.stringify({ name, description }),
    headers: { 'Content-Type': 'application/json' },
  })
