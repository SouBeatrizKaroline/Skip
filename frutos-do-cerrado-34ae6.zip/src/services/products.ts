import pb from '@/lib/pocketbase/client'
import type { Product, TraceabilityEvent, Review } from '@/types'

export const getProducts = (params?: {
  filter?: string
  sort?: string
  page?: number
  perPage?: number
}): Promise<any> =>
  pb.collection('products').getList(params?.page ?? 1, params?.perPage ?? 12, {
    filter: params?.filter || '',
    sort: params?.sort || '-created',
    expand: 'community_id',
  })

export const getProduct = (id: string): Promise<Product> =>
  pb.collection('products').getOne(id, { expand: 'community_id' })

export const getProductBySlug = (slug: string): Promise<Product> =>
  pb.collection('products').getFirstListItem(`slug="${slug}"`, { expand: 'community_id' })

export const getTraceability = (productId: string): Promise<TraceabilityEvent[]> =>
  pb
    .collection('traceability_events')
    .getFullList({ filter: `product_id="${productId}"`, sort: 'event_date' })

export const getReviews = (productId: string): Promise<Review[]> =>
  pb.collection('reviews').getFullList({ filter: `product_id="${productId}"`, sort: '-created' })

export const createProduct = (data: any) => pb.collection('products').create(data)
export const updateProduct = (id: string, data: any) => pb.collection('products').update(id, data)
