import pb from '@/lib/pocketbase/client'
import type { CulturalItem, TourismExperience, LearningTrack, Message, ESGIndicator } from '@/types'

export const getCulturalItems = (type?: string): Promise<CulturalItem[]> =>
  pb
    .collection('cultural_items')
    .getFullList({ filter: type ? `type="${type}"` : '', sort: '-created' })

export const getTourismExperiences = (): Promise<TourismExperience[]> =>
  pb.collection('tourism_experiences').getFullList({ sort: '-created', expand: 'community_id' })

export const getLearningTracks = (): Promise<LearningTrack[]> =>
  pb.collection('learning_tracks').getFullList({ sort: '-created' })

export const getMessages = (userId: string): Promise<Message[]> =>
  pb
    .collection('messages')
    .getFullList({ filter: `sender_id="${userId}" || receiver_id="${userId}"`, sort: 'created' })

export const sendMessage = (data: { sender_id: string; receiver_id: string; content: string }) =>
  pb.collection('messages').create(data)

export const getESGIndicators = (): Promise<ESGIndicator[]> =>
  pb.collection('esg_indicators').getFullList({ sort: '-year,-month' })

export const getEvents = () =>
  pb.collection('events').getFullList({ sort: 'date', expand: 'community_id' })

export const getDocuments = (filter?: string) =>
  pb.collection('documents').getFullList({ filter: filter || '', sort: '-created' })
