import pb from '@/lib/pocketbase/client'
import type { Community } from '@/types'

export const getCommunities = (): Promise<Community[]> =>
  pb.collection('communities').getFullList({ sort: '-created' })

export const getCommunity = (id: string): Promise<Community> =>
  pb.collection('communities').getOne(id)

export const getCommunityBySlug = (slug: string): Promise<Community> =>
  pb.collection('communities').getFirstListItem(`slug="${slug}"`)

export const createCommunity = (data: Partial<Community>) =>
  pb.collection('communities').create(data)

export const updateCommunity = (id: string, data: Partial<Community>) =>
  pb.collection('communities').update(id, data)

export const deleteCommunity = (id: string) => pb.collection('communities').delete(id)
