import pb from '@/lib/pocketbase/client'
import type { Order, OrderItem, Favorite } from '@/types'

export const createOrder = async (data: {
  items: { product_id: string; quantity: number; price: number }[]
  contact_phone: string
  notes?: string
  buyer_id: string
}) => {
  const order = await pb.collection('orders').create({
    buyer_id: data.buyer_id,
    status: 'pending',
    total: data.items.reduce((s, i) => s + i.price * i.quantity, 0),
    contact_phone: data.contact_phone,
    notes: data.notes || '',
  })
  for (const item of data.items) {
    await pb.collection('order_items').create({
      order_id: order.id,
      product_id: item.product_id,
      quantity: item.quantity,
      price: item.price,
    })
  }
  return order as unknown as Order
}

export const getOrders = (buyerId: string): Promise<Order[]> =>
  pb.collection('orders').getFullList({ filter: `buyer_id="${buyerId}"`, sort: '-created' })

export const getOrderItems = (orderId: string): Promise<OrderItem[]> =>
  pb
    .collection('order_items')
    .getFullList({ filter: `order_id="${orderId}"`, expand: 'product_id' })

export const getFavorites = (userId: string): Promise<Favorite[]> =>
  pb.collection('favorites').getFullList({ filter: `user_id="${userId}"`, expand: 'product_id' })

export const toggleFavorite = async (userId: string, productId: string) => {
  try {
    const existing = await pb
      .collection('favorites')
      .getFirstListItem(`user_id="${userId}" && product_id="${productId}"`)
    await pb.collection('favorites').delete(existing.id)
    return false
  } catch {
    await pb.collection('favorites').create({ user_id: userId, product_id: productId })
    return true
  }
}
