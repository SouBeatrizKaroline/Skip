export type UserRole =
  | 'community'
  | 'cooperative'
  | 'administrator'
  | 'partner'
  | 'government'
  | 'researcher'

export type ProductCategory =
  | 'frutos_nativos'
  | 'artesanato'
  | 'biojoias'
  | 'alimentos'
  | 'cosmeticos_naturais'
  | 'fitoterapicos'
  | 'produtos_culturais'

export interface Community {
  id: string
  name: string
  slug: string
  description: string
  history: string
  city: string
  state: string
  region: string
  leader_name: string
  members_count: number
  type: string
  certifications: string
  contact_phone: string
  contact_email: string
  website: string
  photos: string[]
  logo: string
  user_id: string
  created: string
  updated: string
}

export interface Product {
  id: string
  name: string
  slug: string
  description: string
  story: string
  category: ProductCategory
  subcategory: string
  price: number
  origin: string
  availability: string
  certifications: string
  featured: boolean
  photos: string[]
  community_id: string
  user_id: string
  created: string
  updated: string
  expand?: { community_id?: Community }
}

export interface TraceabilityEvent {
  id: string
  product_id: string
  event_type: string
  description: string
  event_date: string
  location: string
  method: string
  environmental_impact: string
  created: string
}

export interface Order {
  id: string
  buyer_id: string
  status: string
  total: number
  contact_phone: string
  notes: string
  created: string
  updated: string
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  quantity: number
  price: number
  expand?: { product_id?: Product }
}

export interface Project {
  id: string
  name: string
  slug: string
  description: string
  status: string
  budget: number
  spent: number
  start_date: string
  end_date: string
  sdgs: string
  progress: number
  community_id: string
  user_id: string
  created: string
  updated: string
}

export interface Partner {
  id: string
  name: string
  description: string
  type: string
  logo: string
  website: string
}

export interface CulturalItem {
  id: string
  title: string
  description: string
  content: string
  type: string
  media: string[]
  community_id: string
  created: string
}

export interface TourismExperience {
  id: string
  title: string
  description: string
  type: string
  price: number
  location: string
  duration: string
  max_participants: number
  photos: string[]
  community_id: string
}

export interface Message {
  id: string
  sender_id: string
  receiver_id: string
  content: string
  read: boolean
  created: string
}

export interface ESGIndicator {
  id: string
  year: number
  month: number
  communities_count: number
  preserved_area_ha: number
  beneficiary_families: number
  generated_income: number
  commercialized_products: number
  co2_avoided: number
  preserved_trees: number
  active_projects: number
}

export interface LearningTrack {
  id: string
  title: string
  description: string
  type: string
  duration_hours: number
  content: string
}
