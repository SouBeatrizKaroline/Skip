import { Link, useNavigate } from 'react-router-dom'
import { Leaf, Home, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'

const NotFound = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-emerald-50 to-stone-50 px-4">
      <div className="text-center max-w-md animate-fade-in-up">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-100 mb-6">
          <Leaf className="w-10 h-10 text-emerald-700" aria-hidden="true" />
        </div>
        <h1 className="text-6xl font-bold text-emerald-800 mb-3">404</h1>
        <h2 className="text-xl font-semibold text-stone-800 mb-3">Página não encontrada</h2>
        <p className="text-stone-500 mb-8 leading-relaxed">
          A página que você procura pode ter sido movida ou não existe mais. Explore os Frutos do
          Cerrado e descubra histórias, sabores e tradições.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/">
            <Button className="w-full sm:w-auto bg-emerald-700 hover:bg-emerald-800 text-white">
              <Home className="w-4 h-4 mr-2" aria-hidden="true" />
              Voltar ao início
            </Button>
          </Link>
          <Button
            variant="outline"
            className="w-full sm:w-auto border-emerald-300 text-emerald-700 hover:bg-emerald-50"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" aria-hidden="true" />
            Página anterior
          </Button>
        </div>
      </div>
    </div>
  )
}

export default NotFound
