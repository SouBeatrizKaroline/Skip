import { Hero } from '@/components/landing/Hero'
import { Mission, Impact } from '@/components/landing/Mission'
import { CommunitiesPreview, ProductsPreview } from '@/components/landing/Showcase'
import { MapSection, ProjectsPreview } from '@/components/landing/MapProjects'
import { Partners, SDG } from '@/components/landing/PartnersSDG'
import { FAQ } from '@/components/landing/FAQ'
import { ContactCTA } from '@/components/landing/ContactCTA'

const Index = () => {
  return (
    <>
      <Hero />
      <Mission />
      <Impact />
      <CommunitiesPreview />
      <ProductsPreview />
      <MapSection />
      <ProjectsPreview />
      <Partners />
      <SDG />
      <FAQ />
      <ContactCTA />
    </>
  )
}

export default Index
