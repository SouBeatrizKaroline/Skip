import { useEffect, useState } from 'react'
import { getCommunities } from '@/services/communities'
import { Community } from '@/types'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function ComunidadesGestao() {
  const [list, setList] = useState<Community[]>([])

  useEffect(() => {
    getCommunities()
      .then(setList)
      .catch(() => {})
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Gestão de Comunidades</h1>
        <Button size="sm" className="bg-emerald-700 text-white text-xs">
          + Cadastrar Comunidade
        </Button>
      </div>

      <div className="space-y-3">
        {list.map((c) => (
          <Card key={c.id} className="p-4 bg-white flex items-center justify-between text-xs">
            <div>
              <p className="font-bold text-stone-900 text-sm">{c.name}</p>
              <p className="text-stone-500">
                {c.city}, {c.region} • {c.members_count} famílias
              </p>
            </div>
            <Badge className="bg-emerald-100 text-emerald-900">{c.type}</Badge>
          </Card>
        ))}
      </div>
    </div>
  )
}
