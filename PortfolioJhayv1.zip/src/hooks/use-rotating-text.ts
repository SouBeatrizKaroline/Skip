import { useState, useEffect, useCallback } from 'react'

export function useRotatingText(
  texts: string[],
  typeSpeed = 70,
  deleteSpeed = 35,
  pauseDuration = 2200,
) {
  const [displayText, setDisplayText] = useState('')
  const [textIndex, setTextIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const currentText = texts[textIndex]
    let timeout: ReturnType<typeof setTimeout>

    if (!isDeleting && displayText === currentText) {
      timeout = setTimeout(() => setIsDeleting(true), pauseDuration)
    } else if (isDeleting && displayText === '') {
      setIsDeleting(false)
      setTextIndex((prev) => (prev + 1) % texts.length)
    } else {
      timeout = setTimeout(
        () => {
          setDisplayText((prev) =>
            isDeleting
              ? currentText.substring(0, prev.length - 1)
              : currentText.substring(0, prev.length + 1),
          )
        },
        isDeleting ? deleteSpeed : typeSpeed,
      )
    }

    return () => clearTimeout(timeout)
  }, [displayText, isDeleting, textIndex, texts, typeSpeed, deleteSpeed, pauseDuration])

  const currentFullText = texts[textIndex]

  return { displayText, currentFullText, textIndex }
}
