import { SPECIALTIES } from '@/data/portfolio-data'
import { Layers } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export function SpecialtiesSection() {
  return (
    <section id="especialidades" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Specialties &amp; Stack
            </h2>
            <p className="text-xs font-mono text-indigo-400">03. TECHNICAL EXPERTISE &amp; TOOLS</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SPECIALTIES.map((item, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/50 border border-indigo-500/20 backdrop-blur-xl shadow-xl hover:border-violet-500/40 transition duration-300"
            >
              <h3 className="text-lg font-bold text-violet-300 mb-4 font-display flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-violet-500 animate-ping" />
                {item.category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {item.technologies.map((tech, techIdx) => (
                  <Badge
                    key={techIdx}
                    className="bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-200 border-indigo-500/30 px-3 py-1.5 text-xs rounded-lg shadow-sm transition"
                  >
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
