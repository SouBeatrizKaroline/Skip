import { GITHUB_REPOS, GITHUB_CATEGORIES } from '@/data/github-repos'
import { Github, ExternalLink } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { SectionStars } from '@/components/DecorativeElements'
import { cn } from '@/lib/utils'

const CATEGORY_COLORS: Record<string, string> = {
  Backend: 'bg-indigo-500/20 border-indigo-400/40 text-indigo-300',
  Frontend: 'bg-violet-500/20 border-violet-400/40 text-violet-300',
  'Academic Projects': 'bg-blue-500/20 border-blue-400/40 text-blue-300',
  Hackathons: 'bg-amber-500/20 border-amber-400/40 text-amber-300',
  'Experimentos / Games': 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300',
  'Experiments / Games': 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300',
  'Open Source': 'bg-rose-500/20 border-rose-400/40 text-rose-300',
  Tools: 'bg-cyan-500/20 border-cyan-400/40 text-cyan-300',
}

export function GitHubSection() {
  return (
    <section id="github" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={5} />
      <div className="container max-w-5xl mx-auto relative">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Github className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Always Building
            </h2>
            <p className="text-xs font-mono text-indigo-400 mt-1">
              07. OPEN SOURCE &amp; REAL PROJECTS
            </p>
          </div>
        </div>

        <p className="text-slate-300 text-sm md:text-base leading-relaxed mb-8 max-w-2xl">
          Every repository is proof that this person actually codes. From backend to frontend, from
          experimental games to hackathon solutions — the code is always evolving.
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {GITHUB_CATEGORIES.map((cat) => (
            <Badge
              key={cat}
              variant="outline"
              className={cn('text-[10px] font-mono border', CATEGORY_COLORS[cat])}
            >
              {cat}
            </Badge>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {GITHUB_REPOS.map((repo) => (
            <div
              key={repo.id}
              className="p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-lg hover:border-violet-500/40 hover:-translate-y-1 transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span
                    className={cn(
                      'px-2 py-0.5 rounded-md text-[9px] font-mono font-bold border',
                      CATEGORY_COLORS[repo.category],
                    )}
                  >
                    {repo.category}
                  </span>
                  <Github className="w-4 h-4 text-slate-500 group-hover:text-violet-400 transition" />
                </div>
                <h3 className="text-base font-bold text-white font-display mb-2 group-hover:text-violet-300 transition">
                  {repo.name}
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed mb-3 line-clamp-2">
                  {repo.description}
                </p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {repo.technologies.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-indigo-950/60 text-indigo-300 border border-indigo-500/20"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
              <Button
                asChild
                variant="ghost"
                size="sm"
                className="w-full text-indigo-300 hover:text-white hover:bg-indigo-900/40 text-xs cursor-pointer mt-2"
              >
                <a href={repo.url} target="_blank" rel="noopener noreferrer">
                  View repository <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </Button>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button
            asChild
            variant="outline"
            className="border-indigo-500/40 text-indigo-200 hover:bg-indigo-900/40 hover:text-white cursor-pointer"
          >
            <a href="https://github.com/Jhaysavi" target="_blank" rel="noopener noreferrer">
              <Github className="w-4 h-4 mr-2 text-violet-400" /> View full GitHub profile
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
