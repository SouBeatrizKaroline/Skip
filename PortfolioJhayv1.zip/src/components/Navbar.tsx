import { useState, useEffect } from 'react'
import { NAV_LINKS } from '@/data/portfolio-data'
import { useTheme } from '@/hooks/use-theme'
import { Sun, Moon, Menu, X, Code2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface NavbarProps {
  activeSection: string
}

export function Navbar({ activeSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false)
    const element = document.getElementById(id)
    if (element) {
      const offset = 80
      const bodyRect = document.body.getBoundingClientRect().top
      const elementRect = element.getBoundingClientRect().top
      const elementPosition = elementRect - bodyRect
      const offsetPosition = elementPosition - offset
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' })
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${isScrolled ? 'py-3 bg-[#09090B]/90 backdrop-blur-md border-b border-indigo-500/20 shadow-[0_4px_20px_rgba(79,70,229,0.15)]' : 'py-5 bg-transparent'}`}
    >
      <div className="container mx-auto px-4 md:px-8 flex items-center justify-between">
        <button
          onClick={() => scrollToSection('hero')}
          className="flex items-center gap-2 group cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-[#4F46E5] to-[#6D28D9] p-[2px] transition-transform duration-300 group-hover:scale-105">
            <div className="w-full h-full bg-[#09090B] rounded-[6px] flex items-center justify-center text-white">
              <Code2 className="w-5 h-5 text-violet-400 group-hover:rotate-12 transition-transform" />
            </div>
          </div>
          <div className="text-left">
            <span className="text-xl font-bold font-display bg-gradient-to-r from-white via-indigo-200 to-violet-400 bg-clip-text text-transparent">
              Jhay
            </span>
            <span className="text-[10px] block font-mono text-indigo-400 -mt-1">
              &lt;FullStack /&gt;
            </span>
          </div>
        </button>

        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {NAV_LINKS.map((link) => {
            const isActive = activeSection === link.id
            return (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer ${isActive ? 'bg-indigo-600/30 text-violet-300 border border-indigo-500/40 shadow-[0_0_10px_rgba(79,70,229,0.3)]' : 'text-slate-300 hover:text-white hover:bg-white/5'}`}
              >
                {link.label}
              </button>
            )
          })}
        </nav>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full w-9 h-9 text-indigo-300 hover:text-white hover:bg-indigo-500/20 border border-indigo-500/20 cursor-pointer"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-300 animate-pulse" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-400" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden rounded-full w-9 h-9 text-slate-200 hover:bg-white/10 cursor-pointer"
            aria-label="Open menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[60px] bg-[#09090B]/95 backdrop-blur-xl border-b border-indigo-500/20 p-6 flex flex-col gap-3 z-50 animate-fade-in-down overflow-y-auto">
          {NAV_LINKS.map((link) => {
            const isActive = activeSection === link.id
            return (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`w-full text-left px-4 py-3 rounded-xl font-medium text-sm transition-all cursor-pointer ${isActive ? 'bg-gradient-to-r from-indigo-900/60 to-violet-900/40 text-violet-300 border border-violet-500/40 font-semibold' : 'text-slate-300 hover:bg-white/5'}`}
              >
                {link.label}
              </button>
            )
          })}
        </div>
      )}
    </header>
  )
}
