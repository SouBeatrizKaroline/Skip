import { RECOMMENDATIONS } from '@/data/portfolio-data'
import { Quote, MessageSquare, Star, Code2 } from 'lucide-react'
import { SectionStars } from '@/components/DecorativeElements'

export function RecommendationsSection() {
  return (
    <section id="recomendacoes" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={6} />
      <div className="container max-w-5xl mx-auto relative">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Recommendations &amp; Testimonials
            </h2>
            <p className="text-xs font-mono text-indigo-400 mt-1">10. WHAT PEOPLE SAY ABOUT ME</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {RECOMMENDATIONS.map((rec, idx) => (
            <div
              key={idx}
              className="p-6 md:p-8 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl relative overflow-hidden flex flex-col justify-between group hover:border-violet-500/40 hover:shadow-[0_0_30px_rgba(79,70,229,0.15)] transition-all duration-300"
            >
              <Code2 className="absolute -bottom-6 -right-6 w-28 h-28 text-indigo-500/5 pointer-events-none rotate-12" />
              <Quote className="absolute top-4 right-4 w-16 h-16 text-violet-500/10 pointer-events-none" />

              <div className="relative z-10">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} className="w-4 h-4 text-violet-400 fill-violet-400/60" />
                  ))}
                </div>

                <p className="text-slate-300 text-sm md:text-base leading-relaxed italic mb-6">
                  &ldquo;{rec.text}&rdquo;
                </p>
              </div>

              <div className="relative z-10">
                <div className="h-px bg-gradient-to-r from-transparent via-indigo-500/30 to-transparent mb-4" />
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xl">⭐</span>
                  <h3 className="text-lg font-bold text-white font-display">{rec.name}</h3>
                </div>
                <p className="text-sm text-indigo-300 font-medium">{rec.role}</p>
                <p className="text-[11px] font-mono text-slate-400 mt-1">{rec.relationship}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
