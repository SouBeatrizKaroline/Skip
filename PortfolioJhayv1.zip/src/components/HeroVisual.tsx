import { Atom, GitBranch, Database, Braces, Star, Moon, Sparkles } from 'lucide-react'
import { ConstellationLines, SoundWave, LightstickMotif } from '@/components/DecorativeElements'

export function HeroVisual() {
  return (
    <div className="relative w-full max-w-sm mx-auto mb-8 h-[280px]">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/15 via-violet-600/10 to-blue-900/10 rounded-3xl blur-2xl" />
      <ConstellationLines className="opacity-40" />

      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[260px] sm:w-[300px] rounded-xl overflow-hidden border border-indigo-500/30 bg-[#0a0a1a]/90 backdrop-blur-xl shadow-[0_0_40px_rgba(79,70,229,0.2)] z-20">
        <div className="flex items-center gap-2 px-3 py-2 border-b border-indigo-500/20 bg-indigo-950/40">
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
          </div>
          <span className="text-[10px] font-mono text-indigo-300/60 ml-1">developer.ts</span>
        </div>
        <div className="p-3 font-mono text-[11px] leading-relaxed">
          <div>
            <span className="text-violet-400">const</span>{' '}
            <span className="text-indigo-300">jhay</span> <span className="text-slate-500">=</span>{' '}
            <span className="text-slate-300">{'{'}</span>
          </div>
          <div className="pl-3">
            <span className="text-indigo-300">role</span>:{' '}
            <span className="text-emerald-400">'Full Stack'</span>,
          </div>
          <div className="pl-3">
            <span className="text-indigo-300">stack</span>: [
            <span className="text-emerald-400">'React'</span>,{' '}
            <span className="text-emerald-400">'Node'</span>],
          </div>
          <div className="pl-3">
            <span className="text-indigo-300">vibe</span>:{' '}
            <span className="text-emerald-400">'Seoul ✨'</span>,
          </div>
          <div className="pl-3">
            <span className="text-indigo-300">status</span>:{' '}
            <span className="text-emerald-400">'online'</span>
          </div>
          <div>
            <span className="text-slate-300">{'}'}</span>
          </div>
        </div>
      </div>

      <div className="absolute top-2 left-2 w-10 h-10 rounded-xl bg-indigo-950/60 border border-indigo-500/30 backdrop-blur-md flex items-center justify-center shadow-lg animate-float-slow">
        <Atom className="w-5 h-5 text-cyan-400" />
      </div>
      <div
        className="absolute top-6 right-0 w-10 h-10 rounded-xl bg-indigo-950/60 border border-indigo-500/30 backdrop-blur-md flex items-center justify-center shadow-lg animate-float-slow"
        style={{ animationDelay: '0.5s' }}
      >
        <GitBranch className="w-5 h-5 text-violet-400" />
      </div>
      <div
        className="absolute bottom-12 left-0 w-10 h-10 rounded-xl bg-indigo-950/60 border border-indigo-500/30 backdrop-blur-md flex items-center justify-center shadow-lg animate-float-slow"
        style={{ animationDelay: '1s' }}
      >
        <Database className="w-5 h-5 text-indigo-400" />
      </div>
      <div
        className="absolute bottom-4 right-4 w-10 h-10 rounded-xl bg-indigo-950/60 border border-indigo-500/30 backdrop-blur-md flex items-center justify-center shadow-lg animate-float-slow"
        style={{ animationDelay: '1.5s' }}
      >
        <Braces className="w-5 h-5 text-blue-400" />
      </div>

      <div className="absolute top-1/4 -left-2 animate-twinkle">
        <Star className="w-3 h-3 text-violet-300/60" />
      </div>
      <div
        className="absolute bottom-16 right-1/4 animate-twinkle"
        style={{ animationDelay: '1s' }}
      >
        <Star className="w-2 h-2 text-indigo-300/50" />
      </div>
      <div className="absolute top-16 right-1/3 animate-twinkle" style={{ animationDelay: '2s' }}>
        <Star className="w-1.5 h-1.5 text-blue-300/40" />
      </div>
      <div className="absolute top-8 left-1/3 animate-twinkle" style={{ animationDelay: '0.5s' }}>
        <Sparkles className="w-3 h-3 text-violet-300/40" />
      </div>

      <Moon className="absolute top-0 right-6 w-4 h-4 text-indigo-300/40" />
      <LightstickMotif className="absolute top-4 left-1/2 -translate-x-1/2 opacity-40" />
      <LightstickMotif className="absolute bottom-8 right-2 opacity-30 rotate-12" />

      <div className="absolute bottom-0 left-1/2 -translate-x-1/2">
        <SoundWave />
      </div>
    </div>
  )
}
