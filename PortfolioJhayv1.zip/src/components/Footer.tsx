import { Github, Linkedin, Mail, Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="py-8 px-4 border-t border-indigo-500/20 bg-[#09090B] text-slate-400 text-xs relative z-10">
      <div className="container max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
        <div>
          <span className="font-bold font-display text-white text-base block">
            Jhay (Sonia Barros)
          </span>
          <span className="text-indigo-400 font-mono text-[11px]">Building code with passion.</span>
        </div>

        <div className="flex items-center gap-1 text-slate-300 font-mono">
          <span>Built with React + lots of coffee ☕ &amp;</span>
          <Heart className="w-3.5 h-3.5 text-violet-500 fill-violet-500 inline mx-1 animate-pulse" />
        </div>

        <div className="flex items-center gap-3">
          <a
            href="https://github.com/Jhaysavi"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-lg bg-slate-900 border border-indigo-500/20 text-slate-300 hover:text-white hover:border-violet-500/40 transition"
            aria-label="GitHub"
          >
            <Github className="w-4 h-4" />
          </a>
          <a
            href="https://www.linkedin.com/in/jhaysavi/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-lg bg-slate-900 border border-indigo-500/20 text-slate-300 hover:text-white hover:border-violet-500/40 transition"
            aria-label="LinkedIn"
          >
            <Linkedin className="w-4 h-4" />
          </a>
          <a
            href="mailto:jhay.dev@outlook.com"
            className="p-2 rounded-lg bg-slate-900 border border-indigo-500/20 text-slate-300 hover:text-white hover:border-violet-500/40 transition"
            aria-label="Email"
          >
            <Mail className="w-4 h-4" />
          </a>
        </div>
      </div>
    </footer>
  )
}
