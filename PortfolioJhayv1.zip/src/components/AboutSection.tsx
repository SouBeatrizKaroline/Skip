import { Heart, Sparkles, User, Lightbulb, Star } from 'lucide-react'
import { SectionStars } from '@/components/DecorativeElements'

export function AboutSection() {
  return (
    <section id="sobre" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={4} />
      <div className="container max-w-5xl mx-auto relative">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              About Me
            </h2>
            <p className="text-xs font-mono text-indigo-400">01. MY JOURNEY</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 p-6 md:p-8 rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-indigo-500/20 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-violet-500/10 to-transparent rounded-bl-full pointer-events-none" />

            <p className="text-slate-300 text-base md:text-lg leading-relaxed mb-4">
              My journey in technology began driven by the curiosity to understand how complex
              systems come to life and how code can transform people's daily routines. During my{' '}
              <strong className="text-violet-300">B.Sc. in Computer Science</strong> at Universidade
              Anhembi Morumbi, I built solid foundations in software engineering, algorithms, and
              data structures.
            </p>

            <p className="text-slate-300 text-base md:text-lg leading-relaxed mb-4">
              In the industry, as a{' '}
              <strong className="text-indigo-300">Systems Analyst at DF Transportes</strong>, I
              exercise the critical ability to translate operational and logistical challenges into
              functional architectures, managing backlogs, coordinating sprints, and ensuring
              high-value deliveries.
            </p>

            <p className="text-slate-300 text-base md:text-lg leading-relaxed mb-6">
              Beyond that, I deeply believe in the power of{' '}
              <strong className="text-violet-300">community and collaborative leadership</strong>.
              As a leader in the Codando movement, I foster mentoring, facilitate tech events, and
              drive Open Source projects with enthusiasm and empathy.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-indigo-500/20 text-xs font-mono text-indigo-300">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" />
                <span>Clean Code &amp; SOLID</span>
              </div>
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-amber-300" />
                <span>Business Vision</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-rose-400" />
                <span>Empathy &amp; Leadership</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col items-center justify-center">
            <div className="relative group w-full max-w-[280px]">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-blue-600 opacity-50 blur-md group-hover:opacity-80 transition duration-500" />
              <div className="relative rounded-2xl overflow-hidden border border-indigo-500/30 bg-[#0a0a1a] p-5 backdrop-blur-xl">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-indigo-500/20">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500/60" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300/60">~ /jhay identity</span>
                </div>
                <div className="space-y-3 font-mono text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">$ name</span>
                    <span className="text-indigo-300">Sonia Barros</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">$ alias</span>
                    <span className="text-violet-300">Jhay</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">$ role</span>
                    <span className="text-blue-300">Full Stack Dev</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">$ location</span>
                    <span className="text-indigo-300">Brasília • DF • Brasil</span>
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-indigo-500/20 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-[10px] font-mono text-slate-400">Now coding...</span>
                  <div className="flex-1 flex items-end gap-0.5 justify-end">
                    {[0.4, 0.7, 0.3, 0.5, 0.6].map((h, i) => (
                      <div
                        key={i}
                        className="w-1 bg-gradient-to-t from-indigo-500 to-violet-400 rounded-full animate-pulse"
                        style={{ height: `${h * 12}px`, animationDelay: `${i * 0.1}s` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <div className="absolute -top-3 -right-3 w-8 h-8 rounded-lg bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center animate-float-slow">
                <Star className="w-4 h-4 text-violet-300/60" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
