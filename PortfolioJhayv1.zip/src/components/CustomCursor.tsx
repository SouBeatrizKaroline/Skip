import { useCustomCursor } from '@/hooks/use-custom-cursor'

export function CustomCursor() {
  const { position, isHovered, isClicked } = useCustomCursor()

  return (
    <>
      <div
        className="fixed top-0 left-0 pointer-events-none z-50 transition-transform duration-75 ease-out -translate-x-1/2 -translate-y-1/2 hidden md:block"
        style={{ transform: `translate3d(${position.x}px, ${position.y}px, 0)` }}
      >
        <div
          className={`rounded-full transition-all duration-300 ${
            isHovered
              ? 'w-10 h-10 bg-indigo-500/20 border-2 border-violet-500 shadow-[0_0_20px_rgba(79,70,229,0.6)] backdrop-blur-[1px]'
              : 'w-4 h-4 bg-indigo-500/80 border border-white/60 shadow-[0_0_10px_rgba(79,70,229,0.8)]'
          } ${isClicked ? 'scale-75 bg-violet-500/90' : 'scale-100'}`}
        />
      </div>
      <div
        className="fixed top-0 left-0 pointer-events-none z-50 transition-transform duration-200 ease-out -translate-x-1/2 -translate-y-1/2 hidden md:block"
        style={{ transform: `translate3d(${position.x}px, ${position.y}px, 0)` }}
      >
        <div className="w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_6px_#fff]" />
      </div>
    </>
  )
}
