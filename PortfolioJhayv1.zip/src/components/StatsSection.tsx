import { STATS_ITEMS } from '@/data/portfolio-data'
import { Code, Cpu, Trophy, Users } from 'lucide-react'

export function StatsSection() {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Code':
        return <Code className="w-6 h-6 text-violet-400" />
      case 'Cpu':
        return <Cpu className="w-6 h-6 text-indigo-400" />
      case 'Trophy':
        return <Trophy className="w-6 h-6 text-amber-300" />
      case 'Users':
        return <Users className="w-6 h-6 text-blue-400" />
      default:
        return <Code className="w-6 h-6 text-violet-400" />
    }
  }

  return (
    <section className="py-12 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STATS_ITEMS.map((stat, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-gradient-to-b from-indigo-950/40 to-slate-900/60 border border-indigo-500/20 backdrop-blur-md shadow-xl hover:-translate-y-2 transition-all duration-300 group"
            >
              <div className="w-12 h-12 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                {getIcon(stat.icon)}
              </div>
              <div className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-indigo-100 to-violet-300 bg-clip-text text-transparent mb-1">
                {stat.number}
              </div>
              <div className="text-sm font-semibold text-slate-200 mb-1">{stat.label}</div>
              <div className="text-xs text-slate-400">{stat.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
