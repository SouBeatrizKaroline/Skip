import { Code2, Database, Layout, GitBranch, Terminal, Smile } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export function SkillsSection() {
  const skillCategories = [
    {
      title: 'Frontend',
      icon: <Layout className="w-5 h-5 text-violet-400" />,
      skills: [
        'React.js',
        'TypeScript',
        'JavaScript (ES6+)',
        'Tailwind CSS',
        'HTML5 & CSS3',
        'Bootstrap',
        'Vite',
      ],
    },
    {
      title: 'Backend',
      icon: <Code2 className="w-5 h-5 text-indigo-400" />,
      skills: [
        'Node.js',
        'Java',
        'Python',
        'Express.js',
        'REST APIs',
        'Object-Oriented Programming',
      ],
    },
    {
      title: 'Databases',
      icon: <Database className="w-5 h-5 text-blue-400" />,
      skills: ['MySQL', 'Advanced SQL', 'Relational Modeling', 'PocketBase / SQLite'],
    },
    {
      title: 'UI/UX & Design',
      icon: <Terminal className="w-5 h-5 text-violet-300" />,
      skills: ['Figma (Prototyping)', 'Wireframing', 'Design Systems', 'Information Architecture'],
    },
    {
      title: 'Agile Methodologies & Management',
      icon: <GitBranch className="w-5 h-5 text-amber-300" />,
      skills: [
        'Scrum',
        'Kanban',
        'Requirements Gathering',
        'Backlog Management',
        'Logistics TMS Systems',
      ],
    },
    {
      title: 'Soft Skills',
      icon: <Smile className="w-5 h-5 text-emerald-400" />,
      skills: [
        'Technical Leadership',
        'Clear Communication',
        'Teamwork',
        'Problem Solving',
        'Adaptability',
      ],
    },
  ]

  return (
    <section id="competencias" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Detailed Skills
            </h2>
            <p className="text-xs font-mono text-indigo-400">08. HARD &amp; SOFT SKILLS</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((cat, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl hover:border-violet-500/40 transition duration-300"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-indigo-950/60 border border-indigo-500/30">
                  {cat.icon}
                </div>
                <h3 className="text-base font-bold text-white font-display">{cat.title}</h3>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {cat.skills.map((skill, sIdx) => (
                  <Badge
                    key={sIdx}
                    className="bg-indigo-950/50 hover:bg-indigo-900/70 text-indigo-200 border-indigo-500/20 text-xs py-1"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
