import { TIMELINE_ITEMS } from '@/data/portfolio-data'
import { Calendar, CheckCircle2 } from 'lucide-react'

export function TimelineSection() {
  return (
    <section id="timeline" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              My Journey
            </h2>
            <p className="text-xs font-mono text-indigo-400">
              02. PROFESSIONAL &amp; ACADEMIC HISTORY
            </p>
          </div>
        </div>

        <div className="relative pl-6 md:pl-8 border-l-2 border-indigo-500/30 space-y-10">
          {TIMELINE_ITEMS.map((item, index) => (
            <div key={index} className="relative group">
              <div className="absolute -left-[31px] md:-left-[39px] top-1.5 w-6 h-6 rounded-full bg-[#09090B] border-2 border-violet-500 flex items-center justify-center group-hover:scale-125 transition-transform duration-300 shadow-[0_0_12px_rgba(139,92,246,0.8)]">
                <div className="w-2 h-2 rounded-full bg-indigo-400" />
              </div>
              <div className="p-6 rounded-2xl bg-slate-900/50 backdrop-blur-xl border border-indigo-500/20 shadow-lg hover:border-violet-500/40 transition-all duration-300">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <span className="px-3 py-0.5 rounded-full bg-gradient-to-r from-indigo-900/80 to-violet-900/60 border border-indigo-500/40 text-violet-300 font-mono text-xs font-bold">
                    {item.year}
                  </span>
                  <span className="text-xs font-mono text-slate-400">{item.subtitle}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2 font-display">{item.title}</h3>
                <p className="text-slate-300 text-sm leading-relaxed mb-3">{item.description}</p>
                {item.bullets && item.bullets.length > 0 && (
                  <ul className="space-y-1.5 pt-2 border-t border-indigo-500/10">
                    {item.bullets.map((bullet, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-violet-400 shrink-0 mt-0.5" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
