import { COURSES } from '@/data/portfolio-data'
import { GraduationCap, BookOpen, Globe } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export function EducationSection() {
  return (
    <section id="formacao" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Education &amp; Courses
            </h2>
            <p className="text-xs font-mono text-indigo-400">10. ACADEMIC &amp; LANGUAGES</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-violet-400">BACHELOR'S DEGREE</span>
                <span className="text-xs font-mono text-slate-400">2022 - 2026</span>
              </div>
              <h3 className="text-xl font-bold text-white font-display mb-1">Computer Science</h3>
              <p className="text-indigo-300 text-sm font-medium mb-3">
                Universidade Anhembi Morumbi
              </p>
              <p className="text-slate-300 text-xs leading-relaxed">
                Focus on software engineering, distributed systems, computational mathematics,
                algorithms, and databases.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-5 h-5 text-violet-400" />
                <h3 className="text-lg font-bold text-white font-display">Languages</h3>
              </div>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-white">Portuguese</span>
                    <span className="text-violet-300 font-mono">Native</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-indigo-950 overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-r from-indigo-500 to-violet-500" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-white">English</span>
                    <span className="text-indigo-300 font-mono">Advanced / Fluent</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-indigo-950 overflow-hidden">
                    <div className="w-[88%] h-full bg-gradient-to-r from-indigo-500 to-violet-500" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 p-6 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-indigo-400" />
                <h3 className="text-lg font-bold text-white font-display">
                  Certifications &amp; Courses
                </h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {COURSES.map((course, idx) => (
                  <Badge
                    key={idx}
                    className="bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-200 border-indigo-500/30 px-3 py-1.5 text-xs rounded-lg"
                  >
                    {course}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="mt-6 pt-4 border-t border-indigo-500/20 text-xs font-mono text-slate-400">
              ⚡ Continuous learning &amp; certifications updated in 2026.
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
