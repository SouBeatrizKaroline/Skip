import { useEffect, useRef } from 'react'
import { useTheme } from '@/hooks/use-theme'

interface Particle {
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  symbol?: string
  type: 'star' | 'symbol' | 'sakura' | 'dot'
  opacity: number
  rotation: number
  rotSpeed: number
}

export function ParticleBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const { theme } = useTheme()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationFrameId: number
    let width = (canvas.width = window.innerWidth)
    let height = (canvas.height = window.innerHeight)

    const handleResize = () => {
      if (!canvas) return
      width = canvas.width = window.innerWidth
      height = canvas.height = window.innerHeight
    }

    window.addEventListener('resize', handleResize)

    const codeSymbols = ['{}', '</>', '=>', '#', '@', ';', 'fn()', '01', 'git', '&&']
    const particleCount = Math.min(Math.floor(width / 25), 45)
    const particles: Particle[] = []

    for (let i = 0; i < particleCount; i++) {
      const typeChoice = Math.random()
      let type: Particle['type'] = 'dot'
      let symbol: string | undefined = undefined

      if (typeChoice > 0.75) {
        type = 'symbol'
        symbol = codeSymbols[Math.floor(Math.random() * codeSymbols.length)]
      } else if (typeChoice > 0.55) {
        type = 'star'
      } else if (typeChoice > 0.35) {
        type = 'sakura'
      }

      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: type === 'symbol' ? 12 : type === 'sakura' ? 8 : type === 'star' ? 3 : 2,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: type === 'sakura' ? 0.3 + Math.random() * 0.4 : -0.2 - Math.random() * 0.3,
        symbol,
        type,
        opacity: 0.15 + Math.random() * 0.45,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.02,
      })
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height)
      const isDark = theme === 'dark'

      particles.forEach((p) => {
        p.x += p.speedX
        p.y += p.speedY
        p.rotation += p.rotSpeed

        if (p.x < 0) p.x = width
        if (p.x > width) p.x = 0
        if (p.y < 0) p.y = height
        if (p.y > height) p.y = 0

        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(p.rotation)

        if (p.type === 'symbol' && p.symbol) {
          ctx.font = `${p.size}px monospace`
          ctx.fillStyle = isDark
            ? `rgba(139, 92, 246, ${p.opacity * 0.7})`
            : `rgba(79, 70, 229, ${p.opacity * 0.6})`
          ctx.fillText(p.symbol, 0, 0)
        } else if (p.type === 'sakura') {
          ctx.fillStyle = isDark
            ? `rgba(255, 192, 203, ${p.opacity * 0.3})`
            : `rgba(244, 114, 182, ${p.opacity * 0.2})`
          ctx.beginPath()
          ctx.ellipse(0, 0, p.size, p.size / 2, Math.PI / 4, 0, Math.PI * 2)
          ctx.fill()
        } else if (p.type === 'star') {
          ctx.fillStyle = isDark
            ? `rgba(248, 250, 252, ${p.opacity})`
            : `rgba(79, 70, 229, ${p.opacity})`
          ctx.beginPath()
          ctx.arc(0, 0, p.size, 0, Math.PI * 2)
          ctx.fill()
        } else {
          ctx.fillStyle = isDark
            ? `rgba(79, 70, 229, ${p.opacity * 0.5})`
            : `rgba(139, 92, 246, ${p.opacity * 0.5})`
          ctx.beginPath()
          ctx.arc(0, 0, p.size, 0, Math.PI * 2)
          ctx.fill()
        }
        ctx.restore()
      })

      animationFrameId = requestAnimationFrame(render)
    }

    render()

    return () => {
      window.removeEventListener('resize', handleResize)
      cancelAnimationFrame(animationFrameId)
    }
  }, [theme])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0 opacity-80" />
}
