import { HACKATHONS } from '@/data/hackathons'
import { Trophy, Award, Zap, Globe } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { SectionStars } from '@/components/DecorativeElements'

export function HackathonsSection() {
  return (
    <section id="hackathons" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={7} />
      <div className="container max-w-5xl mx-auto relative">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Trophy className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Building Solutions Under Pressure
            </h2>
            <p className="text-xs font-mono text-indigo-400 mt-1">06. MARATHONS &amp; HACKATHONS</p>
          </div>
        </div>

        <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-violet-950/40 to-indigo-950/60 border border-violet-500/30 backdrop-blur-xl shadow-xl mb-8">
          <p className="text-slate-200 text-base md:text-lg leading-relaxed font-medium">
            Hackathons are part of my identity. I don't just participate —{' '}
            <span className="text-violet-300 font-bold">
              I compete, deliver, and make the podium.
            </span>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {HACKATHONS.map((hack) => (
            <div
              key={hack.id}
              className={`p-6 rounded-2xl backdrop-blur-xl overflow-hidden relative group transition-all duration-300 hover:-translate-y-1 ${hack.isGlobal ? 'bg-gradient-to-br from-indigo-950/80 via-slate-900/80 to-violet-950/60 border-violet-500/40 shadow-[0_0_30px_rgba(79,70,229,0.2)]' : 'bg-slate-900/60 border-indigo-500/20 shadow-xl hover:border-violet-500/40 border'}`}
            >
              {hack.isGlobal && (
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-violet-500/10 to-transparent rounded-bl-full pointer-events-none" />
              )}

              <div className="flex items-start justify-between mb-4 relative z-10">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{hack.placementIcon}</span>
                  <div>
                    <h3 className="text-lg font-bold text-white font-display">{hack.name}</h3>
                    <p className="text-xs text-indigo-300 font-mono">{hack.event}</p>
                  </div>
                </div>
                <div
                  className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${hack.placement.includes('1') ? 'bg-amber-500/20 border border-amber-400/40 text-amber-300' : hack.placement.includes('3') ? 'bg-orange-500/20 border border-orange-400/40 text-orange-300' : 'bg-violet-500/20 border border-violet-400/40 text-violet-300'}`}
                >
                  {hack.placement}
                </div>
              </div>

              <p className="text-slate-300 text-sm leading-relaxed mb-4 relative z-10">
                {hack.description}
              </p>

              <div className="flex flex-wrap gap-1.5 mb-3 relative z-10">
                {hack.technologies.map((tech, idx) => (
                  <Badge
                    key={idx}
                    variant="secondary"
                    className="bg-indigo-950/60 text-indigo-200 border border-indigo-500/20 text-[10px]"
                  >
                    {tech}
                  </Badge>
                ))}
              </div>

              {hack.badge && (
                <div className="flex items-center gap-2 pt-3 border-t border-indigo-500/20 relative z-10">
                  <Globe className="w-3.5 h-3.5 text-violet-400" />
                  <span className="text-xs font-mono text-violet-300 font-semibold">
                    {hack.badge}
                  </span>
                </div>
              )}
            </div>
          ))}

          {[1, 2].map((item) => (
            <div
              key={`future-${item}`}
              className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-[#09090B] border border-indigo-500/20 backdrop-blur-xl flex flex-col items-center justify-center text-center relative overflow-hidden group hover:border-violet-500/40 transition duration-300"
            >
              <div className="w-14 h-14 rounded-2xl bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center mb-3 text-violet-400 group-hover:scale-110 transition duration-300">
                {item === 1 ? (
                  <Award className="w-7 h-7 text-indigo-400" />
                ) : (
                  <Zap className="w-7 h-7 text-violet-400" />
                )}
              </div>
              <div className="inline-block px-3 py-1 rounded-full bg-indigo-950/60 border border-violet-500/30 text-violet-300 text-xs font-mono font-bold mb-2">
                Coming Soon
              </div>
              <p className="text-xs text-slate-400">Next innovation marathon in preparation.</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
