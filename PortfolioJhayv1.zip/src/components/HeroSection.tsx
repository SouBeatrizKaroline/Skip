import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Github, Linkedin, Mail, ArrowDown, Sparkles } from 'lucide-react'
import { HeroVisual } from '@/components/HeroVisual'
import { useRotatingText } from '@/hooks/use-rotating-text'

const TAGLINES = [
  'Building products, communities and crazy hackathon ideas',
  'Code. Create. Compete.',
  'Turning impossible deadlines into working software.',
]

export function HeroSection() {
  const [typedName, setTypedName] = useState('')
  const fullName = 'Jhay'
  const { displayText: tagline } = useRotatingText(TAGLINES, 55, 30, 2000)

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>
    if (typedName.length < fullName.length) {
      timer = setTimeout(() => setTypedName(fullName.slice(0, typedName.length + 1)), 200)
    }
    return () => clearTimeout(timer)
  }, [typedName])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 80
      window.scrollTo({ top, behavior: 'smooth' })
    }
  }

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center items-center pt-24 pb-16 px-4 md:px-8 overflow-hidden z-10"
    >
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] sm:w-[500px] h-[350px] sm:h-[500px] bg-gradient-to-tr from-indigo-700/20 via-violet-600/15 to-blue-900/10 rounded-full blur-3xl pointer-events-none animate-pulse" />

      <div className="container max-w-4xl mx-auto text-center relative z-10 flex flex-col items-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-mono mb-6 backdrop-blur-md shadow-[0_0_15px_rgba(79,70,229,0.3)] animate-fade-in">
          <Sparkles
            className="w-3.5 h-3.5 text-violet-400 animate-spin"
            style={{ animationDuration: '6s' }}
          />
          <span>Sonia Janara Silva Barros</span>
          <span className="w-1.5 h-1.5 rounded-full bg-violet-500 animate-ping" />
          <span className="bg-gradient-to-r from-violet-400 to-indigo-400 bg-clip-text text-transparent font-bold">
            Level 2.0
          </span>
        </div>

        <HeroVisual />

        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight font-display mb-3 min-h-[1.2em]">
          <span className="bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
            {typedName}
          </span>
          <span className="inline-block w-1 h-8 sm:h-12 bg-violet-500 ml-1 animate-pulse" />
        </h1>

        <p className="text-base sm:text-xl font-semibold bg-gradient-to-r from-indigo-300 via-violet-300 to-indigo-200 bg-clip-text text-transparent mb-4 max-w-2xl min-h-[1.8em] font-mono">
          {tagline}
          <span className="inline-block w-0.5 h-5 bg-violet-400 ml-0.5 animate-pulse" />
        </p>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed mb-8 text-center sm:text-justify px-2">
          Building digital solutions that unite technology, collaboration, and real impact. I work
          in Full Stack development, technical leadership, and organizing tech communities, always
          striving to turn ideas into efficient, scalable, and people-centered products.
        </p>

        <div className="flex flex-wrap justify-center gap-3 sm:gap-4 mb-10 w-full max-w-md">
          <Button
            onClick={() => scrollTo('projetos')}
            className="flex-1 min-w-[140px] bg-gradient-to-r from-[#4F46E5] to-[#6D28D9] hover:from-[#312E81] hover:to-[#4F46E5] text-white font-semibold shadow-[0_0_20px_rgba(79,70,229,0.4)] border-none h-11 rounded-xl cursor-pointer"
          >
            View Projects
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-indigo-500/40 bg-indigo-950/20 text-indigo-200 hover:bg-indigo-900/40 hover:text-white h-11 rounded-xl cursor-pointer"
          >
            <a href="https://github.com/Jhaysavi" target="_blank" rel="noopener noreferrer">
              <Github className="w-4 h-4 mr-2 text-violet-400" /> GitHub
            </a>
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-indigo-500/40 bg-indigo-950/20 text-indigo-200 hover:bg-indigo-900/40 hover:text-white h-11 rounded-xl cursor-pointer"
          >
            <a
              href="https://www.linkedin.com/in/jhaysavi/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Linkedin className="w-4 h-4 mr-2 text-violet-400" /> LinkedIn
            </a>
          </Button>
          <Button
            onClick={() => scrollTo('contato')}
            variant="outline"
            className="border-violet-500/40 bg-indigo-950/20 text-violet-200 hover:bg-indigo-900/40 hover:text-white h-11 rounded-xl cursor-pointer"
          >
            <Mail className="w-4 h-4 mr-2 text-violet-400" /> Contact
          </Button>
        </div>

        <div className="flex items-center gap-1.5 mb-10 px-4 py-2 rounded-full bg-slate-900/80 border border-indigo-500/20">
          <span className="text-[11px] font-mono text-slate-400 mr-2">AUDIO EQUALIZER</span>
          {[0.6, 1, 0.4, 0.8, 0.5, 0.9, 0.3].map((height, i) => (
            <div
              key={i}
              className="w-1 bg-gradient-to-t from-indigo-500 to-violet-500 rounded-full animate-pulse"
              style={{ height: `${height * 20}px`, animationDuration: `${0.6 + i * 0.2}s` }}
            />
          ))}
        </div>

        <button
          onClick={() => scrollTo('sobre')}
          className="text-slate-400 hover:text-violet-400 transition-colors animate-bounce p-2 cursor-pointer"
          aria-label="Scroll down"
        >
          <ArrowDown className="w-6 h-6" />
        </button>
      </div>
    </section>
  )
}
