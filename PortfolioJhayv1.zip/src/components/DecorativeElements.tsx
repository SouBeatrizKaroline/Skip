import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'

export function TechGridBg({ className }: { className?: string }) {
  return <div className={cn('absolute inset-0 tech-grid-bg pointer-events-none', className)} />
}

export function GlowOrb({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'absolute rounded-full blur-3xl pointer-events-none animate-glow-pulse',
        className,
      )}
    />
  )
}

export function SectionStars({ count = 5 }: { count?: number }) {
  const positions = [
    { top: '15%', left: '10%' },
    { top: '30%', left: '85%' },
    { top: '60%', left: '20%' },
    { top: '75%', left: '70%' },
    { top: '45%', left: '50%' },
    { top: '20%', left: '60%' },
    { top: '80%', left: '40%' },
  ]
  return (
    <>
      {positions.slice(0, count).map((pos, i) => (
        <div
          key={i}
          className="absolute animate-twinkle pointer-events-none"
          style={{ top: pos.top, left: pos.left, animationDelay: `${i * 0.4}s` }}
        >
          <Star className="w-2 h-2 text-violet-300/30" />
        </div>
      ))}
    </>
  )
}

export function LuminousDivider({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center justify-center gap-2 py-2', className)}>
      <div className="h-px w-16 bg-gradient-to-r from-transparent to-indigo-500/40" />
      <div className="w-1.5 h-1.5 rounded-full bg-violet-400/60 shadow-[0_0_8px_rgba(139,92,246,0.6)]" />
      <div className="h-px w-16 bg-gradient-to-l from-transparent to-indigo-500/40" />
    </div>
  )
}

export function ConstellationLines({ className }: { className?: string }) {
  return (
    <svg
      className={cn('absolute inset-0 w-full h-full pointer-events-none opacity-30', className)}
      viewBox="0 0 400 300"
      preserveAspectRatio="none"
    >
      <line
        x1="40"
        y1="50"
        x2="120"
        y2="80"
        stroke="rgba(139,92,246,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <line
        x1="120"
        y1="80"
        x2="200"
        y2="40"
        stroke="rgba(79,70,229,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <line
        x1="200"
        y1="40"
        x2="320"
        y2="70"
        stroke="rgba(139,92,246,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <line
        x1="320"
        y1="70"
        x2="360"
        y2="150"
        stroke="rgba(99,102,241,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <line
        x1="60"
        y1="220"
        x2="140"
        y2="250"
        stroke="rgba(139,92,246,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <line
        x1="140"
        y1="250"
        x2="280"
        y2="230"
        stroke="rgba(79,70,229,0.3)"
        strokeWidth="0.5"
        strokeDasharray="3 3"
      />
      <circle cx="40" cy="50" r="2" fill="rgba(139,92,246,0.5)" />
      <circle cx="120" cy="80" r="1.5" fill="rgba(79,70,229,0.5)" />
      <circle cx="200" cy="40" r="2" fill="rgba(139,92,246,0.5)" />
      <circle cx="320" cy="70" r="1.5" fill="rgba(99,102,241,0.5)" />
      <circle cx="360" cy="150" r="2" fill="rgba(139,92,246,0.5)" />
      <circle cx="60" cy="220" r="1.5" fill="rgba(79,70,229,0.5)" />
      <circle cx="140" cy="250" r="2" fill="rgba(139,92,246,0.5)" />
      <circle cx="280" cy="230" r="1.5" fill="rgba(99,102,241,0.5)" />
    </svg>
  )
}

export function SoundWave({ className }: { className?: string }) {
  const bars = [0.4, 0.7, 0.3, 0.9, 0.5, 0.8, 0.4, 0.6, 0.3, 0.7]
  return (
    <div className={cn('flex items-end gap-1', className)}>
      {bars.map((h, i) => (
        <div
          key={i}
          className="w-1 bg-gradient-to-t from-indigo-500 to-violet-400 rounded-full animate-pulse"
          style={{ height: `${h * 24}px`, animationDuration: `${0.5 + i * 0.15}s` }}
        />
      ))}
    </div>
  )
}

export function LightstickMotif({ className }: { className?: string }) {
  return (
    <div className={cn('relative pointer-events-none', className)}>
      <div className="w-1.5 h-16 rounded-full bg-gradient-to-b from-violet-400 via-indigo-500 to-transparent opacity-60 blur-[1px]" />
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-violet-400/40 blur-[2px] animate-glow-pulse" />
    </div>
  )
}

export function HoloOverlay({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'absolute inset-0 holo-gradient-animated pointer-events-none rounded-2xl',
        className,
      )}
    />
  )
}
