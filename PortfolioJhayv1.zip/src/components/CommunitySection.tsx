import { Users, Mic, GraduationCap, Code2, Handshake, Rocket, Globe, Lightbulb } from 'lucide-react'
import { SectionStars } from '@/components/DecorativeElements'

const COMMUNITY_CARDS = [
  { icon: Mic, label: 'Event organization', color: 'text-violet-400' },
  { icon: GraduationCap, label: 'Mentoring', color: 'text-indigo-400' },
  { icon: Code2, label: 'Collaborative development', color: 'text-blue-400' },
  { icon: Handshake, label: 'Technical leadership', color: 'text-violet-300' },
  { icon: Rocket, label: 'Hackathons', color: 'text-amber-300' },
  { icon: Globe, label: 'Networking', color: 'text-cyan-400' },
  { icon: Lightbulb, label: 'Knowledge sharing', color: 'text-emerald-400' },
]

export function CommunitySection() {
  return (
    <section id="comunidade" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={4} />
      <div className="container max-w-5xl mx-auto relative">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Technology is also about community
            </h2>
            <p className="text-xs font-mono text-indigo-400 mt-1">
              08. ENGAGEMENT &amp; CODANDO COMMUNITY
            </p>
          </div>
        </div>

        <div className="p-6 md:p-8 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl mb-8">
          <p className="text-slate-300 text-base leading-relaxed">
            I believe that shared knowledge accelerates careers. I actively participate in the{' '}
            <span className="text-violet-300 font-semibold">Codando Community</span>, where I help
            develop projects, organize events, and encourage new developers to take their first
            steps in the tech ecosystem.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {COMMUNITY_CARDS.map((card, idx) => {
            const Icon = card.icon
            return (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-lg flex flex-col items-center justify-center text-center gap-3 hover:border-violet-500/40 hover:-translate-y-1 transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-xl bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <Icon className={`w-5 h-5 ${card.color}`} />
                </div>
                <span className="text-xs font-medium text-slate-200 leading-tight">
                  {card.label}
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
