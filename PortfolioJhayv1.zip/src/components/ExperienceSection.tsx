import { EXPERIENCES } from '@/data/portfolio-data'
import { Briefcase, ChevronDown, Check } from 'lucide-react'
import { useState } from 'react'
import { Badge } from '@/components/ui/badge'

export function ExperienceSection() {
  const [expandedId, setExpandedId] = useState<string | null>('df-transportes')

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id))
  }

  return (
    <section id="experiencia" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Where I Built Solutions
            </h2>
            <p className="text-xs font-mono text-indigo-400 mt-1">
              04. EXPERIENCES &amp; LEARNINGS
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {EXPERIENCES.map((exp) => {
            const isExpanded = expandedId === exp.id
            return (
              <div
                key={exp.id}
                className="rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl shadow-xl overflow-hidden transition-all duration-300 hover:border-violet-500/30"
              >
                <button
                  onClick={() => toggleExpand(exp.id)}
                  className="w-full p-6 text-left flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer hover:bg-white/5 transition"
                >
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold font-display bg-gradient-to-r from-violet-200 to-indigo-300 bg-clip-text text-transparent mb-1">
                      {exp.narrativeTitle}
                    </h3>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm text-slate-300 font-medium">{exp.company}</span>
                      <span className="text-slate-500">•</span>
                      <span className="text-xs text-indigo-300">{exp.role}</span>
                      <span className="px-2 py-0.5 rounded-md bg-indigo-900/60 border border-indigo-500/30 text-violet-300 text-[10px] font-mono">
                        {exp.period}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs text-slate-400 font-mono hidden md:inline">
                      {isExpanded ? 'Collapse' : 'Expand'}
                    </span>
                    <div
                      className={`w-8 h-8 rounded-full bg-indigo-950 border border-indigo-500/30 flex items-center justify-center text-violet-400 transition-transform duration-300 ${isExpanded ? 'rotate-180 bg-violet-950/60' : ''}`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-6 pb-6 pt-2 border-t border-indigo-500/10 grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
                    <div className="lg:col-span-7 space-y-4">
                      <p className="text-slate-300 text-sm leading-relaxed">{exp.description}</p>
                      <div className="space-y-2">
                        <span className="text-xs font-mono text-indigo-400 uppercase font-semibold">
                          Learnings &amp; Deliverables:
                        </span>
                        {exp.highlights.map((item, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                            <Check className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                      <div className="pt-2">
                        <span className="text-xs font-mono text-slate-400 block mb-2">
                          COMPETENCIES:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {exp.tags.map((tag, tagIdx) => (
                            <Badge
                              key={tagIdx}
                              variant="outline"
                              className="border-indigo-500/30 text-indigo-300 bg-indigo-950/30 text-[11px]"
                            >
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="lg:col-span-5 rounded-xl overflow-hidden border border-indigo-500/20 bg-black/40">
                      <img
                        src={exp.image}
                        alt={exp.company}
                        className="w-full h-48 md:h-full object-cover filter contrast-105"
                      />
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
