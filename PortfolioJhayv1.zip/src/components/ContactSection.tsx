import { Mail, Github, Linkedin, Send } from 'lucide-react'
import { SectionStars } from '@/components/DecorativeElements'

export function ContactSection() {
  return (
    <section id="contato" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <SectionStars count={5} />
      <div className="container max-w-4xl mx-auto text-center relative">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-mono mb-6">
          <Send className="w-3.5 h-3.5" />
          <span>LET'S TALK?</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent mb-4">
          Let's Connect
        </h2>

        <p className="text-slate-300 text-base md:text-lg max-w-xl mx-auto mb-10 leading-relaxed">
          Whether for professional opportunities, collaborative projects, community talks, or simply
          to chat about technology!
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10 max-w-2xl mx-auto">
          <a
            href="https://github.com/Jhaysavi"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl flex flex-col items-center justify-center gap-2 hover:border-violet-500/50 hover:-translate-y-1 transition duration-300 group"
          >
            <Github className="w-8 h-8 text-violet-400 group-hover:scale-110 transition" />
            <span className="text-sm font-bold text-white">GitHub</span>
            <span className="text-[11px] font-mono text-indigo-300">@Jhaysavi</span>
          </a>
          <a
            href="https://www.linkedin.com/in/jhaysavi/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl flex flex-col items-center justify-center gap-2 hover:border-violet-500/50 hover:-translate-y-1 transition duration-300 group"
          >
            <Linkedin className="w-8 h-8 text-indigo-400 group-hover:scale-110 transition" />
            <span className="text-sm font-bold text-white">LinkedIn</span>
            <span className="text-[11px] font-mono text-indigo-300">Sonia Barros</span>
          </a>
          <a
            href="mailto:jhay.dev@outlook.com"
            className="p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20 backdrop-blur-xl flex flex-col items-center justify-center gap-2 hover:border-violet-500/50 hover:-translate-y-1 transition duration-300 group"
          >
            <Mail className="w-8 h-8 text-violet-400 group-hover:scale-110 transition" />
            <span className="text-sm font-bold text-white">Email</span>
            <span className="text-[11px] font-mono text-indigo-300">Direct Contact</span>
          </a>
        </div>

        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono text-violet-400 mt-4">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Now Coding...</span>
            <span className="inline-block w-1.5 h-4 bg-violet-400 animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  )
}
