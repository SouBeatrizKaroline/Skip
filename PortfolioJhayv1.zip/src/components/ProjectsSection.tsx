import { PROJECTS } from '@/data/portfolio-data'
import { FolderGit2, Github, ExternalLink, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export function ProjectsSection() {
  return (
    <section id="projetos" className="py-20 md:py-32 px-4 md:px-8 relative z-10">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center text-violet-400 shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <FolderGit2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
              Featured Projects
            </h2>
            <p className="text-xs font-mono text-indigo-400">05. CODE, DESIGN &amp; FEATURES</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROJECTS.map((proj) => (
            <div
              key={proj.id}
              className={`rounded-2xl border backdrop-blur-xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-2 group ${proj.isEncore ? 'bg-gradient-to-b from-indigo-950/80 via-slate-900/80 to-[#09090B] border-violet-500/40 shadow-[0_0_25px_rgba(79,70,229,0.2)]' : 'bg-slate-900/60 border-indigo-500/20 shadow-xl hover:border-violet-500/40'}`}
            >
              <div>
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={proj.image}
                    alt={proj.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#09090B] via-transparent to-transparent opacity-80" />
                  {proj.badge && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-indigo-600 text-white border-none font-mono text-[10px] animate-pulse shadow-lg flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        {proj.badge}
                      </Badge>
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-bold font-display text-white mb-2 group-hover:text-violet-300 transition">
                    {proj.title}
                  </h3>
                  <p className="text-slate-300 text-xs leading-relaxed mb-4 line-clamp-3">
                    {proj.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {proj.tags.map((tag, tagIdx) => (
                      <Badge
                        key={tagIdx}
                        variant="secondary"
                        className="bg-indigo-950/60 text-indigo-200 border border-indigo-500/20 text-[10px]"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="p-5 pt-0 flex items-center gap-2">
                {proj.githubUrl && (
                  <Button
                    asChild
                    variant="outline"
                    size="sm"
                    className="flex-1 border-indigo-500/40 text-indigo-200 hover:bg-indigo-900/40 hover:text-white text-xs cursor-pointer"
                  >
                    <a href={proj.githubUrl} target="_blank" rel="noopener noreferrer">
                      <Github className="w-3.5 h-3.5 mr-1 text-violet-400" /> Repository
                    </a>
                  </Button>
                )}
                {proj.demoUrl && (
                  <Button
                    asChild
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-xs cursor-pointer"
                  >
                    <a href={proj.demoUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-3.5 h-3.5 mr-1" /> Demo
                    </a>
                  </Button>
                )}
                {proj.isEncore && (
                  <div className="w-full text-center py-2 text-xs font-mono text-violet-300 bg-indigo-950/30 rounded-lg border border-violet-500/20">
                    🚀 Upcoming Hackathons
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
