import { HackathonItem } from '@/types/portfolio'

export const HACKATHONS: HackathonItem[] = [
  {
    id: 'earth-connections',
    name: 'Earth Connections',
    placement: 'Global Nominee',
    placementIcon: '🌎',
    event: 'NASA Space Apps Challenge 2024',
    description:
      'An international project inspired by NASA data to understand the relationships between wildfires, deforestation, and environmental changes.',
    technologies: ['JavaScript', 'Data Visualization', 'Data', 'Sustainability', 'NASA APIs'],
    badge: 'Regional Finalist • Global Nominee',
    isGlobal: true,
  },
  {
    id: 'frutos-do-cerrado',
    name: 'Frutos do Cerrado',
    placement: '1st Place',
    placementIcon: '🥇',
    event: 'Hackathon Governo de Goiás',
    description:
      'A solution created to strengthen Quilombola communities through technology, connecting production, culture, and sustainability.',
    technologies: ['React', 'Node.js', 'MongoDB', 'Sustainability'],
  },
  {
    id: 'raizes-go',
    name: 'RaízesGo',
    placement: '1st Place',
    placementIcon: '🥇',
    event: 'Impulso Regional',
    description:
      'Connecting rural producers, institutional buyers, and logistics through an intelligent platform.',
    technologies: ['React', 'Node.js', 'PostgreSQL', 'Logistics'],
  },
  {
    id: 'destin-ai',
    name: 'DestinAI',
    placement: '3rd Place',
    placementIcon: '🥉',
    event: "Don't Skip Challenge",
    description:
      'Predictive AI to reduce food waste using intelligent analysis of the logistics supply chain.',
    technologies: ['Python', 'AI', 'Data Analysis', 'Flask'],
  },
]
