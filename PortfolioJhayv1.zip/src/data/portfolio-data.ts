import {
  TimelineItem,
  StatItem,
  SpecialtyCategory,
  ExperienceItem,
  ProjectItem,
  RecommendationItem,
  NavLinkItem,
} from '@/types/portfolio'

export const NAV_LINKS: NavLinkItem[] = [
  { id: 'hero', label: 'Home' },
  { id: 'sobre', label: 'About' },
  { id: 'timeline', label: 'Timeline' },
  { id: 'experiencia', label: 'Experience' },
  { id: 'projetos', label: 'Projects' },
  { id: 'hackathons', label: 'Hackathons' },
  { id: 'github', label: 'GitHub' },
  { id: 'comunidade', label: 'Community' },
  { id: 'competencias', label: 'Skills' },
  { id: 'recomendacoes', label: 'Recommendations' },
  { id: 'formacao', label: 'Education' },
  { id: 'contato', label: 'Contact' },
]

export const TIMELINE_ITEMS: TimelineItem[] = [
  {
    year: '2015',
    title: 'High School',
    subtitle: 'CED Vale do Amanhecer',
    description:
      'First steps and the awakening of a passion for science, logic, and problem-solving.',
  },
  {
    year: '2022',
    title: 'B.Sc. in Computer Science',
    subtitle: 'Universidade Anhembi Morumbi',
    description:
      'Beginning of an academic journey focused on algorithms, software architecture, and engineering.',
  },
  {
    year: '2023',
    title: 'Joined the Codando Community',
    subtitle: 'Tech Leadership & Development',
    description: 'Direct engagement in a collaborative tech ecosystem.',
    bullets: [
      'Development of high-impact collaborative projects',
      'Organization and facilitation of tech events',
      'Mentoring new developers',
      'UI/UX design conception and improvement',
    ],
  },
  {
    year: '2025',
    title: 'Systems Analyst',
    subtitle: 'DF Transportes',
    description: 'Strategic role in modernizing and managing operational processes.',
    bullets: [
      'Detailed requirements gathering and specification',
      'Strategic backlog and agile sprint management',
      'TMS systems and logistics process optimization',
      'Data analysis for operational decision-making',
    ],
  },
  {
    year: 'Now',
    title: 'Full Stack Developer & Leader',
    subtitle: 'Projects, Hackathons & Open Source',
    description:
      'Constantly building end-to-end solutions with a focus on innovation, high performance, and community engagement.',
  },
]

export const STATS_ITEMS: StatItem[] = [
  {
    number: '2+ years',
    label: 'Development Experience',
    description: 'Building efficient Full Stack products',
    icon: 'Code',
  },
  {
    number: '30+',
    label: 'Technologies & Tools',
    description: 'Mastery of modern ecosystems',
    icon: 'Cpu',
  },
  {
    number: '3+',
    label: 'Participations & Awards',
    description: 'High-performance hackathons',
    icon: 'Trophy',
  },
  {
    number: 'Leader',
    label: 'Community & Mentoring',
    description: 'Technical leadership and facilitation',
    icon: 'Users',
  },
]

export const SPECIALTIES: SpecialtyCategory[] = [
  {
    category: 'Frontend',
    technologies: [
      'React',
      'TypeScript',
      'JavaScript',
      'HTML5',
      'CSS3',
      'Tailwind CSS',
      'Bootstrap',
      'UI/UX Design',
    ],
  },
  {
    category: 'Backend',
    technologies: ['Node.js', 'Java', 'Python', 'Express.js', 'MySQL', 'REST APIs', 'SQL'],
  },
  {
    category: 'Agile Methodologies',
    technologies: ['Scrum', 'Kanban', 'Backlog Management', 'User Stories', 'Business Agility'],
  },
  {
    category: 'Tools & Analysis',
    technologies: [
      'Figma',
      'Git',
      'GitHub',
      'Trello',
      'Data Analysis',
      'Logistics TMS',
      'Technical Documentation',
    ],
  },
]

export const EXPERIENCES: ExperienceItem[] = [
  {
    id: 'df-transportes',
    company: 'DF Transportes',
    role: 'Systems Analyst',
    period: '2025 - Present',
    narrativeTitle: 'Modernizing logistics operations',
    description:
      'An experience where I helped translate complex processes into digital solutions, bridging technology, logistics, and people. There, I developed skills in requirements gathering, prototyping, technical documentation, backlog management, and cross-functional communication.',
    tags: [
      'Requirements Gathering',
      'Backlog Management',
      'Agile Sprints',
      'TMS',
      'Logistics',
      'Data Analysis',
      'Figma',
      'Documentation',
      'Cross-functional Collaboration',
    ],
    highlights: [
      'Complete mapping of operational flows for route and load optimization',
      'Prototyping in Figma for internal freight tracking systems',
      'Direct interface between technology teams and operational directors',
    ],
    image: 'https://img.usecurling.com/p/600/350?q=logistics%20data%20analytics',
  },
  {
    id: 'comunidade-codando',
    company: 'Codando Community',
    role: 'Development Lead',
    period: '2023 - Present',
    narrativeTitle: 'Growing together with others',
    description:
      'A transformative experience where technology meets empathy and collaboration. As a volunteer tech lead, I mentor new developers, organize events that bring people closer to the tech ecosystem, and architect collaborative web solutions. Every project built in community is proof that we grow more — and faster — when we grow together.',
    tags: [
      'Website Development',
      'Technical Leadership',
      'Mentoring',
      'Event Organization',
      'Team Management',
      'UI/UX Design',
      'Collaborative Projects',
    ],
    highlights: [
      'Coordinating multidisciplinary teams in the development of community-driven applications',
      'Weekly mentoring in web programming, Git versioning, and React architecture',
      'Significant increase in member retention and engagement through hands-on projects',
    ],
    image: 'https://img.usecurling.com/p/600/350?q=tech%20community%20workshop',
  },
]

export const PROJECTS: ProjectItem[] = [
  {
    id: 'ar-livre',
    title: 'Ar Livre',
    description:
      'A vibrant and responsive landing page built with React and Vite. The interface is focused on delivering a seamless experience for outdoor enthusiasts and travelers.',
    tags: ['React', 'Vite', 'Tailwind CSS', 'Responsive', 'UI/UX'],
    githubUrl: 'https://github.com/Jhaysavi/arLivre',
    image: 'https://img.usecurling.com/p/600/350?q=nature%20adventure%20website',
  },
  {
    id: 'saude-express',
    title: 'Saúde Express',
    description:
      'An innovative system for optimizing healthcare appointments. Integration with external APIs, WhatsApp communication, and intelligent triage to speed up hospital screenings.',
    tags: ['React', 'Node.js', 'WhatsApp API', 'Intelligent Triage', 'REST API'],
    image: 'https://img.usecurling.com/p/600/350?q=healthcare%20digital%20app',
  },
  {
    id: 'encore-projects',
    title: 'Encore Projects',
    description:
      'A space reserved for upcoming releases and solutions developed during hackathon marathons and high-level tech challenges.',
    tags: ['Hackathons', 'Future Projects', 'Innovation', 'Open Source'],
    badge: 'Coming Soon',
    isEncore: true,
    image: 'https://img.usecurling.com/p/600/350?q=cyberpunk%20futuristic%20code',
  },
]

export const RECOMMENDATIONS: RecommendationItem[] = [
  {
    name: 'Isabella Saiti',
    role: 'Developer & Study Colleague',
    relationship: 'Studied together at Universidade Anhembi Morumbi',
    text: 'Jhay stands out deeply for her impeccable dedication, strategic planning, and high level of organization. She pursues continuous improvement in every line of code, and is also an extremely collaborative work partner with exemplary professionalism.',
  },
  {
    name: 'Jeferson Moreira',
    role: 'Full Stack Engineer & Project Partner',
    relationship: 'Colleague in studies and collaborative projects',
    text: 'Jhay is an excellent Full Stack developer. She combines rigorous technical quality with on-time delivery and a consistent team spirit. Her ability to communicate complex requirements and turn ideas into functional prototypes makes all the difference.',
  },
]

export const COURSES = [
  'Oracle + Alura (Java & Backend Bootcamp)',
  'DIO - Digital Innovation One',
  'Advanced React & TypeScript',
  'Java & Object-Oriented Programming',
  'Git & Collaborative Versioning',
  'JavaScript ES6+ & Async Programming',
  'Data Modeling & SQL Queries',
  'Business Agility & Scrum Framework',
  'Tech Entrepreneurship',
]
