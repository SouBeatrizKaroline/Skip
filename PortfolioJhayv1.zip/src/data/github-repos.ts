import { GitHubRepo } from '@/types/portfolio'

export const GITHUB_REPOS: GitHubRepo[] = [
  {
    id: 'ar-livre',
    name: 'Ar Livre',
    description: 'Vibrant and responsive landing page for outdoor enthusiasts and travelers.',
    category: 'Frontend',
    technologies: ['React', 'Vite', 'Tailwind CSS'],
    url: 'https://github.com/Jhaysavi/arLivre',
  },
  {
    id: 'saude-express',
    name: 'Saúde Express',
    description:
      'System for optimizing healthcare appointments with intelligent triage and WhatsApp.',
    category: 'Hackathons',
    technologies: ['React', 'Node.js', 'WhatsApp API', 'REST API'],
    url: 'https://github.com/Jhaysavi/saude-express',
  },
  {
    id: 'earth-connections-repo',
    name: 'Earth Connections',
    description:
      'Environmental data visualization using NASA data to analyze wildfires and deforestation.',
    category: 'Hackathons',
    technologies: ['JavaScript', 'D3.js', 'NASA API'],
    url: 'https://github.com/Jhaysavi/earth-connections',
  },
  {
    id: 'frutos-cerrado-repo',
    name: 'Frutos do Cerrado',
    description:
      'Platform to strengthen Quilombola communities by connecting production and culture.',
    category: 'Hackathons',
    technologies: ['React', 'Node.js', 'MongoDB'],
    url: 'https://github.com/Jhaysavi/frutos-do-cerrado',
  },
  {
    id: 'raizes-go-repo',
    name: 'RaízesGo',
    description: 'Intelligent platform connecting rural producers and institutional buyers.',
    category: 'Hackathons',
    technologies: ['React', 'Node.js', 'PostgreSQL'],
    url: 'https://github.com/Jhaysavi/raizes-go',
  },
  {
    id: 'api-java',
    name: 'Java REST API',
    description: 'REST API for task management with JWT authentication and SOLID best practices.',
    category: 'Backend',
    technologies: ['Java', 'Spring Boot', 'MySQL', 'JWT'],
    url: 'https://github.com/Jhaysavi/api-java-rest',
  },
  {
    id: 'node-server',
    name: 'Node Express Server',
    description: 'Node.js server with Express, middlewares, and scalable architecture.',
    category: 'Backend',
    technologies: ['Node.js', 'Express', 'MongoDB'],
    url: 'https://github.com/Jhaysavi/node-express-server',
  },
  {
    id: 'estrutura-dados',
    name: 'Data Structures',
    description: 'Implementations of classic data structures and algorithms in Java.',
    category: 'Academic Projects',
    technologies: ['Java', 'Algorithms', 'OOP'],
    url: 'https://github.com/Jhaysavi/estrutura-dados-java',
  },
  {
    id: 'banco-digital',
    name: 'OO Digital Bank',
    description:
      'Object-oriented banking system with account operations, withdrawals, and transfers.',
    category: 'Academic Projects',
    technologies: ['Java', 'OOP', 'Design Patterns'],
    url: 'https://github.com/Jhaysavi/banco-digital-oo',
  },
  {
    id: 'canvas-game',
    name: 'Canvas Game',
    description: 'Experimental 2D game built with the Canvas API and vanilla JavaScript.',
    category: 'Experiments / Games',
    technologies: ['JavaScript', 'HTML5 Canvas', 'CSS3'],
    url: 'https://github.com/Jhaysavi/canvas-game',
  },
  {
    id: 'codando-site',
    name: 'Codando Community Website',
    description: 'Institutional website for the Codando Community, built collaboratively.',
    category: 'Open Source',
    technologies: ['React', 'Tailwind CSS', 'Open Source'],
    url: 'https://github.com/Jhaysavi/codando-site',
  },
  {
    id: 'dev-utils',
    name: 'Dev Utils',
    description: 'A collection of utilities and snippets to speed up daily development.',
    category: 'Tools',
    technologies: ['TypeScript', 'Node.js', 'CLI'],
    url: 'https://github.com/Jhaysavi/dev-utils',
  },
]

export const GITHUB_CATEGORIES = [
  'Backend',
  'Frontend',
  'Academic Projects',
  'Hackathons',
  'Experiments / Games',
  'Open Source',
  'Tools',
]
