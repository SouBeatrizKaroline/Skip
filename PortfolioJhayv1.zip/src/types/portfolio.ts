export interface TimelineItem {
  year: string
  title: string
  subtitle: string
  description: string
  bullets?: string[]
  iconName?: string
}

export interface StatItem {
  number: string
  label: string
  description: string
  icon: string
}

export interface SpecialtyCategory {
  category: string
  technologies: string[]
}

export interface ExperienceItem {
  id: string
  company: string
  role: string
  period: string
  narrativeTitle: string
  description: string
  tags: string[]
  highlights: string[]
  image: string
}

export interface HackathonItem {
  id: string
  name: string
  placement: string
  placementIcon: string
  event: string
  description: string
  technologies: string[]
  badge?: string
  isGlobal?: boolean
}

export interface GitHubRepo {
  id: string
  name: string
  description: string
  category: string
  technologies: string[]
  url: string
}

export interface ProjectItem {
  id: string
  title: string
  description: string
  tags: string[]
  githubUrl?: string
  demoUrl?: string
  badge?: string
  isEncore?: boolean
  image: string
}

export interface RecommendationItem {
  name: string
  role: string
  relationship: string
  text: string
}

export interface NavLinkItem {
  id: string
  label: string
}
