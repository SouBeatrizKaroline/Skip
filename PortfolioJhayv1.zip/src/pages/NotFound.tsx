import { useLocation } from 'react-router-dom'
import { useEffect } from 'react'

const NotFound = () => {
  const location = useLocation()

  useEffect(() => {
    console.error('404 Error: User attempted to access non-existent route:', location.pathname)
  }, [location.pathname])

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#09090B]">
      <div className="text-center">
        <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-indigo-400 to-violet-400 bg-clip-text text-transparent">
          404
        </h1>
        <p className="text-xl text-slate-400 mb-4">Page not found</p>
        <a href="/" className="text-indigo-400 hover:text-violet-300 underline">
          Back to home
        </a>
      </div>
    </div>
  )
}

export default NotFound
