import { useScrollSpy } from '@/hooks/use-scroll-spy'
import { NAV_LINKS } from '@/data/portfolio-data'
import { Navbar } from '@/components/Navbar'
import { HeroSection } from '@/components/HeroSection'
import { AboutSection } from '@/components/AboutSection'
import { TimelineSection } from '@/components/TimelineSection'
import { StatsSection } from '@/components/StatsSection'
import { SpecialtiesSection } from '@/components/SpecialtiesSection'
import { ExperienceSection } from '@/components/ExperienceSection'
import { ProjectsSection } from '@/components/ProjectsSection'
import { HackathonsSection } from '@/components/HackathonsSection'
import { GitHubSection } from '@/components/GitHubSection'
import { CommunitySection } from '@/components/CommunitySection'
import { SkillsSection } from '@/components/SkillsSection'
import { RecommendationsSection } from '@/components/RecommendationsSection'
import { EducationSection } from '@/components/EducationSection'
import { ContactSection } from '@/components/ContactSection'
import { Footer } from '@/components/Footer'
import { ParticleBackground } from '@/components/ParticleBackground'
import { CustomCursor } from '@/components/CustomCursor'

export default function Index() {
  const sectionIds = NAV_LINKS.map((item) => item.id)
  const activeSection = useScrollSpy(sectionIds, 120)

  return (
    <div className="min-h-screen bg-[#09090B] text-slate-100 font-sans selection:bg-indigo-500 selection:text-white relative overflow-x-hidden">
      <div className="fixed inset-0 tech-grid-bg pointer-events-none z-0" />
      <CustomCursor />
      <ParticleBackground />
      <Navbar activeSection={activeSection} />

      <main className="relative z-10 space-y-4">
        <HeroSection />
        <AboutSection />
        <TimelineSection />
        <StatsSection />
        <SpecialtiesSection />
        <ExperienceSection />
        <ProjectsSection />
        <HackathonsSection />
        <GitHubSection />
        <CommunitySection />
        <SkillsSection />
        <RecommendationsSection />
        <EducationSection />
        <ContactSection />
      </main>

      <Footer />
    </div>
  )
}
