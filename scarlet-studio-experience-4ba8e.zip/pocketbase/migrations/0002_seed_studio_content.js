migrate(
  (app) => {
    const portfolioCol = app.findCollectionByNameOrId('portfolio_projects')
    const projects = [
      {
        title: 'Neon Vanguard',
        category: 'FPS',
        description:
          'A fast-paced retro-futuristic FPS with neon-soaked arenas and fluid movement.',
        overview:
          'Neon Vanguard combines old-school arena shooter mechanics with modern vertical traversal and dynamic lighting. Players control an augmented operative navigating a cyberpunk metropolis overrun by rogue synthetic lifeforms.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=cyberpunk%20game',
        tags: ['FPS', 'Neon', 'Retro-Future'],
        year: 2025,
      },
      {
        title: 'Emberfall',
        category: 'Stylized RPG',
        description: 'An open-world fantasy shattered by an eternal fire, rebuilt from its ashes.',
        overview:
          'Emberfall is a rich action-RPG featuring a vibrant hand-crafted world devastated by a celestial cataclysm. Explore ancient ruins, master elemental magic, and unite fragmented factions to reshape the realm.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=fantasy%20rpg%20game',
        tags: ['RPG', 'Open World', 'Stylized'],
        year: 2024,
      },
      {
        title: 'Chrono Drift',
        category: 'Sci-Fi Racing',
        description: 'Time-bending hover racing across collapsing dimensions.',
        overview:
          'Chrono Drift challenges racers to manipulate temporal pockets while navigating gravity-defying tracks suspended over cosmic voids. High-speed adrenaline meets tactical time rewinds.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=sci%20fi%20racing',
        tags: ['Racing', 'Sci-Fi', 'Arcade'],
        year: 2024,
      },
      {
        title: 'Last Signal',
        category: 'Survival Horror',
        description:
          'A lonely radio operator uncovers a signal that should never have been answered.',
        overview:
          'Set in an isolated sub-arctic research station during the 1980s, Last Signal delivers intense psychological horror through realistic audio design, limited resources, and cosmic dread.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=dark%20horror%20game',
        tags: ['Horror', 'Atmospheric', 'Single-player'],
        year: 2023,
      },
      {
        title: 'Verdant',
        category: 'Cozy Sim',
        description: 'A hand-painted farming and exploration adventure in a breathing world.',
        overview:
          'Verdant invites players to restore an enchanted ancient forest island. Tend magical flora, forge bonds with spirit inhabitants, and uncover forgotten mysteries at your own peaceful pace.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=cozy%20forest%20game',
        tags: ['Cozy', 'Farming', 'Hand-painted'],
        year: 2023,
      },
      {
        title: 'Mecha Rhapsody',
        category: 'Stylized Action',
        description: 'Rhythm-combat mecha battles choreographed to a synthwave score.',
        overview:
          'Mecha Rhapsody synchronizes high-octane mecha combat with energetic synthwave beats. Time your slashes, dodges, and laser salvos to the music to unleash unstoppable combos.',
        cover_url: 'https://img.usecurling.com/p/800/500?q=mecha%20action%20game',
        tags: ['Action', 'Rhythm', 'Mecha'],
        year: 2022,
      },
    ]

    for (const p of projects) {
      try {
        app.findFirstRecordByData('portfolio_projects', 'title', p.title)
      } catch (_) {
        const rec = new Record(portfolioCol)
        rec.set('title', p.title)
        rec.set('category', p.category)
        rec.set('description', p.description)
        rec.set('overview', p.overview)
        rec.set('cover_url', p.cover_url)
        rec.set('tags', p.tags)
        rec.set('year', p.year)
        app.save(rec)
      }
    }

    const teamCol = app.findCollectionByNameOrId('team_members')
    const members = [
      {
        name: 'Aria Chen',
        role: 'Creative Director',
        bio: 'Turns coffee into gameplay mechanics ☕🎮',
        avatar_url: 'https://img.usecurling.com/ppl/medium?gender=female&seed=10',
        skills: ['Game Design', 'Narrative', 'Prototyping'],
        socials: { twitter: 'https://twitter.com', linkedin: 'https://linkedin.com' },
      },
      {
        name: 'Lucas Mendes',
        role: 'Lead Developer',
        bio: 'Ships bug-free builds at 3am (allegedly).',
        avatar_url: 'https://img.usecurling.com/ppl/medium?gender=male&seed=20',
        skills: ['C#', 'Unity', 'Optimization'],
        socials: { github: 'https://github.com', linkedin: 'https://linkedin.com' },
      },
      {
        name: 'Maya Sato',
        role: 'Art Director',
        bio: 'Paints worlds with pixels and obsession.',
        avatar_url: 'https://img.usecurling.com/ppl/medium?gender=female&seed=30',
        skills: ['Concept Art', '3D', 'Color Theory'],
        socials: { instagram: 'https://instagram.com', twitter: 'https://twitter.com' },
      },
      {
        name: 'Renan Costa',
        role: 'Sound Designer',
        bio: 'Makes silence sound expensive.',
        avatar_url: 'https://img.usecurling.com/ppl/medium?gender=male&seed=40',
        skills: ['Audio Design', 'Voice Direction', 'Scoring'],
        socials: { linkedin: 'https://linkedin.com', twitter: 'https://twitter.com' },
      },
    ]

    for (const m of members) {
      try {
        app.findFirstRecordByData('team_members', 'name', m.name)
      } catch (_) {
        const rec = new Record(teamCol)
        rec.set('name', m.name)
        rec.set('role', m.role)
        rec.set('bio', m.bio)
        rec.set('avatar_url', m.avatar_url)
        rec.set('skills', m.skills)
        rec.set('socials', m.socials)
        app.save(rec)
      }
    }
  },
  (app) => {},
)
