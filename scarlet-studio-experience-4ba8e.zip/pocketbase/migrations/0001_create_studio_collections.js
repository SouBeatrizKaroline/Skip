migrate(
  (app) => {
    const portfolio = new Collection({
      name: 'portfolio_projects',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'title', type: 'text', required: true },
        { name: 'category', type: 'text', required: true },
        { name: 'description', type: 'text', required: true },
        { name: 'overview', type: 'text', required: true },
        { name: 'cover_url', type: 'text', required: true },
        { name: 'tags', type: 'json' },
        { name: 'year', type: 'number', required: true },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_portfolio_cat ON portfolio_projects (category)',
        'CREATE INDEX idx_portfolio_year ON portfolio_projects (year DESC)',
      ],
    })
    app.save(portfolio)

    const team = new Collection({
      name: 'team_members',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'role', type: 'text', required: true },
        { name: 'bio', type: 'text', required: true },
        { name: 'avatar_url', type: 'text' },
        { name: 'skills', type: 'json' },
        { name: 'socials', type: 'json' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(team)

    const contacts = new Collection({
      name: 'contacts',
      type: 'base',
      listRule: null,
      viewRule: null,
      createRule: '',
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'email', type: 'email', required: true },
        { name: 'project_idea', type: 'text', required: true },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE INDEX idx_contacts_created ON contacts (created DESC)'],
    })
    app.save(contacts)
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId('portfolio_projects'))
    } catch (_) {}
    try {
      app.delete(app.findCollectionByNameOrId('team_members'))
    } catch (_) {}
    try {
      app.delete(app.findCollectionByNameOrId('contacts'))
    } catch (_) {}
  },
)
