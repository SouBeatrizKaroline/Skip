export interface PortfolioProject {
  id: string
  title: string
  category: string
  description: string
  overview: string
  cover_url: string
  tags: string[]
  year: number
  created: string
  updated: string
}

export interface TeamMember {
  id: string
  name: string
  role: string
  bio: string
  avatar_url: string
  skills: string[]
  socials: {
    twitter?: string
    linkedin?: string
    github?: string
    instagram?: string
  }
  created: string
  updated: string
}

export interface ContactSubmission {
  name: string
  email: string
  project_idea: string
}

export interface PhaseInfo {
  id: string
  number: string
  label: string
}

export interface Showcase3DItem {
  id: string
  title: string
  category: string
  image_url: string
  description: string
}

export interface Art2DItem {
  id: string
  title: string
  category: 'Concept Art' | 'UI/UX' | 'Illustration'
  image_url: string
  description: string
}

export interface AudioTrack {
  id: string
  title: string
  category: string
  description: string
  duration: string
}

export interface LabExperiment {
  id: string
  title: string
  tag: 'WIP' | 'Prototype' | 'Test'
  description: string
  image_url: string
}

export interface ProcessStep {
  id: string
  step: number
  title: string
  description: string
  icon: string
}
