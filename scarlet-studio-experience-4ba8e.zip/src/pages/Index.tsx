import { useState, useEffect } from 'react'
import { useOutletContext } from 'react-router-dom'
import { HeroSection } from '@/components/sections/HeroSection'
import { StorySection } from '@/components/sections/StorySection'
import { ServicesSection } from '@/components/sections/ServicesSection'
import { WhyUsSection } from '@/components/sections/WhyUsSection'
import { PortfolioSection } from '@/components/sections/PortfolioSection'
import { Showcase3DSection } from '@/components/sections/Showcase3DSection'
import { Art2DSection } from '@/components/sections/Art2DSection'
import { AudioSection } from '@/components/sections/AudioSection'
import { CreativeLabSection } from '@/components/sections/CreativeLabSection'
import { ProcessSection } from '@/components/sections/ProcessSection'
import { TransformationsSection } from '@/components/sections/TransformationsSection'
import { TeamSection } from '@/components/sections/TeamSection'
import { StatsSection } from '@/components/sections/StatsSection'
import { FinalCtaSection } from '@/components/sections/FinalCtaSection'
import { ContactSection } from '@/components/sections/ContactSection'
import { CaseStudyModal } from '@/components/CaseStudyModal'
import { getPortfolioProjects } from '@/services/portfolio'
import { getTeamMembers } from '@/services/team'
import type { PortfolioProject, TeamMember } from '@/types/studio'

interface ContextType {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export default function Index() {
  const { playSound } = useOutletContext<ContextType>()

  const [projects, setProjects] = useState<PortfolioProject[]>([])
  const [team, setTeam] = useState<TeamMember[]>([])
  const [loadingProjects, setLoadingProjects] = useState(true)
  const [loadingTeam, setLoadingTeam] = useState(true)
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null)

  useEffect(() => {
    getPortfolioProjects()
      .then((data) => setProjects(data))
      .catch(() => {})
      .finally(() => setLoadingProjects(false))

    getTeamMembers()
      .then((data) => setTeam(data))
      .catch(() => {})
      .finally(() => setLoadingTeam(false))
  }, [])

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      <HeroSection
        playSound={playSound}
        onExplore={() => scrollToSection('worlds')}
        onStart={() => scrollToSection('contact')}
      />

      <StorySection />

      <ServicesSection playSound={playSound} />

      <WhyUsSection playSound={playSound} />

      <PortfolioSection
        projects={projects}
        loading={loadingProjects}
        onSelectProject={(p) => setSelectedProject(p)}
        playSound={playSound}
      />

      <Showcase3DSection playSound={playSound} />

      <Art2DSection playSound={playSound} />

      <AudioSection />

      <CreativeLabSection playSound={playSound} />

      <ProcessSection />

      <TransformationsSection />

      <TeamSection team={team} loading={loadingTeam} playSound={playSound} />

      <StatsSection />

      <FinalCtaSection playSound={playSound} onStart={() => scrollToSection('contact')} />

      <ContactSection playSound={playSound} />

      <CaseStudyModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onStartSimilar={() => scrollToSection('contact')}
        playSound={playSound}
      />
    </>
  )
}
