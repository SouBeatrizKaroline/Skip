import pb from '@/lib/pocketbase/client'
import type { TeamMember } from '@/types/studio'

export const getTeamMembers = async (): Promise<TeamMember[]> => {
  return pb.collection('team_members').getFullList<TeamMember>({
    sort: 'created',
  })
}
