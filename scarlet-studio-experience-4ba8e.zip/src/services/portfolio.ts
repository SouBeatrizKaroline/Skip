import pb from '@/lib/pocketbase/client'
import type { PortfolioProject } from '@/types/studio'

export const getPortfolioProjects = async (): Promise<PortfolioProject[]> => {
  return pb.collection('portfolio_projects').getFullList<PortfolioProject>({
    sort: '-year,-created',
  })
}
