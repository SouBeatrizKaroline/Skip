import pb from '@/lib/pocketbase/client'
import type { ContactSubmission } from '@/types/studio'

export const submitContact = async (data: ContactSubmission) => {
  return pb.collection('contacts').create(data)
}
