import { X } from 'lucide-react'

interface EasterEggModalProps {
  onClose: () => void
}

export function EasterEggModal({ onClose }: EasterEggModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in">
      <div className="relative max-w-md w-full bg-[#0b0b0e] border-2 border-[#ff3b3b] rounded-2xl p-8 text-center shadow-[0_0_80px_rgba(255,59,59,0.5)]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-white/60 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-4xl mb-4 animate-bounce">👾</div>

        <h3 className="font-display font-extrabold text-2xl text-white mb-2">
          SECRET UNIVERSE UNLOCKED
        </h3>

        <p className="font-sans text-sm text-[#9ca3af] mb-6 leading-relaxed">
          You found the hidden universe. Stay curious, player.
        </p>

        <div className="font-mono text-xs text-[#ff3b3b] bg-[#ff3b3b]/10 border border-[#ff3b3b]/30 p-3 rounded-lg mb-6">
          STATUS: LEGENDARY EXPLORER
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-xl font-sans font-semibold text-white bg-[#ff3b3b] hover:bg-[#ff6b6b] transition-all shadow-[0_0_20px_rgba(255,59,59,0.5)]"
        >
          Resume Journey
        </button>
      </div>
    </div>
  )
}
