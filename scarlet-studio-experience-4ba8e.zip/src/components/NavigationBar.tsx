import { useState, useEffect } from 'react'
import { Volume2, VolumeX, Menu, X } from 'lucide-react'

interface NavigationBarProps {
  soundEnabled: boolean
  onToggleSound: () => void
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
  activePhase: string
}

const NAV_LINKS = [
  { id: 'worlds', label: 'Worlds' },
  { id: 'services', label: 'Services' },
  { id: 'crew', label: 'Crew' },
  { id: 'contact', label: 'Contact' },
]

export function NavigationBar({
  soundEnabled,
  onToggleSound,
  playSound,
  activePhase,
}: NavigationBarProps) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    playSound('click')
    setMobileMenuOpen(false)
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-[#050507]/80 backdrop-blur-md border-b border-white/10 py-3 shadow-lg'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-5 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => scrollToSection('hero')}
          onMouseEnter={() => playSound('hover')}
          className="flex items-center gap-3 group focus:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#ff3b3b] to-[#b91c1c] p-0.5 group-hover:shadow-[0_0_15px_#ff3b3b] transition-all">
            <div className="w-full h-full bg-[#050507] rounded-[6px] flex items-center justify-center">
              <span className="font-display font-extrabold text-sm text-[#ff3b3b] group-hover:scale-110 transition-transform">
                S
              </span>
            </div>
          </div>
          <span className="font-display font-extrabold text-base tracking-wider text-white group-hover:text-[#ff3b3b] transition-colors">
            SCARLET STUDIO
          </span>
        </button>

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => {
            const isActive = activePhase === link.id
            return (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                onMouseEnter={() => playSound('hover')}
                className={`relative font-sans text-sm font-medium transition-colors py-1 ${
                  isActive ? 'text-white font-semibold' : 'text-[#9ca3af] hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#ff3b3b] shadow-[0_0_8px_#ff3b3b] rounded-full animate-fade-in" />
                )}
              </button>
            )
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              onToggleSound()
              playSound('click')
            }}
            onMouseEnter={() => playSound('hover')}
            className="p-2 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 text-[#9ca3af] hover:text-white transition-all focus:outline-none"
            aria-label="Toggle sound"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-[#ff3b3b]" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>

          <button
            onClick={() => scrollToSection('contact')}
            onMouseEnter={() => playSound('hover')}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 rounded-xl font-sans text-xs font-semibold tracking-wide text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] hover:shadow-[0_0_20px_rgba(255,59,59,0.5)] transition-all hover:scale-105 active:scale-95 border border-[#ff6b6b]/30"
          >
            Start a Project
          </button>

          {/* Mobile Hamburger */}
          <button
            onClick={() => {
              playSound('click')
              setMobileMenuOpen(!mobileMenuOpen)
            }}
            className="md:hidden p-2 text-white focus:outline-none"
            aria-label="Open menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[60px] bg-[#050507]/95 backdrop-blur-xl z-50 flex flex-col p-6 border-t border-white/10 animate-fade-in">
          <div className="flex flex-col gap-6 mt-6">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="text-left font-display text-2xl font-bold text-white hover:text-[#ff3b3b] transition-colors py-2 border-b border-white/5"
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => scrollToSection('contact')}
              className="mt-4 w-full py-4 rounded-xl font-sans font-semibold text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] text-center shadow-[0_0_20px_rgba(255,59,59,0.4)]"
            >
              Start a Project
            </button>
          </div>
        </div>
      )}
    </header>
  )
}
