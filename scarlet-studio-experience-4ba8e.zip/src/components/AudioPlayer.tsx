import { useState, useEffect, useRef } from 'react'
import { Play, Pause } from 'lucide-react'

interface AudioPlayerProps {
  title: string
  category: string
  description: string
  duration: string
}

export function AudioPlayer({ title, category, description, duration }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const [mins, secs] = duration.split(':').map(Number)
  const totalSeconds = mins * 60 + secs

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= totalSeconds) {
            setIsPlaying(false)
            return 0
          }
          return prev + 1
        })
      }, 1000)
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [isPlaying, totalSeconds])

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return `${m}:${sec.toString().padStart(2, '0')}`
  }

  return (
    <div className="bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b]/50 rounded-2xl p-6 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,59,59,0.15)]">
      <div className="flex items-start justify-between mb-4">
        <div>
          <span className="font-mono text-xs text-[#ff3b3b] uppercase tracking-wider font-semibold">
            {category}
          </span>
          <h3 className="font-display font-bold text-lg text-white mt-1">{title}</h3>
        </div>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-12 h-12 rounded-full bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] flex items-center justify-center text-white hover:scale-110 active:scale-95 transition-all shadow-[0_0_20px_rgba(255,59,59,0.4)] flex-shrink-0"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </button>
      </div>
      <p className="font-sans text-xs text-[#9ca3af] mb-4 leading-relaxed">{description}</p>
      <div className="flex items-end gap-0.5 h-8 mb-3">
        {Array.from({ length: 24 }).map((_, i) => (
          <div
            key={i}
            className="w-1 bg-gradient-to-t from-[#b91c1c] to-[#ff6b6b] rounded-full transition-all duration-150"
            style={{
              height: isPlaying
                ? `${30 + Math.abs(Math.sin(i * 0.5 + progress * 0.3)) * 65 + 5}%`
                : '12%',
            }}
          />
        ))}
      </div>
      <div className="flex items-center gap-2">
        <span className="font-mono text-[10px] text-[#9ca3af] w-8">{formatTime(progress)}</span>
        <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#ff3b3b] to-[#ff6b6b] transition-all duration-1000 ease-linear"
            style={{ width: `${(progress / totalSeconds) * 100}%` }}
          />
        </div>
        <span className="font-mono text-[10px] text-[#9ca3af] w-8 text-right">{duration}</span>
      </div>
    </div>
  )
}
