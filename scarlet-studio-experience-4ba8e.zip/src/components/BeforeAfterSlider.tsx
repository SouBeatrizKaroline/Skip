import { useState, useRef } from 'react'

export function BeforeAfterSlider() {
  const [sliderPos, setSliderPos] = useState(50)
  const [isDragging, setIsDragging] = useState(false)
  const containerRef = useRef<HTMLDivElement | null>(null)

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return
    const rect = containerRef.current.getBoundingClientRect()
    const x = clientX - rect.left
    const percentage = Math.min(Math.max((x / rect.width) * 100, 0), 100)
    setSliderPos(percentage)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging && e.buttons !== 1) return
    handleMove(e.clientX)
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div
        ref={containerRef}
        onMouseDown={() => setIsDragging(true)}
        onMouseUp={() => setIsDragging(false)}
        onMouseLeave={() => setIsDragging(false)}
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
        className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/15 shadow-[0_0_30px_rgba(0,0,0,0.8)] cursor-ew-resize select-none bg-[#050507]"
      >
        {/* Right Image (Game Ready) */}
        <img
          src="https://img.usecurling.com/p/1000/600?q=cyberpunk%20game%20render"
          alt="Game Ready"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 z-10 font-mono text-xs font-bold text-white bg-[#050507]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 uppercase tracking-widest shadow-lg">
          GAME-READY
        </div>

        {/* Left Image Clipped (Concept) */}
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
          <img
            src="https://img.usecurling.com/p/1000/600?q=cyberpunk%20concept%20art%20sketch"
            alt="Concept Art"
            className="absolute inset-0 w-full h-full object-cover max-w-none"
            style={{ width: containerRef.current ? containerRef.current.clientWidth : '100%' }}
          />
          <div className="absolute top-4 left-4 z-10 font-mono text-xs font-bold text-[#ff3b3b] bg-[#050507]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#ff3b3b]/30 uppercase tracking-widest shadow-lg">
            CONCEPT
          </div>
        </div>

        {/* Divider Handle */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-[#ff3b3b] shadow-[0_0_15px_#ff3b3b] z-20 pointer-events-none"
          style={{ left: `${sliderPos}%` }}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-[#050507] border-2 border-[#ff3b3b] flex items-center justify-center text-[#ff3b3b] shadow-[0_0_20px_#ff3b3b]">
            <span className="text-xs font-mono font-black">◄ ►</span>
          </div>
        </div>
      </div>
      <p className="text-center font-mono text-xs text-[#9ca3af] mt-3 tracking-widest uppercase">
        Drag to compare
      </p>
    </div>
  )
}
