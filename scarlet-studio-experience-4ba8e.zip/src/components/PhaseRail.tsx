import type { PhaseInfo } from '@/types/studio'

interface PhaseRailProps {
  phases: PhaseInfo[]
  activePhase: string
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function PhaseRail({ phases, activePhase, playSound }: PhaseRailProps) {
  const scrollTo = (id: string) => {
    playSound('click')
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="hidden lg:flex fixed right-6 top-1/2 -translate-y-1/2 z-40 flex-col items-end gap-4 pointer-events-auto">
      {phases.map((phase) => {
        const isActive = activePhase === phase.id
        return (
          <button
            key={phase.id}
            onClick={() => scrollTo(phase.id)}
            onMouseEnter={() => playSound('hover')}
            className="group relative flex items-center gap-3 py-1 cursor-pointer focus:outline-none"
            aria-label={`Scroll to ${phase.label}`}
          >
            {/* Hover Tooltip Label */}
            <span
              className={`font-mono text-[10px] tracking-widest uppercase transition-all duration-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 translate-x-2 ${
                isActive ? 'text-[#ff3b3b] font-bold' : 'text-[#9ca3af]'
              }`}
            >
              {phase.number} {phase.label}
            </span>

            {/* Indicator Dot */}
            <div
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                isActive
                  ? 'bg-[#ff3b3b] shadow-[0_0_12px_#ff3b3b] scale-125'
                  : 'bg-white/20 hover:bg-white/50 scale-100'
              }`}
            />
          </button>
        )
      })}
    </div>
  )
}
