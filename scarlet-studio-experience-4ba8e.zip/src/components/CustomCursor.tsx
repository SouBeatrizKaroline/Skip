import { useEffect, useState } from 'react'

export function CustomCursor() {
  const [pos, setPos] = useState({ x: -100, y: -100 })
  const [ringPos, setRingPos] = useState({ x: -100, y: -100 })
  const [isHovered, setIsHovered] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      return // Hide on touch devices
    }
    setIsVisible(true)

    const handleMouseMove = (e: MouseEvent) => {
      setPos({ x: e.clientX, y: e.clientY })

      const target = e.target as HTMLElement
      if (
        target.tagName === 'A' ||
        target.tagName === 'BUTTON' ||
        target.closest('a') ||
        target.closest('button') ||
        target.closest('input') ||
        target.closest('textarea') ||
        target.hasAttribute('data-cursor-hover')
      ) {
        setIsHovered(true)
      } else {
        setIsHovered(false)
      }
    }

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  useEffect(() => {
    if (!isVisible) return
    let animId: number

    const follow = () => {
      setRingPos((prev) => ({
        x: prev.x + (pos.x - prev.x) * 0.2,
        y: prev.y + (pos.y - prev.y) * 0.2,
      }))
      animId = requestAnimationFrame(follow)
    }

    animId = requestAnimationFrame(follow)
    return () => cancelAnimationFrame(animId)
  }, [pos, isVisible])

  if (!isVisible) return null

  return (
    <>
      {/* Dot */}
      <div
        className="fixed top-0 left-0 w-2 h-2 bg-[#ff3b3b] rounded-full pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2 shadow-[0_0_10px_#ff3b3b]"
        style={{ transform: `translate3d(${pos.x}px, ${pos.y}px, 0)` }}
      />
      {/* Trailing Ring */}
      <div
        className={`fixed top-0 left-0 rounded-full border border-[#ff3b3b]/50 pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2 transition-all duration-150 ease-out ${
          isHovered ? 'w-10 h-10 bg-[#ff3b3b]/10 border-[#ff3b3b]' : 'w-6 h-6'
        }`}
        style={{ transform: `translate3d(${ringPos.x}px, ${ringPos.y}px, 0)` }}
      />
    </>
  )
}
