import { useState, useEffect } from 'react'

interface BootOverlayProps {
  onComplete: () => void
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

const MESSAGES = ['Initializing Universe…', 'Loading Assets…', 'Entering Experience…']

export function BootOverlay({ onComplete, playSound }: BootOverlayProps) {
  const [progress, setProgress] = useState(0)
  const [msgIndex, setMsgIndex] = useState(0)
  const [isDone, setIsDone] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        const next = prev + Math.floor(Math.random() * 8) + 3
        return next > 100 ? 100 : next
      })
    }, 80)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (progress < 40) setMsgIndex(0)
    else if (progress < 80) setMsgIndex(1)
    else setMsgIndex(2)

    if (progress === 100) {
      playSound('whoosh')
      const timer = setTimeout(() => {
        setIsDone(true)
        setTimeout(onComplete, 600)
      }, 300)
      return () => clearTimeout(timer)
    }
  }, [progress, onComplete, playSound])

  const handleSkip = () => {
    playSound('click')
    setProgress(100)
    setIsDone(true)
    setTimeout(onComplete, 300)
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050507] transition-all duration-700 ${
        isDone ? '-translate-y-full opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="relative flex flex-col items-center text-center px-4 max-w-md w-full">
        {/* Logo Mark */}
        <div className="mb-8 relative flex items-center justify-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#ff3b3b] via-[#ff6b6b] to-[#b91c1c] p-0.5 animate-pulse shadow-[0_0_30px_rgba(255,59,59,0.5)]">
            <div className="w-full h-full bg-[#050507] rounded-[14px] flex items-center justify-center">
              <span className="font-display font-black text-2xl text-[#ff3b3b]">S</span>
            </div>
          </div>
        </div>

        {/* Studio Name */}
        <h1 className="font-display font-extrabold text-xl tracking-widest text-white mb-2">
          SCARLET STUDIO
        </h1>

        {/* Status Message */}
        <div className="h-6 font-mono text-xs text-[#9ca3af] flex items-center gap-1 mb-6">
          <span>{MESSAGES[msgIndex]}</span>
          <span className="animate-pulse text-[#ff3b3b]">█</span>
        </div>

        {/* Progress Bar Container */}
        <div className="w-full bg-[#0b0b0e] rounded-full h-1.5 p-0.5 border border-white/10 relative overflow-hidden mb-3">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#b91c1c] via-[#ff3b3b] to-[#ff6b6b] shadow-[0_0_15px_rgba(255,59,59,0.8)] transition-all duration-150 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Percentage Counter */}
        <div className="font-mono text-xs font-semibold text-[#ff3b3b] mb-8">{progress}%</div>

        {/* Skip Hint */}
        <button
          onClick={handleSkip}
          className="font-mono text-[10px] text-[#52525b] hover:text-[#9ca3af] tracking-widest uppercase transition-colors"
        >
          [ CLICK TO SKIP ]
        </button>
      </div>
    </div>
  )
}
