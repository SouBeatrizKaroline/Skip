import { ArrowUp, Twitter, Linkedin, Github, Instagram, Youtube } from 'lucide-react'

interface FooterProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function Footer({ playSound }: FooterProps) {
  const scrollToTop = () => {
    playSound('click')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="relative bg-[#050507] border-t border-white/10 pt-16 pb-12 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Logo & Manifesto */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#ff3b3b] to-[#b91c1c] p-0.5">
                <div className="w-full h-full bg-[#050507] rounded-[6px] flex items-center justify-center">
                  <span className="font-display font-extrabold text-sm text-[#ff3b3b]">S</span>
                </div>
              </div>
              <span className="font-display font-extrabold text-lg text-white tracking-wider">
                SCARLET STUDIO
              </span>
            </div>
            <p className="font-sans text-[#9ca3af] text-sm max-w-sm italic">
              "We don't follow trends. We create worlds."
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-mono text-xs text-[#ff3b3b] uppercase tracking-widest mb-4 font-semibold">
              Studio
            </h4>
            <ul className="space-y-2 font-sans text-sm text-[#9ca3af]">
              <li>
                <a href="#origin" className="hover:text-white transition-colors">
                  Origin
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#worlds" className="hover:text-white transition-colors">
                  Worlds
                </a>
              </li>
              <li>
                <a href="#crew" className="hover:text-white transition-colors">
                  Crew
                </a>
              </li>
            </ul>
          </div>

          {/* Socials */}
          <div>
            <h4 className="font-mono text-xs text-[#ff3b3b] uppercase tracking-widest mb-4 font-semibold">
              Connect
            </h4>
            <div className="flex gap-3">
              {[
                { icon: Twitter, href: 'https://twitter.com' },
                { icon: Linkedin, href: 'https://linkedin.com' },
                { icon: Github, href: 'https://github.com' },
                { icon: Instagram, href: 'https://instagram.com' },
                { icon: Youtube, href: 'https://youtube.com' },
              ].map((s, i) => (
                <a
                  key={i}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  onMouseEnter={() => playSound('hover')}
                  className="p-2.5 rounded-lg bg-white/5 hover:bg-[#ff3b3b]/20 border border-white/10 hover:border-[#ff3b3b]/50 text-[#9ca3af] hover:text-[#ff3b3b] transition-all"
                >
                  <s.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs text-[#52525b]">
          <div>CNPJ: 00.000.000/0001-00</div>
          <div>
            © {new Date().getFullYear()} Scarlet Studio. Designed & built by Scarlet Studio.
          </div>
          <div className="text-[10px] text-[#52525b]/60 hover:text-[#ff3b3b] transition-colors cursor-default">
            ↑↑↓↓←→←→ BA
          </div>
        </div>
      </div>

      {/* Back to Top */}
      <button
        onClick={scrollToTop}
        onMouseEnter={() => playSound('hover')}
        className="fixed bottom-6 right-6 z-30 p-3 rounded-xl bg-[#0b0b0e] border border-white/15 text-white hover:text-[#ff3b3b] hover:border-[#ff3b3b] hover:shadow-[0_0_20px_rgba(255,59,59,0.4)] transition-all"
        aria-label="Back to top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  )
}
