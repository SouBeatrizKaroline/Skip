import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { BootOverlay } from '@/components/BootOverlay'
import { ParticleCanvas } from '@/components/ParticleCanvas'
import { CustomCursor } from '@/components/CustomCursor'
import { PhaseRail } from '@/components/PhaseRail'
import { NavigationBar } from '@/components/NavigationBar'
import { Footer } from '@/components/Footer'
import { EasterEggModal } from '@/components/EasterEggModal'
import { useSound } from '@/hooks/use-sound'
import { useScrollObserver } from '@/hooks/use-scroll-observer'
import { useKonami } from '@/hooks/use-konami'
import type { PhaseInfo } from '@/types/studio'

const PHASES: PhaseInfo[] = [
  { id: 'hero', number: '00', label: 'HERO' },
  { id: 'origin', number: '01', label: 'ORIGIN' },
  { id: 'services', number: '02', label: 'ARSENAL' },
  { id: 'why-scarlet', number: '03', label: 'WHY SCARLET' },
  { id: 'worlds', number: '04', label: 'WORLDS' },
  { id: 'showcase-3d', number: '05', label: '3D SHOWCASE' },
  { id: 'art-gallery', number: '06', label: 'ART GALLERY' },
  { id: 'voices', number: '07', label: 'VOICES' },
  { id: 'lab', number: '08', label: 'LAB' },
  { id: 'process', number: '09', label: 'PROCESS' },
  { id: 'evolution', number: '10', label: 'EVOLUTION' },
  { id: 'crew', number: '11', label: 'CREW' },
  { id: 'metrics', number: '12', label: 'METRICS' },
  { id: 'transmission', number: '13', label: 'TRANSMISSION' },
  { id: 'contact', number: '14', label: 'CONTACT' },
]

export default function Layout() {
  const [booted, setBooted] = useState(false)
  const [easterEggOpen, setEasterEggOpen] = useState(false)

  const { enabled: soundEnabled, toggleSound, playSound } = useSound()
  const { scrollProgress, activePhase } = useScrollObserver(PHASES.map((p) => p.id))

  useKonami(() => {
    playSound('whoosh')
    setEasterEggOpen(true)
    console.log(
      '%cSCARLET STUDIO // Secret Universe Unlocked! 🎮',
      'color: #ff3b3b; font-size: 16px; font-weight: bold;',
    )
  })

  return (
    <div className="min-h-screen bg-[#050507] text-[#f5f5f7] font-sans selection:bg-[#ff3b3b] selection:text-white relative overflow-x-hidden">
      {!booted && <BootOverlay onComplete={() => setBooted(true)} playSound={playSound} />}
      <ParticleCanvas />
      <CustomCursor />

      <div className="fixed top-0 left-0 right-0 h-[3px] bg-[#050507] z-50">
        <div
          className="h-full bg-gradient-to-r from-[#b91c1c] via-[#ff3b3b] to-[#ff6b6b] shadow-[0_0_10px_#ff3b3b] transition-all duration-75"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <NavigationBar
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
        playSound={playSound}
        activePhase={activePhase}
      />

      <PhaseRail phases={PHASES} activePhase={activePhase} playSound={playSound} />

      <main className="relative z-10">
        <Outlet context={{ playSound }} />
      </main>

      <Footer playSound={playSound} />

      {easterEggOpen && <EasterEggModal onClose={() => setEasterEggOpen(false)} />}
    </div>
  )
}
