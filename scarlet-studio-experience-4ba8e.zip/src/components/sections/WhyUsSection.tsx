interface WhyUsSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

const WHY_ITEMS = [
  { emoji: '🎮', title: 'We think like players' },
  { emoji: '🚀', title: 'Indie speed, pro quality' },
  { emoji: '🎨', title: 'Art + Code synergy' },
  { emoji: '🤝', title: 'Collaborative workflow' },
  { emoji: '💡', title: 'Creative solutions' },
]

export function WhyUsSection({ playSound }: WhyUsSectionProps) {
  return (
    <section id="why-scarlet" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-3 font-semibold">
        PHASE 03 // WHY SCARLET
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-12">
        Why Scarlet Studio
      </h2>

      <div className="space-y-4">
        {WHY_ITEMS.map((item, idx) => (
          <div
            key={idx}
            onMouseEnter={() => playSound('hover')}
            className="group relative bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b] rounded-xl p-6 transition-all duration-300 flex items-center gap-6 hover:shadow-[0_0_20px_rgba(255,59,59,0.2)]"
          >
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ff3b3b] opacity-0 group-hover:opacity-100 transition-opacity rounded-l-xl" />
            <span className="text-3xl group-hover:scale-125 transition-transform">
              {item.emoji}
            </span>
            <span className="font-display font-bold text-xl sm:text-2xl text-white group-hover:text-[#ff3b3b] transition-colors">
              {item.title}
            </span>
          </div>
        ))}
      </div>
    </section>
  )
}
