import { DragCarousel } from '@/components/DragCarousel'
import { AudioPlayer } from '@/components/AudioPlayer'
import { AUDIO_TRACKS } from '@/data/audio'

export function AudioSection() {
  return (
    <section id="voices" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 07 // FREQUENCY
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">
        VOICES & SOUND
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-4">
        Voices &amp; Sound
      </h2>
      <p className="font-sans text-sm text-[#9ca3af] mb-10 max-w-xl">
        Original soundtracks, voice acting, and sound design that bring our universes to life.
      </p>

      <DragCarousel>
        {AUDIO_TRACKS.map((track) => (
          <div key={track.id} className="flex-shrink-0 w-[85%] sm:w-[340px] snap-center">
            <AudioPlayer
              title={track.title}
              category={track.category}
              description={track.description}
              duration={track.duration}
            />
          </div>
        ))}
      </DragCarousel>
    </section>
  )
}
