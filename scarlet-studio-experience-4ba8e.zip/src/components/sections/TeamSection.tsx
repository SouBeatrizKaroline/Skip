import { Twitter, Linkedin, Github, Instagram, Wrench } from 'lucide-react'
import type { TeamMember } from '@/types/studio'
import { getToolsForRole } from '@/data/team-tools'

interface TeamSectionProps {
  team: TeamMember[]
  loading: boolean
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function TeamSection({ team, loading, playSound }: TeamSectionProps) {
  return (
    <section id="crew" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 11 // CREW
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">TEAM</div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-12">
        The Crew
      </h2>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-80 rounded-2xl bg-white/5 animate-pulse border border-white/10"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member) => {
            const tools = getToolsForRole(member.role)
            return (
              <div
                key={member.id}
                onMouseEnter={() => playSound('hover')}
                className="group relative bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b] rounded-2xl overflow-hidden p-6 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(255,59,59,0.2)] flex flex-col items-center text-center"
              >
                <div className="relative w-28 h-28 rounded-2xl overflow-hidden mb-4 border border-white/10 group-hover:border-[#ff3b3b] transition-colors">
                  <img
                    src={member.avatar_url}
                    alt={member.name}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-500"
                  />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-1">{member.name}</h3>
                <p className="font-mono text-xs text-[#ff3b3b] uppercase tracking-wider mb-3 font-semibold">
                  {member.role}
                </p>
                <p className="font-sans text-xs text-[#9ca3af] leading-relaxed mb-4">
                  {member.bio}
                </p>

                <div className="flex flex-wrap gap-1.5 justify-center mb-3">
                  {member.skills?.map((skill, i) => (
                    <span
                      key={i}
                      className="font-mono text-[10px] bg-white/5 border border-white/10 px-2 py-0.5 rounded text-[#f5f5f7]"
                    >
                      {skill}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Wrench className="w-3 h-3 text-[#ff3b3b]" />
                  <div className="flex flex-wrap gap-1 justify-center">
                    {tools.map((tool, i) => (
                      <span
                        key={i}
                        className="font-mono text-[10px] bg-[#ff3b3b]/10 border border-[#ff3b3b]/20 px-2 py-0.5 rounded text-[#ff6b6b]"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 pt-2 border-t border-white/5 w-full justify-center">
                  {member.socials?.twitter && (
                    <a
                      href={member.socials.twitter}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 text-[#9ca3af] hover:text-[#ff3b3b] transition-colors"
                    >
                      <Twitter className="w-4 h-4" />
                    </a>
                  )}
                  {member.socials?.linkedin && (
                    <a
                      href={member.socials.linkedin}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 text-[#9ca3af] hover:text-[#ff3b3b] transition-colors"
                    >
                      <Linkedin className="w-4 h-4" />
                    </a>
                  )}
                  {member.socials?.github && (
                    <a
                      href={member.socials.github}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 text-[#9ca3af] hover:text-[#ff3b3b] transition-colors"
                    >
                      <Github className="w-4 h-4" />
                    </a>
                  )}
                  {member.socials?.instagram && (
                    <a
                      href={member.socials.instagram}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 text-[#9ca3af] hover:text-[#ff3b3b] transition-colors"
                    >
                      <Instagram className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}
