import { BeforeAfterSlider } from '@/components/BeforeAfterSlider'

export function TransformationsSection() {
  return (
    <section id="evolution" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-3 font-semibold">
        PHASE 05 // EVOLUTION
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-12">
        From Concept → Game-Ready
      </h2>

      <BeforeAfterSlider />
    </section>
  )
}
