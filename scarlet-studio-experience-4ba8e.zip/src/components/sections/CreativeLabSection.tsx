import { RevealOnScroll } from '@/components/RevealOnScroll'
import { LAB_EXPERIMENTS } from '@/data/lab'
import { cn } from '@/lib/utils'

interface CreativeLabSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

const TAG_STYLES: Record<string, string> = {
  WIP: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  Prototype: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
  Test: 'bg-green-500/15 text-green-400 border-green-500/30',
}

export function CreativeLabSection({ playSound }: CreativeLabSectionProps) {
  return (
    <section id="lab" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 08 // LABORATORY
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">
        CREATIVE LAB
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-4">
        Creative Lab
      </h2>
      <p className="font-sans text-sm text-[#9ca3af] mb-10 max-w-xl">
        Prototypes, experiments, and wild ideas. This is where we push boundaries and explore the
        unknown.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {LAB_EXPERIMENTS.map((exp, idx) => (
          <RevealOnScroll key={exp.id} delay={idx * 70}>
            <div
              onMouseEnter={() => playSound('hover')}
              className="group relative bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b]/40 rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_25px_rgba(255,59,59,0.15)]"
            >
              <div className="relative aspect-video w-full overflow-hidden">
                <img
                  src={exp.image_url}
                  alt={exp.title}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent" />
                <span
                  className={cn(
                    'absolute top-3 right-3 font-mono text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border backdrop-blur-md',
                    TAG_STYLES[exp.tag],
                  )}
                >
                  {exp.tag}
                </span>
              </div>
              <div className="p-4">
                <h3 className="font-display font-bold text-sm text-white group-hover:text-[#ff3b3b] transition-colors mb-1">
                  {exp.title}
                </h3>
                <p className="font-sans text-xs text-[#9ca3af] leading-relaxed">
                  {exp.description}
                </p>
              </div>
            </div>
          </RevealOnScroll>
        ))}
      </div>
    </section>
  )
}
