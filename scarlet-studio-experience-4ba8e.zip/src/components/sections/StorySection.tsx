export function StorySection() {
  return (
    <section id="origin" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-3 font-semibold">
        PHASE 01 // ORIGIN
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Sticky Text */}
        <div className="space-y-6">
          <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white leading-tight">
            Every Universe Starts With an Idea
          </h2>
          <p className="font-sans text-lg text-[#9ca3af] leading-relaxed">
            From a simple concept to a living world — we design experiences that players feel,
            explore, and remember.
          </p>
          <p className="font-sans text-lg text-[#9ca3af] leading-relaxed">
            We combine creativity, technology, and storytelling to build digital universes.
          </p>
        </div>

        {/* Right Atmospheric Glass Shard Visual */}
        <div className="relative group">
          <div className="w-full aspect-square max-w-md mx-auto rounded-3xl bg-gradient-to-tr from-white/5 to-white/10 border border-white/15 p-8 backdrop-blur-xl shadow-[0_0_50px_rgba(255,59,59,0.15)] group-hover:shadow-[0_0_80px_rgba(255,59,59,0.3)] transition-all duration-500 relative overflow-hidden flex flex-col justify-between">
            <div className="absolute inset-0 bg-gradient-to-br from-[#ff3b3b]/20 via-transparent to-[#b91c1c]/30 pointer-events-none" />

            <div className="relative z-10 flex justify-between items-start">
              <span className="font-mono text-xs text-[#ff3b3b]">SYSTEM // CORE</span>
              <div className="w-2 h-2 rounded-full bg-[#ff3b3b] animate-ping" />
            </div>

            <div className="relative z-10 my-auto text-center space-y-4">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-[#ff3b3b]/10 border border-[#ff3b3b]/30 flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(255,59,59,0.4)]">
                🌌
              </div>
              <p className="font-mono text-sm text-white tracking-widest uppercase font-bold">
                SCARLET ENGINE
              </p>
            </div>

            <div className="relative z-10 flex justify-between font-mono text-[10px] text-[#52525b]">
              <span>VER 3.0</span>
              <span>ACTIVE</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
