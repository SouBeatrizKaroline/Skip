import { ChevronDown } from 'lucide-react'

interface HeroSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
  onExplore: () => void
  onStart: () => void
}

export function HeroSection({ playSound, onExplore, onStart }: HeroSectionProps) {
  return (
    <section
      id="hero"
      className="relative min-h-[100svh] flex flex-col items-center justify-center pt-20 pb-16 px-5 overflow-hidden"
    >
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#ff3b3b]/15 rounded-full blur-[140px] pointer-events-none animate-fade-in" />
      <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] bg-[#b91c1c]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 max-w-4xl text-center space-y-6">
        <div
          className="inline-block font-mono text-xs sm:text-sm font-bold text-[#ff3b3b] tracking-[0.25em] uppercase px-4 py-1.5 rounded-full bg-[#ff3b3b]/10 border border-[#ff3b3b]/30 shadow-[0_0_20px_rgba(255,59,59,0.2)] animate-fade-in-up"
          style={{ animationDelay: '100ms', animationFillMode: 'backwards' }}
        >
          SCARLET STUDIO // CREATORS OF UNIVERSES
        </div>

        <h1
          className="font-display font-black text-4xl sm:text-6xl md:text-7xl uppercase text-white leading-[1.05] tracking-tight animate-fade-in-up"
          style={{ animationDelay: '300ms', animationFillMode: 'backwards' }}
        >
          We Don't Just Build Games.{' '}
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#ff6b6b] via-[#ff3b3b] to-[#b91c1c] drop-shadow-[0_0_35px_rgba(255,59,59,0.6)]">
            We Create Universes.
          </span>
        </h1>

        <p
          className="font-sans text-base sm:text-xl text-[#9ca3af] max-w-2xl mx-auto leading-relaxed animate-fade-in-up"
          style={{ animationDelay: '500ms', animationFillMode: 'backwards' }}
        >
          We transform ideas into immersive worlds through game development, art, and cutting-edge
          digital experiences.
        </p>

        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 animate-fade-in-up"
          style={{ animationDelay: '700ms', animationFillMode: 'backwards' }}
        >
          <button
            onClick={() => {
              playSound('click')
              onStart()
            }}
            onMouseEnter={() => playSound('hover')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl font-sans font-semibold text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] hover:shadow-[0_0_30px_rgba(255,59,59,0.6)] hover:scale-105 active:scale-95 transition-all duration-200 border border-[#ff6b6b]/40 shadow-lg"
          >
            🚀 Start a Project
          </button>
          <button
            onClick={() => {
              playSound('click')
              onExplore()
            }}
            onMouseEnter={() => playSound('hover')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl font-sans font-semibold text-white bg-white/5 hover:bg-white/10 border border-white/15 hover:border-white/30 transition-all duration-200 hover:scale-105 active:scale-95 backdrop-blur-md"
          >
            🎮 Explore Our Worlds
          </button>
        </div>
      </div>

      <button
        onClick={() => {
          playSound('click')
          onExplore()
        }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50 hover:text-[#ff3b3b] transition-colors animate-bounce"
        style={{ animationDelay: '1200ms', animationFillMode: 'backwards' }}
        aria-label="Scroll down"
      >
        <span className="font-mono text-[10px] tracking-[0.3em] uppercase">Scroll to Explore</span>
        <ChevronDown className="w-6 h-6" />
      </button>
    </section>
  )
}
