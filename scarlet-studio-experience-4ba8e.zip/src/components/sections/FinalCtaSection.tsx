interface FinalCtaSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
  onStart: () => void
}

export function FinalCtaSection({ playSound, onStart }: FinalCtaSectionProps) {
  return (
    <section id="transmission" className="py-28 px-5 relative overflow-hidden text-center">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[#ff3b3b]/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/4 left-1/3 w-[200px] h-[200px] bg-[#b91c1c]/10 rounded-full blur-[80px] pointer-events-none" />

      <div className="relative z-10 max-w-3xl mx-auto space-y-6">
        <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase font-semibold">
          PHASE 13 // TRANSMISSION
        </div>

        <h2 className="font-display font-black text-3xl sm:text-5xl md:text-6xl uppercase text-white leading-tight">
          Let's Build Something{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff6b6b] via-[#ff3b3b] to-[#b91c1c] animate-glow-pulse">
            Legendary
          </span>
        </h2>

        <p className="font-sans text-base sm:text-xl text-[#9ca3af]">
          We turn your vision into immersive experiences that players will never forget.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={() => {
              playSound('click')
              onStart()
            }}
            onMouseEnter={() => playSound('hover')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl font-sans font-semibold text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] hover:shadow-[0_0_40px_rgba(255,59,59,0.7)] hover:scale-105 active:scale-95 transition-all shadow-lg"
          >
            Start a Project
          </button>
          <button
            onClick={() => {
              playSound('click')
              onStart()
            }}
            onMouseEnter={() => playSound('hover')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl font-sans font-semibold text-white bg-white/5 hover:bg-white/10 border border-white/15 hover:border-white/30 transition-all backdrop-blur-md"
          >
            Contact Us
          </button>
        </div>
      </div>
    </section>
  )
}
