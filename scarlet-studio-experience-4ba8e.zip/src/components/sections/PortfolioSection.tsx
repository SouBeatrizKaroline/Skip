import { Eye } from 'lucide-react'
import { DragCarousel } from '@/components/DragCarousel'
import { TiltCard } from '@/components/TiltCard'
import type { PortfolioProject } from '@/types/studio'

interface PortfolioSectionProps {
  projects: PortfolioProject[]
  loading: boolean
  onSelectProject: (p: PortfolioProject) => void
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function PortfolioSection({
  projects,
  loading,
  onSelectProject,
  playSound,
}: PortfolioSectionProps) {
  return (
    <section id="worlds" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 04 // WORLDS
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">
        PORTFOLIO
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-4">
        Our Worlds
      </h2>
      <p className="font-sans text-sm text-[#9ca3af] mb-10 max-w-xl">
        Drag to explore our portfolio. Each world has a story — click to dive deeper.
      </p>

      {loading ? (
        <div className="flex gap-6 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="flex-shrink-0 w-[340px] h-96 rounded-2xl bg-white/5 animate-pulse border border-white/10"
            />
          ))}
        </div>
      ) : (
        <DragCarousel>
          {projects.map((proj) => (
            <div key={proj.id} className="flex-shrink-0 w-[85%] sm:w-[380px] snap-center">
              <TiltCard maxTilt={10}>
                <div
                  onClick={() => {
                    playSound('click')
                    onSelectProject(proj)
                  }}
                  onMouseEnter={() => playSound('hover')}
                  className="group relative rounded-2xl overflow-hidden bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b] transition-all duration-300 cursor-pointer shadow-lg hover:shadow-[0_0_40px_rgba(255,59,59,0.3)] h-full"
                >
                  <div className="relative aspect-video w-full overflow-hidden">
                    <img
                      src={proj.cover_url}
                      alt={proj.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/30 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="font-mono text-xs font-semibold text-[#ff3b3b] bg-[#050507]/80 backdrop-blur-md border border-[#ff3b3b]/30 px-3 py-1 rounded-full uppercase tracking-wider">
                        {proj.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-display font-bold text-2xl text-white mb-2 group-hover:text-[#ff3b3b] transition-colors">
                      {proj.title}
                    </h3>
                    <p className="font-sans text-sm text-[#9ca3af] line-clamp-2 mb-4">
                      {proj.description}
                    </p>
                    <div className="flex items-center gap-2 font-mono text-xs text-[#ff3b3b] font-semibold group-hover:translate-x-1 transition-transform">
                      <Eye className="w-4 h-4" />
                      <span>View Case Study</span>
                    </div>
                  </div>
                </div>
              </TiltCard>
            </div>
          ))}
        </DragCarousel>
      )}
    </section>
  )
}
