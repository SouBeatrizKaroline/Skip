import { RevealOnScroll } from '@/components/RevealOnScroll'
import { PROCESS_STEPS } from '@/data/process'

export function ProcessSection() {
  return (
    <section id="process" className="py-24 px-5 max-w-[900px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 09 // BLUEPRINT
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">PROCESS</div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-12">
        How We Build Universes
      </h2>

      <div className="relative">
        {/* Vertical connecting line */}
        <div className="absolute left-6 sm:left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#ff3b3b] via-[#ff3b3b]/40 to-transparent" />

        {PROCESS_STEPS.map((step, idx) => (
          <RevealOnScroll key={step.id} delay={idx * 120} className="mb-10 last:mb-0">
            <div className="relative flex items-start gap-6 pl-0">
              {/* Step number circle */}
              <div className="relative flex-shrink-0 z-10">
                <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-[#ff3b3b] to-[#b91c1c] flex items-center justify-center text-2xl sm:text-3xl shadow-[0_0_20px_rgba(255,59,59,0.4)] border border-[#ff6b6b]/30">
                  {step.icon}
                </div>
                <span className="absolute -top-2 -right-2 font-mono text-[9px] font-bold text-[#ff3b3b] bg-[#050507] border border-[#ff3b3b]/30 rounded-full w-5 h-5 flex items-center justify-center">
                  {step.step}
                </span>
              </div>

              {/* Content */}
              <div className="flex-1 pt-2 sm:pt-3">
                <h3 className="font-display font-bold text-xl sm:text-2xl text-white mb-2">
                  {step.title}
                </h3>
                <p className="font-sans text-sm text-[#9ca3af] leading-relaxed max-w-md">
                  {step.description}
                </p>
              </div>

              {/* Step label */}
              <div className="hidden sm:block pt-3">
                <span className="font-mono text-xs text-[#52525b] tracking-widest">
                  STEP {step.step.toString().padStart(2, '0')}
                </span>
              </div>
            </div>
          </RevealOnScroll>
        ))}
      </div>
    </section>
  )
}
