import { DragCarousel } from '@/components/DragCarousel'
import { TiltCard } from '@/components/TiltCard'
import { SHOWCASE_3D } from '@/data/showcase'

interface Showcase3DSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function Showcase3DSection({ playSound }: Showcase3DSectionProps) {
  return (
    <section id="showcase-3d" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 05 // DIMENSIONS
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">
        3D SHOWCASE
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-4">
        3D Showcase
      </h2>
      <p className="font-sans text-sm text-[#9ca3af] mb-10 max-w-xl">
        Characters, environments, and props crafted with precision. Hover to rotate and inspect.
      </p>

      <DragCarousel>
        {SHOWCASE_3D.map((item) => (
          <div key={item.id} className="flex-shrink-0 w-[85%] sm:w-[340px] snap-center">
            <TiltCard maxTilt={15} className="h-full">
              <div
                onMouseEnter={() => playSound('hover')}
                className="group relative bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b]/50 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_40px_rgba(255,59,59,0.2)]"
              >
                <div className="relative aspect-square w-full overflow-hidden bg-gradient-to-br from-[#1a0a0a] to-[#0b0b0e]">
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="font-mono text-xs font-semibold text-[#ff3b3b] bg-[#050507]/80 backdrop-blur-md border border-[#ff3b3b]/30 px-3 py-1 rounded-full uppercase tracking-wider">
                      {item.category}
                    </span>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                    <div className="w-16 h-16 rounded-full bg-[#ff3b3b]/20 border-2 border-[#ff3b3b] flex items-center justify-center backdrop-blur-sm shadow-[0_0_30px_rgba(255,59,59,0.5)]">
                      <span className="text-2xl">🔄</span>
                    </div>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-display font-bold text-lg text-white mb-1 group-hover:text-[#ff3b3b] transition-colors">
                    {item.title}
                  </h3>
                  <p className="font-sans text-xs text-[#9ca3af] leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </TiltCard>
          </div>
        ))}
      </DragCarousel>
    </section>
  )
}
