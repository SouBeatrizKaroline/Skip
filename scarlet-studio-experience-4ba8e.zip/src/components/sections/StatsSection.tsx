import { useScrollReveal } from '@/hooks/use-scroll-reveal'
import { useCountUp } from '@/hooks/use-count-up'

export function StatsSection() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>()
  const projects = useCountUp(50, 2000, isVisible)
  const clients = useCountUp(30, 2000, isVisible)
  const years = useCountUp(3, 1500, isVisible)
  const assets = useCountUp(500, 2500, isVisible)
  const audios = useCountUp(120, 2000, isVisible)

  const stats = [
    { value: `${projects}+`, label: 'Projects' },
    { value: `${clients}+`, label: 'Clients' },
    { value: `${years}+`, label: 'Years' },
    { value: `${assets}+`, label: 'Assets Created' },
    { value: `${audios}+`, label: 'Audios Produced' },
  ]

  return (
    <section
      id="metrics"
      className="py-20 bg-[#0b0b0e]/80 border-y border-white/10 relative overflow-hidden"
    >
      <div ref={ref} className="max-w-[1200px] mx-auto px-5">
        <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-8 text-center font-semibold">
          PHASE 12 // METRICS
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 text-center">
          {stats.map((stat, idx) => (
            <div key={idx} className="space-y-2">
              <div className="font-display font-black text-3xl sm:text-5xl text-white shadow-[0_0_30px_rgba(255,59,59,0.2)]">
                {stat.value}
              </div>
              <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 flex justify-center">
          <div className="inline-flex items-center gap-2 font-display font-black text-2xl sm:text-3xl text-[#ff3b3b] drop-shadow-[0_0_20px_#ff3b3b]">
            <span>24/7</span>
            <span className="w-3 h-3 rounded-full bg-[#ff3b3b] animate-ping" />
            <span className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest">
              Support
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
