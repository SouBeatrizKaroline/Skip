import { useState } from 'react'
import { CheckCircle2, Send } from 'lucide-react'
import { submitContact } from '@/services/contacts'

interface ContactSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function ContactSection({ playSound }: ContactSectionProps) {
  const [formData, setFormData] = useState({ name: '', email: '', project_idea: '' })
  const [errors, setErrors] = useState<{ name?: string; email?: string; project_idea?: string }>({})
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const validate = () => {
    const errs: typeof errors = {}
    if (!formData.name.trim()) errs.name = 'Name is required.'
    if (!formData.email.trim()) errs.email = 'Email is required.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      errs.email = 'Valid email address is required.'
    if (!formData.project_idea.trim()) errs.project_idea = 'Project idea is required.'
    else if (formData.project_idea.trim().length < 20)
      errs.project_idea = 'Please describe your idea with at least 20 characters.'
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    playSound('click')
    const errs = validate()
    if (Object.keys(errs).length > 0) {
      setErrors(errs)
      return
    }

    setErrors({})
    setSubmitting(true)

    try {
      await submitContact(formData)
      setSubmitted(true)
      setFormData({ name: '', email: '', project_idea: '' })
    } catch {
      setErrors({ project_idea: 'Failed to submit. Please try again.' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section id="contact" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* Pitch Copy */}
        <div className="space-y-6">
          <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase font-semibold">
            TRANSMISSION // DIRECT
          </div>

          <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
            Tell us about your universe.
          </h2>

          <p className="font-sans text-lg text-[#9ca3af] leading-relaxed">
            Have a game concept, 3D art need, or digital platform in mind? Reach out and let's craft
            something unforgettable together.
          </p>

          <div className="pt-4 space-y-2 font-mono text-sm">
            <div className="text-[#52525b]">DIRECT FREQUENCY:</div>
            <a
              href="mailto:contact@scarletstudio.games"
              className="text-[#ff3b3b] hover:underline font-bold text-lg"
            >
              contact@scarletstudio.games
            </a>
          </div>
        </div>

        {/* Glass Form Card */}
        <div className="bg-[#0b0b0e] border border-white/15 rounded-2xl p-8 backdrop-blur-xl shadow-[0_0_40px_rgba(0,0,0,0.8)] relative">
          {submitted ? (
            <div className="text-center py-12 space-y-4 animate-scale-in">
              <CheckCircle2 className="w-16 h-16 text-[#10b981] mx-auto animate-bounce" />
              <h3 className="font-display font-bold text-2xl text-white">Transmission received.</h3>
              <p className="font-sans text-sm text-[#9ca3af]">We'll get back to you within 48h.</p>
              <button
                onClick={() => setSubmitted(false)}
                className="mt-4 font-mono text-xs text-[#ff3b3b] underline uppercase tracking-wider"
              >
                Send another
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block font-mono text-xs text-[#9ca3af] uppercase tracking-wider mb-2 font-semibold">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your Name / Studio"
                  className="w-full bg-white/5 border border-white/10 focus:border-[#ff3b3b] focus:ring-1 focus:ring-[#ff3b3b] rounded-xl px-4 py-3 text-white text-sm outline-none transition-all placeholder:text-[#52525b]"
                />
                {errors.name && (
                  <p className="font-mono text-xs text-[#f43f5e] mt-1">{errors.name}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <label className="block font-mono text-xs text-[#9ca3af] uppercase tracking-wider mb-2 font-semibold">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your@email.com"
                  className="w-full bg-white/5 border border-white/10 focus:border-[#ff3b3b] focus:ring-1 focus:ring-[#ff3b3b] rounded-xl px-4 py-3 text-white text-sm outline-none transition-all placeholder:text-[#52525b]"
                />
                {errors.email && (
                  <p className="font-mono text-xs text-[#f43f5e] mt-1">{errors.email}</p>
                )}
              </div>

              {/* Project Idea */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="font-mono text-xs text-[#9ca3af] uppercase tracking-wider font-semibold">
                    Project Idea
                  </label>
                  <span className="font-mono text-[10px] text-[#52525b]">
                    {formData.project_idea.length} chars
                  </span>
                </div>
                <textarea
                  rows={4}
                  value={formData.project_idea}
                  onChange={(e) => setFormData({ ...formData, project_idea: e.target.value })}
                  placeholder="Describe your game concept, mechanics, artistic vision, or platform..."
                  className="w-full bg-white/5 border border-white/10 focus:border-[#ff3b3b] focus:ring-1 focus:ring-[#ff3b3b] rounded-xl px-4 py-3 text-white text-sm outline-none transition-all placeholder:text-[#52525b] resize-none"
                />
                {errors.project_idea && (
                  <p className="font-mono text-xs text-[#f43f5e] mt-1">{errors.project_idea}</p>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitting}
                onMouseEnter={() => playSound('hover')}
                className="w-full py-4 rounded-xl font-sans font-semibold text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] hover:shadow-[0_0_30px_rgba(255,59,59,0.5)] transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
              >
                {submitting ? (
                  <span className="font-mono text-xs animate-pulse">TRANSMITTING…</span>
                ) : (
                  <>
                    <span>Launch Transmission</span>
                    <Send className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}
