import { useState } from 'react'
import { ZoomIn } from 'lucide-react'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { RevealOnScroll } from '@/components/RevealOnScroll'
import { ART_2D } from '@/data/art2d'
import type { Art2DItem } from '@/types/studio'
import { cn } from '@/lib/utils'

interface Art2DSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

const CATEGORIES = ['All', 'Concept Art', 'UI/UX', 'Illustration'] as const

export function Art2DSection({ playSound }: Art2DSectionProps) {
  const [filter, setFilter] = useState<string>('All')
  const [lightbox, setLightbox] = useState<Art2DItem | null>(null)

  const filtered = filter === 'All' ? ART_2D : ART_2D.filter((a) => a.category === filter)

  return (
    <section id="art-gallery" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 06 // CANVAS
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">2D ART</div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-8">
        Art Gallery
      </h2>

      <div className="flex flex-wrap gap-2 mb-10">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              playSound('click')
              setFilter(cat)
            }}
            onMouseEnter={() => playSound('hover')}
            className={cn(
              'px-4 py-2 rounded-full font-mono text-xs uppercase tracking-wider transition-all duration-300 border',
              filter === cat
                ? 'bg-[#ff3b3b] text-white border-[#ff3b3b] shadow-[0_0_15px_rgba(255,59,59,0.4)]'
                : 'bg-white/5 text-[#9ca3af] border-white/10 hover:border-[#ff3b3b]/50 hover:text-white',
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((item, idx) => (
          <RevealOnScroll key={item.id} delay={idx * 80}>
            <div
              onClick={() => {
                playSound('click')
                setLightbox(item)
              }}
              onMouseEnter={() => playSound('hover')}
              className="group relative rounded-2xl overflow-hidden bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b] transition-all duration-300 hover:-translate-y-2 cursor-pointer hover:shadow-[0_0_30px_rgba(255,59,59,0.25)]"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden">
                <img
                  src={item.image_url}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="font-mono text-[10px] font-semibold text-[#ff3b3b] bg-[#050507]/80 backdrop-blur-md border border-[#ff3b3b]/30 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    {item.category}
                  </span>
                </div>
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#050507]/80 backdrop-blur-md border border-white/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ZoomIn className="w-4 h-4 text-white" />
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-display font-bold text-sm text-white group-hover:text-[#ff3b3b] transition-colors">
                  {item.title}
                </h3>
                <p className="font-sans text-xs text-[#9ca3af] mt-1 line-clamp-2">
                  {item.description}
                </p>
              </div>
            </div>
          </RevealOnScroll>
        ))}
      </div>

      <Dialog open={!!lightbox} onOpenChange={(open) => !open && setLightbox(null)}>
        <DialogContent className="max-w-3xl p-0 bg-[#0b0b0e] border-white/15 overflow-hidden">
          {lightbox && (
            <>
              <DialogTitle className="sr-only">{lightbox.title}</DialogTitle>
              <img src={lightbox.image_url} alt={lightbox.title} className="w-full h-auto" />
              <div className="p-5">
                <span className="font-mono text-xs text-[#ff3b3b] uppercase tracking-wider">
                  {lightbox.category}
                </span>
                <h3 className="font-display font-bold text-lg text-white mt-1">{lightbox.title}</h3>
                <p className="font-sans text-sm text-[#9ca3af] mt-2">{lightbox.description}</p>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
