interface ServicesSectionProps {
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

const SERVICES = [
  {
    emoji: '🎮',
    title: 'Game Development',
    desc: 'Immersive gameplay experiences built for engagement and performance.',
  },
  {
    emoji: '🧊',
    title: '3D Modeling',
    desc: 'Game-ready assets, characters, and environments with high detail.',
  },
  {
    emoji: '🎨',
    title: '2D Art & Design',
    desc: 'Concept art, UI/UX, and visual storytelling.',
  },
  {
    emoji: '🎙',
    title: 'Voice Acting',
    desc: 'Professional voice and audio immersion.',
  },
  {
    emoji: '🌐',
    title: 'Web & Apps',
    desc: 'Modern digital platforms and experiences.',
  },
]

export function ServicesSection({ playSound }: ServicesSectionProps) {
  return (
    <section id="services" className="py-24 px-5 max-w-[1200px] mx-auto">
      <div className="font-mono text-xs text-[#ff3b3b] tracking-[0.2em] uppercase mb-2 font-semibold">
        PHASE 02 // ARSENAL
      </div>
      <div className="font-mono text-xs text-[#9ca3af] uppercase tracking-widest mb-1">
        SERVICES
      </div>
      <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white mb-12">
        What We Do
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES.map((srv, idx) => (
          <div
            key={idx}
            onMouseEnter={() => playSound('hover')}
            className="group relative bg-[#0b0b0e] border border-white/10 hover:border-[#ff3b3b]/50 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(255,59,59,0.2)] flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#ff3b3b]/10 border border-[#ff3b3b]/20 flex items-center justify-center text-2xl mb-6 group-hover:scale-110 group-hover:bg-[#ff3b3b]/20 transition-all shadow-[0_0_15px_rgba(255,59,59,0.2)]">
                {srv.emoji}
              </div>
              <h3 className="font-display font-bold text-xl text-white mb-3">{srv.title}</h3>
              <p className="font-sans text-sm text-[#9ca3af] leading-relaxed">{srv.desc}</p>
            </div>

            <div className="mt-8 flex justify-end">
              <span className="text-[#ff3b3b] opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all">
                →
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
