import { X, ArrowRight } from 'lucide-react'
import type { PortfolioProject } from '@/types/studio'

interface CaseStudyModalProps {
  project: PortfolioProject | null
  onClose: () => void
  onStartSimilar: () => void
  playSound: (type: 'hover' | 'click' | 'whoosh') => void
}

export function CaseStudyModal({
  project,
  onClose,
  onStartSimilar,
  playSound,
}: CaseStudyModalProps) {
  if (!project) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div
        className="relative w-full max-w-2xl bg-[#0b0b0e] border border-white/15 rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(255,59,59,0.2)] max-h-[90vh] flex flex-col animate-scale-in"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={() => {
            playSound('click')
            onClose()
          }}
          onMouseEnter={() => playSound('hover')}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:text-[#ff3b3b] hover:bg-black transition-all border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Cover Image Header */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden">
          <img src={project.cover_url} alt={project.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/40 to-transparent" />
          <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between">
            <span className="font-mono text-xs text-[#ff3b3b] bg-[#ff3b3b]/10 border border-[#ff3b3b]/30 px-3 py-1 rounded-full uppercase tracking-widest font-semibold">
              {project.category}
            </span>
            <span className="font-mono text-xs text-[#9ca3af]">{project.year}</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white mb-2">
              {project.title}
            </h2>
            <p className="text-[#9ca3af] text-sm sm:text-base leading-relaxed">
              {project.overview}
            </p>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 pt-2">
            {project.tags?.map((tag, idx) => (
              <span
                key={idx}
                className="font-mono text-xs bg-white/5 border border-white/10 px-3 py-1 rounded-md text-[#f5f5f7]"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Action CTA */}
          <div className="pt-4 border-t border-white/10 flex justify-end">
            <button
              onClick={() => {
                playSound('click')
                onClose()
                onStartSimilar()
              }}
              onMouseEnter={() => playSound('hover')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-sans text-sm font-semibold text-white bg-gradient-to-r from-[#ff3b3b] to-[#b91c1c] hover:shadow-[0_0_20px_rgba(255,59,59,0.5)] transition-all group"
            >
              <span>Start a Similar Project</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
