import { useState, useEffect, useCallback, useRef } from 'react'

export function useSound() {
  const [enabled, setEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('scarlet_sound')
    return saved !== null ? saved === 'true' : true
  })

  const ctxRef = useRef<AudioContext | null>(null)

  useEffect(() => {
    localStorage.setItem('scarlet_sound', String(enabled))
  }, [enabled])

  const initContext = useCallback(() => {
    if (!ctxRef.current) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      if (AudioCtx) {
        ctxRef.current = new AudioCtx()
      }
    }
    if (ctxRef.current && ctxRef.current.state === 'suspended') {
      ctxRef.current.resume()
    }
  }, [])

  const playSound = useCallback(
    (type: 'hover' | 'click' | 'whoosh') => {
      if (!enabled) return
      initContext()
      const ctx = ctxRef.current
      if (!ctx) return

      const now = ctx.currentTime

      if (type === 'hover') {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = 'sine'
        osc.frequency.setValueAtTime(440, now)
        osc.frequency.exponentialRampToValueAtTime(220, now + 0.03)
        gain.gain.setValueAtTime(0.02, now)
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(now)
        osc.stop(now + 0.03)
      } else if (type === 'click') {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = 'triangle'
        osc.frequency.setValueAtTime(523.25, now) // C5
        osc.frequency.setValueAtTime(659.25, now + 0.04) // E5
        gain.gain.setValueAtTime(0.05, now)
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(now)
        osc.stop(now + 0.1)
      } else if (type === 'whoosh') {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = 'sine'
        osc.frequency.setValueAtTime(150, now)
        osc.frequency.exponentialRampToValueAtTime(600, now + 0.12)
        gain.gain.setValueAtTime(0.03, now)
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(now)
        osc.stop(now + 0.12)
      }
    },
    [enabled, initContext],
  )

  const toggleSound = useCallback(() => {
    setEnabled((prev) => !prev)
  }, [])

  return { enabled, toggleSound, playSound }
}
