import { useState, useEffect } from 'react'

export function useScrollObserver(phaseIds: string[]) {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [activePhase, setActivePhase] = useState<string>('hero')

  useEffect(() => {
    const handleScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight
      if (total > 0) {
        const progress = Math.min(100, Math.max(0, (window.scrollY / total) * 100))
        setScrollProgress(progress)
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    handleScroll()
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const observers: IntersectionObserver[] = []

    phaseIds.forEach((id) => {
      const el = document.getElementById(id)
      if (!el) return

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setActivePhase(id)
            }
          })
        },
        { threshold: 0.3 },
      )

      observer.observe(el)
      observers.push(observer)
    })

    return () => {
      observers.forEach((obs) => obs.disconnect())
    }
  }, [phaseIds])

  return { scrollProgress, activePhase }
}
