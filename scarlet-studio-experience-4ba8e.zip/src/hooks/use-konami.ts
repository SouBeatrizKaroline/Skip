import { useEffect, useState } from 'react'

const KONAMI_CODE = [
  'ArrowUp',
  'ArrowUp',
  'ArrowDown',
  'ArrowDown',
  'ArrowLeft',
  'ArrowRight',
  'ArrowLeft',
  'ArrowRight',
  'b',
  'a',
]

export function useKonami(onSuccess: () => void) {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key
      const expected =
        KONAMI_CODE[index].length === 1 ? KONAMI_CODE[index].toLowerCase() : KONAMI_CODE[index]

      if (key === expected) {
        const next = index + 1
        if (next === KONAMI_CODE.length) {
          onSuccess()
          setIndex(0)
        } else {
          setIndex(next)
        }
      } else {
        setIndex(0)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [index, onSuccess])
}
