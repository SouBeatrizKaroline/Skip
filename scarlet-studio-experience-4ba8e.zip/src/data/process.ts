export interface ProcessStep {
  id: string
  step: number
  title: string
  description: string
  icon: string
}

export const PROCESS_STEPS: ProcessStep[] = [
  {
    id: '1',
    step: 1,
    title: 'Idea',
    description: 'Every universe begins with a spark. We brainstorm, sketch, and dream big.',
    icon: '💡',
  },
  {
    id: '2',
    step: 2,
    title: 'Concept',
    description: 'We flesh out the vision with concept art, narrative arcs, and design documents.',
    icon: '🎨',
  },
  {
    id: '3',
    step: 3,
    title: 'Design',
    description: 'Mechanics, systems, and aesthetics take shape in detailed design specs.',
    icon: '📐',
  },
  {
    id: '4',
    step: 4,
    title: 'Development',
    description: 'Code, assets, and audio come together in iterative playable builds.',
    icon: '⚙️',
  },
  {
    id: '5',
    step: 5,
    title: 'Final',
    description: 'Polish, test, and ship. The universe is ready for players to explore.',
    icon: '🚀',
  },
]
