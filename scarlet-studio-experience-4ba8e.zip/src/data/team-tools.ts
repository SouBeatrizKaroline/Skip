export const TEAM_TOOLS: Record<string, string[]> = {
  'Creative Director': ['Unity', 'Figma', 'Notion'],
  'Lead Developer': ['Unity', 'C#', 'Git', 'VS Code'],
  'Art Director': ['Blender', 'Photoshop', 'Procreate'],
  'Sound Designer': ['FMOD', 'Logic Pro', 'Audacity'],
}

export function getToolsForRole(role: string): string[] {
  return TEAM_TOOLS[role] || ['Unity', 'Blender']
}
