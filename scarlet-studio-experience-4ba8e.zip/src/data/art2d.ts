export interface Art2DItem {
  id: string
  title: string
  category: 'Concept Art' | 'UI/UX' | 'Illustration'
  image_url: string
  description: string
}

export const ART_2D: Art2DItem[] = [
  {
    id: '1',
    title: 'Neon Vanguard Key Art',
    category: 'Concept Art',
    image_url: 'https://img.usecurling.com/p/800/600?q=cyberpunk%20concept%20art&color=red',
    description: 'Hero composition for Neon Vanguard establishing mood and scale.',
  },
  {
    id: '2',
    title: 'Emberfall World Map',
    category: 'Concept Art',
    image_url: 'https://img.usecurling.com/p/800/600?q=fantasy%20map%20art&color=orange',
    description: 'Hand-painted world map showing the fractured realms of Emberfall.',
  },
  {
    id: '3',
    title: 'Game HUD Design',
    category: 'UI/UX',
    image_url: 'https://img.usecurling.com/p/800/600?q=game%20ui%20hud%20design&color=blue',
    description: 'Diegetic HUD system with modular widgets and adaptive layout.',
  },
  {
    id: '4',
    title: 'Menu Interface',
    category: 'UI/UX',
    image_url: 'https://img.usecurling.com/p/800/600?q=game%20menu%20interface&color=purple',
    description: 'Cinematic main menu with animated background and parallax layers.',
  },
  {
    id: '5',
    title: 'Chrono Drift Poster',
    category: 'Illustration',
    image_url: 'https://img.usecurling.com/p/800/600?q=sci%20fi%20racing%20poster&color=cyan',
    description: 'Dynamic promotional illustration for Chrono Drift launch campaign.',
  },
  {
    id: '6',
    title: 'Verdant Spirit Portrait',
    category: 'Illustration',
    image_url: 'https://img.usecurling.com/p/800/600?q=fantasy%20spirit%20portrait&color=green',
    description: 'Character portrait of a forest spirit from the Verdant universe.',
  },
]
