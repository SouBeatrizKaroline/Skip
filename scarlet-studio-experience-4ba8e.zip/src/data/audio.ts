export interface AudioTrack {
  id: string
  title: string
  category: string
  description: string
  duration: string
}

export const AUDIO_TRACKS: AudioTrack[] = [
  {
    id: '1',
    title: 'Neon Vanguard Battle Theme',
    category: 'Soundtrack',
    description: 'High-energy synthwave combat track with driving basslines.',
    duration: '3:24',
  },
  {
    id: '2',
    title: 'Emberfall Forest Ambience',
    category: 'Ambience',
    description: 'Atmospheric environmental soundscape with magical layers.',
    duration: '4:12',
  },
  {
    id: '3',
    title: 'Cyber Knight Voice Pack',
    category: 'Voice Acting',
    description: 'Combat grunts, dialogue lines, and interaction responses.',
    duration: '2:48',
  },
  {
    id: '4',
    title: 'Chrono Drift Menu Theme',
    category: 'Soundtrack',
    description: 'Pulsing electronic menu music with time-bend motifs.',
    duration: '3:56',
  },
  {
    id: '5',
    title: 'Last Signal Horror Stingers',
    category: 'SFX',
    description: 'Psychological horror stingers and tension-building cues.',
    duration: '1:34',
  },
  {
    id: '6',
    title: 'Verdant Cozy Melody',
    category: 'Soundtrack',
    description: 'Gentle acoustic guitar and flute for peaceful exploration.',
    duration: '5:02',
  },
]
