export interface LabExperiment {
  id: string
  title: string
  tag: 'WIP' | 'Prototype' | 'Test'
  description: string
  image_url: string
}

export const LAB_EXPERIMENTS: LabExperiment[] = [
  {
    id: '1',
    title: 'Procedural Terrain Gen',
    tag: 'Prototype',
    description: 'Noise-based infinite terrain with biome blending and erosion simulation.',
    image_url: 'https://img.usecurling.com/p/400/300?q=procedural%20terrain',
  },
  {
    id: '2',
    title: 'AI NPC Dialogue System',
    tag: 'WIP',
    description: 'LLM-powered dynamic NPC conversations with memory and emotion.',
    image_url: 'https://img.usecurling.com/p/400/300?q=ai%20dialogue%20system',
  },
  {
    id: '3',
    title: 'Volumetric Cloud Shader',
    tag: 'Test',
    description: 'Real-time volumetric clouds with wind simulation and lighting.',
    image_url: 'https://img.usecurling.com/p/400/300?q=volumetric%20clouds',
  },
  {
    id: '4',
    title: 'Rhythm Combat Prototype',
    tag: 'Prototype',
    description: 'Combat system synced to music BPM with visual feedback.',
    image_url: 'https://img.usecurling.com/p/400/300?q=rhythm%20combat%20game',
  },
  {
    id: '5',
    title: 'Water Simulation',
    tag: 'Test',
    description: 'GPU-based fluid simulation with refraction and caustics.',
    image_url: 'https://img.usecurling.com/p/400/300?q=water%20simulation%20shader',
  },
  {
    id: '6',
    title: 'Dynamic Weather System',
    tag: 'WIP',
    description: 'Seamless weather transitions affecting gameplay and visuals.',
    image_url: 'https://img.usecurling.com/p/400/300?q=dynamic%20weather%20system',
  },
]
