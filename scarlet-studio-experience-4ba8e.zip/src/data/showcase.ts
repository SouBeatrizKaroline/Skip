export interface Showcase3DItem {
  id: string
  title: string
  category: string
  image_url: string
  description: string
}

export const SHOWCASE_3D: Showcase3DItem[] = [
  {
    id: '1',
    title: 'Cyber Knight',
    category: 'Character',
    image_url: 'https://img.usecurling.com/p/600/600?q=3d%20character%20knight&color=red',
    description:
      'High-poly character with PBR textures and dynamic rigging for real-time animation.',
  },
  {
    id: '2',
    title: 'Neon Environment',
    category: 'Environment',
    image_url: 'https://img.usecurling.com/p/600/600?q=3d%20neon%20city&color=purple',
    description: 'Modular cyberpunk city blocks with emissive materials and optimized LODs.',
  },
  {
    id: '3',
    title: 'Mech Warrior',
    category: 'Vehicle',
    image_url: 'https://img.usecurling.com/p/600/600?q=3d%20mecha%20robot&color=orange',
    description: 'Stylized combat mech with destructible armor plating and hydraulic joints.',
  },
  {
    id: '4',
    title: 'Forest Spirit',
    category: 'Creature',
    image_url: 'https://img.usecurling.com/p/600/600?q=3d%20fantasy%20creature&color=green',
    description: 'Organic creature sculpt with subsurface scattering and fur simulation.',
  },
  {
    id: '5',
    title: 'Weapon Pack',
    category: 'Props',
    image_url: 'https://img.usecurling.com/p/600/600?q=3d%20game%20weapons&color=gray',
    description: 'Game-ready weapon set with customizable materials and attachment points.',
  },
]
