import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'
import { I18nProvider } from '@/hooks/use-i18n'
import Index from './pages/Index'
import NotFound from './pages/NotFound'
import Layout from './components/Layout'
import EarthSystemDetail from './pages/EarthSystemDetail'
import ClimateSimulator from './pages/ClimateSimulator'
import Visualizations from './pages/Visualizations'
import ClimateTimeline from './pages/ClimateTimeline'
import GlobeView from './pages/GlobeView'
import QuizHub from './pages/QuizHub'
import Library from './pages/Library'
import AiChat from './pages/AiChat'
import SignIn from './pages/SignIn'
import SignUp from './pages/SignUp'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import VerifyEmail from './pages/VerifyEmail'
import ConfirmEmailChange from './pages/ConfirmEmailChange'
import ArticleDetail from './pages/ArticleDetail'

const App = () => (
  <BrowserRouter>
    <I18nProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Index />} />
              <Route path="/systems/:slug" element={<EarthSystemDetail />} />
              <Route path="/visualizations" element={<Visualizations />} />
              <Route path="/visualizations/globe" element={<GlobeView />} />
              <Route path="/simulator" element={<ClimateSimulator />} />
              <Route path="/timeline" element={<ClimateTimeline />} />
              <Route path="/quiz" element={<QuizHub />} />
              <Route path="/biblioteca" element={<Library />} />
              <Route path="/ia" element={<AiChat />} />
              <Route path="/articles/:slug" element={<ArticleDetail />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/verify-email" element={<VerifyEmail />} />
              <Route path="/confirm-email-change" element={<ConfirmEmailChange />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </TooltipProvider>
      </AuthProvider>
    </I18nProvider>
  </BrowserRouter>
)

export default App
