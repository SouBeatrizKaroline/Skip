import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import pb from '@/lib/pocketbase/client'

export interface UserProfile {
  id: string
  role: 'student' | 'teacher' | 'school' | 'admin'
  country?: string
  language?: string
  bio?: string
}

interface AuthContextType {
  user: any
  profile: UserProfile | null
  isAuthenticated: boolean
  loading: boolean
  signUp: (
    email: string,
    pass: string,
    name: string,
    role: string,
    country?: string,
  ) => Promise<{ error: any }>
  signIn: (email: string, pass: string) => Promise<{ error: any }>
  signOut: () => void
  requestPasswordReset: (email: string) => Promise<{ error: any }>
  confirmPasswordReset: (token: string, pass: string) => Promise<{ error: any }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within an AuthProvider')
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<any>(pb.authStore.isValid ? pb.authStore.record : null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(pb.authStore.isValid)
  const [loading, setLoading] = useState(true)

  const fetchProfile = async (userId: string) => {
    try {
      const records = await pb.collection('profiles').getList(1, 1, { filter: `user="${userId}"` })
      if (records.items.length > 0) {
        setProfile(records.items[0] as unknown as UserProfile)
      }
    } catch {
      /* intentionally ignored */
    }
  }

  useEffect(() => {
    const unsubscribe = pb.authStore.onChange((_token, record) => {
      const valid = pb.authStore.isValid
      setUser(valid ? record : null)
      setIsAuthenticated(valid)
      if (valid && record) {
        fetchProfile(record.id)
      } else {
        setProfile(null)
      }
    })

    if (pb.authStore.isValid && pb.authStore.record) {
      pb.collection('users')
        .authRefresh()
        .then((res) => fetchProfile(res.record.id))
        .catch(() => pb.authStore.clear())
        .finally(() => setLoading(false))
    } else {
      if (pb.authStore.record) pb.authStore.clear()
      setLoading(false)
    }
    return () => {
      unsubscribe()
    }
  }, [])

  const signUp = async (
    email: string,
    pass: string,
    name: string,
    role: string,
    country?: string,
  ) => {
    try {
      const newUser = await pb.collection('users').create({
        email,
        password: pass,
        passwordConfirm: pass,
        name,
      })
      await pb.collection('users').authWithPassword(email, pass)

      // Create profile and gamification record
      await pb.collection('profiles').create({
        user: newUser.id,
        role: role || 'student',
        country: country || 'Brasil',
        language: 'pt',
      })
      await pb.collection('gamification').create({
        user: newUser.id,
        xp: 10,
        level: 1,
        streak: 1,
        last_streak_date: new Date().toISOString().split('T')[0],
      })

      return { error: null }
    } catch (error) {
      return { error }
    }
  }

  const signIn = async (email: string, pass: string) => {
    try {
      await pb.collection('users').authWithPassword(email, pass)
      return { error: null }
    } catch (error) {
      return { error }
    }
  }

  const signOut = () => {
    pb.authStore.clear()
  }

  const requestPasswordReset = async (email: string) => {
    try {
      await pb.collection('users').requestPasswordReset(email)
      return { error: null }
    } catch (error) {
      return { error }
    }
  }

  const confirmPasswordReset = async (token: string, pass: string) => {
    try {
      await pb.collection('users').confirmPasswordReset(token, pass, pass)
      return { error: null }
    } catch (error) {
      return { error }
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isAuthenticated,
        loading,
        signUp,
        signIn,
        signOut,
        requestPasswordReset,
        confirmPasswordReset,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
