export interface SystemData {
  metrics: Array<{ icon: string; label: string; value: string; trend: string; color: string }>
  mapPoints: Array<{ lat: number; lon: number; intensity: number }>
  timeline: Array<{ year: number; value: number }>
  ranking: Array<{ country: string; value: string; pct: number }>
  sidebar: Array<{ title: string; items: Array<{ label: string; value: string }> }>
}

function genT(base: number, slope: number): Array<{ year: number; value: number }> {
  return Array.from({ length: 20 }, (_, i) => ({
    year: 2006 + i,
    value: parseFloat((base + slope * i + Math.sin(i / 3) * Math.abs(slope) * 2).toFixed(1)),
  }))
}

const SLUGS: Record<string, string> = {
  wildfires: 'wildfires',
  'incendios-florestais': 'wildfires',
  'incêndios-florestais': 'wildfires',
  deforestation: 'deforestation',
  desmatamento: 'deforestation',
  'air-quality': 'air-quality',
  'qualidade-do-ar': 'air-quality',
  'ocean-temperature': 'ocean-temperature',
  'temperatura-dos-oceanos': 'ocean-temperature',
  'sea-level': 'sea-level',
  'nivel-do-mar': 'sea-level',
  'polar-ice': 'polar-ice',
  'gelo-polar': 'polar-ice',
  'carbon-emissions': 'carbon-emissions',
  'emissoes-de-carbono': 'carbon-emissions',
  'emissões-de-carbono': 'carbon-emissions',
  'water-cycle': 'water-cycle',
  'ciclo-da-agua': 'water-cycle',
  biodiversity: 'biodiversity',
  biodiversidade: 'biodiversity',
  'extreme-weather': 'extreme-weather',
  'eventos-extremos': 'extreme-weather',
}

function mk(
  color: string,
  metrics: [string, string, string, string][],
  points: [number, number, number][],
  tl: [number, number],
  ranking: [string, string, number][],
  sidebar: [string, [string, string][]][],
): SystemData {
  return {
    metrics: metrics.map(([icon, label, value, trend]) => ({ icon, label, value, trend, color })),
    mapPoints: points.map(([lat, lon, intensity]) => ({ lat, lon, intensity })),
    timeline: genT(tl[0], tl[1]),
    ranking: ranking.map(([country, value, pct]) => ({ country, value, pct })),
    sidebar: sidebar.map(([title, items]) => ({
      title,
      items: items.map(([label, value]) => ({ label, value })),
    })),
  }
}

const DATA: Record<string, SystemData> = {
  wildfires: mk(
    '#F97316',
    [
      ['Flame', 'Focos Ativos', '12.847', '+8.3%'],
      ['Globe', 'Area Afetada', '3.2M km2', '+12%'],
      ['Factory', 'CO2 Emitido', '1.9 Gt', '+15%'],
      ['Thermometer', 'Temp. Media', '38.4C', '+3.2C'],
    ],
    [
      [-10, -55, 0.9],
      [-15, -50, 0.8],
      [45, -100, 0.7],
      [55, 100, 0.8],
      [-30, 145, 0.6],
      [35, 0, 0.5],
      [0, 20, 0.7],
      [-5, 30, 0.6],
      [40, 35, 0.5],
    ],
    [8000, 300],
    [
      ['Brasil', '42.180 focos', 100],
      ['EUA', '31.500 focos', 75],
      ['Australia', '18.200 focos', 43],
      ['Indonesia', '12.800 focos', 30],
      ['Russia', '9.400 focos', 22],
    ],
    [
      [
        'Causas',
        [
          ['Naturais', '15%'],
          ['Humanas', '85%'],
          ['Queima agricola', '48%'],
          ['Raios', '12%'],
        ],
      ],
      [
        'Curiosidades',
        [
          ['Fumaca global', 'Circunda a Terra em 2 sem.'],
          ['Maior incendio', 'Australia 2019-20'],
        ],
      ],
    ],
  ),

  deforestation: mk(
    '#22C55E',
    [
      ['Trees', 'Perda Anual', '10M ha', '+5%'],
      ['Factory', 'CO2 Liberado', '4.8 Gt', '+8%'],
      ['Bird', 'Especies Afetadas', '8.200', '+3%'],
      ['Globe', 'Perda Total', '178M ha', 'Desde 2000'],
    ],
    [
      [-5, -60, 0.95],
      [-10, -55, 0.9],
      [0, 20, 0.7],
      [-20, 145, 0.6],
      [0, 110, 0.75],
      [55, 90, 0.65],
      [-10, -40, 0.5],
      [5, -75, 0.7],
    ],
    [12, 0.3],
    [
      ['Brasil', '2.8M ha', 100],
      ['RD Congo', '1.3M ha', 46],
      ['Bolivia', '850 mil ha', 30],
      ['Indonesia', '640 mil ha', 23],
      ['Peru', '490 mil ha', 18],
    ],
    [
      [
        'Biomas',
        [
          ['Amazonia', '35%'],
          ['Cerrado', '28%'],
          ['Mata Atlantica', '12%'],
        ],
      ],
      [
        'Historico',
        [
          ['Ano 2000', '4.1 bi ha'],
          ['Ano 2010', '3.9 bi ha'],
          ['Hoje', '3.7 bi ha'],
        ],
      ],
    ],
  ),

  'air-quality': mk(
    '#06B6D4',
    [
      ['Wind', 'AQI Global', '142', '+8%'],
      ['CloudFog', 'PM2.5', '35 ug/m3', '+12%'],
      ['Factory', 'NO2', '28 ppb', '+5%'],
      ['CloudFog', 'O3', '45 ppb', '-3%'],
    ],
    [
      [30, 110, 0.9],
      [25, 75, 0.85],
      [40, -75, 0.7],
      [35, -100, 0.65],
      [50, 10, 0.6],
      [-15, -50, 0.5],
      [30, 80, 0.7],
      [-25, 140, 0.55],
    ],
    [100, 3],
    [
      ['India', 'Delhi 450', 100],
      ['China', 'Pequim 280', 62],
      ['Paquistao', 'Lahore 220', 49],
      ['Bangladesh', 'Daca 210', 47],
      ['Brasil', 'SP 120', 27],
    ],
    [
      [
        'Poluentes',
        [
          ['PM2.5', '35 ug/m3'],
          ['NO2', '28 ppb'],
          ['O3', '45 ppb'],
          ['SO2', '12 ppb'],
        ],
      ],
      [
        'Saude',
        [
          ['Pop. afetada', '4.2 bi'],
          ['Mortes/ano', '7 mi'],
          ['Escolas fechadas', '8.500'],
        ],
      ],
    ],
  ),

  'ocean-temperature': mk(
    '#3B82F6',
    [
      ['Thermometer', 'Temp. Media', '21.2C', '+0.8C'],
      ['Waves', 'Anomalia', '+0.6C', '+15%'],
      ['Globe', 'Area Quente', '67%', '+8%'],
      ['Bird', 'Corais Branqueados', '45%', '+12%'],
    ],
    [
      [0, -150, 0.8],
      [0, 0, 0.7],
      [0, 150, 0.85],
      [-30, 150, 0.6],
      [30, -40, 0.65],
      [20, 90, 0.7],
      [0, 90, 0.75],
      [-20, -10, 0.5],
    ],
    [0.3, 0.04],
    [
      ['Pacifico', '+0.8C', 100],
      ['Atlantico', '+0.6C', 75],
      ['Indico', '+0.7C', 87],
      ['Artico', '+2.1C', 100],
      ['Antartico', '+0.4C', 50],
    ],
    [
      [
        'El Nino',
        [
          ['Status', 'Ativo'],
          ['Intensidade', 'Forte'],
          ['Previsao', 'Marco 2026'],
        ],
      ],
      [
        'Impactos',
        [
          ['Branqueamento coral', '45%'],
          ['Pesca reduzida', '12%'],
          ['Furacoes', '+18%'],
        ],
      ],
    ],
  ),

  'sea-level': mk(
    '#0EA5E9',
    [
      ['Waves', 'Elevacao Global', '+21 cm', '+3.4mm/ano'],
      ['Globe', 'Cidades em Risco', '570', '+8%'],
      ['Waves', 'Projecao 2100', '+65 cm', 'IPCC'],
      ['Mountain', 'Pop. Afetada', '900M', '+5%'],
    ],
    [
      [40, -74, 0.9],
      [52, 5, 0.7],
      [30, 120, 0.8],
      [-6, 107, 0.75],
      [25, 55, 0.65],
      [40, 140, 0.6],
      [-22, -43, 0.55],
      [30, -90, 0.5],
    ],
    [10, 0.5],
    [
      ['Holanda', '+25 cm', 100],
      ['Bangladesh', '+32 cm', 100],
      ['Maldivas', '+28 cm', 100],
      ['EUA (Florida)', '+22 cm', 88],
      ['Brasil', '+18 cm', 72],
    ],
    [
      [
        'Projecoes',
        [
          ['2050', '+30 cm'],
          ['2100', '+65 cm'],
          ['2150', '+1.2 m'],
        ],
      ],
      [
        'Cidades',
        [
          ['Miami', '570 mil hab.'],
          ['Xangai', '24 mi'],
          ['Daca', '9 mi'],
          ['Jacarta', '10 mi'],
        ],
      ],
    ],
  ),

  'polar-ice': mk(
    '#38BDF8',
    [
      ['Snowflake', 'Gelo Artico', '4.2M km2', '-12%'],
      ['Snowflake', 'Gelo Antartico', '5.1M km2', '-8%'],
      ['Mountain', 'Perda Anual', '270 Gt', '+15%'],
      ['Waves', 'Elevacao do Mar', '+0.7mm/ano', 'Derretimento'],
    ],
    [
      [75, -40, 0.95],
      [80, 0, 0.9],
      [72, 40, 0.85],
      [-80, 0, 0.9],
      [-75, -60, 0.85],
      [-78, 90, 0.8],
      [70, -100, 0.7],
      [-70, 120, 0.75],
    ],
    [8, -0.25],
    [
      ['Groenlandia', '270 Gt/ano', 100],
      ['Antartica', '150 Gt/ano', 56],
      ['Artico', '4.2M km2', 42],
      ['Alasca', '50 Gt/ano', 19],
      ['Patagonia', '25 Gt/ano', 9],
    ],
    [
      [
        'Artico',
        [
          ['Gelo minimo', '4.2M km2'],
          ['Reducao desde 1979', '-40%'],
          ['Projecao 2050', 'Sem gelo no verao'],
        ],
      ],
      [
        'Curiosidades',
        [
          ['Groenlandia', 'Maior ilha do mundo'],
          ['Antartica', '60% da agua doce'],
        ],
      ],
    ],
  ),

  'carbon-emissions': mk(
    '#8B5CF6',
    [
      ['Factory', 'CO2 Atmosferico', '421 ppm', '+2.4 ppm'],
      ['Globe', 'Emissoes/ano', '36.8 Gt', '+0.8%'],
      ['Factory', 'Maior Emissor', 'China', '31%'],
      ['Zap', 'Setor Energia', '40%', 'Maior fonte'],
    ],
    [
      [35, 110, 0.95],
      [40, -100, 0.85],
      [50, 10, 0.8],
      [25, 80, 0.7],
      [-15, -50, 0.5],
      [35, 0, 0.6],
      [-25, 135, 0.65],
      [55, 40, 0.7],
    ],
    [30, 0.5],
    [
      ['China', '11.4 Gt', 100],
      ['EUA', '5.0 Gt', 44],
      ['India', '2.9 Gt', 25],
      ['Russia', '1.7 Gt', 15],
      ['Brasil', '1.2 Gt', 11],
    ],
    [
      [
        'Setores',
        [
          ['Energia', '40%'],
          ['Transporte', '24%'],
          ['Industria', '18%'],
          ['Agro', '12%'],
        ],
      ],
      [
        'Concentracao',
        [
          ['Pre-industrial', '280 ppm'],
          ['Ano 2000', '369 ppm'],
          ['Hoje', '421 ppm'],
        ],
      ],
    ],
  ),

  'water-cycle': mk(
    '#06B6D4',
    [
      ['Droplets', 'Precipitacao', '990 mm/ano', '-2%'],
      ['CloudRain', 'Areas Secas', '28%', '+5%'],
      ['Droplets', 'Agua Subterranea', '-4mm/ano', 'Reduzindo'],
      ['Waves', 'Enchentes', '1.430', '+12%'],
    ],
    [
      [20, -60, 0.8],
      [5, 20, 0.7],
      [30, 100, 0.9],
      [-25, 140, 0.6],
      [35, -100, 0.5],
      [0, -60, 0.75],
      [50, 10, 0.6],
      [-10, 30, 0.5],
    ],
    [1000, -5],
    [
      ['India', '2.400 mm', 100],
      ['Colombia', '3.240 mm', 100],
      ['Brasil', '1.760 mm', 73],
      ['Indonesia', '2.702 mm', 100],
      ['Egito', '51 mm', 2],
    ],
    [
      [
        'Reservatorios',
        [
          ['Amazonas', '209 mil m3/s'],
          ['Congo', '41 mil m3/s'],
          ['Ganges', '12 mil m3/s'],
        ],
      ],
      [
        'Secas',
        [
          ['Pop. afetada', '2.2 bi'],
          ['Sahel', '60% em seca'],
          ['California', 'Megasseca'],
        ],
      ],
    ],
  ),

  biodiversity: mk(
    '#10B981',
    [
      ['Bird', 'Especies Catalogadas', '2.1M', '+1.2%'],
      ['Bird', 'Ameacadas', '41.415', '+3%'],
      ['Trees', 'Areas Protegidas', '15.7%', '+1%'],
      ['Mountain', 'Hotspots', '36', 'Criticos'],
    ],
    [
      [-5, -60, 0.95],
      [0, 20, 0.8],
      [-15, 130, 0.85],
      [5, 110, 0.8],
      [10, -70, 0.7],
      [-5, 30, 0.75],
      [35, -100, 0.6],
      [-25, 145, 0.65],
    ],
    [1.8, 0.02],
    [
      ['Brasil', '55 mil spp', 100],
      ['Colombia', '56 mil spp', 100],
      ['Indonesia', '30 mil spp', 54],
      ['China', '30 mil spp', 54],
      ['Mexico', '26 mil spp', 46],
    ],
    [
      [
        'Hotspots',
        [
          ['Mata Atlantica', '8% restante'],
          ['Madagascar', '10% restante'],
          ['Indo-Birmania', '5% restante'],
        ],
      ],
      [
        'Ameacas',
        [
          ['Desmatamento', '70%'],
          ['Mudanca climatica', '45%'],
          ['Poluicao', '30%'],
        ],
      ],
    ],
  ),

  'extreme-weather': mk(
    '#EF4444',
    [
      ['CloudRain', 'Eventos/ano', '156', '+18%'],
      ['Thermometer', 'Ondas de Calor', '42', '+25%'],
      ['CloudRain', 'Enchentes', '58', '+12%'],
      ['Zap', 'Prejuizo Economico', '$280 bi', '+8%'],
    ],
    [
      [25, -90, 0.9],
      [35, -100, 0.85],
      [20, 90, 0.8],
      [-10, 120, 0.75],
      [40, 0, 0.65],
      [50, -100, 0.7],
      [-20, -50, 0.6],
      [30, 140, 0.7],
    ],
    [120, 4],
    [
      ['EUA', '$145 bi', 100],
      ['China', '$52 bi', 36],
      ['Japao', '$28 bi', 19],
      ['India', '$22 bi', 15],
      ['Brasil', '$15 bi', 10],
    ],
    [
      [
        'Tipos',
        [
          ['Furacoes', '38'],
          ['Secas', '28'],
          ['Enchentes', '58'],
          ['Ondas de calor', '42'],
        ],
      ],
      [
        'Tendencia',
        [
          ['Anos 80', '45 eventos'],
          ['Anos 2000', '89 eventos'],
          ['Hoje', '156 eventos'],
        ],
      ],
    ],
  ),
}

export function getSystemData(slug: string): SystemData | null {
  const key = SLUGS[slug.toLowerCase()] || slug.toLowerCase()
  return DATA[key] || null
}
