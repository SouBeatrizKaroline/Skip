import pb from '@/lib/pocketbase/client'

export const createClass = async (teacherId: string, name: string, description: string) => {
  const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase()
  return await pb.collection('classes').create({
    teacher: teacherId,
    name,
    description,
    invite_code: inviteCode,
  })
}

export const joinClassByCode = async (inviteCode: string) => {
  return await pb.send('/backend/v1/classes/join', {
    method: 'POST',
    body: JSON.stringify({ invite_code: inviteCode }),
    headers: { 'Content-Type': 'application/json' },
  })
}

export const getTeacherClasses = async (teacherId: string) => {
  try {
    return await pb.collection('classes').getFullList({ filter: `teacher="${teacherId}"` })
  } catch (_) {
    return []
  }
}
