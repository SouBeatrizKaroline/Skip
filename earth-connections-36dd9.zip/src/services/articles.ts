import pb from '@/lib/pocketbase/client'

export interface Article {
  id: string
  slug: string
  title_pt: string
  title_en?: string
  title_es?: string
  content_pt: string
  content_en?: string
  content_es?: string
  reading_time: number
  difficulty: 'basic' | 'intermediate' | 'advanced'
  category: 'article' | 'video' | 'infographic' | 'curiosity' | 'experiment' | 'teacher'
}

export interface GlossaryTerm {
  id: string
  term_pt: string
  term_en?: string
  term_es?: string
  definition_pt: string
  definition_en?: string
  definition_es?: string
}

export const getArticles = async (category?: string) => {
  try {
    const filter = category ? `category="${category}"` : ''
    return await pb.collection('articles').getFullList({ filter, sort: '-created' })
  } catch (_) {
    return []
  }
}

export const getGlossaryTerms = async () => {
  try {
    return await pb.collection('glossary_terms').getFullList({ sort: 'term_pt' })
  } catch (_) {
    return []
  }
}
