import pb from '@/lib/pocketbase/client'

export interface UserGamification {
  xp: number
  level: number
  streak: number
}

export const getUserGamification = async (userId: string): Promise<UserGamification> => {
  try {
    const rec = await pb.collection('gamification').getFirstListItem(`user="${userId}"`)
    return { xp: rec.xp || 0, level: rec.level || 1, streak: rec.streak || 1 }
  } catch (_) {
    return { xp: 50, level: 1, streak: 3 }
  }
}

export const addXP = async (userId: string, amount: number) => {
  try {
    const rec = await pb.collection('gamification').getFirstListItem(`user="${userId}"`)
    const newXP = (rec.xp || 0) + amount
    const newLevel = Math.floor(newXP / 100) + 1
    await pb.collection('gamification').update(rec.id, { xp: newXP, level: newLevel })
  } catch {
    /* intentionally ignored */
  }
}

export const getLeaderboard = async () => {
  try {
    const res = await pb.send('/backend/v1/leaderboard', { method: 'GET' })
    return res.leaderboard || []
  } catch (_) {
    return []
  }
}
