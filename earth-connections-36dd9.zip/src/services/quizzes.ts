import pb from '@/lib/pocketbase/client'

export interface QuizQuestion {
  id: string
  question_pt: string
  options_pt: string[]
  correct_index: number
  explanation_pt: string
  difficulty: 'basic' | 'intermediate' | 'advanced'
  xp: number
}

export const getQuizQuestions = async (difficulty?: string) => {
  try {
    const filter = difficulty ? `difficulty="${difficulty}"` : ''
    return await pb.collection('quiz_questions').getFullList({ filter })
  } catch (_) {
    return []
  }
}

export const saveQuizAttempt = async (data: {
  userId: string
  quizType: string
  score: number
  totalQuestions: number
  xpEarned: number
}) => {
  return await pb.collection('quiz_attempts').create({
    user: data.userId,
    quiz_type: data.quizType,
    score: data.score,
    total_questions: data.totalQuestions,
    xp_earned: data.xpEarned,
  })
}
