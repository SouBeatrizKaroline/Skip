import pb from '@/lib/pocketbase/client'

export const explainChartWithAI = async (title: string, dataSummary: string) => {
  try {
    const res = await pb.send('/backend/v1/ai/explain-chart', {
      method: 'POST',
      body: JSON.stringify({ title, dataSummary }),
      headers: { 'Content-Type': 'application/json' },
    })
    return res.explanation || ''
  } catch (_) {
    return 'Não foi possível gerar a explicação automática no momento.'
  }
}

export const simplifyArticleWithAI = async (content: string, scientistMode: boolean = false) => {
  try {
    const res = await pb.send('/backend/v1/ai/simplify-article', {
      method: 'POST',
      body: JSON.stringify({ content, scientistMode }),
      headers: { 'Content-Type': 'application/json' },
    })
    return res.summary || ''
  } catch (_) {
    return 'Falha ao processar o resumo inteligente.'
  }
}
