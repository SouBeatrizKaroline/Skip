import pb from '@/lib/pocketbase/client'

export interface EarthSystem {
  id: string
  slug: string
  title_pt: string
  title_en?: string
  title_es?: string
  summary_pt: string
  summary_en?: string
  summary_es?: string
  icon: string
  color: string
  datasets: string[]
  order: number
}

export const getEarthSystems = async (): Promise<EarthSystem[]> => {
  try {
    const res = await pb.collection('earth_systems').getFullList({ sort: 'order' })
    return res as unknown as EarthSystem[]
  } catch (_) {
    return []
  }
}

export const getEarthSystemBySlug = async (slug: string): Promise<EarthSystem | null> => {
  try {
    const res = await pb.collection('earth_systems').getFirstListItem(`slug="${slug}"`)
    return res as unknown as EarthSystem
  } catch (_) {
    return null
  }
}
