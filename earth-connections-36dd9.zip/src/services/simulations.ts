import pb from '@/lib/pocketbase/client'

export interface SimulationScenario {
  id?: string
  name: string
  variables: Record<string, number>
  scenarioResults: Record<string, number | string>
}

export const saveSimulation = async (userId: string, scenario: SimulationScenario) => {
  return await pb.collection('simulations').create({
    user: userId,
    name: scenario.name,
    variables: scenario.variables,
    scenario_results: scenario.scenarioResults,
  })
}

export const getUserSimulations = async (userId: string) => {
  try {
    return await pb
      .collection('simulations')
      .getFullList({ filter: `user="${userId}"`, sort: '-created' })
  } catch (_) {
    return []
  }
}
