import { useEffect, useRef } from 'react'

interface SimulatorGlobeProps {
  tempIncrease: number
  co2: number
  deforestation: number
}

export function SimulatorGlobe({ tempIncrease, co2, deforestation }: SimulatorGlobeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animId: number
    let rotation = 0

    const getColors = () => {
      if (tempIncrease < 1.5)
        return { land: 'rgba(34, 197, 94, 0.5)', glow: 'rgba(34, 197, 94, 0.2)', ocean: '#1E40AF' }
      if (tempIncrease < 2.5)
        return {
          land: 'rgba(250, 204, 21, 0.5)',
          glow: 'rgba(250, 204, 21, 0.2)',
          ocean: '#1E3A5F',
        }
      if (tempIncrease < 3.5)
        return {
          land: 'rgba(249, 115, 22, 0.5)',
          glow: 'rgba(249, 115, 22, 0.2)',
          ocean: '#7C2D12',
        }
      return { land: 'rgba(239, 68, 68, 0.5)', glow: 'rgba(239, 68, 68, 0.3)', ocean: '#991B1B' }
    }

    const render = () => {
      const width = canvas.width
      const height = canvas.height
      const radius = Math.min(width, height) * 0.35
      const centerX = width / 2
      const centerY = height / 2
      const colors = getColors()

      ctx.clearRect(0, 0, width, height)

      const glowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        radius * 0.8,
        centerX,
        centerY,
        radius * 1.3,
      )
      glowGrad.addColorStop(0, colors.glow)
      glowGrad.addColorStop(1, 'rgba(11, 29, 58, 0)')
      ctx.fillStyle = glowGrad
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * 1.3, 0, Math.PI * 2)
      ctx.fill()

      const oceanGrad = ctx.createRadialGradient(
        centerX - radius * 0.3,
        centerY - radius * 0.3,
        radius * 0.1,
        centerX,
        centerY,
        radius,
      )
      oceanGrad.addColorStop(0, colors.ocean)
      oceanGrad.addColorStop(0.7, '#0F172A')
      oceanGrad.addColorStop(1, '#020617')
      ctx.fillStyle = oceanGrad
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fill()

      rotation += 0.005
      ctx.fillStyle = colors.land
      for (let lat = -60; lat <= 60; lat += 15) {
        for (let lon = 0; lon < 360; lon += 20) {
          const radLat = (lat * Math.PI) / 180
          const radLon = ((lon + rotation * 50) * Math.PI) / 180
          const x = radius * Math.cos(radLat) * Math.sin(radLon)
          const y = radius * Math.sin(radLat)
          const z = radius * Math.cos(radLat) * Math.cos(radLon)
          if (z > 0) {
            ctx.beginPath()
            ctx.arc(centerX + x, centerY - y, 2.5, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      }

      const numHotspots = Math.floor(8 + tempIncrease * 5 + deforestation * 0.3)
      ctx.fillStyle = tempIncrease > 2.5 ? '#EF4444' : '#F97316'
      for (let i = 0; i < numHotspots; i++) {
        const angle = rotation * 2 + (i * Math.PI * 2) / numHotspots
        const r = radius * (0.4 + 0.3 * Math.sin(i * 1.7))
        const fx = centerX + Math.cos(angle) * r
        const fy = centerY + Math.sin(angle) * r * 0.8
        const pulse = Math.sin(rotation * 20 + i) * 0.3 + 0.7
        ctx.globalAlpha = pulse * 0.8
        ctx.beginPath()
        ctx.arc(fx, fy, 3, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalAlpha = 1

      animId = requestAnimationFrame(render)
    }

    render()
    return () => cancelAnimationFrame(animId)
  }, [tempIncrease, co2, deforestation])

  return (
    <div className="relative w-full h-[300px] md:h-[400px] flex items-center justify-center bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      <canvas ref={canvasRef} width={600} height={400} className="w-full h-full object-cover" />
      <div className="absolute bottom-3 left-4 bg-slate-900/80 backdrop-blur px-3 py-1 rounded-full text-xs text-teal-400 font-mono border border-slate-700">
        ● Simulação Climática 3D
      </div>
      <div
        className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur px-3 py-1 rounded-full text-xs font-mono border border-slate-700"
        style={{ color: tempIncrease > 2.5 ? '#EF4444' : '#14B8A6' }}
      >
        +{tempIncrease.toFixed(2)}°C
      </div>
    </div>
  )
}
