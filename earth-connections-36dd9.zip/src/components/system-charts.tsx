import { Area, AreaChart, Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart'

export function TimelineAreaChart({
  data,
  color = 'hsl(var(--chart-1))',
  label = 'Valor',
}: {
  data: Array<{ year: number; value: number }>
  color?: string
  label?: string
}) {
  const config = { value: { label, color } } satisfies ChartConfig
  return (
    <div className="rounded-2xl border border-slate-800 bg-card p-4 space-y-3">
      <h3 className="text-sm font-bold text-white">Evolucao Temporal</h3>
      <ChartContainer config={config} className="h-[200px] w-full">
        <AreaChart data={data} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
          <defs>
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.4} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid
            vertical={false}
            strokeDasharray="3 3"
            stroke="hsl(var(--border))"
            opacity={0.2}
          />
          <XAxis dataKey="year" tickLine={false} axisLine={false} tick={{ fontSize: 11 }} />
          <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11 }} width={30} />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2}
            fill="url(#areaGrad)"
          />
        </AreaChart>
      </ChartContainer>
    </div>
  )
}

export function RankingBarChart({
  data,
  color = 'hsl(var(--chart-1))',
  label = 'Valor',
}: {
  data: Array<{ name: string; value: number }>
  color?: string
  label?: string
}) {
  const config = { value: { label, color } } satisfies ChartConfig
  return (
    <div className="rounded-2xl border border-slate-800 bg-card p-4 space-y-3">
      <h3 className="text-sm font-bold text-white">Comparativo</h3>
      <ChartContainer config={config} className="h-[180px] w-full">
        <BarChart data={data} layout="vertical" margin={{ left: 10, right: 10 }}>
          <XAxis type="number" hide />
          <YAxis
            type="category"
            dataKey="name"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11 }}
            width={70}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Bar dataKey="value" fill={color} radius={4} />
        </BarChart>
      </ChartContainer>
    </div>
  )
}
