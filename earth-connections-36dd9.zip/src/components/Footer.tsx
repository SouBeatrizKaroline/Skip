import { Link } from 'react-router-dom'
import { Globe, Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-[#0B1D3A] text-slate-300 border-t border-slate-800 py-12 px-4 mt-auto">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-sm">
        <div>
          <div className="flex items-center gap-2 text-white font-bold text-lg mb-3">
            <Globe className="h-5 w-5 text-teal-400" />
            <span>Earth Connections</span>
          </div>
          <p className="text-slate-400 leading-relaxed text-xs">
            Connecting Earth Systems Through Science, Data and Education.
          </p>
        </div>

        <div>
          <h4 className="font-semibold text-white mb-3">Navegação</h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>
              <Link to="/visualizations" className="hover:text-white">
                Visualizações de Dados
              </Link>
            </li>
            <li>
              <Link to="/simulator" className="hover:text-white">
                Simulador Climático
              </Link>
            </li>
            <li>
              <Link to="/timeline" className="hover:text-white">
                Linha do Tempo
              </Link>
            </li>
            <li>
              <Link to="/quiz" className="hover:text-white">
                Quiz & Gamificação
              </Link>
            </li>
            <li>
              <Link to="/biblioteca" className="hover:text-white">
                Biblioteca Científica
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-white mb-3">Fontes da NASA</h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>NASA EarthData & FIRMS</li>
            <li>NASA Earth Observatory</li>
            <li>GISS Surface Temperature</li>
            <li>ESA Copernicus Satellite Data</li>
            <li>NOAA Climate Data Center</li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-white mb-3">Projeto</h4>
          <p className="text-xs text-slate-400 mb-2">
            Global Nominee — NASA Space Apps Challenge 2024.
          </p>
          <div className="flex items-center gap-1 text-xs text-teal-400">
            <Heart className="h-3.5 w-3.5 fill-teal-400" />
            <span>Educação climática para o futuro</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto border-t border-slate-800 pt-6 text-center text-xs text-slate-500">
        Dados científicos de fontes públicas. Projeto educacional e científico. ©{' '}
        {new Date().getFullYear()} Earth Connections.
      </div>
    </footer>
  )
}
