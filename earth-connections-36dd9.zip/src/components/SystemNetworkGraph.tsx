import { Link } from 'react-router-dom'

export function SystemNetworkGraph() {
  return (
    <div className="relative w-full h-[320px] bg-slate-900 rounded-2xl p-4 border border-slate-800 flex items-center justify-center">
      <svg className="w-full h-full" viewBox="0 0 600 300">
        <line
          x1="150"
          y1="100"
          x2="300"
          y2="150"
          stroke="#F97316"
          strokeWidth="2"
          strokeDasharray="4"
        />
        <line x1="300" y1="150" x2="450" y2="100" stroke="#14B8A6" strokeWidth="2" />
        <line x1="300" y1="150" x2="300" y2="250" stroke="#38BDF8" strokeWidth="2" />
        <line x1="150" y1="200" x2="300" y2="150" stroke="#8B5CF6" strokeWidth="2" />

        {/* Nodes */}
        <g>
          <circle cx="150" cy="100" r="24" fill="#F97316" opacity="0.2" />
          <circle cx="150" cy="100" r="16" fill="#F97316" />
          <text x="150" y="104" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
            Queimadas
          </text>
        </g>
        <g>
          <circle cx="300" cy="150" r="30" fill="#14B8A6" opacity="0.2" />
          <circle cx="300" cy="150" r="20" fill="#14B8A6" />
          <text x="300" y="154" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
            Clima
          </text>
        </g>
        <g>
          <circle cx="450" cy="100" r="24" fill="#2563EB" opacity="0.2" />
          <circle cx="450" cy="100" r="16" fill="#2563EB" />
          <text x="450" y="104" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
            Oceanos
          </text>
        </g>
        <g>
          <circle cx="300" cy="250" r="24" fill="#38BDF8" opacity="0.2" />
          <circle cx="300" cy="250" r="16" fill="#38BDF8" />
          <text x="300" y="254" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
            Gelo
          </text>
        </g>
      </svg>
      <div className="absolute bottom-2 text-center text-xs text-slate-400">
        Toque nos nós para analisar interconexões entre os ecossistemas
      </div>
    </div>
  )
}
