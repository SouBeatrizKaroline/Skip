import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Flame,
  Trees,
  Wind,
  Thermometer,
  Waves,
  Snowflake,
  CloudFog,
  Droplets,
  Bird,
  Zap,
} from 'lucide-react'
import { getEarthSystems, EarthSystem } from '@/services/earth-systems'

const iconMap: Record<string, any> = {
  Flame,
  Trees,
  Wind,
  Thermometer,
  Waves,
  Snowflake,
  CloudFog,
  Droplets,
  Bird,
  Zap,
}

export function EarthSystemsGrid() {
  const [systems, setSystems] = useState<EarthSystem[]>([])

  useEffect(() => {
    getEarthSystems().then(setSystems)
  }, [])

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {systems.map((sys) => {
        const Icon = iconMap[sys.icon] || Flame
        return (
          <Link
            key={sys.id}
            to={`/systems/${sys.slug}`}
            className="group relative p-5 rounded-2xl bg-card border border-border/60 hover:border-teal-500/50 hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-transform group-hover:scale-110"
                style={{ backgroundColor: `${sys.color}15`, color: sys.color }}
              >
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-base mb-1 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                {sys.title_pt}
              </h3>
              <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                {sys.summary_pt}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-border/40 flex items-center justify-between text-[10px] text-muted-foreground font-mono">
              <span>{sys.datasets?.[0] || 'NASA'}</span>
              <span className="text-teal-500 font-bold group-hover:translate-x-1 transition-transform">
                Explorar →
              </span>
            </div>
          </Link>
        )
      })}
    </div>
  )
}
