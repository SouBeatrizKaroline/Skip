import { useState, useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Globe, Flame, Bell, User, Menu, X, Sun, Moon, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import { I18nContext, Language } from '@/hooks/use-i18n'
import { useAuth } from '@/hooks/use-auth'

export function Navbar() {
  const { language, setLanguage, t } = useContext(I18nContext)
  const { user, profile, isAuthenticated, signOut } = useAuth()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [dark, setDark] = useState(false)
  const navigate = useNavigate()

  const toggleTheme = () => {
    setDark(!dark)
    document.documentElement.classList.toggle('dark')
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link
          to="/"
          className="flex items-center gap-2 font-display text-xl font-bold tracking-tight text-foreground"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-tr from-blue-900 via-teal-500 to-green-400 p-0.5 shadow-md">
            <Globe className="h-5 w-5 text-white animate-spin-slow" />
          </div>
          <span>{t('appName')}</span>
        </Link>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <Link to="/" className="hover:text-foreground transition-colors">
            {t('home')}
          </Link>
          <Link to="/visualizations" className="hover:text-foreground transition-colors">
            {t('visualizations')}
          </Link>
          <Link to="/visualizations/globe" className="hover:text-foreground transition-colors">
            Globo 3D
          </Link>
          <Link to="/simulator" className="hover:text-foreground transition-colors">
            {t('simulator')}
          </Link>
          <Link to="/timeline" className="hover:text-foreground transition-colors">
            {t('timeline')}
          </Link>
          <Link to="/quiz" className="hover:text-foreground transition-colors">
            {t('quiz')}
          </Link>
          <Link to="/biblioteca" className="hover:text-foreground transition-colors">
            {t('library')}
          </Link>
          <Link
            to="/ia"
            className="hover:text-foreground transition-colors text-purple-600 dark:text-purple-400 font-semibold"
          >
            {t('aiChat')}
          </Link>
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-3">
          {/* Streak Counter */}
          {isAuthenticated && (
            <div className="hidden sm:flex items-center gap-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2.5 py-1 rounded-full text-xs font-semibold">
              <Flame className="h-4 w-4 fill-amber-500 text-amber-500" />
              <span>3 d</span>
            </div>
          )}

          {/* i18n Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Globe className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setLanguage('pt')}>Português (BR)</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('en')}>English (US)</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('es')}>Español</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Theme Toggle */}
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="h-9 w-9">
            {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          {/* Auth Actions */}
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full bg-primary/10">
                  <User className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-2 py-1.5 text-xs text-muted-foreground truncate">
                  {user?.email}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/dashboard')}>
                  {t('dashboard')}
                </DropdownMenuItem>
                {profile?.role === 'teacher' && (
                  <DropdownMenuItem onClick={() => navigate('/professor')}>
                    {t('teacherArea')}
                  </DropdownMenuItem>
                )}
                {profile?.role === 'school' && (
                  <DropdownMenuItem onClick={() => navigate('/escola')}>
                    {t('schoolArea')}
                  </DropdownMenuItem>
                )}
                {profile?.role === 'admin' && (
                  <DropdownMenuItem onClick={() => navigate('/admin')}>
                    {t('adminArea')}
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => navigate('/perfil')}>
                  {t('profile')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/certificados')}>
                  {t('certificates')}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={signOut} className="text-red-500">
                  <LogOut className="h-4 w-4 mr-2" />
                  {t('signOut')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => navigate('/signin')}>
                {t('signIn')}
              </Button>
              <Button size="sm" onClick={() => navigate('/signup')}>
                {t('signUp')}
              </Button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-b border-border bg-background px-4 py-4 space-y-3">
          <Link to="/" onClick={() => setMobileOpen(false)} className="block py-1 text-sm">
            {t('home')}
          </Link>
          <Link
            to="/visualizations"
            onClick={() => setMobileOpen(false)}
            className="block py-1 text-sm"
          >
            {t('visualizations')}
          </Link>
          <Link
            to="/visualizations/globe"
            onClick={() => setMobileOpen(false)}
            className="block py-1 text-sm"
          >
            Globo 3D
          </Link>
          <Link to="/simulator" onClick={() => setMobileOpen(false)} className="block py-1 text-sm">
            {t('simulator')}
          </Link>
          <Link to="/timeline" onClick={() => setMobileOpen(false)} className="block py-1 text-sm">
            {t('timeline')}
          </Link>
          <Link to="/quiz" onClick={() => setMobileOpen(false)} className="block py-1 text-sm">
            {t('quiz')}
          </Link>
          <Link
            to="/biblioteca"
            onClick={() => setMobileOpen(false)}
            className="block py-1 text-sm"
          >
            {t('library')}
          </Link>
          <Link
            to="/ia"
            onClick={() => setMobileOpen(false)}
            className="block py-1 text-sm font-semibold text-purple-600"
          >
            {t('aiChat')}
          </Link>
          {!isAuthenticated && (
            <div className="pt-2 flex gap-2">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setMobileOpen(false)
                  navigate('/signin')
                }}
              >
                {t('signIn')}
              </Button>
              <Button
                className="w-full"
                onClick={() => {
                  setMobileOpen(false)
                  navigate('/signup')
                }}
              >
                {t('signUp')}
              </Button>
            </div>
          )}
        </div>
      )}
    </header>
  )
}
