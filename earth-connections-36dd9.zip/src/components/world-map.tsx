import { useEffect, useRef } from 'react'

interface MapPoint {
  lat: number
  lon: number
  intensity: number
}

function isLand(lat: number, lon: number): boolean {
  if (lat > 30 && lat < 70 && lon > -165 && lon < -55) return true
  if (lat > 15 && lat < 30 && lon > -110 && lon < -75) return true
  if (lat > 7 && lat < 18 && lon > -92 && lon < -77) return true
  if (lat > -55 && lat < 12 && lon > -82 && lon < -35) return true
  if (lat > 36 && lat < 71 && lon > -10 && lon < 40) return true
  if (lat > 55 && lat < 65 && lon > -25 && lon < -5) return true
  if (lat > -35 && lat < 36 && lon > -18 && lon < 52) return true
  if (lat > 12 && lat < 42 && lon > 35 && lon < 60) return true
  if (lat > 5 && lat < 75 && lon > 40 && lon < 145) return true
  if (lat > 8 && lat < 35 && lon > 68 && lon < 90) return true
  if (lat > -10 && lat < 25 && lon > 95 && lon < 140) return true
  if (lat > 30 && lat < 46 && lon > 130 && lon < 146) return true
  if (lat > -40 && lat < -10 && lon > 113 && lon < 154) return true
  if (lat > -47 && lat < -34 && lon > 166 && lon < 178) return true
  if (lat > 60 && lat < 84 && lon > -55 && lon < -20) return true
  if (lat < -65) return true
  return false
}

export function WorldMap({ points, color = '#14B8A6' }: { points: MapPoint[]; color?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animId: number
    let time = 0

    const render = () => {
      const w = canvas.width
      const h = canvas.height
      time += 0.03

      ctx.fillStyle = '#0a0f1e'
      ctx.fillRect(0, 0, w, h)

      ctx.strokeStyle = 'rgba(20, 184, 166, 0.06)'
      ctx.lineWidth = 1
      for (let lon = -180; lon <= 180; lon += 30) {
        const x = ((lon + 180) / 360) * w
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, h)
        ctx.stroke()
      }
      for (let lat = -90; lat <= 90; lat += 30) {
        const y = ((90 - lat) / 180) * h
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(w, y)
        ctx.stroke()
      }

      ctx.fillStyle = 'rgba(34, 197, 94, 0.12)'
      for (let lat = -60; lat <= 80; lat += 4) {
        for (let lon = -180; lon <= 180; lon += 4) {
          if (isLand(lat, lon)) {
            const x = ((lon + 180) / 360) * w
            const y = ((90 - lat) / 180) * h
            ctx.beginPath()
            ctx.arc(x, y, 1.2, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      }

      points.forEach((pt, i) => {
        const x = ((pt.lon + 180) / 360) * w
        const y = ((90 - pt.lat) / 180) * h
        const pulse = Math.sin(time + i * 0.7) * 0.3 + 0.7
        const radius = Math.max(2, (3 + pt.intensity * 4) * pulse)
        const grad = ctx.createRadialGradient(x, y, 0, x, y, radius * 3)
        grad.addColorStop(0, color)
        grad.addColorStop(1, 'rgba(0,0,0,0)')
        ctx.globalAlpha = 0.5
        ctx.fillStyle = grad
        ctx.beginPath()
        ctx.arc(x, y, radius * 3, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1
        ctx.fillStyle = color
        ctx.beginPath()
        ctx.arc(x, y, Math.max(1, radius * 0.4), 0, Math.PI * 2)
        ctx.fill()
      })

      animId = requestAnimationFrame(render)
    }

    render()
    return () => cancelAnimationFrame(animId)
  }, [points, color])

  return (
    <div className="relative rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden">
      <canvas ref={canvasRef} width={800} height={400} className="w-full h-[280px] md:h-[340px]" />
      <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-full text-[10px] text-teal-400 font-mono border border-slate-700">
        <span className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-pulse" /> LIVE
      </div>
      <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-full text-[10px] text-slate-400 font-mono border border-slate-700">
        Equirectangular • NASA EarthData
      </div>
    </div>
  )
}
