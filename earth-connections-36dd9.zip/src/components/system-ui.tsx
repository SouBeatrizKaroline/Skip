import {
  type LucideIcon,
  Flame,
  Trees,
  Wind,
  Thermometer,
  Waves,
  Snowflake,
  CloudFog,
  Droplets,
  Bird,
  Zap,
  Factory,
  CloudRain,
  Mountain,
  Globe,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const iconMap: Record<string, LucideIcon> = {
  Flame,
  Trees,
  Wind,
  Thermometer,
  Waves,
  Snowflake,
  CloudFog,
  Droplets,
  Bird,
  Zap,
  Factory,
  CloudRain,
  Mountain,
  Globe,
}

export function getIcon(name: string): LucideIcon {
  return iconMap[name] || Globe
}

export function SystemHero({
  title,
  description,
  iconName,
  color,
  badge = 'NASA Earth Science',
}: {
  title: string
  description: string
  iconName: string
  color: string
  badge?: string
}) {
  const Icon = getIcon(iconName)
  return (
    <section className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 md:p-10 animate-fade-in-down">
      <div
        className="absolute inset-0 opacity-10"
        style={{ background: `radial-gradient(circle at 30% 50%, ${color}, transparent 60%)` }}
      />
      <div className="relative z-10 space-y-3">
        <div
          className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold"
          style={{ backgroundColor: `${color}20`, color }}
        >
          <Icon className="h-3.5 w-3.5" />
          <span>{badge}</span>
        </div>
        <h1 className="text-2xl md:text-4xl font-bold font-display text-white">{title}</h1>
        <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">{description}</p>
      </div>
    </section>
  )
}

export function MetricCard({
  iconName,
  label,
  value,
  trend,
  color,
}: {
  iconName: string
  label: string
  value: string
  trend: string
  color: string
}) {
  const Icon = getIcon(iconName)
  const isUp = trend.startsWith('+')
  const TrendIcon = isUp ? TrendingUp : trend.startsWith('-') ? TrendingDown : Minus
  return (
    <div className="rounded-2xl border border-slate-800 bg-card p-4 space-y-2 hover:border-slate-700 transition-colors animate-fade-in-up">
      <div className="flex items-center justify-between">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${color}15`, color }}
        >
          <Icon className="h-4 w-4" />
        </div>
        <div
          className={cn(
            'flex items-center gap-0.5 text-xs font-semibold',
            isUp ? 'text-red-400' : trend.startsWith('-') ? 'text-green-400' : 'text-slate-400',
          )}
        >
          <TrendIcon className="h-3 w-3" />
          {trend}
        </div>
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-xl font-bold font-mono">{value}</p>
      </div>
    </div>
  )
}

export function MetricGrid({
  metrics,
}: {
  metrics: Array<{ icon: string; label: string; value: string; trend: string; color: string }>
}) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {metrics.map((m, i) => (
        <MetricCard
          key={i}
          iconName={m.icon}
          label={m.label}
          value={m.value}
          trend={m.trend}
          color={m.color}
        />
      ))}
    </div>
  )
}

export function RankingList({
  ranking,
  color = '#14B8A6',
  title = 'Ranking de Países',
}: {
  ranking: Array<{ country: string; value: string; pct: number }>
  color?: string
  title?: string
}) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-card p-4 space-y-3">
      <h3 className="text-sm font-bold text-white">{title}</h3>
      <div className="space-y-2.5">
        {ranking.map((item, i) => (
          <div key={i} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">
                <span className="text-slate-500 mr-1.5">{i + 1}.</span>
                {item.country}
              </span>
              <span className="font-mono text-slate-400">{item.value}</span>
            </div>
            <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${item.pct}%`, backgroundColor: color }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function InfoPanel({
  title,
  items,
}: {
  title: string
  items: Array<{ label: string; value: string }>
}) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-card p-4 space-y-2">
      <h3 className="text-sm font-bold text-white">{title}</h3>
      <div className="space-y-1.5">
        {items.map((item, i) => (
          <div key={i} className="flex justify-between gap-2 text-xs">
            <span className="text-slate-400">{item.label}</span>
            <span className="text-slate-200 font-medium text-right">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function FilterTabs({
  tabs,
  active,
  onChange,
}: {
  tabs: string[]
  active: string
  onChange: (v: string) => void
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {tabs.map((tab) => (
        <button
          key={tab}
          onClick={() => onChange(tab)}
          className={cn(
            'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all',
            active === tab
              ? 'bg-teal-600 text-white shadow-lg'
              : 'bg-muted text-muted-foreground hover:bg-muted/80',
          )}
        >
          {tab}
        </button>
      ))}
    </div>
  )
}
