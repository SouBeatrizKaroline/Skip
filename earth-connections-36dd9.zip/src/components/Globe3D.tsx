import { useEffect, useRef } from 'react'

interface Globe3DProps {
  activeLayer?: string
}

export function Globe3D({ activeLayer = 'fires' }: Globe3DProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animId: number
    let rotation = 0

    const render = () => {
      const width = canvas.width
      const height = canvas.height
      const radius = Math.min(width, height) * 0.35
      const centerX = width / 2
      const centerY = height / 2

      ctx.clearRect(0, 0, width, height)

      // Outer glow
      const glowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        radius * 0.8,
        centerX,
        centerY,
        radius * 1.3,
      )
      glowGrad.addColorStop(0, 'rgba(20, 184, 166, 0.2)')
      glowGrad.addColorStop(1, 'rgba(11, 29, 58, 0)')
      ctx.fillStyle = glowGrad
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * 1.3, 0, Math.PI * 2)
      ctx.fill()

      // Earth body
      const oceanGrad = ctx.createRadialGradient(
        centerX - radius * 0.3,
        centerY - radius * 0.3,
        radius * 0.1,
        centerX,
        centerY,
        radius,
      )
      oceanGrad.addColorStop(0, '#1E40AF')
      oceanGrad.addColorStop(0.7, '#0F172A')
      oceanGrad.addColorStop(1, '#020617')
      ctx.fillStyle = oceanGrad
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fill()

      // Continents (procedural dots / latitude longitude grid)
      rotation += 0.005
      ctx.fillStyle = 'rgba(34, 197, 94, 0.4)'

      for (let lat = -60; lat <= 60; lat += 15) {
        for (let lon = 0; lon < 360; lon += 20) {
          const radLat = (lat * Math.PI) / 180
          const radLon = ((lon + rotation * 50) * Math.PI) / 180

          const x = radius * Math.cos(radLat) * Math.sin(radLon)
          const y = radius * Math.sin(radLat)
          const z = radius * Math.cos(radLat) * Math.cos(radLon)

          if (z > 0) {
            ctx.beginPath()
            ctx.arc(centerX + x, centerY - y, 2.5, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      }

      // Layer overlays
      if (activeLayer === 'fires') {
        ctx.fillStyle = '#F97316'
        for (let i = 0; i < 8; i++) {
          const angle = rotation * 2 + i
          const fx = centerX + Math.cos(angle) * (radius * 0.6)
          const fy = centerY + Math.sin(angle) * (radius * 0.6)
          ctx.beginPath()
          ctx.arc(fx, fy, 4, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      animId = requestAnimationFrame(render)
    }

    render()
    return () => cancelAnimationFrame(animId)
  }, [activeLayer])

  return (
    <div className="relative w-full h-[400px] flex items-center justify-center bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      <canvas ref={canvasRef} width={600} height={400} className="w-full h-full object-cover" />
      <div className="absolute bottom-3 left-4 bg-slate-900/80 backdrop-blur px-3 py-1 rounded-full text-xs text-teal-400 font-mono border border-slate-700">
        ● Globo Interativo NASA Earth
      </div>
    </div>
  )
}
