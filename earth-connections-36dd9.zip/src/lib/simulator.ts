export interface SimParams {
  co2: number
  deforestation: number
  renewableEnergy: number
  industrialEmissions: number
  populationGrowth: number
  reforestation: number
}

export interface SimResults {
  atmosphericCO2: number
  tempIncrease: number
  seaLevelRise: number
  biodiversityLoss: number
  extremeEvents: number
  oceanAcidification: number
}

export const CURRENT_SCENARIO: SimParams = {
  co2: 421,
  deforestation: 25,
  renewableEnergy: 20,
  industrialEmissions: 70,
  populationGrowth: 1.1,
  reforestation: 5,
}

export const PREDEFINED_SCENARIOS: Record<string, SimParams> = {
  paris: {
    co2: 450,
    deforestation: 10,
    renewableEnergy: 70,
    industrialEmissions: 30,
    populationGrowth: 0.5,
    reforestation: 50,
  },
  trend: {
    co2: 550,
    deforestation: 30,
    renewableEnergy: 30,
    industrialEmissions: 60,
    populationGrowth: 1.0,
    reforestation: 10,
  },
  worst: {
    co2: 800,
    deforestation: 70,
    renewableEnergy: 10,
    industrialEmissions: 90,
    populationGrowth: 2.0,
    reforestation: 0,
  },
}

export const SLIDER_CONFIG: Array<{
  key: keyof SimParams
  min: number
  max: number
  step: number
  unit: string
}> = [
  { key: 'co2', min: 280, max: 1000, step: 5, unit: 'ppm' },
  { key: 'deforestation', min: 0, max: 100, step: 1, unit: '%' },
  { key: 'renewableEnergy', min: 0, max: 100, step: 1, unit: '%' },
  { key: 'industrialEmissions', min: 0, max: 100, step: 1, unit: '%' },
  { key: 'populationGrowth', min: 0, max: 3, step: 0.1, unit: '%' },
  { key: 'reforestation', min: 0, max: 100, step: 1, unit: '%' },
]

export function computeResults(p: SimParams): SimResults {
  const atmosphericCO2 = Math.round(
    p.co2 - p.reforestation * 0.5 + p.industrialEmissions * 0.3 + p.populationGrowth * 10,
  )
  const tempIncrease = parseFloat(
    ((atmosphericCO2 - 280) * 0.01 + p.deforestation * 0.01 - p.renewableEnergy * 0.005).toFixed(2),
  )
  const seaLevelRise = parseFloat((tempIncrease * 25).toFixed(1))
  const biodiversityLoss = Math.min(
    100,
    parseFloat((tempIncrease * 8 + p.deforestation * 0.3).toFixed(1)),
  )
  const extremeEvents = parseFloat((1 + tempIncrease * 0.4).toFixed(2))
  const oceanAcidification = parseFloat(((atmosphericCO2 - 280) * 0.0007).toFixed(3))
  return {
    atmosphericCO2,
    tempIncrease,
    seaLevelRise,
    biodiversityLoss,
    extremeEvents,
    oceanAcidification,
  }
}

export function getRiskLevel(temp: number): {
  label: string
  color: string
  value: number
  desc: string
} {
  if (temp < 1.5)
    return {
      label: 'Baixo',
      color: 'text-green-400',
      value: 20,
      desc: 'Cenário dentro dos limites do Acordo de Paris.',
    }
  if (temp < 2.5)
    return {
      label: 'Moderado',
      color: 'text-yellow-400',
      value: 45,
      desc: 'Risco moderado — ações climáticas urgentes necessárias.',
    }
  if (temp < 3.5)
    return {
      label: 'Alto',
      color: 'text-orange-400',
      value: 70,
      desc: 'Risco alto — eventos extremos se tornarão frequentes.',
    }
  return {
    label: 'Crítico',
    color: 'text-red-400',
    value: 95,
    desc: 'Risco crítico — mudanças irreversíveis no sistema climático.',
  }
}

export function buildChartData(r: SimResults) {
  return Array.from({ length: 8 }, (_, i) => {
    const year = 2025 + i * 10
    const factor = 0.3 + i * 0.15
    return {
      year,
      temp: parseFloat((r.tempIncrease * factor).toFixed(2)),
      seaLevel: parseFloat((r.seaLevelRise * (0.2 + factor * 0.8)).toFixed(1)),
    }
  })
}
