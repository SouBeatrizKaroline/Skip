import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/use-auth'
import { toast } from '@/hooks/use-toast'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const { requestPasswordReset } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await requestPasswordReset(email)
    setSubmitted(true)
    toast({ title: 'Solicitação enviada!' })
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md p-8 rounded-2xl bg-card border border-border shadow-xl space-y-6">
        <h1 className="text-2xl font-bold font-display text-center">Recuperar Senha</h1>
        {submitted ? (
          <p className="text-sm text-muted-foreground text-center">
            Se o e-mail existir na nossa base, enviaremos um link para redefinição de senha.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>E-mail cadastrado</Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="seu@email.com"
              />
            </div>
            <Button type="submit" className="w-full bg-teal-600">
              Enviar Link de Recuperação
            </Button>
          </form>
        )}
      </div>
    </div>
  )
}
