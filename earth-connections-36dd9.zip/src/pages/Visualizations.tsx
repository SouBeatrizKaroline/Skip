import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Map, Layers, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'

export default function Visualizations() {
  const [dataset, setDataset] = useState('wildfires')

  return (
    <div className="container mx-auto py-8 px-4 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border pb-4">
        <div>
          <h1 className="text-2xl font-bold font-display">Explorador Global de Dados Climáticos</h1>
          <p className="text-xs text-muted-foreground">
            Satélites NASA, ESA e NOAA em tempo quase real
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={dataset} onValueChange={setDataset}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="wildfires">Queimadas (FIRMS)</SelectItem>
              <SelectItem value="deforestation">Desmatamento (Landsat)</SelectItem>
              <SelectItem value="air-quality">Qualidade do Ar (Sentinel-5P)</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" asChild>
            <Link to="/visualizations/globe">
              <Map className="h-4 w-4 mr-2" />
              Modo Globo 3D
            </Link>
          </Button>
        </div>
      </div>

      <div className="relative h-[500px] bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center text-slate-400 font-mono text-sm overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-950" />
        <div className="relative z-10 text-center space-y-3">
          <Layers className="h-12 w-12 text-teal-400 mx-auto animate-pulse" />
          <div>
            Visualização de Camada Ativa:{' '}
            <span className="text-teal-400 font-bold">{dataset.toUpperCase()}</span>
          </div>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Carregando mapa de calor de satélite e camada espacial interativa...
          </p>
        </div>
      </div>
    </div>
  )
}
