import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { SystemHero, MetricGrid, FilterTabs, RankingList, InfoPanel } from '@/components/system-ui'
import { WorldMap } from '@/components/world-map'
import { TimelineAreaChart } from '@/components/system-charts'
import { getEarthSystemBySlug, EarthSystem } from '@/services/earth-systems'
import { getSystemData } from '@/services/system-data'
import { SystemNetworkGraph } from '@/components/SystemNetworkGraph'

export default function EarthSystemDetail() {
  const { slug } = useParams<{ slug: string }>()
  const [system, setSystem] = useState<EarthSystem | null>(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('7 dias')

  useEffect(() => {
    if (slug) {
      setLoading(true)
      getEarthSystemBySlug(slug)
        .then(setSystem)
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [slug])

  const sysData = slug ? getSystemData(slug) : null

  if (loading) {
    return (
      <div className="container mx-auto py-8 px-4 space-y-6">
        <div className="h-32 rounded-3xl bg-muted animate-pulse" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-24 rounded-2xl bg-muted animate-pulse" />
          ))}
        </div>
        <div className="h-[340px] rounded-2xl bg-muted animate-pulse" />
      </div>
    )
  }

  if (!system) {
    return (
      <div className="container mx-auto py-20 text-center space-y-4">
        <p className="text-muted-foreground">Sistema não encontrado.</p>
        <Link to="/" className="text-teal-600 hover:underline">
          ← Voltar ao início
        </Link>
      </div>
    )
  }

  if (!sysData) {
    return (
      <div className="container mx-auto py-8 px-4 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold font-display">{system.title_pt}</h1>
          <p className="text-sm text-muted-foreground max-w-2xl">{system.summary_pt}</p>
        </div>
        <SystemNetworkGraph />
      </div>
    )
  }

  const color = system.color || '#14B8A6'
  const iconName = system.icon || 'Globe'

  return (
    <div className="container mx-auto py-6 px-4 space-y-6">
      <SystemHero
        title={system.title_pt}
        description={system.summary_pt || ''}
        iconName={iconName}
        color={color}
      />

      <MetricGrid metrics={sysData.metrics} />

      <div className="flex items-center justify-between flex-wrap gap-3">
        <FilterTabs
          tabs={['Hoje', '7 dias', '30 dias', '1 ano']}
          active={filter}
          onChange={setFilter}
        />
        <span className="text-xs text-muted-foreground font-mono">Atualizado: agora</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <WorldMap points={sysData.mapPoints} color={color} />
          <TimelineAreaChart data={sysData.timeline} color={color} />
        </div>
        <div className="space-y-4">
          <RankingList ranking={sysData.ranking} color={color} />
          {sysData.sidebar.map((panel, i) => (
            <InfoPanel key={i} title={panel.title} items={panel.items} />
          ))}
        </div>
      </div>
    </div>
  )
}
