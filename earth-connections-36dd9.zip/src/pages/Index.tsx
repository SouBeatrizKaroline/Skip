import { useContext } from 'react'
import { Link } from 'react-router-dom'
import { Globe, ArrowRight, ShieldCheck, Cpu, Award, Play } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Globe3D } from '@/components/Globe3D'
import { EarthSystemsGrid } from '@/components/EarthSystemsGrid'
import { I18nContext } from '@/hooks/use-i18n'

export default function Index() {
  const { t } = useContext(I18nContext)

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center bg-gradient-to-b from-slate-950 via-[#0B1D3A] to-background text-white px-4 overflow-hidden">
        <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center z-10 pt-8">
          <div className="space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/30 text-xs font-semibold">
              <Globe className="h-3.5 w-3.5" />
              <span>Global Nominee — NASA Space Apps Challenge 2024</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight font-display leading-tight">
              {t('tagline')}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              {t('subtagline')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="bg-gradient-to-r from-teal-500 to-green-500 hover:from-teal-600 hover:to-green-600 text-white font-semibold shadow-lg shadow-teal-500/20"
                asChild
              >
                <Link to="/visualizations">
                  {t('explorePlanet')} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-700 text-white hover:bg-slate-800"
                asChild
              >
                <Link to="/signup">{t('startLearning')}</Link>
              </Button>
            </div>
          </div>

          <div className="w-full max-w-md mx-auto">
            <Globe3D activeLayer="fires" />
          </div>
        </div>
      </section>

      {/* Earth Systems Section */}
      <section className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl font-bold font-display mb-3">{t('systems')}</h2>
          <p className="text-sm text-muted-foreground">
            Acompanhe os 10 indicadores vitais do planeta alimentados por dados contínuos de
            satélites da NASA.
          </p>
        </div>
        <EarthSystemsGrid />
      </section>

      {/* Simulator Teaser */}
      <section className="container mx-auto px-4">
        <div className="bg-card border border-border/80 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="space-y-4 max-w-lg">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-teal-500 bg-teal-500/10 px-2.5 py-0.5 rounded-full">
              <Cpu className="h-3.5 w-3.5" />
              <span>Simulador Climático Interativo</span>
            </div>
            <h3 className="text-2xl md:text-3xl font-bold font-display">
              Simule cenários futuros para a Terra
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Ajuste níveis de CO₂, taxa de desmatamento e matriz energética para visualizar as
              projeções de aquecimento e elevação do nível do mar.
            </p>
            <Button className="bg-teal-600 hover:bg-teal-700" asChild>
              <Link to="/simulator">
                Abrir Simulador Climático <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="w-full md:w-1/2 h-48 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
            [ Animação do Simulador de Clima ]
          </div>
        </div>
      </section>
    </div>
  )
}
