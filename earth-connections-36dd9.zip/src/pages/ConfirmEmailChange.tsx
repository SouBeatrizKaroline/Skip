import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'

export default function ConfirmEmailChange() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="text-center space-y-4 p-8 bg-card border border-border rounded-2xl max-w-md">
        <h1 className="text-2xl font-bold font-display">Alteração de E-mail</h1>
        <p className="text-sm text-muted-foreground">
          Seu e-mail foi alterado com sucesso. Faça login novamente para continuar.
        </p>
        <Button asChild className="bg-teal-600">
          <Link to="/signin">Fazer Login</Link>
        </Button>
      </div>
    </div>
  )
}
