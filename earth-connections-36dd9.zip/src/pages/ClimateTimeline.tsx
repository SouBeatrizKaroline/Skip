import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'

const milestones = [
  {
    year: 1850,
    title: 'Era Pré-Industrial',
    desc: 'Início da contagem histórica de emissões globais de carbono.',
  },
  {
    year: 1958,
    title: 'Início das Medições em Mauna Loa',
    desc: 'Primeiras medições diretas e contínuas de CO₂ atmosférico por Charles Keeling.',
  },
  {
    year: 1972,
    title: 'Lançamento do Satélite Landsat 1',
    desc: 'Primeiro programa da NASA de monitoramento contínuo da superfície terrestre por espaço.',
  },
  {
    year: 2015,
    title: 'Acordo de Paris',
    desc: 'Tratado internacional para conter o aumento da temperatura média global abaixo de 2°C.',
  },
  {
    year: 2025,
    title: 'Hoje — Era do Monitoramento em Tempo Real',
    desc: 'Satélites modernos como TEMPO e Sentinel fornecem dados diários de emissões e ar.',
  },
]

export default function ClimateTimeline() {
  const [selected, setSelected] = useState(milestones[3])

  return (
    <div className="container mx-auto py-8 px-4 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold font-display">Linha do Tempo Climática e Espacial</h1>
        <p className="text-sm text-muted-foreground">
          Marcos históricos da ciência do clima e da observação da Terra da NASA
        </p>
      </div>

      <div className="flex overflow-x-auto gap-4 py-4 border-b border-border">
        {milestones.map((m) => (
          <button
            key={m.year}
            onClick={() => setSelected(m)}
            className={`px-5 py-2.5 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
              selected.year === m.year
                ? 'bg-teal-600 text-white shadow-lg'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            {m.year}
          </button>
        ))}
      </div>

      <Card className="max-w-2xl mx-auto p-6 space-y-4 border-teal-500/30">
        <CardHeader className="p-0">
          <span className="text-xs font-mono text-teal-600 font-bold">{selected.year}</span>
          <CardTitle className="text-xl">{selected.title}</CardTitle>
        </CardHeader>
        <CardContent className="p-0 text-sm text-muted-foreground leading-relaxed">
          {selected.desc}
        </CardContent>
      </Card>
    </div>
  )
}
