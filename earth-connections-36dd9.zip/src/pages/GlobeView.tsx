import { useState } from 'react'
import { Globe3D } from '@/components/Globe3D'
import { Button } from '@/components/ui/button'

export default function GlobeView() {
  const [layer, setLayer] = useState('fires')

  return (
    <div className="container mx-auto py-8 px-4 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold font-display">Globo Interativo NASA 3D</h1>
          <p className="text-xs text-muted-foreground">
            Alterne camadas de observação espacial da Terra
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={layer === 'fires' ? 'default' : 'outline'}
            onClick={() => setLayer('fires')}
          >
            Queimadas
          </Button>
          <Button
            size="sm"
            variant={layer === 'temp' ? 'default' : 'outline'}
            onClick={() => setLayer('temp')}
          >
            Temperatura
          </Button>
          <Button
            size="sm"
            variant={layer === 'ice' ? 'default' : 'outline'}
            onClick={() => setLayer('ice')}
          >
            Gelo Polar
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        <Globe3D activeLayer={layer} />
      </div>
    </div>
  )
}
