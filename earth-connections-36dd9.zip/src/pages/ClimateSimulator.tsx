import { useState, useMemo, useCallback } from 'react'
import { Slider } from '@/components/ui/slider'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/hooks/use-auth'
import { saveSimulation } from '@/services/simulations'
import { toast } from '@/hooks/use-toast'
import { SimulatorGlobe } from '@/components/SimulatorGlobe'
import { ChartContainer, type ChartConfig } from '@/components/ui/chart'
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from 'recharts'
import { RefreshCw, Share2, Thermometer, Waves, Bird, Zap, Cloud, FlaskConical } from 'lucide-react'
import {
  type SimParams,
  CURRENT_SCENARIO,
  PREDEFINED_SCENARIOS,
  SLIDER_CONFIG,
  computeResults,
  getRiskLevel,
  buildChartData,
} from '@/lib/simulator'

const SLIDER_LABELS: Record<string, string> = {
  co2: 'Concentração de CO₂',
  deforestation: 'Desmatamento Anual',
  renewableEnergy: 'Energia Renovável',
  industrialEmissions: 'Emissões Industriais',
  populationGrowth: 'Crescimento Populacional',
  reforestation: 'Reflorestamento Anual',
}

export default function ClimateSimulator() {
  const { user, isAuthenticated } = useAuth()
  const [params, setParams] = useState<SimParams>(CURRENT_SCENARIO)

  const results = useMemo(() => computeResults(params), [params])
  const risk = useMemo(() => getRiskLevel(results.tempIncrease), [results.tempIncrease])
  const chartData = useMemo(() => buildChartData(results), [results])

  const updateParam = useCallback((key: keyof SimParams, value: number) => {
    setParams((prev) => ({ ...prev, [key]: value }))
  }, [])

  const handleRestore = () => setParams(CURRENT_SCENARIO)
  const handleScenario = (key: string) => {
    const s = PREDEFINED_SCENARIOS[key]
    if (s) setParams(s)
  }

  const handleShare = () => {
    const text = `Earth Connections: +${results.tempIncrease}°C, +${results.seaLevelRise}cm mar, ${results.biodiversityLoss}% bio`
    if (navigator.share) {
      navigator.share({ title: 'Minha Simulação Climática', text })
    } else {
      navigator.clipboard.writeText(text)
      toast({ title: 'Resultados copiados!' })
    }
  }

  const handleSave = async () => {
    if (!isAuthenticated || !user) {
      toast({ title: 'Atenção', description: 'Faça login para salvar seus cenários.' })
      return
    }
    await saveSimulation(user.id, {
      name: `Cenário CO₂ ${params.co2}ppm`,
      variables: params,
      scenarioResults: results,
    })
    toast({ title: 'Cenário salvo no perfil!' })
  }

  const resultCards = [
    {
      icon: Thermometer,
      label: 'Aumento de Temperatura',
      value: `+${results.tempIncrease}`,
      unit: '°C',
      color: 'text-amber-500',
    },
    {
      icon: Waves,
      label: 'Elevação do Nível do Mar',
      value: `+${results.seaLevelRise}`,
      unit: 'cm',
      color: 'text-blue-400',
    },
    {
      icon: Bird,
      label: 'Perda de Biodiversidade',
      value: `${results.biodiversityLoss}`,
      unit: '%',
      color: 'text-red-400',
    },
    {
      icon: Zap,
      label: 'Eventos Extremos',
      value: `${results.extremeEvents}`,
      unit: 'x',
      color: 'text-orange-400',
    },
    {
      icon: Cloud,
      label: 'CO₂ Atmosférico',
      value: `${results.atmosphericCO2}`,
      unit: 'ppm',
      color: 'text-purple-400',
    },
    {
      icon: FlaskConical,
      label: 'Acidificação Oceânica',
      value: `-${results.oceanAcidification}`,
      unit: 'pH',
      color: 'text-cyan-400',
    },
  ]

  const comparisons = [
    { label: 'Cenário Atual', temp: 1.2, sea: 21, bio: 15 },
    {
      label: 'Projeção 2050',
      temp: parseFloat((results.tempIncrease * 0.6).toFixed(2)),
      sea: parseFloat((results.seaLevelRise * 0.5).toFixed(1)),
      bio: parseFloat((results.biodiversityLoss * 0.6).toFixed(1)),
    },
    {
      label: 'Projeção 2100',
      temp: results.tempIncrease,
      sea: results.seaLevelRise,
      bio: results.biodiversityLoss,
    },
  ]

  const chartConfig = {
    temp: { label: 'Temperatura (°C)', color: 'hsl(var(--chart-1))' },
    seaLevel: { label: 'Nível do Mar (cm)', color: 'hsl(var(--chart-2))' },
  } satisfies ChartConfig

  return (
    <div className="container mx-auto py-8 px-4 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold font-display">Simulador Climático Interativo</h1>
        <p className="text-sm text-muted-foreground max-w-xl">
          Ajuste variáveis globais e observe os impactos na temperatura, nível do mar e ecossistemas
          terrestres.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 space-y-5">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <FlaskConical className="h-5 w-5 text-teal-500" /> Parâmetros de Entrada
          </h2>
          {SLIDER_CONFIG.map((s) => (
            <div key={s.key} className="space-y-2">
              <div className="flex justify-between text-sm font-medium">
                <span>{SLIDER_LABELS[s.key]}</span>
                <span className="text-teal-600 font-bold">
                  {params[s.key]} {s.unit}
                </span>
              </div>
              <Slider
                value={[params[s.key]]}
                min={s.min}
                max={s.max}
                step={s.step}
                onValueChange={(v) => updateParam(s.key, v[0])}
              />
            </div>
          ))}
          <div className="flex flex-wrap gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={handleRestore}>
              <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Restaurar
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleScenario('paris')}>
              Acordo de Paris
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleScenario('trend')}>
              Tendência Atual
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleScenario('worst')}>
              Pior Cenário
            </Button>
          </div>
          <div className="flex gap-2">
            <Button className="flex-1 bg-teal-600 hover:bg-teal-700" onClick={handleSave}>
              Salvar Cenário
            </Button>
            <Button variant="outline" onClick={handleShare}>
              <Share2 className="h-4 w-4 mr-1.5" /> Compartilhar
            </Button>
          </div>
        </Card>

        <SimulatorGlobe
          tempIncrease={results.tempIncrease}
          co2={params.co2}
          deforestation={params.deforestation}
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {resultCards.map((r, i) => (
          <Card key={i} className="p-4 space-y-2 animate-fade-in-up">
            <r.icon className={`h-5 w-5 ${r.color}`} />
            <p className="text-xs text-muted-foreground">{r.label}</p>
            <p className={`text-2xl font-bold font-mono ${r.color}`}>{r.value}</p>
            <p className="text-xs text-muted-foreground">{r.unit}</p>
          </Card>
        ))}
      </div>

      <Card className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">Nível de Risco</h2>
          <Badge variant="outline" className={`text-sm font-bold ${risk.color}`}>
            {risk.label}
          </Badge>
        </div>
        <Progress value={risk.value} className="h-3" />
        <p className="text-xs text-muted-foreground">{risk.desc}</p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-4 space-y-3">
          <h3 className="text-sm font-bold">Projeção de Temperatura (°C)</h3>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <AreaChart data={chartData} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
              <defs>
                <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tickLine={false} axisLine={false} tick={{ fontSize: 11 }} />
              <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11 }} width={30} />
              <Area
                type="monotone"
                dataKey="temp"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                fill="url(#tempGrad)"
              />
            </AreaChart>
          </ChartContainer>
        </Card>
        <Card className="p-4 space-y-3">
          <h3 className="text-sm font-bold">Projeção do Nível do Mar (cm)</h3>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <AreaChart data={chartData} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
              <defs>
                <linearGradient id="seaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-2))" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(var(--chart-2))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tickLine={false} axisLine={false} tick={{ fontSize: 11 }} />
              <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11 }} width={30} />
              <Area
                type="monotone"
                dataKey="seaLevel"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                fill="url(#seaGrad)"
              />
            </AreaChart>
          </ChartContainer>
        </Card>
      </div>

      <Card className="p-6">
        <h2 className="text-lg font-bold mb-4">Comparação de Cenários</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {comparisons.map((s, i) => (
            <div key={i} className="rounded-xl border border-border p-4 space-y-2">
              <h3 className="font-bold text-sm">{s.label}</h3>
              <div className="space-y-1 text-xs text-muted-foreground">
                <p>
                  🌡 Temp: <span className="font-mono text-amber-500">+{s.temp}°C</span>
                </p>
                <p>
                  🌊 Mar: <span className="font-mono text-blue-400">+{s.sea}cm</span>
                </p>
                <p>
                  🦜 Bio: <span className="font-mono text-red-400">{s.bio}%</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
