import { Link } from 'react-router-dom'
import { CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function VerifyEmail() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="text-center space-y-4 p-8 bg-card border border-border rounded-2xl max-w-md">
        <CheckCircle className="h-12 w-12 text-teal-500 mx-auto" />
        <h1 className="text-2xl font-bold font-display">Verificação de E-mail</h1>
        <p className="text-sm text-muted-foreground">
          E-mail verificado com sucesso. Você já pode acessar todas as funcionalidades da
          plataforma.
        </p>
        <Button asChild className="bg-teal-600">
          <Link to="/dashboard">Ir para o Dashboard</Link>
        </Button>
      </div>
    </div>
  )
}
