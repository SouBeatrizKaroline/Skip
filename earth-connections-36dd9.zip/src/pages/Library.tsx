import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { getArticles, getGlossaryTerms, Article, GlossaryTerm } from '@/services/articles'
import { BookOpen, HelpCircle } from 'lucide-react'

export default function Library() {
  const [articles, setArticles] = useState<Article[]>([])
  const [terms, setTerms] = useState<GlossaryTerm[]>([])

  useEffect(() => {
    getArticles().then((res) => setArticles(res as unknown as Article[]))
    getGlossaryTerms().then((res) => setTerms(res as unknown as GlossaryTerm[]))
  }, [])

  return (
    <div className="container mx-auto py-8 px-4 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold font-display">Biblioteca Científica Climática</h1>
        <p className="text-sm text-muted-foreground">
          Glossário, artigos e materiais educacionais produzidos com dados da NASA
        </p>
      </div>

      <Tabs defaultValue="articles" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-xs">
          <TabsTrigger value="articles">
            <BookOpen className="h-4 w-4 mr-2" />
            Artigos
          </TabsTrigger>
          <TabsTrigger value="glossary">
            <HelpCircle className="h-4 w-4 mr-2" />
            Glossário
          </TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {articles.length > 0 ? (
            articles.map((art) => (
              <Card key={art.id} className="hover:border-teal-500/50 transition-all">
                <CardHeader>
                  <span className="text-[10px] font-mono text-teal-600 uppercase tracking-wide">
                    {art.category}
                  </span>
                  <CardTitle className="text-base">{art.title_pt}</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-muted-foreground flex justify-between items-center">
                  <span>{art.reading_time || 5} min de leitura</span>
                  <Link
                    to={`/biblioteca/artigos/${art.id}`}
                    className="text-teal-600 font-semibold hover:underline"
                  >
                    Ler artigo →
                  </Link>
                </CardContent>
              </Card>
            ))
          ) : (
            <p className="text-xs text-muted-foreground col-span-2">Nenhum artigo encontrado.</p>
          )}
        </TabsContent>

        <TabsContent value="glossary" className="pt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          {terms.map((t) => (
            <Card key={t.id} className="p-4 space-y-2">
              <h3 className="font-bold text-sm text-teal-600">{t.term_pt}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{t.definition_pt}</p>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
