import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/use-auth'
import { toast } from '@/hooks/use-toast'

export default function SignIn() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { signIn } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await signIn(email, password)
    setLoading(false)
    if (error) {
      toast({
        title: 'Erro ao entrar',
        description: 'Credenciais inválidas ou e-mail não verificado.',
        variant: 'destructive',
      })
    } else {
      toast({ title: 'Bem-vindo de volta!' })
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md p-8 rounded-2xl bg-card border border-border shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold font-display">Entrar na plataforma</h1>
          <p className="text-xs text-muted-foreground">
            Acesse sua conta para ver progresso, conquistas e turmas
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="seu@email.com"
            />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <Label htmlFor="pass">Senha</Label>
              <Link to="/forgot-password" className="text-teal-600 hover:underline">
                Esqueceu a senha?
              </Link>
            </div>
            <Input
              id="pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700" disabled={loading}>
            {loading ? 'Entrando...' : 'Entrar'}
          </Button>
        </form>

        <div className="text-center text-xs text-muted-foreground pt-4 border-t border-border">
          Ainda não tem conta?{' '}
          <Link to="/signup" className="text-teal-600 font-semibold hover:underline">
            Criar conta
          </Link>
        </div>
      </div>
    </div>
  )
}
