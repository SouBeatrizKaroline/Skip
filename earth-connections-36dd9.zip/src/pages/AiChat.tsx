import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Send, Bot, User } from 'lucide-react'
import pb from '@/lib/pocketbase/client'
import { streamAgentChat } from '@/lib/skipAi'

export default function AiChat() {
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content:
        'Olá! Eu sou o Guia da Terra, seu assistente científico de IA. Como posso ajudar com dúvidas sobre o clima ou dados da NASA hoje?',
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSend = async () => {
    if (!input.trim() || loading) return

    const userMsg = input.trim()
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }])
    setLoading(true)

    try {
      const res = await fetch(`${import.meta.env.VITE_POCKETBASE_URL}/backend/v1/ask`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: pb.authStore.token,
        },
        body: JSON.stringify({ message: userMsg }),
      })

      let assistantContent = ''
      setMessages((prev) => [...prev, { role: 'assistant', content: '' }])

      await streamAgentChat(res, {
        onChunk: (_delta, full) => {
          assistantContent = full
          setMessages((prev) => {
            const next = [...prev]
            next[next.length - 1] = { role: 'assistant', content: full }
            return next
          })
        },
      })
    } catch (_) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Desculpe, não consegui processar a resposta no momento.' },
      ])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-2xl space-y-4">
      <div className="flex items-center gap-3 border-b border-border pb-4">
        <div className="h-10 w-10 rounded-full bg-purple-600/10 flex items-center justify-center text-purple-600">
          <Bot className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-xl font-bold font-display">Guia da Terra — IA Climática</h1>
          <p className="text-xs text-muted-foreground">
            Assistente respaldado por dados da NASA, ESA e NOAA
          </p>
        </div>
      </div>

      <Card className="h-[450px] p-4 flex flex-col justify-between space-y-4">
        <div className="flex-1 overflow-y-auto space-y-3 pr-2">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="h-7 w-7 rounded-full bg-purple-600/10 flex items-center justify-center text-purple-600 flex-shrink-0">
                  <Bot className="h-4 w-4" />
                </div>
              )}
              <div
                className={`p-3 rounded-2xl text-xs max-w-xs sm:max-w-md leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-teal-600 text-white rounded-br-none'
                    : 'bg-muted rounded-bl-none'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Pergunte sobre queimadas, temperatura, satélites..."
            className="text-xs"
          />
          <Button
            onClick={handleSend}
            disabled={loading}
            size="icon"
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </Card>
    </div>
  )
}
