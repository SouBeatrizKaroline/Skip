import { useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/use-auth'
import { toast } from '@/hooks/use-toast'

export default function ResetPassword() {
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token') || ''
  const [pass, setPass] = useState('')
  const { confirmPasswordReset } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await confirmPasswordReset(token, pass)
    if (!error) {
      toast({ title: 'Senha redefinida com sucesso!' })
      navigate('/signin')
    } else {
      toast({ title: 'Erro', description: 'Token inválido ou expirado.', variant: 'destructive' })
    }
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md p-8 rounded-2xl bg-card border border-border shadow-xl space-y-6">
        <h1 className="text-2xl font-bold font-display text-center">Redefinir Senha</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Nova Senha</Label>
            <Input
              type="password"
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" className="w-full bg-teal-600">
            Salvar Nova Senha
          </Button>
        </form>
      </div>
    </div>
  )
}
