import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import { useAuth } from '@/hooks/use-auth'
import { toast } from '@/hooks/use-toast'

export default function SignUp() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('student')
  const [loading, setLoading] = useState(false)
  const { signUp } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await signUp(email, password, name, role)
    setLoading(false)
    if (error) {
      toast({
        title: 'Erro ao cadastrar',
        description: 'Verifique se a senha tem pelo menos 8 caracteres.',
        variant: 'destructive',
      })
    } else {
      toast({ title: 'Conta criada com sucesso!' })
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md p-8 rounded-2xl bg-card border border-border shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold font-display">Criar conta gratuita</h1>
          <p className="text-xs text-muted-foreground">
            Junte-se à missão de educação climática da NASA
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome completo</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="Seu nome"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="seu@email.com"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pass">Senha (mínimo 8 caracteres)</Label>
            <Input
              id="pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          <div className="space-y-2">
            <Label>Perfil de uso</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="student">Estudante / Curioso</SelectItem>
                <SelectItem value="teacher">Professor(a)</SelectItem>
                <SelectItem value="school">Escola / Instituição</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700" disabled={loading}>
            {loading ? 'Cadastrando...' : 'Criar Conta'}
          </Button>
        </form>

        <div className="text-center text-xs text-muted-foreground pt-4 border-t border-border">
          Já possui uma conta?{' '}
          <Link to="/signin" className="text-teal-600 font-semibold hover:underline">
            Fazer login
          </Link>
        </div>
      </div>
    </div>
  )
}
