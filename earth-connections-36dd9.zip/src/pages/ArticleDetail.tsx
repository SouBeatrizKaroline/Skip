import { useState } from 'react'
import { useParams } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { simplifyArticleWithAI } from '@/services/ai-assistant'

export default function ArticleDetail() {
  const { id } = useParams<{ id: string }>()
  const [aiSummary, setAiSummary] = useState('')
  const [loadingAi, setLoadingAi] = useState(false)

  const sampleContent = `
    O monitoramento da atmosfera terrestre por satélites da NASA revolucionou nossa compreensão do ciclo global de carbono.
    Com instrumentos de alta precisão a bordo de espaçonaves em órbita, é possível mapear fontes e sumidouros de CO2 com resolução regional sem precedentes.
  `

  const handleSimplify = async () => {
    setLoadingAi(true)
    const summary = await simplifyArticleWithAI(sampleContent)
    setAiSummary(summary)
    setLoadingAi(false)
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-2xl space-y-6">
      <Card className="p-6 space-y-6">
        <CardHeader className="px-0 pt-0">
          <CardTitle className="text-2xl font-bold font-display">
            Monitoramento Espacial da Atmosfera
          </CardTitle>
          <span className="text-xs text-muted-foreground">
            Publicado com dados da missão NASA Earth Observatory
          </span>
        </CardHeader>

        <CardContent className="px-0 space-y-4 text-sm leading-relaxed">
          <p>{sampleContent}</p>
          <Button
            onClick={handleSimplify}
            variant="outline"
            className="w-full text-purple-600 border-purple-300 hover:bg-purple-50"
          >
            {loadingAi ? 'Gerando resumo inteligente...' : '✨ Resumir Artigo com IA'}
          </Button>

          {aiSummary && (
            <div className="p-4 bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-800 rounded-xl text-xs space-y-2">
              <h4 className="font-bold text-purple-700 dark:text-purple-300">
                Resumo Gerado pelo Guia da Terra:
              </h4>
              <p className="whitespace-pre-line text-muted-foreground">{aiSummary}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
