import { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getQuizQuestions, QuizQuestion, saveQuizAttempt } from '@/services/quizzes'
import { useAuth } from '@/hooks/use-auth'
import { addXP } from '@/services/gamification'
import { toast } from '@/hooks/use-toast'

export default function QuizHub() {
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [completed, setCompleted] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    getQuizQuestions().then((res) => {
      if (res.length > 0) {
        setQuestions(res as unknown as QuizQuestion[])
      } else {
        // Fallback demo question
        setQuestions([
          {
            id: '1',
            question_pt:
              'Qual principal gás de efeito estufa é monitorado pelo satélite NASA OCO-2?',
            options_pt: [
              'Dióxido de Carbono (CO₂)',
              'Oxigênio (O₂)',
              'Nitrogênio (N₂)',
              'Hélio (He)',
            ],
            correct_index: 0,
            explanation_pt: 'O OCO-2 mede com alta precisão o CO₂ na atmosfera terrestre.',
            difficulty: 'basic',
            xp: 20,
          },
        ])
      }
    })
  }, [])

  const handleSelect = (idx: number) => {
    if (selectedOption !== null) return
    setSelectedOption(idx)
    if (idx === questions[currentIndex].correct_index) {
      setScore((s) => s + 1)
    }
  }

  const handleNext = async () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((c) => c + 1)
      setSelectedOption(null)
    } else {
      setCompleted(true)
      if (user) {
        const xpEarned = score * 20 + 10
        await saveQuizAttempt({
          userId: user.id,
          quizType: 'daily',
          score,
          totalQuestions: questions.length,
          xpEarned,
        })
        await addXP(user.id, xpEarned)
        toast({ title: `Quiz concluído! +${xpEarned} XP` })
      }
    }
  }

  if (questions.length === 0)
    return <div className="p-12 text-center text-muted-foreground">Carregando quiz...</div>

  const q = questions[currentIndex]

  return (
    <div className="container mx-auto py-8 px-4 max-w-xl space-y-6">
      <div className="space-y-1 text-center">
        <h1 className="text-2xl font-bold font-display">Quiz Científico do Clima</h1>
        <p className="text-xs text-muted-foreground">
          Teste seu conhecimento e ganhe pontos de experiência (XP)
        </p>
      </div>

      {!completed ? (
        <Card className="p-6 space-y-6">
          <div className="flex justify-between text-xs text-muted-foreground font-mono">
            <span>
              Questão {currentIndex + 1} de {questions.length}
            </span>
            <span>XP: +{q.xp || 20}</span>
          </div>

          <h2 className="text-base font-semibold leading-relaxed">{q.question_pt}</h2>

          <div className="space-y-2">
            {(q.options_pt || []).map((opt, i) => {
              let btnVariant = 'outline'
              if (selectedOption !== null) {
                if (i === q.correct_index) btnVariant = 'default'
                else if (i === selectedOption) btnVariant = 'destructive'
              }
              return (
                <Button
                  key={i}
                  variant={btnVariant as any}
                  className="w-full justify-start text-left text-sm py-3"
                  onClick={() => handleSelect(i)}
                >
                  {opt}
                </Button>
              )
            })}
          </div>

          {selectedOption !== null && (
            <div className="p-3 bg-muted rounded-xl text-xs space-y-2">
              <p className="font-semibold text-teal-600">Explicação:</p>
              <p>{q.explanation_pt}</p>
              <Button onClick={handleNext} className="w-full mt-2 bg-teal-600">
                Próxima Questão
              </Button>
            </div>
          )}
        </Card>
      ) : (
        <Card className="p-8 text-center space-y-4">
          <h2 className="text-2xl font-bold text-teal-600 font-display">Parabéns!</h2>
          <p className="text-sm text-muted-foreground">
            Você acertou {score} de {questions.length} questões.
          </p>
          <Button
            onClick={() => {
              setCompleted(false)
              setCurrentIndex(0)
              setSelectedOption(null)
              setScore(0)
            }}
            className="bg-teal-600"
          >
            Tentar Novamente
          </Button>
        </Card>
      )}
    </div>
  )
}
