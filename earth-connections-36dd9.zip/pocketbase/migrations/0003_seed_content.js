migrate((app) => {
  const systemsCol = app.findCollectionByNameOrId('earth_systems')

  const systems = [
    {
      slug: 'wildfires',
      title_pt: 'Incêndios Florestais',
      title_en: 'Wildfires',
      title_es: 'Incendios Forestales',
      summary_pt:
        'Análise de queimadas ativas e emissões de carbono com satélites NASA FIRMS e MODIS.',
      summary_en: 'Active fire tracking and carbon emissions via NASA FIRMS and MODIS.',
      summary_es: 'Rastreo de incendios activos y emisiones con NASA FIRMS y MODIS.',
      icon: 'Flame',
      color: '#F97316',
      datasets: ['NASA FIRMS', 'MODIS', 'VIIRS'],
      order: 1,
    },
    {
      slug: 'deforestation',
      title_pt: 'Desmatamento',
      title_en: 'Deforestation',
      title_es: 'Deforestación',
      summary_pt: 'Monitoramento da perda de cobertura florestal global e na Amazônia com Landsat.',
      summary_en: 'Global and Amazon forest cover loss monitoring with Landsat.',
      summary_es: 'Monitoreo de pérdida de cobertura forestal con Landsat.',
      icon: 'Trees',
      color: '#16A34A',
      datasets: ['Landsat', 'GLAD', 'PRODES'],
      order: 2,
    },
    {
      slug: 'air-quality',
      title_pt: 'Qualidade do Ar',
      title_en: 'Air Quality',
      title_es: 'Calidad del Aire',
      summary_pt: 'Níveis de dióxido de nitrogênio, ozônio e material particulado na atmosfera.',
      summary_en: 'NO2, ozone, and particulate matter levels in the atmosphere.',
      summary_es: 'Niveles de NO2, ozono y material particulado atmosférico.',
      icon: 'Wind',
      color: '#8B5CF6',
      datasets: ['Sentinel-5P', 'AURA/OMI', 'TEMPO'],
      order: 3,
    },
    {
      slug: 'ocean-temperature',
      title_pt: 'Temperatura dos Oceanos',
      title_en: 'Ocean Temperature',
      title_es: 'Temperatura Oceánica',
      summary_pt: 'Anomalias de temperatura da superfície do mar (SST) e eventos El Niño/La Niña.',
      summary_en: 'Sea surface temperature anomalies (SST) and El Niño/La Niña cycles.',
      summary_es: 'Anomalías de temperatura superficial del mar y ciclos de El Niño.',
      icon: 'Thermometer',
      color: '#06B6D4',
      datasets: ['NOAA OISST', 'MODIS Aqua'],
      order: 4,
    },
    {
      slug: 'sea-level',
      title_pt: 'Nível do Mar',
      title_en: 'Sea Level Rise',
      title_es: 'Nivel del Mar',
      summary_pt: 'Elevação do nível do mar medida por altimetria de satélite da NASA/CNES.',
      summary_en: 'Global sea level rise measured by NASA satellite altimetry.',
      summary_es: 'Elevación del nivel del mar por altimetría satelital de la NASA.',
      icon: 'Waves',
      color: '#2563EB',
      datasets: ['JASON-3', 'Sentinel-6', 'GRACE-FO'],
      order: 5,
    },
    {
      slug: 'polar-ice',
      title_pt: 'Gelo Polar',
      title_en: 'Polar Ice Melting',
      title_es: 'Hielo Polar',
      summary_pt:
        'Retração das camadas de gelo da Groenlândia, Antártica e gelo marinho do Ártico.',
      summary_en: 'Ice sheet loss in Greenland, Antarctica, and Arctic sea ice extent.',
      summary_es: 'Pérdida de capas de hielo en Groenlandia, Antártida y heladas del Ártico.',
      icon: 'Snowflake',
      color: '#38BDF8',
      datasets: ['NSIDC', 'ICESat-2', 'GRACE'],
      order: 6,
    },
    {
      slug: 'carbon-emissions',
      title_pt: 'Emissões de Carbono',
      title_en: 'Carbon Emissions',
      title_es: 'Emisiones de Carbono',
      summary_pt: 'Concentração atmosférica de CO₂ e metano monitorada pelo OCO-2 e TROPOMI.',
      summary_en: 'Atmospheric CO₂ and methane concentrations tracked by OCO-2.',
      summary_es: 'Concentración atmosférica de CO₂ y metano rastreados por OCO-2.',
      icon: 'CloudFog',
      color: '#64748B',
      datasets: ['OCO-2', 'GISS', 'Mauna Loa'],
      order: 7,
    },
    {
      slug: 'water-cycle',
      title_pt: 'Ciclo da Água',
      title_en: 'Water Cycle',
      title_es: 'Ciclo del Agua',
      summary_pt: 'Variações no armazenamento de água subterrânea e precipitação global.',
      summary_en: 'Subsurface groundwater storage and global precipitation dynamics.',
      summary_es: 'Variaciones en almacenamiento de agua subterránea y precipitación.',
      icon: 'Droplets',
      color: '#0EA5E9',
      datasets: ['GPM', 'GRACE-FO', 'SMAP'],
      order: 8,
    },
    {
      slug: 'biodiversity',
      title_pt: 'Biodiversidade',
      title_en: 'Biodiversity Loss',
      title_es: 'Biodiversidad',
      summary_pt: 'Integridade de ecossistemas e degradação de habitats em escala biômica.',
      summary_en: 'Ecosystem integrity and habitat degradation across major biomes.',
      summary_es: 'Integridad de ecosistemas y degradación de hábitats globales.',
      icon: 'Bird',
      color: '#EAB308',
      datasets: ['GEDI', 'MODIS NDVI', 'GBIF'],
      order: 9,
    },
    {
      slug: 'extreme-weather',
      title_pt: 'Eventos Extremos',
      title_en: 'Extreme Weather',
      title_es: 'Eventos Extremos',
      summary_pt: 'Frequência e intensidade de furacões, secas e ondas de calor extremas.',
      summary_en: 'Frequency and severity of hurricanes, droughts, and heatwaves.',
      summary_es: 'Frecuencia e intensidad de huracanes, sequías y olas de calor.',
      icon: 'Zap',
      color: '#EF4444',
      datasets: ['NOAA NCEI', 'NASA EarthData'],
      order: 10,
    },
  ]

  for (let i = 0; i < systems.length; i++) {
    const sys = systems[i]
    try {
      app.findFirstRecordByData('earth_systems', 'slug', sys.slug)
    } catch (_) {
      const rec = new Record(systemsCol)
      rec.set('slug', sys.slug)
      rec.set('title_pt', sys.title_pt)
      rec.set('title_en', sys.title_en)
      rec.set('title_es', sys.title_es)
      rec.set('summary_pt', sys.summary_pt)
      rec.set('summary_en', sys.summary_en)
      rec.set('summary_es', sys.summary_es)
      rec.set('icon', sys.icon)
      rec.set('color', sys.color)
      rec.set('datasets', sys.datasets)
      rec.set('order', sys.order)
      app.save(rec)
    }
  }

  // Seed achievements
  const achCol = app.findCollectionByNameOrId('achievements')
  const achievements = [
    {
      code: 'first_step',
      title_pt: 'Primeiro Passo',
      title_en: 'First Step',
      title_es: 'Primer Paso',
      description_pt: 'Completou seu primeiro quiz científico.',
      description_en: 'Completed your first science quiz.',
      description_es: 'Completaste tu primer quiz científico.',
      icon: 'Award',
      condition: 'quiz_count >= 1',
    },
    {
      code: 'climate_guardian',
      title_pt: 'Guardião do Clima',
      title_en: 'Climate Guardian',
      title_es: 'Guardián del Clima',
      description_pt: 'Explorou todos os 10 Sistemas da Terra.',
      description_en: 'Explored all 10 Earth Systems.',
      description_es: 'Exploraste los 10 Sistemas de la Tierra.',
      icon: 'ShieldCheck',
      condition: 'visited_systems >= 10',
    },
    {
      code: 'data_detective',
      title_pt: 'Detetive de Dados',
      title_en: 'Data Detective',
      title_es: 'Detective de Datos',
      description_pt: 'Usou mais de 5 camadas no Mapa Interativo.',
      description_en: 'Used 5+ layers on the Data Map.',
      description_es: 'Usaste más de 5 capas en el Mapa Interactivo.',
      icon: 'Search',
      condition: 'layers_used >= 5',
    },
    {
      code: 'simulator_scientist',
      title_pt: 'Cientista Simulador',
      title_en: 'Simulator Scientist',
      title_es: 'Científico Simulador',
      description_pt: 'Salvou 3 cenários climáticos personalizados.',
      description_en: 'Saved 3 custom climate scenarios.',
      description_es: 'Guardaste 3 escenarios climáticos.',
      icon: 'Cpu',
      condition: 'simulations_saved >= 3',
    },
    {
      code: 'streak_7',
      title_pt: 'Sequência de 7 Dias',
      title_en: '7-Day Streak',
      title_es: 'Racha de 7 Días',
      description_pt: 'Acessou a plataforma por 7 dias seguidos.',
      description_en: 'Logged in 7 days in a row.',
      description_es: 'Accediste por 7 días seguidos.',
      icon: 'Flame',
      condition: 'streak >= 7',
    },
  ]

  for (let j = 0; j < achievements.length; j++) {
    const ach = achievements[j]
    try {
      app.findFirstRecordByData('achievements', 'code', ach.code)
    } catch (_) {
      const rec = new Record(achCol)
      rec.set('code', ach.code)
      rec.set('title_pt', ach.title_pt)
      rec.set('title_en', ach.title_en)
      rec.set('title_es', ach.title_es)
      rec.set('description_pt', ach.description_pt)
      rec.set('description_en', ach.description_en)
      rec.set('description_es', ach.description_es)
      rec.set('icon', ach.icon)
      rec.set('condition', ach.condition)
      app.save(rec)
    }
  }
})
