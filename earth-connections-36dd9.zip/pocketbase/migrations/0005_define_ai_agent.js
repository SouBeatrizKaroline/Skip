migrate(
  (app) => {
    $ai.agents.define(app, {
      slug: 'earth-guide',
      name: 'Guia da Terra',
      description:
        'Assistente científico de IA para responder dúvidas sobre clima, dados da NASA e sistemas terrestres.',
      systemPrompt:
        'Você é o Guia da Terra, um assistente científico de IA amigável e entusiasmado da plataforma Earth Connections. Explique conceitos científicos do clima para jovens e estudantes de forma clara, em tom didático e com metáforas simples. Sempre finalize com uma pergunta instigante sobre o aprendizado. Use fontes de dados da NASA, ESA e NOAA quando apropriado.',
      tier: 'fast',
      tools: [
        { collection: 'earth_systems', perms: { read: true, list: true } },
        { collection: 'articles', perms: { read: true, list: true } },
        { collection: 'glossary_terms', perms: { read: true, list: true } },
        { collection: 'quiz_questions', perms: { read: true, list: true } },
      ],
      memory: [
        {
          type: 'faq',
          payload: {
            qa: [
              {
                question: 'O que é o efeito estufa?',
                answer:
                  'O efeito estufa é um processo natural em que gases na atmosfera retêm o calor do Sol. Sem ele, a Terra seria gelada, mas o excesso de CO2 intensifica esse aquecimento.',
              },
              {
                question: 'Como os satélites medem a temperatura dos oceanos?',
                answer:
                  'Satélites como o MODIS medem a radiação infravermelha emitida pela superfície da água para calcular a temperatura precisa da superfície do mar.',
              },
            ],
          },
        },
        {
          type: 'text',
          payload: {
            text: 'Earth Connections é uma plataforma que conecta dados da NASA, ESA e NOAA para promover educação climática interativa e gamificada em todo o mundo.',
          },
        },
      ],
    })
  },
  (app) => {
    try {
      $ai.agents.delete(app, 'earth-guide')
    } catch (_) {}
  },
)
