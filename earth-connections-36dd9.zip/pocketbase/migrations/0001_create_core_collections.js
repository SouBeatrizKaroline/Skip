migrate(
  (app) => {
    const usersId = '_pb_users_auth_'

    const profilesCol = new Collection({
      name: 'profiles',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'role',
          type: 'select',
          required: false,
          values: ['student', 'teacher', 'school', 'admin'],
          maxSelect: 1,
        },
        { name: 'country', type: 'text' },
        { name: 'language', type: 'select', values: ['pt', 'en', 'es'], maxSelect: 1 },
        { name: 'bio', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_profiles_user ON profiles (user)'],
    })
    app.save(profilesCol)

    const systemsCol = new Collection({
      name: 'earth_systems',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'slug', type: 'text', required: true },
        { name: 'title_pt', type: 'text', required: true },
        { name: 'title_en', type: 'text' },
        { name: 'title_es', type: 'text' },
        { name: 'summary_pt', type: 'text' },
        { name: 'summary_en', type: 'text' },
        { name: 'summary_es', type: 'text' },
        { name: 'icon', type: 'text' },
        { name: 'color', type: 'text' },
        { name: 'datasets', type: 'json' },
        { name: 'order', type: 'number' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_systems_slug ON earth_systems (slug)'],
    })
    app.save(systemsCol)

    const systemsId = app.findCollectionByNameOrId('earth_systems').id

    const recordsCol = new Collection({
      name: 'climate_records',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'system',
          type: 'relation',
          required: true,
          collectionId: systemsId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'year', type: 'number', required: true },
        { name: 'value', type: 'number' },
        { name: 'anomaly', type: 'number' },
        { name: 'source', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE INDEX idx_climate_rec ON climate_records (system, year)'],
    })
    app.save(recordsCol)

    const articlesCol = new Collection({
      name: 'articles',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'slug', type: 'text', required: true },
        { name: 'title_pt', type: 'text', required: true },
        { name: 'title_en', type: 'text' },
        { name: 'title_es', type: 'text' },
        { name: 'content_pt', type: 'editor' },
        { name: 'content_en', type: 'editor' },
        { name: 'content_es', type: 'editor' },
        { name: 'cover', type: 'file', maxSelect: 1, maxSize: 5242880 },
        { name: 'system', type: 'relation', collectionId: systemsId, maxSelect: 1 },
        { name: 'reading_time', type: 'number' },
        {
          name: 'difficulty',
          type: 'select',
          values: ['basic', 'intermediate', 'advanced'],
          maxSelect: 1,
        },
        {
          name: 'category',
          type: 'select',
          values: ['article', 'video', 'infographic', 'curiosity', 'experiment', 'teacher'],
          maxSelect: 1,
        },
        { name: 'download_file', type: 'file', maxSelect: 1, maxSize: 10485760 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_articles_slug ON articles (slug)'],
    })
    app.save(articlesCol)

    const glossaryCol = new Collection({
      name: 'glossary_terms',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'term_pt', type: 'text', required: true },
        { name: 'term_en', type: 'text' },
        { name: 'term_es', type: 'text' },
        { name: 'definition_pt', type: 'text' },
        { name: 'definition_en', type: 'text' },
        { name: 'definition_es', type: 'text' },
        { name: 'system', type: 'relation', collectionId: systemsId, maxSelect: 1 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(glossaryCol)

    const quizCol = new Collection({
      name: 'quiz_questions',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'question_pt', type: 'text', required: true },
        { name: 'question_en', type: 'text' },
        { name: 'question_es', type: 'text' },
        { name: 'options_pt', type: 'json' },
        { name: 'options_en', type: 'json' },
        { name: 'options_es', type: 'json' },
        { name: 'correct_index', type: 'number', required: true },
        { name: 'explanation_pt', type: 'text' },
        { name: 'explanation_en', type: 'text' },
        { name: 'explanation_es', type: 'text' },
        {
          name: 'difficulty',
          type: 'select',
          values: ['basic', 'intermediate', 'advanced'],
          maxSelect: 1,
        },
        { name: 'system', type: 'relation', collectionId: systemsId, maxSelect: 1 },
        { name: 'xp', type: 'number' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(quizCol)

    const attemptsCol = new Collection({
      name: 'quiz_attempts',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'quiz_type', type: 'select', values: ['system', 'daily', 'level'], maxSelect: 1 },
        { name: 'system', type: 'relation', collectionId: systemsId, maxSelect: 1 },
        { name: 'score', type: 'number' },
        { name: 'total_questions', type: 'number' },
        { name: 'xp_earned', type: 'number' },
        { name: 'answers', type: 'json' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(attemptsCol)

    const progressCol = new Collection({
      name: 'user_progress',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'system', type: 'relation', required: true, collectionId: systemsId, maxSelect: 1 },
        { name: 'visited', type: 'bool' },
        { name: 'quiz_perfect_score', type: 'bool' },
        { name: 'last_activity', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(progressCol)

    const gamiCol = new Collection({
      name: 'gamification',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'xp', type: 'number' },
        { name: 'level', type: 'number' },
        { name: 'streak', type: 'number' },
        { name: 'last_streak_date', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_gami_user ON gamification (user)'],
    })
    app.save(gamiCol)

    const achCol = new Collection({
      name: 'achievements',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'code', type: 'text', required: true },
        { name: 'title_pt', type: 'text', required: true },
        { name: 'title_en', type: 'text' },
        { name: 'title_es', type: 'text' },
        { name: 'description_pt', type: 'text' },
        { name: 'description_en', type: 'text' },
        { name: 'description_es', type: 'text' },
        { name: 'icon', type: 'text' },
        { name: 'condition', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_ach_code ON achievements (code)'],
    })
    app.save(achCol)

    const achId = app.findCollectionByNameOrId('achievements').id

    const uAchCol = new Collection({
      name: 'user_achievements',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'achievement',
          type: 'relation',
          required: true,
          collectionId: achId,
          maxSelect: 1,
        },
        { name: 'earned_at', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(uAchCol)

    const missCol = new Collection({
      name: 'missions',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'mission_data', type: 'json' },
        { name: 'week_start', type: 'date' },
        { name: 'completed', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(missCol)

    const simCol = new Collection({
      name: 'simulations',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'name', type: 'text', required: true },
        { name: 'variables', type: 'json' },
        { name: 'scenario_results', type: 'json' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(simCol)
  },
  (app) => {
    const cols = [
      'simulations',
      'missions',
      'user_achievements',
      'achievements',
      'gamification',
      'user_progress',
      'quiz_attempts',
      'quiz_questions',
      'glossary_terms',
      'articles',
      'climate_records',
      'earth_systems',
      'profiles',
    ]
    for (let i = 0; i < cols.length; i++) {
      try {
        const c = app.findCollectionByNameOrId(cols[i])
        if (c) app.delete(c)
      } catch (_) {}
    }
  },
)
