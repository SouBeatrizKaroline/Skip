migrate(
  (app) => {
    const usersId = '_pb_users_auth_'

    const schoolsCol = new Collection({
      name: 'schools',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'country', type: 'text' },
        { name: 'contact_email', type: 'email' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(schoolsCol)

    const schoolsId = app.findCollectionByNameOrId('schools').id

    const sMemCol = new Collection({
      name: 'school_members',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'school',
          type: 'relation',
          required: true,
          collectionId: schoolsId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(sMemCol)

    const classesCol = new Collection({
      name: 'classes',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && teacher = @request.auth.id",
      deleteRule: "@request.auth.id != '' && teacher = @request.auth.id",
      fields: [
        {
          name: 'teacher',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'name', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'invite_code', type: 'text', required: true },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_classes_code ON classes (invite_code)'],
    })
    app.save(classesCol)

    const classesId = app.findCollectionByNameOrId('classes').id

    const cMemCol = new Collection({
      name: 'class_members',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'class',
          type: 'relation',
          required: true,
          collectionId: classesId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'student',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'joined_at', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(cMemCol)

    const assignCol = new Collection({
      name: 'assignments',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && teacher = @request.auth.id",
      deleteRule: "@request.auth.id != '' && teacher = @request.auth.id",
      fields: [
        {
          name: 'class',
          type: 'relation',
          required: true,
          collectionId: classesId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'teacher', type: 'relation', required: true, collectionId: usersId, maxSelect: 1 },
        { name: 'title', type: 'text', required: true },
        { name: 'instructions', type: 'text' },
        {
          name: 'content_type',
          type: 'select',
          values: ['quiz', 'article', 'system'],
          maxSelect: 1,
        },
        { name: 'content_id', type: 'text' },
        { name: 'due_date', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(assignCol)

    const assignId = app.findCollectionByNameOrId('assignments').id

    const subCol = new Collection({
      name: 'submissions',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && student = @request.auth.id",
      deleteRule: "@request.auth.id != '' && student = @request.auth.id",
      fields: [
        {
          name: 'assignment',
          type: 'relation',
          required: true,
          collectionId: assignId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'student',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'score', type: 'number' },
        { name: 'completed', type: 'bool' },
        { name: 'submitted_at', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(subCol)

    const chalCol = new Collection({
      name: 'challenges',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'class',
          type: 'relation',
          required: true,
          collectionId: classesId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'target_xp', type: 'number' },
        { name: 'start_date', type: 'date' },
        { name: 'end_date', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(chalCol)

    const eventsCol = new Collection({
      name: 'events',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'school', type: 'relation', collectionId: schoolsId, maxSelect: 1 },
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        {
          name: 'type',
          type: 'select',
          values: ['competition', 'workshop', 'hackathon'],
          maxSelect: 1,
        },
        { name: 'start_date', type: 'date' },
        { name: 'end_date', type: 'date' },
        { name: 'participants', type: 'json' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(eventsCol)

    const notifCol = new Collection({
      name: 'notifications',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'type', type: 'text' },
        { name: 'title', type: 'text', required: true },
        { name: 'body', type: 'text' },
        { name: 'link', type: 'text' },
        { name: 'read', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(notifCol)

    const certCol = new Collection({
      name: 'certificates',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'code', type: 'text', required: true },
        { name: 'title', type: 'text', required: true },
        { name: 'issued_at', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE UNIQUE INDEX idx_cert_code ON certificates (code)'],
    })
    app.save(certCol)

    const chatCol = new Collection({
      name: 'chat_messages',
      type: 'base',
      listRule: "@request.auth.id != '' && user = @request.auth.id",
      viewRule: "@request.auth.id != '' && user = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user = @request.auth.id",
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: usersId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'role', type: 'select', values: ['user', 'assistant'], maxSelect: 1 },
        { name: 'content', type: 'text', required: true },
        { name: 'conversation_id', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(chatCol)

    const contactCol = new Collection({
      name: 'contact_messages',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: '',
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'email', type: 'email', required: true },
        { name: 'message', type: 'text', required: true },
        { name: 'status', type: 'select', values: ['new', 'read', 'replied'], maxSelect: 1 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(contactCol)

    const analyticsCol = new Collection({
      name: 'analytics_events',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: '',
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'user', type: 'relation', collectionId: usersId, maxSelect: 1 },
        { name: 'event', type: 'text', required: true },
        { name: 'payload', type: 'json' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(analyticsCol)
  },
  (app) => {
    const cols = [
      'analytics_events',
      'contact_messages',
      'chat_messages',
      'certificates',
      'notifications',
      'events',
      'challenges',
      'submissions',
      'assignments',
      'class_members',
      'classes',
      'school_members',
      'schools',
    ]
    for (let i = 0; i < cols.length; i++) {
      try {
        const c = app.findCollectionByNameOrId(cols[i])
        if (c) app.delete(c)
      } catch (_) {}
    }
  },
)
