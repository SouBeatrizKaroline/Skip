migrate((app) => {
  const users = app.findCollectionByNameOrId('_pb_users_auth_')
  const profiles = app.findCollectionByNameOrId('profiles')
  const gami = app.findCollectionByNameOrId('gamification')

  const adminEmail = '1aspiraqualquer@gmail.com'
  let adminRecord

  try {
    adminRecord = app.findAuthRecordByEmail('_pb_users_auth_', adminEmail)
  } catch (_) {
    adminRecord = new Record(users)
    adminRecord.setEmail(adminEmail)
    adminRecord.setPassword('Skip@Pass')
    adminRecord.setVerified(true)
    adminRecord.set('name', 'Administrador NASA Earth')
    app.save(adminRecord)
  }

  try {
    app.findFirstRecordByData('profiles', 'user', adminRecord.id)
  } catch (_) {
    const p = new Record(profiles)
    p.set('user', adminRecord.id)
    p.set('role', 'admin')
    p.set('country', 'Brasil')
    p.set('language', 'pt')
    p.set('bio', 'Administrador principal da plataforma Earth Connections.')
    app.save(p)
  }

  try {
    app.findFirstRecordByData('gamification', 'user', adminRecord.id)
  } catch (_) {
    const g = new Record(gami)
    g.set('user', adminRecord.id)
    g.set('xp', 1250)
    g.set('level', 5)
    g.set('streak', 14)
    g.set('last_streak_date', new Date().toISOString().split('T')[0])
    app.save(g)
  }
})
