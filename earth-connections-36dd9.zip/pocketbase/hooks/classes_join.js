routerAdd(
  'POST',
  '/backend/v1/classes/join',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const code = (body.invite_code || '').trim().toUpperCase()
      const userId = e.auth?.id
      if (!userId) return e.unauthorizedError('Autenticação necessária')
      if (!code) return e.badRequestError('Código de convite obrigatório')

      const targetClass = $app.findFirstRecordByData('classes', 'invite_code', code)

      // Check if already a member
      const filter = `class='${targetClass.id}' && student='${userId}'`
      const existing = $app.findRecordsByFilter('class_members', filter, '', 1, 0)
      if (existing.length > 0) {
        return e.json(200, { message: 'Você já faz parte desta turma!', class: targetClass })
      }

      const col = $app.findCollectionByNameOrId('class_members')
      const mem = new Record(col)
      mem.set('class', targetClass.id)
      mem.set('student', userId)
      mem.set('joined_at', new Date().toISOString())
      $app.save(mem)

      return e.json(201, { message: 'Inscrito na turma com sucesso!', class: targetClass })
    } catch (err) {
      return e.badRequestError('Código de turma inválido ou turma não encontrada.')
    }
  },
  $apis.requireAuth(),
)
