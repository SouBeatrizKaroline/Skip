routerAdd(
  'POST',
  '/backend/v1/ai/simplify-article',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const content = body.content || ''
      const scientistMode = !!body.scientistMode

      const prompt = `Resuma o seguinte artigo científico em 4 pontos-chave em tópicos marcados com marcadores (bullet points), mantendo os conceitos principais fáceis de entender:\n\n${content.slice(0, 3000)}`

      const res = $ai.chat({
        model: scientistMode ? 'reasoning' : 'fast',
        messages: [
          { role: 'system', content: 'Você é um divulgador científico do Earth Connections.' },
          { role: 'user', content: prompt },
        ],
      })

      const summary = res.choices?.[0]?.message?.content || 'Resumo indisponível.'
      return e.json(200, { summary })
    } catch (err) {
      return e.json(500, { error: 'Erro ao simplificar o artigo.' })
    }
  },
  $apis.requireAuth(),
)
