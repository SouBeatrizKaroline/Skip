routerAdd('GET', '/backend/v1/leaderboard', (e) => {
  try {
    const records = $app.findRecordsByFilter('gamification', '', '-xp', 100, 0)
    $apis.enrichRecords(e, records, 'user')
    return e.json(200, { leaderboard: records })
  } catch (err) {
    return e.json(500, { error: 'Erro ao obter ranking' })
  }
})
