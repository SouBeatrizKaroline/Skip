routerAdd(
  'POST',
  '/backend/v1/ai/explain-chart',
  (e) => {
    try {
      const body = e.requestInfo().body || {}
      const title = body.title || 'Gráfico Climático'
      const dataSummary = body.dataSummary || ''

      const prompt = `Como um cientista da NASA, explique de forma simples e direta este gráfico para um estudante:
Título: ${title}
Dados resumidos: ${dataSummary}
Forneça uma explicação em 3 frases destacando a tendência e o impacto no planeta.`

      const res = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é um educador científico especializado em visualização de dados do clima.',
          },
          { role: 'user', content: prompt },
        ],
      })

      const text = res.choices?.[0]?.message?.content || 'Explicação indisponível.'
      return e.json(200, { explanation: text })
    } catch (err) {
      return e.json(500, { error: 'Não foi possível explicar o gráfico no momento.' })
    }
  },
  $apis.requireAuth(),
)
