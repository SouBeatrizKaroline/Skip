import pb from '@/lib/pocketbase/client'

export interface KnowledgeRecord {
  id: string
  user_id: string
  source_id: string
  source_name: string
  theme: string
  insight: string
  practical_application: string
  created: string
  updated: string
}

export const getKnowledgeEntries = () =>
  pb.collection('knowledge_entries').getFullList<KnowledgeRecord>({
    sort: '-created',
    expand: 'source_id',
  })

export const createKnowledgeEntry = (data: Partial<KnowledgeRecord>) =>
  pb.collection('knowledge_entries').create<KnowledgeRecord>(data)

export const deleteKnowledgeEntry = (id: string) => pb.collection('knowledge_entries').delete(id)
