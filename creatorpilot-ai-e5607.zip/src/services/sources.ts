import pb from '@/lib/pocketbase/client'

export interface SourceRecord {
  id: string
  user_id: string
  title: string
  description: string
  origin: string
  source_url: string
  collected_date: string
  author: string
  source_type: 'official' | 'specialized' | 'community'
  category: string
  reliability: 'high' | 'medium' | 'low'
  context: string
  limitations: string
  created: string
  updated: string
}

export const getSources = () =>
  pb.collection('sources').getFullList<SourceRecord>({ sort: '-created' })

export const getSource = (id: string) => pb.collection('sources').getOne<SourceRecord>(id)

export const createSource = (data: Partial<SourceRecord>) =>
  pb.collection('sources').create<SourceRecord>(data)

export const updateSource = (id: string, data: Partial<SourceRecord>) =>
  pb.collection('sources').update<SourceRecord>(id, data)

export const deleteSource = (id: string) => pb.collection('sources').delete(id)
