import pb from '@/lib/pocketbase/client'

export async function askStream(
  message: string,
  conversationId: string | null,
  signal?: AbortSignal,
): Promise<Response> {
  return fetch(`${import.meta.env.VITE_POCKETBASE_URL}/backend/v1/ask-stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: pb.authStore.token,
    },
    body: JSON.stringify({ message, conversation_id: conversationId }),
    signal,
  })
}

export const listConversations = () => pb.send('/backend/v1/chats', { method: 'GET' })

export const listMessages = (conversationId: string) =>
  pb.send(`/backend/v1/chats/${conversationId}/messages`, { method: 'GET' })

export const auditContent = (content: string) =>
  pb.send('/backend/v1/audit', {
    method: 'POST',
    body: JSON.stringify({ content }),
    headers: { 'Content-Type': 'application/json' },
  })
