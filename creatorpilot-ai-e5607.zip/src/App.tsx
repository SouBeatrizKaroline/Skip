import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { DashboardLayout } from '@/components/DashboardLayout'
import Index from './pages/Index'
import Login from './pages/Login'
import Signup from './pages/Signup'
import Dashboard from './pages/Dashboard'
import Brand from './pages/Brand'
import Persona from './pages/Persona'
import BrandKit from './pages/BrandKit'
import CalendarPage from './pages/CalendarPage'
import ContentCreator from './pages/ContentCreator'
import Editor from './pages/Editor'
import SourceIntelligence from './pages/SourceIntelligence'
import KnowledgeBank from './pages/KnowledgeBank'
import Assistant from './pages/Assistant'
import AnalyticsPage from './pages/AnalyticsPage'
import NotFound from './pages/NotFound'
import Layout from './components/Layout'

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
          </Route>
          <Route element={<ProtectedRoute />}>
            <Route element={<DashboardLayout />}>
              <Route path="/app" element={<Dashboard />} />
              <Route path="/app/brand" element={<Brand />} />
              <Route path="/app/persona" element={<Persona />} />
              <Route path="/app/brand-kit" element={<BrandKit />} />
              <Route path="/app/calendar" element={<CalendarPage />} />
              <Route path="/app/content-creator" element={<ContentCreator />} />
              <Route path="/app/editor" element={<Editor />} />
              <Route path="/app/analytics" element={<AnalyticsPage />} />
              <Route path="/app/sources" element={<SourceIntelligence />} />
              <Route path="/app/knowledge" element={<KnowledgeBank />} />
              <Route path="/app/assistant" element={<Assistant />} />
            </Route>
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </TooltipProvider>
    </AuthProvider>
  </BrowserRouter>
)

export default App
