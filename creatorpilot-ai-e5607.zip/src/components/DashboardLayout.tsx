import { useState } from 'react'
import { Outlet, Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  BarChart3,
  Search,
  Brain,
  Bot,
  LogOut,
  Menu,
  Sparkles,
  Target,
  Users,
  Palette,
  CalendarDays,
  PenTool,
  FileEdit,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { useAuth } from '@/hooks/use-auth'
import { cn } from '@/lib/utils'

const navItems = [
  { href: '/app', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/app/brand', label: 'Minha Marca', icon: Target },
  { href: '/app/persona', label: 'Minha Persona', icon: Users },
  { href: '/app/brand-kit', label: 'Brand Kit', icon: Palette },
  { href: '/app/calendar', label: 'Calendário', icon: CalendarDays },
  { href: '/app/content-creator', label: 'Criador de Conteúdo', icon: PenTool },
  { href: '/app/editor', label: 'Editor', icon: FileEdit },
  { href: '/app/analytics', label: 'Analytics', icon: BarChart3 },
  { href: '/app/assistant', label: 'CreatorPilot Assistant', icon: Bot },
  { href: '/app/sources', label: 'Source Intelligence', icon: Search },
  { href: '/app/knowledge', label: 'Knowledge Bank', icon: Brain },
]

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation()
  return (
    <nav className="flex flex-col gap-1 p-3">
      {navItems.map((item) => {
        const Icon = item.icon
        const active =
          location.pathname === item.href ||
          (item.href !== '/app' && location.pathname.startsWith(item.href))
        return (
          <Link
            key={item.href}
            to={item.href}
            onClick={onNavigate}
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
              active
                ? 'bg-primary text-primary-foreground'
                : 'text-slate-400 hover:text-white hover:bg-white/5',
            )}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </Link>
        )
      })}
    </nav>
  )
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { signOut } = useAuth()
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-5 py-5 border-b border-[#1e2438]">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <Sparkles className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="font-bold text-white">CreatorPilot AI</span>
      </div>
      <div className="flex-1 overflow-y-auto">
        <NavLinks onNavigate={onNavigate} />
      </div>
      <div className="p-3 border-t border-[#1e2438]">
        <Button
          variant="ghost"
          size="sm"
          onClick={signOut}
          className="w-full justify-start text-slate-400 hover:text-white"
        >
          <LogOut className="h-4 w-4 mr-2" /> Sair
        </Button>
      </div>
    </div>
  )
}

export function DashboardLayout() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="flex h-screen bg-[#0B0E17]">
      <aside className="hidden md:flex w-64 flex-col border-r border-[#1e2438] bg-[#0F1320]">
        <SidebarContent />
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="md:hidden flex items-center gap-3 px-4 py-3 border-b border-[#1e2438] bg-[#0F1320]">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 bg-[#0F1320] border-[#1e2438] p-0">
              <SidebarContent onNavigate={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>
          <span className="font-bold text-white">CreatorPilot AI</span>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
