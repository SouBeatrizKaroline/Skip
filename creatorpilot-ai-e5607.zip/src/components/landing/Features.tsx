import {
  ClipboardList,
  UserCircle,
  Package,
  Sparkles,
  CalendarRange,
  FileText,
  BarChart3,
  Bot,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'

const features = [
  {
    icon: ClipboardList,
    title: 'Questionário de Onboarding',
    description:
      'Perguntas estratégicas que mapeiam seu nicho, público-alvo, objetivos e diferenciais competitivos.',
  },
  {
    icon: UserCircle,
    title: 'Marca, Persona e Identidade',
    description:
      'Criação completa de personalidade de marca, definição de persona e posicionamento de mercado.',
  },
  {
    icon: Package,
    title: 'Brand Kit Inteligente',
    description:
      'Paleta de cores, tipografia, tom de voz e elementos visuais gerados automaticamente pela IA.',
  },
  {
    icon: Sparkles,
    title: 'Gerador de Conteúdo',
    description:
      'Criação de posts, legendas, roteiros e ideias com IA, adaptados ao seu estilo e objetivos.',
  },
  {
    icon: CalendarRange,
    title: 'Calendário Editorial',
    description:
      'Planejamento visual de conteúdo com temas, datas e plataformas organizados em um só lugar.',
  },
  {
    icon: FileText,
    title: 'Editor com IA',
    description:
      'Refine e otimize seus textos com sugestões inteligentes em tempo real, direto no editor.',
  },
  {
    icon: BarChart3,
    title: 'Analytics e Insights',
    description:
      'Acompanhe métricas de performance e receba recomendações acionáveis para crescer.',
  },
  {
    icon: Bot,
    title: 'CreatorPilot Assistant',
    description:
      'Um assistente dedicado que orienta você diariamente com dicas, ideias e ações estratégicas.',
  },
]

export function Features() {
  return (
    <section id="recursos" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-semibold text-primary uppercase tracking-wider">
            Recursos do MVP
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mt-4 mb-6">
            Tudo o que você precisa para <span className="text-gradient">decolar</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Um conjunto completo de ferramentas com inteligência artificial para cada etapa da sua
            jornada como criador de conteúdo.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-elevation"
            >
              <CardHeader>
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary mb-2">
                  <feature.icon className="h-5 w-5" />
                </div>
                <CardTitle className="text-base font-semibold">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
