import {
  ClipboardList,
  Palette,
  Package,
  CalendarDays,
  Share2,
  RefreshCw,
  FileEdit,
  BarChart3,
  Bot,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

const steps = [
  {
    icon: ClipboardList,
    num: '01',
    title: 'Onboarding',
    desc: 'Questionário inteligente para entender seu nicho, público e objetivos.',
  },
  {
    icon: Palette,
    num: '02',
    title: 'Criação de Marca',
    desc: 'Definição de identidade, personalidade e posicionamento da sua marca.',
  },
  {
    icon: Package,
    num: '03',
    title: 'Brand Kit',
    desc: 'Paleta de cores, tipografia, tom de voz e elementos visuais padronizados.',
  },
  {
    icon: CalendarDays,
    num: '04',
    title: 'Estratégia de Conteúdo',
    desc: 'Calendário editorial com temas, formatos e frequência otimizados.',
  },
  {
    icon: Share2,
    num: '05',
    title: 'Gerador Multi-plataforma',
    desc: 'Conteúdo adaptado para Instagram, TikTok, LinkedIn, YouTube e mais.',
  },
  {
    icon: RefreshCw,
    num: '06',
    title: 'Adaptador Inteligente',
    desc: 'Adequação automática de tom, formato e hashtag para cada rede social.',
  },
  {
    icon: FileEdit,
    num: '07',
    title: 'Editor de Marketing',
    desc: 'Refinamento de copy com sugestões de IA em tempo real.',
  },
  {
    icon: BarChart3,
    num: '08',
    title: 'Analista de Crescimento',
    desc: 'Métricas, insights e recomendações para evoluir sua estratégia.',
  },
  {
    icon: Bot,
    num: '09',
    title: 'Assistente Diário',
    desc: 'O CreatorPilot Assistant orienta você todos os dias com dicas e ações.',
  },
]

export function Journey() {
  return (
    <section id="jornada" className="py-20 md:py-28 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-semibold text-primary uppercase tracking-wider">
            O Processo
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mt-4 mb-6">
            Uma jornada de <span className="text-gradient">9 etapas</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Do primeiro clique ao crescimento contínuo, cada etapa foi desenhada para construir,
            criar e escalar sua presença digital com inteligência.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps.map((step) => (
            <Card
              key={step.num}
              className="group relative overflow-hidden border-border/50 hover:border-primary/40 transition-all duration-300 hover:shadow-elevation hover:-translate-y-1"
            >
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                    <step.icon className="h-6 w-6" />
                  </div>
                  <span className="text-3xl font-bold text-muted/40">{step.num}</span>
                </div>
                <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
