import { Link } from 'react-router-dom'
import { Sparkles, ArrowRight, Play } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Hero() {
  return (
    <section className="relative hero-gradient pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      <div className="container mx-auto px-4 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-medium text-primary mb-8 animate-fade-in">
          <Sparkles className="h-4 w-4" />
          Seu copiloto estratégico de marketing digital
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 animate-fade-in-up">
          CreatorPilot <span className="text-gradient">AI</span>
        </h1>

        <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-fade-in-up font-medium">
          Você cria. O CreatorPilot guia o caminho.
        </p>

        <p className="text-base md:text-lg text-muted-foreground max-w-3xl mx-auto mb-10 animate-fade-in-up">
          Uma plataforma de inteligência artificial que guia criadores de conteúdo, influenciadores,
          freelancers, especialistas e pequenos negócios na construção de marca, criação e
          crescimento nas redes sociais.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up">
          <Button size="lg" asChild className="w-full sm:w-auto text-base">
            <Link to="/signup">
              Começar gratuitamente
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild className="w-full sm:w-auto text-base">
            <Link to="/login">
              <Play className="mr-2 h-4 w-4" />
              Já tenho conta
            </Link>
          </Button>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
          {[
            { value: '9', label: 'Etapas guiadas' },
            { value: 'IA', label: 'Assistente dedicado' },
            { value: 'Multi', label: 'Plataformas' },
            { value: '100%', label: 'Estratégico' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl font-bold text-gradient">{stat.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
