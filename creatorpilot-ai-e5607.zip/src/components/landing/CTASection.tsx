import { Link } from 'react-router-dom'
import { ArrowRight, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'

const benefits = [
  'Onboarding guiado em minutos',
  'Marca e identidade criadas com IA',
  'Conteúdo para múltiplas plataformas',
  'Assistente dedicado todos os dias',
]

export function CTASection() {
  return (
    <section id="contato" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-3xl bg-primary px-6 py-16 md:px-16 md:py-24 text-center">
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary to-purple-600 opacity-90" />

          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-6">
              Pronto para guiar sua marca ao próximo nível?
            </h2>
            <p className="text-lg text-primary-foreground/80 mb-10">
              Junte-se a criadores que já estão usando o CreatorPilot AI para construir marcas
              memoráveis e crescer nas redes sociais com inteligência.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-10 max-w-md mx-auto text-left">
              {benefits.map((benefit) => (
                <div key={benefit} className="flex items-center gap-2 text-primary-foreground/90">
                  <Check className="h-5 w-5 flex-shrink-0" />
                  <span className="text-sm">{benefit}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" variant="secondary" asChild className="w-full sm:w-auto text-base">
                <Link to="/signup">
                  Criar minha conta
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="w-full sm:w-auto text-base border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
              >
                <Link to="/login">Entrar</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
