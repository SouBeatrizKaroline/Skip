import { Target, Lightbulb, TrendingUp, Heart } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

const values = [
  {
    icon: Target,
    title: 'Estratégico',
    description:
      'Cada etapa é projetada para construir uma marca sólida e um plano de conteúdo com propósito.',
  },
  {
    icon: Lightbulb,
    title: 'Inteligente',
    description:
      'IA que entende seu nicho, sua voz e seus objetivos para gerar conteúdo que realmente converte.',
  },
  {
    icon: TrendingUp,
    title: 'Crescimento',
    description:
      'Métricas e análises que mostram o que funciona, para que você evolua a cada publicação.',
  },
  {
    icon: Heart,
    title: 'Acessível',
    description:
      'Feito para criadores de todos os níveis — do iniciante ao profissional, do freelancer ao pequeno negócio.',
  },
]

export function ValueProposition() {
  return (
    <section id="sobre" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            O que é o <span className="text-gradient">CreatorPilot AI</span>?
          </h2>
          <p className="text-lg text-muted-foreground">
            Um copiloto estratégico de marketing digital que combina inteligência artificial com um
            processo estruturado em 9 etapas. Acompanhamos você desde a definição da sua identidade
            até o crescimento sustentável nas redes sociais — com criatividade, estratégia e dados.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value) => (
            <Card
              key={value.title}
              className="border-border/50 hover:border-primary/30 transition-colors duration-300 hover:shadow-elevation"
            >
              <CardContent className="pt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary mb-4">
                  <value.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground">{value.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
