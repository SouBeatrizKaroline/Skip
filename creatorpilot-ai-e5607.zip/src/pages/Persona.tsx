import { useState } from 'react'
import { Users, Sparkles, Loader2, Heart, MapPin, Briefcase } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from 'sonner'

export default function Persona() {
  const [generating, setGenerating] = useState(false)
  const [aiResult, setAiResult] = useState('')
  const [form, setForm] = useState({
    target_audience: '',
    age_range: '',
    interests: '',
    pain_points: '',
    goals: '',
  })

  const handleGenerate = async () => {
    if (!form.target_audience) {
      toast.error('Descreva seu público-alvo.')
      return
    }
    setGenerating(true)
    setAiResult('')
    try {
      const result = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({
          question: `Crie uma persona detalhada para público-alvo: "${form.target_audience}". Idade: ${form.age_range}. Interesses: ${form.interests}. Dores: ${form.pain_points}. Objetivos: ${form.goals}. Inclua nome, demografia, comportamento e preferências de conteúdo.`,
        }),
        headers: { 'Content-Type': 'application/json' },
      })
      setAiResult(result.content || result.answer || 'Sem resposta no momento.')
    } catch (err) {
      toast.error(getErrorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Users className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">Minha Persona</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Crie personas detalhadas do seu público-alvo com IA.
      </p>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white">Dados do Público</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-slate-300">Público-Alvo *</Label>
              <Input
                value={form.target_audience}
                onChange={(e) => setForm({ ...form, target_audience: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: Jovens empreendedores"
              />
            </div>
            <div>
              <Label className="text-slate-300">Faixa Etária</Label>
              <Input
                value={form.age_range}
                onChange={(e) => setForm({ ...form, age_range: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: 18-30 anos"
              />
            </div>
            <div>
              <Label className="text-slate-300">Interesses</Label>
              <Textarea
                value={form.interests}
                onChange={(e) => setForm({ ...form, interests: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                rows={2}
                placeholder="Ex: Tecnologia, investimentos, startups"
              />
            </div>
            <div>
              <Label className="text-slate-300">Dores e Desafios</Label>
              <Textarea
                value={form.pain_points}
                onChange={(e) => setForm({ ...form, pain_points: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                rows={2}
                placeholder="Ex: Falta de conhecimento financeiro"
              />
            </div>
            <div>
              <Label className="text-slate-300">Objetivos</Label>
              <Textarea
                value={form.goals}
                onChange={(e) => setForm({ ...form, goals: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                rows={2}
                placeholder="Ex: Alcançar independência financeira"
              />
            </div>
            <Button onClick={handleGenerate} disabled={generating} className="w-full">
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" /> Gerar Persona com IA
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-900/20 via-[#141927] to-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-cyan-400" /> Persona Gerada
            </CardTitle>
          </CardHeader>
          <CardContent>
            {aiResult ? (
              <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap">
                {aiResult}
              </div>
            ) : (
              <div className="text-center py-12">
                <Users className="h-10 w-10 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400 text-sm">
                  Descreva seu público e gere uma persona detalhada com IA.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
