import { useState } from 'react'
import { Palette, Type, Eye, Sparkles, Loader2, Copy } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from 'sonner'

const colorPalettes = [
  { name: 'Minimalista', colors: ['#0B0E17', '#141927', '#6366F1', '#22D3EE', '#F8FAFC'] },
  { name: 'Vibrante', colors: ['#7C3AED', '#EC4899', '#F59E0B', '#10B981', '#3B82F6'] },
  { name: 'Profissional', colors: ['#1E293B', '#0EA5E9', '#64748B', '#E2E8F0', '#0F766E'] },
]

export default function BrandKit() {
  const [generating, setGenerating] = useState(false)
  const [aiResult, setAiResult] = useState('')
  const [brandName, setBrandName] = useState('')

  const handleGenerate = async () => {
    if (!brandName) {
      toast.error('Digite o nome da marca.')
      return
    }
    setGenerating(true)
    setAiResult('')
    try {
      const result = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({
          question: `Crie um Brand Kit para a marca "${brandName}". Inclua paleta de cores (com hex), tipografia recomendada, tom de voz e diretrizes visuais.`,
        }),
        headers: { 'Content-Type': 'application/json' },
      })
      setAiResult(result.content || result.answer || 'Sem resposta no momento.')
    } catch (err) {
      toast.error(getErrorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Palette className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">Brand Kit</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Paleta de cores, tipografia, tom de voz e elementos visuais da sua marca.
      </p>

      <Card className="bg-[#141927] border-[#232B42]">
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row gap-3 items-end">
            <div className="flex-1 w-full">
              <Label className="text-slate-300">Nome da Marca</Label>
              <Input
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: CreatorLab"
              />
            </div>
            <Button onClick={handleGenerate} disabled={generating}>
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" /> Gerar Brand Kit
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {aiResult && (
        <Card className="bg-gradient-to-br from-indigo-900/20 via-[#141927] to-[#141927] border-[#232B42]">
          <CardContent className="p-5">
            <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap">
              {aiResult}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        {colorPalettes.map((palette) => (
          <Card key={palette.name} className="bg-[#141927] border-[#232B42]">
            <CardHeader>
              <CardTitle className="text-sm font-bold text-white">{palette.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-3">
                {palette.colors.map((color, i) => (
                  <div
                    key={i}
                    className="flex-1 h-12 rounded-lg cursor-pointer transition-transform hover:scale-105"
                    style={{ backgroundColor: color }}
                    onClick={() => {
                      navigator.clipboard.writeText(color)
                      toast.success(`Copiado: ${color}`)
                    }}
                  />
                ))}
              </div>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <Copy className="h-3 w-3" /> Clique para copiar
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
              <Type className="h-4 w-4 text-primary" /> Tipografia
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-xs text-slate-400 mb-1">Títulos</p>
              <p className="text-2xl font-bold text-white">Inter Bold</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">Corpo de texto</p>
              <p className="text-base text-slate-300">Inter Regular</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
              <Eye className="h-4 w-4 text-primary" /> Tom de Voz
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-300">
              Inspirador, acessível e estratégico. Comunique com clareza, use linguagem do dia a dia
              e traga sempre um call-to-action motivador.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
