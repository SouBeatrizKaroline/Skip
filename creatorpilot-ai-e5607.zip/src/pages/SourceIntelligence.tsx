import { useState, useEffect } from 'react'
import { Plus, ExternalLink, Trash2, Search } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import { getSources, createSource, deleteSource, type SourceRecord } from '@/services/sources'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'
import { toast } from 'sonner'

const typeLabels: Record<string, string> = {
  official: 'Oficial',
  specialized: 'Especializada',
  community: 'Comunitária',
}
const reliabilityLabels: Record<string, string> = {
  high: 'Alta',
  medium: 'Média',
  low: 'Baixa',
}
const reliabilityColors: Record<string, string> = {
  high: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  medium: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  low: 'bg-red-500/20 text-red-400 border-red-500/30',
}

const emptyForm = {
  title: '',
  origin: '',
  source_url: '',
  source_type: 'official' as const,
  reliability: 'high' as const,
  category: '',
  description: '',
  context: '',
  limitations: '',
}

export default function SourceIntelligence() {
  const { user } = useAuth()
  const [sources, setSources] = useState<SourceRecord[]>([])
  const [open, setOpen] = useState(false)
  const [filter, setFilter] = useState('all')
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    try {
      setSources(await getSources())
    } catch {
      /* ignore */
    }
  }
  useEffect(() => {
    load()
  }, [])
  useRealtime('sources', () => {
    load()
  })

  const handleCreate = async () => {
    if (!form.title || !user) return
    setSaving(true)
    try {
      await createSource({ ...form, user_id: user.id })
      toast.success('Fonte registrada com sucesso!')
      setOpen(false)
      setForm(emptyForm)
    } catch {
      toast.error('Erro ao registrar fonte')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteSource(id)
      toast.success('Fonte removida')
    } catch {
      toast.error('Erro ao remover')
    }
  }

  const filtered = filter === 'all' ? sources : sources.filter((s) => s.source_type === filter)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-xl font-bold text-white">Source Intelligence Engine</h1>
          <p className="text-sm text-slate-400 mt-1">
            Rastreie a origem e confiabilidade de cada informação.
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" /> Nova Fonte
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#141927] border-[#232B42] max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Registrar Nova Fonte</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="text-slate-300">Título *</Label>
                <Input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                />
              </div>
              <div>
                <Label className="text-slate-300">Origem / Fonte</Label>
                <Input
                  value={form.origin}
                  onChange={(e) => setForm({ ...form, origin: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  placeholder="Ex: Meta Business Insights"
                />
              </div>
              <div>
                <Label className="text-slate-300">Link Oficial</Label>
                <Input
                  value={form.source_url}
                  onChange={(e) => setForm({ ...form, source_url: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  placeholder="https://..."
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-slate-300">Tipo</Label>
                  <Select
                    value={form.source_type}
                    onValueChange={(v) =>
                      setForm({ ...form, source_type: v as SourceRecord['source_type'] })
                    }
                  >
                    <SelectTrigger className="bg-[#0B0E17] border-[#232B42] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="official">Oficial</SelectItem>
                      <SelectItem value="specialized">Especializada</SelectItem>
                      <SelectItem value="community">Comunitária</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-slate-300">Confiabilidade</Label>
                  <Select
                    value={form.reliability}
                    onValueChange={(v) =>
                      setForm({ ...form, reliability: v as SourceRecord['reliability'] })
                    }
                  >
                    <SelectTrigger className="bg-[#0B0E17] border-[#232B42] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">Alta</SelectItem>
                      <SelectItem value="medium">Média</SelectItem>
                      <SelectItem value="low">Baixa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-slate-300">Categoria</Label>
                <Input
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  placeholder="Ex: Marketing Digital"
                />
              </div>
              <div>
                <Label className="text-slate-300">Descrição</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  rows={2}
                />
              </div>
              <div>
                <Label className="text-slate-300">Contexto</Label>
                <Textarea
                  value={form.context}
                  onChange={(e) => setForm({ ...form, context: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  rows={2}
                />
              </div>
              <Button onClick={handleCreate} disabled={saving || !form.title} className="w-full">
                {saving ? 'Salvando...' : 'Registrar Fonte'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-2 flex-wrap">
        {['all', 'official', 'specialized', 'community'].map((f) => (
          <Button
            key={f}
            variant={filter === f ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(f)}
            className={filter !== f ? 'border-[#232B42] text-slate-400' : ''}
          >
            {f === 'all' ? 'Todas' : typeLabels[f]}
          </Button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card className="bg-[#141927] border-[#232B42]">
          <CardContent className="p-8 text-center">
            <Search className="h-10 w-10 text-slate-600 mx-auto mb-2" />
            <p className="text-slate-400">Nenhuma fonte registrada ainda.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {filtered.map((s) => (
            <Card key={s.id} className="bg-[#141927] border-[#232B42]">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-white">{s.title}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {typeLabels[s.source_type] || s.source_type}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={`text-xs ${reliabilityColors[s.reliability] || ''}`}
                      >
                        Confiança: {reliabilityLabels[s.reliability] || s.reliability}
                      </Badge>
                    </div>
                    {s.description && (
                      <p className="text-sm text-slate-400 mt-1">{s.description}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                      {s.origin && <span>📊 {s.origin}</span>}
                      {s.category && <span>🏷️ {s.category}</span>}
                      {s.source_url && (
                        <a
                          href={s.source_url}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-primary hover:underline"
                        >
                          <ExternalLink className="h-3 w-3" /> Link
                        </a>
                      )}
                    </div>
                    {s.context && <p className="text-xs text-slate-500 mt-2 italic">{s.context}</p>}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(s.id)}
                    className="text-slate-500 hover:text-red-400 shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
