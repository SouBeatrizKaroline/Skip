import { useState, useEffect } from 'react'
import { Target, Palette, TrendingUp, Users, Loader2, Sparkles } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from 'sonner'

export default function Brand() {
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [aiResult, setAiResult] = useState('')
  const [form, setForm] = useState({
    brand_name: '',
    niche: '',
    mission: '',
    values: '',
    positioning: '',
  })

  const handleGenerate = async () => {
    if (!form.brand_name || !form.niche) {
      toast.error('Preencha o nome da marca e o nicho.')
      return
    }
    setGenerating(true)
    setAiResult('')
    try {
      const result = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({
          question: `Crie uma identidade de marca para "${form.brand_name}" no nicho "${form.niche}". Missão: ${form.mission}. Valores: ${form.values}. Inclua posicionamento, tom de voz e diferenciais.`,
        }),
        headers: { 'Content-Type': 'application/json' },
      })
      setAiResult(result.content || result.answer || 'Sem resposta no momento.')
    } catch (err) {
      toast.error(getErrorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Target className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">Minha Marca</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Defina a identidade, missão e posicionamento da sua marca com inteligência artificial.
      </p>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white">Informações da Marca</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-slate-300">Nome da Marca *</Label>
              <Input
                value={form.brand_name}
                onChange={(e) => setForm({ ...form, brand_name: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: CreatorLab"
              />
            </div>
            <div>
              <Label className="text-slate-300">Nicho *</Label>
              <Input
                value={form.niche}
                onChange={(e) => setForm({ ...form, niche: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: Educação financeira"
              />
            </div>
            <div>
              <Label className="text-slate-300">Missão</Label>
              <Textarea
                value={form.mission}
                onChange={(e) => setForm({ ...form, mission: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                rows={2}
                placeholder="Ex: Democratizar o acesso à educação financeira"
              />
            </div>
            <div>
              <Label className="text-slate-300">Valores</Label>
              <Textarea
                value={form.values}
                onChange={(e) => setForm({ ...form, values: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                rows={2}
                placeholder="Ex: Transparência, inovação, acessibilidade"
              />
            </div>
            <Button onClick={handleGenerate} disabled={generating} className="w-full">
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" /> Gerar Identidade com IA
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-900/20 via-[#141927] to-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-cyan-400" /> Identidade Gerada
            </CardTitle>
          </CardHeader>
          <CardContent>
            {aiResult ? (
              <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap">
                {aiResult}
              </div>
            ) : (
              <div className="text-center py-12">
                <Palette className="h-10 w-10 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400 text-sm">
                  Preencha as informações e clique em gerar para criar sua identidade de marca.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
