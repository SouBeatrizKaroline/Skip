import { Link } from 'react-router-dom'
import { Search, Brain, Bot, BarChart3, ArrowRight, ShieldCheck } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { useAuth } from '@/hooks/use-auth'

export default function Dashboard() {
  const { user } = useAuth()
  const name = user?.name || user?.email || 'Criador'

  const sections = [
    {
      href: '/app/sources',
      title: 'Source Intelligence',
      desc: 'Rastreie a origem, fonte e confiabilidade de cada informação utilizada.',
      icon: Search,
    },
    {
      href: '/app/knowledge',
      title: 'Banco de Conhecimento',
      desc: 'Memória organizada: Fonte → Tema → Insight → Aplicação Prática.',
      icon: Brain,
    },
    {
      href: '/app/assistant',
      title: 'CreatorPilot Assistant',
      desc: 'Converse com a IA e use /AUDITAR para auditar respostas.',
      icon: Bot,
    },
    {
      href: '/app/analytics',
      title: 'Analytics',
      desc: 'Dashboard de métricas e insights de crescimento com IA.',
      icon: BarChart3,
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Bem-vindo, {name}! 👋</h1>
        <p className="text-slate-400 mt-1">
          Seu copiloto estratégico de marketing digital está pronto.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-indigo-900/30 via-[#141927] to-[#141927] border-indigo-500/30">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <ShieldCheck className="h-8 w-8 text-emerald-400 shrink-0" />
            <div>
              <h3 className="font-semibold text-white">Source Intelligence Engine ativo</h3>
              <p className="text-sm text-slate-400 mt-1">
                Toda informação gerada pelo agente possui rastreamento de origem, confiabilidade e
                referências verificáveis. Use <code className="text-primary">/AUDITAR</code> no
                assistente para auditorar respostas.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        {sections.map((s) => {
          const Icon = s.icon
          return (
            <Link key={s.href} to={s.href}>
              <Card className="bg-[#141927] border-[#232B42] hover:border-primary/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Icon className="h-5 w-5 text-primary" />
                        <h3 className="font-semibold text-white">{s.title}</h3>
                      </div>
                      <p className="text-sm text-slate-400">{s.desc}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-500" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
