import { useState } from 'react'
import { PenTool, Sparkles, Loader2, Copy, Hash } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from 'sonner'

const platforms = ['Instagram', 'TikTok', 'LinkedIn', 'YouTube', 'Twitter/X']

export default function ContentCreator() {
  const [generating, setGenerating] = useState(false)
  const [result, setResult] = useState('')
  const [form, setForm] = useState({
    topic: '',
    platform: 'Instagram',
    tone: '',
  })

  const handleGenerate = async () => {
    if (!form.topic) {
      toast.error('Digite o tópico do conteúdo.')
      return
    }
    setGenerating(true)
    setResult('')
    try {
      const result = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({
          question: `Crie um conteúdo para ${form.platform} sobre "${form.topic}". Tom: ${form.tone || 'inspirador e profissional'}. Inclua legenda, hashtags e call-to-action.`,
        }),
        headers: { 'Content-Type': 'application/json' },
      })
      setResult(result.content || result.answer || 'Sem resposta no momento.')
    } catch (err) {
      toast.error(getErrorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <PenTool className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">Criador de Conteúdo</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Gere posts, legendas, roteiros e ideias com IA para múltiplas plataformas.
      </p>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white">Configurações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-slate-300">Tópico / Tema *</Label>
              <Input
                value={form.topic}
                onChange={(e) => setForm({ ...form, topic: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: Como crescer no Instagram"
              />
            </div>
            <div>
              <Label className="text-slate-300">Plataforma</Label>
              <Select
                value={form.platform}
                onValueChange={(v) => setForm({ ...form, platform: v })}
              >
                <SelectTrigger className="bg-[#0B0E17] border-[#232B42] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {platforms.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Tom de Voz</Label>
              <Input
                value={form.tone}
                onChange={(e) => setForm({ ...form, tone: e.target.value })}
                className="bg-[#0B0E17] border-[#232B42] text-white"
                placeholder="Ex: Descontraído, profissional"
              />
            </div>
            <Button onClick={handleGenerate} disabled={generating} className="w-full">
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" /> Gerar Conteúdo
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-900/20 via-[#141927] to-[#141927] border-[#232B42]">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-cyan-400" /> Conteúdo Gerado
              </CardTitle>
              {result && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => {
                    navigator.clipboard.writeText(result)
                    toast.success('Conteúdo copiado!')
                  }}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {result ? (
              <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap max-h-[400px] overflow-y-auto">
                {result}
              </div>
            ) : (
              <div className="text-center py-12">
                <PenTool className="h-10 w-10 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400 text-sm">
                  Escolha um tema e gere conteúdo otimizado para sua plataforma.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
