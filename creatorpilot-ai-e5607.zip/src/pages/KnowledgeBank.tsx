import { useState, useEffect } from 'react'
import { Plus, Trash2, Brain, Lightbulb, Target } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  getKnowledgeEntries,
  createKnowledgeEntry,
  deleteKnowledgeEntry,
  type KnowledgeRecord,
} from '@/services/knowledge'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'
import { toast } from 'sonner'

const emptyForm = {
  source_name: '',
  theme: '',
  insight: '',
  practical_application: '',
}

export default function KnowledgeBank() {
  const { user } = useAuth()
  const [entries, setEntries] = useState<KnowledgeRecord[]>([])
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    try {
      setEntries(await getKnowledgeEntries())
    } catch {
      /* ignore */
    }
  }
  useEffect(() => {
    load()
  }, [])
  useRealtime('knowledge_entries', () => {
    load()
  })

  const handleCreate = async () => {
    if (!form.theme || !form.insight || !user) return
    setSaving(true)
    try {
      await createKnowledgeEntry({ ...form, user_id: user.id })
      toast.success('Conhecimento registrado!')
      setOpen(false)
      setForm(emptyForm)
    } catch {
      toast.error('Erro ao registrar')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteKnowledgeEntry(id)
      toast.success('Removido')
    } catch {
      toast.error('Erro')
    }
  }

  const themes = [...new Set(entries.map((e) => e.theme))]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-xl font-bold text-white">Banco de Conhecimento</h1>
          <p className="text-sm text-slate-400 mt-1">Fonte → Tema → Insight → Aplicação Prática</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" /> Novo Conhecimento
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#141927] border-[#232B42] max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-white">Registrar Conhecimento</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="text-slate-300">Fonte</Label>
                <Input
                  value={form.source_name}
                  onChange={(e) => setForm({ ...form, source_name: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  placeholder="Ex: Instagram Creators"
                />
              </div>
              <div>
                <Label className="text-slate-300">Tema *</Label>
                <Input
                  value={form.theme}
                  onChange={(e) => setForm({ ...form, theme: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  placeholder="Ex: Reels"
                />
              </div>
              <div>
                <Label className="text-slate-300">Insight *</Label>
                <Textarea
                  value={form.insight}
                  onChange={(e) => setForm({ ...form, insight: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  rows={2}
                  placeholder="Ex: Vídeos curtos têm maior alcance"
                />
              </div>
              <div>
                <Label className="text-slate-300">Aplicação Prática</Label>
                <Textarea
                  value={form.practical_application}
                  onChange={(e) => setForm({ ...form, practical_application: e.target.value })}
                  className="bg-[#0B0E17] border-[#232B42] text-white"
                  rows={2}
                  placeholder="Ex: Criar calendário de vídeos verticais"
                />
              </div>
              <Button
                onClick={handleCreate}
                disabled={saving || !form.theme || !form.insight}
                className="w-full"
              >
                {saving ? 'Salvando...' : 'Registrar'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {entries.length === 0 ? (
        <Card className="bg-[#141927] border-[#232B42]">
          <CardContent className="p-8 text-center">
            <Brain className="h-10 w-10 text-slate-600 mx-auto mb-2" />
            <p className="text-slate-400">Nenhum conhecimento registrado ainda.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {themes.map((theme) => (
            <div key={theme}>
              <h2 className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                <Brain className="h-4 w-4 text-primary" /> {theme}
              </h2>
              <div className="grid gap-3">
                {entries
                  .filter((e) => e.theme === theme)
                  .map((e) => (
                    <Card key={e.id} className="bg-[#141927] border-[#232B42]">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 space-y-2">
                            {e.source_name && (
                              <Badge variant="secondary" className="text-xs">
                                📎 {e.source_name}
                              </Badge>
                            )}
                            <div className="flex items-start gap-2">
                              <Lightbulb className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
                              <p className="text-sm text-slate-200">{e.insight}</p>
                            </div>
                            {e.practical_application && (
                              <div className="flex items-start gap-2">
                                <Target className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
                                <p className="text-sm text-slate-400">{e.practical_application}</p>
                              </div>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(e.id)}
                            className="text-slate-500 hover:text-red-400 shrink-0"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
