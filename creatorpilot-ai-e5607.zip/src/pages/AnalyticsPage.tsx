import { useState } from 'react'
import { Users, Eye, TrendingUp, Sparkles, Loader2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'

export default function AnalyticsPage() {
  const [loadingAi, setLoadingAi] = useState(false)
  const [aiAnswer, setAiAnswer] = useState('')

  const handleAskQuestion = async (question: string) => {
    setLoadingAi(true)
    setAiAnswer('')
    try {
      const result = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({ question }),
        headers: { 'Content-Type': 'application/json' },
      })
      setAiAnswer(result.content || result.answer || 'Sem resposta no momento.')
    } catch (err) {
      setAiAnswer(getErrorMessage(err))
    } finally {
      setLoadingAi(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Total de Seguidores</p>
                <p className="text-2xl font-bold text-white mt-1">24.5K</p>
              </div>
              <Users className="w-8 h-8 text-indigo-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#141927] border-[#232B42]">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Alcance Total</p>
                <p className="text-2xl font-bold text-cyan-400 mt-1">98.4K</p>
              </div>
              <Eye className="w-8 h-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#141927] border-[#232B42]">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Taxa de Engajamento</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">8.4%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gradient-to-r from-indigo-900/30 via-[#141927] to-[#141927] border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" /> Consultoria de Crescimento com IA
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {[
              'Por que esse conteúdo funcionou?',
              'O que devo publicar agora?',
              'Qual estratégia devo ajustar?',
            ].map((q, idx) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                onClick={() => handleAskQuestion(q)}
                disabled={loadingAi}
                className="border-[#232B42] bg-[#0B0E17] hover:bg-[#1A2033] text-slate-200 text-xs"
              >
                {q}
              </Button>
            ))}
          </div>

          {loadingAi && (
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              Analisando dados...
            </div>
          )}

          {aiAnswer && (
            <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap">
              {aiAnswer}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
