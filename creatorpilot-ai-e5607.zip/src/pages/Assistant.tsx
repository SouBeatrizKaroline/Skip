import { useState, useRef, useEffect } from 'react'
import { Send, Loader2, Sparkles, ShieldCheck } from 'lucide-react'
import { streamAgentChat, type AgentCitation, type DisplayMessage } from '@/lib/skipAi'
import { askStream } from '@/services/agent'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card } from '@/components/ui/card'

export default function Assistant() {
  const [messages, setMessages] = useState<DisplayMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [citations, setCitations] = useState<AgentCitation[]>([])
  const abortRef = useRef<AbortController | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight)
  }, [messages, citations])

  const handleSend = async () => {
    const msg = input.trim()
    if (!msg || loading) return
    setInput('')
    setLoading(true)
    setCitations([])

    const userMsg: DisplayMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: msg,
      created: new Date().toISOString(),
    }
    const assistantId = (Date.now() + 1).toString()
    setMessages((prev) => [
      ...prev,
      userMsg,
      {
        id: assistantId,
        role: 'assistant',
        content: '',
        created: new Date().toISOString(),
      },
    ])

    abortRef.current?.abort()
    const controller = new AbortController()
    abortRef.current = controller

    try {
      const res = await askStream(msg, conversationId, controller.signal)
      const result = await streamAgentChat(res, {
        onChunk: (_delta, full) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantId ? { ...m, content: full } : m)),
          )
        },
        onCitations: (items) => setCitations(items),
        signal: controller.signal,
      })
      setConversationId(result.conversation_id)
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') return
      const errorMsg = err instanceof Error ? err.message : 'falha na comunicação'
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantId ? { ...m, content: `Erro: ${errorMsg}` } : m)),
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">CreatorPilot Assistant</h1>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-2">
        {messages.length === 0 && (
          <div className="text-center py-12">
            <Sparkles className="h-12 w-12 text-primary/50 mx-auto mb-3" />
            <p className="text-slate-400">
              Digite uma mensagem ou use <code className="text-primary">/AUDITAR</code> para auditar
              respostas.
            </p>
          </div>
        )}

        {messages.map((m) => (
          <div key={m.id} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
            <div
              className={`max-w-[80%] rounded-xl px-4 py-3 text-sm whitespace-pre-wrap ${
                m.role === 'user'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-[#141927] border border-[#232B42] text-slate-200'
              }`}
            >
              {m.content || '...'}
            </div>
          </div>
        ))}

        {citations.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-400 flex items-center gap-1">
              <ShieldCheck className="h-3 w-3" /> Fontes e Referências
            </p>
            {citations.map((c, i) => (
              <Card key={i} className="bg-[#0F1320] border-[#232B42] p-3">
                <p className="text-xs text-slate-300">
                  [{c.n}] {c.excerpt}
                </p>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-4 border-t border-[#1e2438]">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Digite sua mensagem... (use /AUDITAR para auditar)"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSend()
            }
          }}
          className="bg-[#141927] border-[#232B42] text-white resize-none"
          rows={1}
        />
        <Button
          onClick={handleSend}
          disabled={loading || !input.trim()}
          size="icon"
          className="h-auto"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  )
}
