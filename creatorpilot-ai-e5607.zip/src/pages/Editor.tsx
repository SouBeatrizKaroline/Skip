import { useState } from 'react'
import { FileEdit, Sparkles, Loader2, Copy, Wand2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import pb from '@/lib/pocketbase/client'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { toast } from 'sonner'

export default function Editor() {
  const [text, setText] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const handleOptimize = async (action: string) => {
    if (!text) {
      toast.error('Digite algum texto para otimizar.')
      return
    }
    setLoading(true)
    setResult('')
    try {
      const res = await pb.send('/backend/v1/ai/insights', {
        method: 'POST',
        body: JSON.stringify({
          question: `${action} o seguinte texto: "${text}"`,
        }),
        headers: { 'Content-Type': 'application/json' },
      })
      setResult(res.content || res.answer || 'Sem resposta no momento.')
    } catch (err) {
      toast.error(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <FileEdit className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-bold text-white">Editor com IA</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Refine e otimize seus textos com sugestões inteligentes em tempo real.
      </p>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-[#141927] border-[#232B42]">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-white">Seu Texto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-slate-300">Texto para otimizar</Label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="bg-[#0B0E17] border-[#232B42] text-white min-h-[200px]"
                placeholder="Cole ou digite seu texto aqui..."
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleOptimize('Melhore e torne mais envolvente')}
                disabled={loading}
                className="border-[#232B42] text-slate-200"
              >
                <Wand2 className="h-3 w-3 mr-1" /> Melhorar
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleOptimize('Resuma de forma concisa')}
                disabled={loading}
                className="border-[#232B42] text-slate-200"
              >
                Resumir
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleOptimize('Adicione hashtags e call-to-action para')}
                disabled={loading}
                className="border-[#232B42] text-slate-200"
              >
                + Hashtags
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleOptimize('Corrija gramática e melhore a clareza de')}
                disabled={loading}
                className="border-[#232B42] text-slate-200"
              >
                Corrigir
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-900/20 via-[#141927] to-[#141927] border-[#232B42]">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-cyan-400" /> Resultado Otimizado
              </CardTitle>
              {result && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => {
                    navigator.clipboard.writeText(result)
                    toast.success('Copiado!')
                  }}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : result ? (
              <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#232B42] text-sm text-slate-200 whitespace-pre-wrap min-h-[200px]">
                {result}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileEdit className="h-10 w-10 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400 text-sm">O texto otimizado aparecerá aqui.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
