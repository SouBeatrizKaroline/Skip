import { useState } from 'react'
import { CalendarDays, Plus, Clock, Video, FileText, Image } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'

interface CalendarEntry {
  day: string
  date: number
  title: string
  platform: string
  type: 'video' | 'post' | 'image'
  time: string
}

const mockEntries: CalendarEntry[] = [
  {
    day: 'Seg',
    date: 4,
    title: 'Reels: Dicas de produtividade',
    platform: 'Instagram',
    type: 'video',
    time: '10:00',
  },
  {
    day: 'Ter',
    date: 5,
    title: 'Carrossel: Tendências 2026',
    platform: 'Instagram',
    type: 'image',
    time: '14:00',
  },
  {
    day: 'Qua',
    date: 6,
    title: 'Artigo: Guia de branding',
    platform: 'LinkedIn',
    type: 'post',
    time: '09:00',
  },
  {
    day: 'Qui',
    date: 7,
    title: 'Vídeo longo: Bastidores',
    platform: 'YouTube',
    type: 'video',
    time: '16:00',
  },
  {
    day: 'Sex',
    date: 8,
    title: 'Story: Enquete semanal',
    platform: 'Instagram',
    type: 'image',
    time: '12:00',
  },
]

const typeIcons = {
  video: Video,
  post: FileText,
  image: Image,
}

const platformColors: Record<string, string> = {
  Instagram: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  LinkedIn: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  YouTube: 'bg-red-500/20 text-red-400 border-red-500/30',
}

export default function CalendarPage() {
  const [entries] = useState<CalendarEntry[]>(mockEntries)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-bold text-white">Calendário Editorial</h1>
        </div>
        <Button size="sm" onClick={() => toast.info('Funcionalidade em desenvolvimento')}>
          <Plus className="h-4 w-4 mr-1" /> Novo Agendamento
        </Button>
      </div>
      <p className="text-sm text-slate-400 -mt-3">
        Planeje seus conteúdos com temas, datas e plataformas organizados.
      </p>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {entries.map((entry, i) => {
          const Icon = typeIcons[entry.type]
          return (
            <Card
              key={i}
              className="bg-[#141927] border-[#232B42] hover:border-primary/30 transition-colors"
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-400">
                    {entry.day}, {entry.date}
                  </span>
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <p className="text-sm font-medium text-white mb-2 line-clamp-2">{entry.title}</p>
                <div className="flex items-center gap-1 text-xs text-slate-500 mb-2">
                  <Clock className="h-3 w-3" /> {entry.time}
                </div>
                <Badge
                  variant="outline"
                  className={`text-xs ${platformColors[entry.platform] || ''}`}
                >
                  {entry.platform}
                </Badge>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card className="bg-gradient-to-r from-indigo-900/30 via-[#141927] to-[#141927] border-indigo-500/30">
        <CardContent className="p-5 text-center">
          <CalendarDays className="h-8 w-8 text-primary mx-auto mb-2" />
          <p className="text-sm text-slate-300">
            Calendário editorial inteligente em breve! A IA irá sugerir os melhores horários e temas
            automaticamente.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
