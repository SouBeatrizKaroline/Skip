import { Navbar } from '@/components/Navbar'
import { Hero } from '@/components/landing/Hero'
import { ValueProposition } from '@/components/landing/ValueProposition'
import { Journey } from '@/components/landing/Journey'
import { Features } from '@/components/landing/Features'
import { CTASection } from '@/components/landing/CTASection'
import { Footer } from '@/components/landing/Footer'

const Index = () => {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <ValueProposition />
        <Journey />
        <Features />
        <CTASection />
      </main>
      <Footer />
    </>
  )
}

export default Index
