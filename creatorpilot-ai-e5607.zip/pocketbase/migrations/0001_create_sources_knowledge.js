migrate(
  (app) => {
    const sources = new Collection({
      name: 'sources',
      type: 'base',
      listRule: "@request.auth.id != '' && user_id = @request.auth.id",
      viewRule: "@request.auth.id != '' && user_id = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'origin', type: 'text' },
        { name: 'source_url', type: 'url' },
        { name: 'collected_date', type: 'date' },
        { name: 'author', type: 'text' },
        {
          name: 'source_type',
          type: 'select',
          values: ['official', 'specialized', 'community'],
          maxSelect: 1,
        },
        { name: 'category', type: 'text' },
        { name: 'reliability', type: 'select', values: ['high', 'medium', 'low'], maxSelect: 1 },
        { name: 'context', type: 'text' },
        { name: 'limitations', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_sources_user ON sources (user_id)',
        'CREATE INDEX idx_sources_type ON sources (source_type)',
      ],
    })
    app.save(sources)

    const sourcesCol = app.findCollectionByNameOrId('sources')
    const knowledge = new Collection({
      name: 'knowledge_entries',
      type: 'base',
      listRule: "@request.auth.id != '' && user_id = @request.auth.id",
      viewRule: "@request.auth.id != '' && user_id = @request.auth.id",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          cascadeDelete: true,
          maxSelect: 1,
        },
        { name: 'source_id', type: 'relation', collectionId: sourcesCol.id, maxSelect: 1 },
        { name: 'source_name', type: 'text' },
        { name: 'theme', type: 'text', required: true },
        { name: 'insight', type: 'text', required: true },
        { name: 'practical_application', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_knowledge_user ON knowledge_entries (user_id)',
        'CREATE INDEX idx_knowledge_theme ON knowledge_entries (theme)',
      ],
    })
    app.save(knowledge)
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId('knowledge_entries'))
    } catch (_) {}
    try {
      app.delete(app.findCollectionByNameOrId('sources'))
    } catch (_) {}
  },
)
