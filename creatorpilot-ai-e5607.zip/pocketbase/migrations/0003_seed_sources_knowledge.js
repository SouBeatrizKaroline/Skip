migrate(
  (app) => {
    let userRecord
    try {
      userRecord = app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com')
    } catch (_) {
      const users = app.findCollectionByNameOrId('_pb_users_auth_')
      userRecord = new Record(users)
      userRecord.setEmail('1aspiraqualquer@gmail.com')
      userRecord.setPassword('Skip@Pass')
      userRecord.setVerified(true)
      userRecord.set('name', 'Criador Demo')
      app.save(userRecord)
    }
    const userId = userRecord.id
    const sourcesCol = app.findCollectionByNameOrId('sources')

    const seedSource = (d) => {
      try {
        app.findFirstRecordByData('sources', 'title', d.title)
        return null
      } catch (_) {}
      const r = new Record(sourcesCol)
      r.set('user_id', userId)
      r.set('title', d.title)
      r.set('description', d.description)
      r.set('origin', d.origin)
      r.set('source_url', d.source_url)
      r.set('source_type', d.source_type)
      r.set('category', d.category)
      r.set('reliability', d.reliability)
      r.set('context', d.context)
      app.save(r)
      return r.id
    }

    const s1 = seedSource({
      title: 'Crescimento de vídeos curtos nas redes sociais',
      description: 'Vídeos curtos verticais possuem maior alcance orgânico inicial.',
      origin: 'Meta Business Insights',
      source_url: 'https://www.facebook.com/business/insights',
      source_type: 'official',
      category: 'Marketing Digital',
      reliability: 'high',
      context: 'Dados oficiais da plataforma Meta sobre desempenho de Reels.',
    })
    const s2 = seedSource({
      title: 'Engajamento em posts de carrossel no Instagram',
      description: 'Carrosséis educativos geram mais salvamentos e compartilhamentos.',
      origin: 'Instagram Creator Blog',
      source_url: 'https://about.instagram.com/blog/creators',
      source_type: 'official',
      category: 'Instagram',
      reliability: 'high',
      context: 'Estudo oficial do Instagram sobre formatos de conteúdo.',
    })
    const s3 = seedSource({
      title: 'Melhores horários para postar em 2026',
      description: 'Horários de pico variam por plataforma e público.',
      origin: 'Sprout Social',
      source_url: 'https://sproutsocial.com/insights',
      source_type: 'specialized',
      category: 'Social Media',
      reliability: 'medium',
      context: 'Relatório anual baseado em dados agregados de múltiplas contas.',
    })
    const s4 = seedSource({
      title: 'Tendências de conteúdo TikTok 2026',
      description: 'Conteúdo autêntico e behind-the-scenes performa melhor.',
      origin: 'TikTok for Business',
      source_url: 'https://www.tiktok.com/business',
      source_type: 'official',
      category: 'TikTok',
      reliability: 'high',
      context: 'Diretrizes oficiais do TikTok para criadores.',
    })

    const knowledgeCol = app.findCollectionByNameOrId('knowledge_entries')
    const seedKnowledge = (d) => {
      try {
        app.findFirstRecordByData('knowledge_entries', 'insight', d.insight)
        return
      } catch (_) {}
      const r = new Record(knowledgeCol)
      r.set('user_id', userId)
      if (d.source_id) r.set('source_id', d.source_id)
      r.set('source_name', d.source_name)
      r.set('theme', d.theme)
      r.set('insight', d.insight)
      r.set('practical_application', d.practical_application)
      app.save(r)
    }

    seedKnowledge({
      source_id: s1,
      source_name: 'Meta Business Insights',
      theme: 'Reels',
      insight: 'Vídeos curtos verticais possuem maior alcance inicial',
      practical_application: 'Criar calendário de vídeos verticais para crescimento orgânico',
    })
    seedKnowledge({
      source_id: s2,
      source_name: 'Instagram Creator Blog',
      theme: 'Carrosséis',
      insight: 'Carrosséis educativos geram mais salvamentos',
      practical_application: 'Criar série de carrosséis educativos sobre o nicho',
    })
    seedKnowledge({
      source_id: s3,
      source_name: 'Sprout Social',
      theme: 'Postagem',
      insight: 'Horários de pico variam por plataforma e público',
      practical_application: 'Ajustar calendário de postagens por plataforma',
    })
    seedKnowledge({
      source_id: s4,
      source_name: 'TikTok for Business',
      theme: 'TikTok',
      insight: 'Conteúdo autêntico e behind-the-scenes performa melhor',
      practical_application: 'Incluir conteúdo de bastidores na estratégia semanal',
    })
  },
  (app) => {
    try {
      const e = app.findRecordsByFilter('knowledge_entries', 'id != ""', '-created', 100, 0)
      for (const r of e) app.delete(r)
    } catch (_) {}
    try {
      const s = app.findRecordsByFilter('sources', 'id != ""', '-created', 100, 0)
      for (const r of s) app.delete(r)
    } catch (_) {}
  },
)
