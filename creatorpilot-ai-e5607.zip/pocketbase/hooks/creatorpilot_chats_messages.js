routerAdd(
  'GET',
  '/backend/v1/chats/{conversationId}/messages',
  (e) => {
    try {
      const userId = e.auth?.id
      if (!userId) return e.unauthorizedError('autenticação necessária')
      return e.json(
        200,
        $ai.agent('creatorpilot').listMessages({
          conversation_id: e.request.pathValue('conversationId'),
          user_id: userId,
        }),
      )
    } catch (err) {
      if (err instanceof SkipAiAgentsError) {
        const status = err.status || 500
        return e.json(status, { error: status >= 500 ? 'erro ao buscar mensagens' : err.message })
      }
      throw err
    }
  },
  $apis.requireAuth(),
)
