routerAdd(
  'POST',
  '/backend/v1/audit',
  (e) => {
    const body = e.requestInfo().body || {}
    const content = (body.content || '').trim()
    if (!content) return e.badRequestError('content é obrigatório')

    try {
      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é um auditor de conteúdo do CreatorPilot AI. Analise o conteúdo fornecido e retorne um RELATÓRIO DE AUDITORIA em português com: 1) Informações verificadas (com fonte), 2) Fontes utilizadas, 3) Links oficiais, 4) Pontos de atenção (suposições, dados desatualizados, risco de interpretação errada), 5) Nível de confiança geral (Alto/Médio/Baixo). Seja objetivo e claro.',
          },
          { role: 'user', content: 'Audite o seguinte conteúdo:\n\n' + content },
        ],
      })
      return e.json(200, { content: reply.choices[0].message.content })
    } catch (err) {
      if (err instanceof SkipAiConfigError)
        return e.json(503, { error: 'IA temporariamente indisponível' })
      if (err instanceof SkipAiError)
        return e.json(502, { error: 'IA temporariamente indisponível' })
      throw err
    }
  },
  $apis.requireAuth(),
)
