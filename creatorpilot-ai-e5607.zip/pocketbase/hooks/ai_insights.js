routerAdd(
  'POST',
  '/backend/v1/ai/insights',
  (e) => {
    const body = e.requestInfo().body || {}
    const question = (body.question || '').trim()
    if (!question) return e.badRequestError('question é obrigatório')

    try {
      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é o CreatorPilot AI, um especialista em branding para criadores de conteúdo. Responda em português (pt-BR). Gere um Brand Kit completo incluindo: 1) Paleta de cores com códigos hex, 2) Tipografia recomendada (fontes para títulos e corpo de texto), 3) Tom de voz da marca, 4) Diretrizes visuais. Formate a resposta de maneira clara e organizada.',
          },
          { role: 'user', content: question },
        ],
      })
      const content = reply.choices[0].message.content
      if (!content) return e.json(500, { error: 'A IA não retornou conteúdo.' })
      return e.json(200, { content })
    } catch (err) {
      if (err instanceof SkipAiConfigError)
        return e.json(503, { error: 'IA temporariamente indisponível' })
      if (err instanceof SkipAiError) {
        const status = err.status || 502
        return e.json(status, { error: 'IA temporariamente indisponível' })
      }
      return e.json(500, { error: 'Erro ao gerar Brand Kit.' })
    }
  },
  $apis.requireAuth(),
)
