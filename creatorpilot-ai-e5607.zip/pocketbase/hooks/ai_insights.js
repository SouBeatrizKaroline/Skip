routerAdd(
  'POST',
  '/backend/v1/ai/insights',
  (e) => {
    const body = e.requestInfo().body || {}
    const question = (body.question || '').trim()
    if (!question) return e.badRequestError('question é obrigatório')

    try {
      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é o CreatorPilot AI, um analista de crescimento para criadores de conteúdo. Responda em português (pt-BR). Sempre cite fontes quando possível. Diferencie fatos de opiniões. Quando não tiver fonte, informe claramente.',
          },
          { role: 'user', content: question },
        ],
      })
      return e.json(200, { content: reply.choices[0].message.content })
    } catch (err) {
      if (err instanceof SkipAiConfigError)
        return e.json(503, { error: 'IA temporariamente indisponível' })
      if (err instanceof SkipAiError)
        return e.json(502, { error: 'IA temporariamente indisponível' })
      throw err
    }
  },
  $apis.requireAuth(),
)
