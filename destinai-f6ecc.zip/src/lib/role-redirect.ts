export function getDashboardPath(role?: string): string {
  switch (role) {
    case 'PRODUCER':
      return '/dashboard/produtor'
    case 'BUYER':
      return '/dashboard/comprador'
    case 'TRANSPORTER':
      return '/dashboard/transportador'
    case 'ADMIN':
      return '/dashboard/admin'
    default:
      return '/impact'
  }
}

export function needsOnboarding(user: any): boolean {
  if (!user) return true
  if (user.status === 'PENDING') return true
  if (!user.role) return true
  return false
}

export function getPostAuthPath(user: any): string {
  if (needsOnboarding(user)) return '/onboarding'
  return getDashboardPath(user.role)
}
