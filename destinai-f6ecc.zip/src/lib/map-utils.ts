export interface MapBounds {
  minLat: number
  maxLat: number
  minLon: number
  maxLon: number
}

export function computeBounds(coords: { lat: number; lon: number }[]): MapBounds {
  if (coords.length === 0) return { minLat: -23.5, maxLat: -22.5, minLon: -47.5, maxLon: -46.5 }
  const bounds = coords.reduce(
    (acc, c) => ({
      minLat: Math.min(acc.minLat, c.lat),
      maxLat: Math.max(acc.maxLat, c.lat),
      minLon: Math.min(acc.minLon, c.lon),
      maxLon: Math.max(acc.maxLon, c.lon),
    }),
    { minLat: 90, maxLat: -90, minLon: 180, maxLon: -180 },
  )
  const latR = Math.max(bounds.maxLat - bounds.minLat, 0.1)
  const lonR = Math.max(bounds.maxLon - bounds.minLon, 0.1)
  return {
    minLat: bounds.minLat - latR * 0.1,
    maxLat: bounds.maxLat + latR * 0.1,
    minLon: bounds.minLon - lonR * 0.1,
    maxLon: bounds.maxLon + lonR * 0.1,
  }
}

export function toXY(lat: number, lon: number, bounds: MapBounds) {
  return {
    x: 20 + ((lon - bounds.minLon) / (bounds.maxLon - bounds.minLon)) * 560,
    y: 20 + ((bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat)) * 360,
  }
}

export interface ClusteredMarker {
  x: number
  y: number
  type: string
  count: number
  isCluster: boolean
}

export function clusterMarkers(
  markers: { x: number; y: number; type: string }[],
  threshold = 25,
): ClusteredMarker[] {
  const grid: Record<string, { x: number; y: number; type: string; count: number }> = {}
  for (const m of markers) {
    const gx = Math.floor(m.x / threshold)
    const gy = Math.floor(m.y / threshold)
    const key = `${gx}:${gy}:${m.type}`
    if (grid[key]) {
      grid[key].count++
    } else {
      grid[key] = { x: m.x, y: m.y, type: m.type, count: 1 }
    }
  }
  return Object.values(grid).map((g) => ({
    x: g.x,
    y: g.y,
    type: g.type,
    count: g.count,
    isCluster: g.count > 1,
  }))
}
