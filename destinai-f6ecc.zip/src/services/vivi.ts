import pb from '@/lib/pocketbase/client'

export const askVivi = (message: string, conversationId: string | null) =>
  pb.send('/backend/v1/ask-vivi', {
    method: 'POST',
    body: JSON.stringify({ message, conversation_id: conversationId }),
    headers: { 'Content-Type': 'application/json' },
  })

export const getViviChats = () => pb.send('/backend/v1/vivi/chats', { method: 'GET' })

export const getViviMessages = (conversationId: string) =>
  pb.send(`/backend/v1/vivi/chats/${conversationId}/messages`, { method: 'GET' })
