import pb from '@/lib/pocketbase/client'

export interface OversupplyAlertItem {
  product_name: string
  city: string
  count: number
  total_kg: number
  suggested_action: string
  products: Array<{
    id: string
    name: string
    quantity_kg: number
    price_per_kg: number
    waste_risk_level: string
  }>
}

export const getOversupplyAlerts = () =>
  pb.send('/backend/v1/oversupply-check', { method: 'GET' }) as Promise<{
    alerts: OversupplyAlertItem[]
  }>
