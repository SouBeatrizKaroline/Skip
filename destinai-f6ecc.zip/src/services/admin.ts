import pb from '@/lib/pocketbase/client'

export interface AdminStats {
  totalUsers: number
  totalProducts: number
  totalMatches: number
  totalOrders: number
  usersByRole: Record<string, number>
  productsByStatus: Record<string, number>
  recentUsers: any[]
}

const emptyList = { items: [], totalItems: 0 } as any

export async function getAdminStats(): Promise<AdminStats> {
  const [users, products, orders, matches] = await Promise.all([
    pb
      .collection('users')
      .getList(1, 500, { sort: '-created' })
      .catch(() => emptyList),
    pb
      .collection('products')
      .getList(1, 500)
      .catch(() => emptyList),
    pb
      .collection('orders')
      .getList(1, 500)
      .catch(() => emptyList),
    pb
      .collection('matches')
      .getList(1, 500)
      .catch(() => emptyList),
  ])

  const usersByRole: Record<string, number> = {}
  for (const u of users.items) {
    const r = u.role || 'UNKNOWN'
    usersByRole[r] = (usersByRole[r] || 0) + 1
  }

  const productsByStatus: Record<string, number> = {}
  for (const p of products.items) {
    const s = p.status || 'UNKNOWN'
    productsByStatus[s] = (productsByStatus[s] || 0) + 1
  }

  return {
    totalUsers: users.totalItems,
    totalProducts: products.totalItems,
    totalMatches: matches.totalItems,
    totalOrders: orders.totalItems,
    usersByRole,
    productsByStatus,
    recentUsers: users.items.slice(0, 8),
  }
}
