import pb from '@/lib/pocketbase/client'

export const getMatchesByProducer = (producerId: string) =>
  pb.collection('matches').getFullList({
    filter: `producer_id="${producerId}"`,
    expand: 'product_id,buyer_id,producer_id',
    sort: '-created',
  })

export const getMatchesByBuyer = (buyerId: string) =>
  pb.collection('matches').getFullList({
    filter: `buyer_id="${buyerId}"`,
    expand: 'product_id,buyer_id,producer_id',
    sort: '-created',
  })

export const updateMatchStatus = (matchId: string, status: string) =>
  pb.collection('matches').update(matchId, { status })

export const getMatch = (id: string) =>
  pb.collection('matches').getOne(id, {
    expand: 'product_id,buyer_id,producer_id',
  })

export async function createMatch(data: {
  product_id: string
  buyer_id: string
  producer_id: string
  price_agreed: number
}): Promise<any> {
  const match = await pb.collection('matches').create({
    product_id: data.product_id,
    buyer_id: data.buyer_id,
    producer_id: data.producer_id,
    price_agreed: data.price_agreed,
    status: 'PENDING',
  })
  try {
    await pb.collection('products').update(data.product_id, { status: 'NEGOTIATING' })
  } catch {
    /* product status update is best-effort */
  }
  return match
}
