import pb from '@/lib/pocketbase/client'

export const getBuyerProfile = (userId: string) =>
  pb.collection('buyer_profiles').getFirstListItem(`user_id="${userId}"`)

export const getAvailableProductsForBuyer = () =>
  pb.collection('products').getFullList({
    filter: "status = 'AVAILABLE'",
    expand: 'producer_id',
    sort: '-created',
  })

export const getBuyerMatches = (buyerId: string) =>
  pb.collection('matches').getFullList({
    filter: `buyer_id="${buyerId}"`,
    expand: 'product_id,producer_id',
    sort: '-created',
  })
