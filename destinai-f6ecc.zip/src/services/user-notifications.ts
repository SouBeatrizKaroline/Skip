import pb from '@/lib/pocketbase/client'

export interface UserNotification {
  id: string
  title: string
  message: string
  type: string
  is_read: boolean
  vivi_insight: string
  created: string
}

export const getNotifications = () =>
  pb.collection('user_notifications').getFullList({ sort: '-created' }) as Promise<
    UserNotification[]
  >

export const markNotificationRead = (id: string) =>
  pb.collection('user_notifications').update(id, { is_read: true })

export const createNotification = (data: {
  user_id: string
  title: string
  message: string
  type: string
  vivi_insight?: string
}) => pb.collection('user_notifications').create({ ...data, is_read: false })
