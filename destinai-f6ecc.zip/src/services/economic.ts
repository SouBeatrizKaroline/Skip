import pb from '@/lib/pocketbase/client'

export interface EconomicAnalysis {
  match_score: number
  economic_score: number
  logistics_score: number
  justification: string
  financial: {
    lot_value: number
    logistics_cost: number
    platform_fee: number
    net_revenue: number
    fee_percentage: number
  }
  distance_km: number
}

export interface ConsolidationGroup {
  products: Array<{ id: string; name: string; quantity_kg: number; city: string; state: string }>
  total_kg: number
  total_value: number
  estimated_savings: number
}

export const getEconomicAnalysis = (productId: string, buyerId: string) =>
  pb.send('/backend/v1/economic-analysis', {
    method: 'POST',
    body: JSON.stringify({ product_id: productId, buyer_id: buyerId }),
    headers: { 'Content-Type': 'application/json' },
  }) as Promise<EconomicAnalysis>

export const getLoadConsolidation = () =>
  pb.send('/backend/v1/load-consolidation', { method: 'GET' }) as Promise<{
    consolidation_groups: ConsolidationGroup[]
  }>
