import pb from '@/lib/pocketbase/client'

export interface LeaderboardEntry {
  user_id: string
  name: string
  company_name: string
  role: string
  reputation_score: number
  tier_status: string
  kg_saved: number
  co2_saved_kg: number
  revenue_recovered: number
  meals_generated: number
  rank: number
  is_current_user: boolean
}

export interface LeaderboardResult {
  role: string
  rankings: LeaderboardEntry[]
  my_rank: number
  total_users: number
}

export const getLeaderboard = () =>
  pb.send('/backend/v1/leaderboard', { method: 'GET' }) as Promise<LeaderboardResult>
