import pb from '@/lib/pocketbase/client'

export interface Achievement {
  slug: string
  name: string
  description: string
  icon: string
  threshold: number
  current: number
  progress: number
  unlocked: boolean
}

export interface AchievementResult {
  achievements: Achievement[]
  new_unlocks: string[]
  stats: {
    kg_saved: number
    co2_saved_kg: number
    revenue_recovered: number
    meals_generated: number
    completed_deliveries: number
  }
}

export const getAchievements = () =>
  pb.send('/backend/v1/achievements', { method: 'GET' }) as Promise<AchievementResult>
