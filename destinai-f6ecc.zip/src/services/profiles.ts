import pb from '@/lib/pocketbase/client'

const ROLE_COLLECTIONS: Record<string, string> = {
  PRODUCER: 'producer_profiles',
  BUYER: 'buyer_profiles',
  TRANSPORTER: 'transporter_profiles',
}

export function getRoleCollection(role: string): string | null {
  return ROLE_COLLECTIONS[role] || null
}

export const getRoleProfile = (role: string, userId: string) => {
  const col = getRoleCollection(role)
  if (!col) throw new Error('Invalid role')
  return pb.collection(col).getFirstListItem(`user_id="${userId}"`)
}

export const updateUser = (userId: string, data: { name?: string; company_name?: string }) =>
  pb.collection('users').update(userId, data)

export const updateRoleProfile = (role: string, profileId: string, data: Record<string, any>) => {
  const col = getRoleCollection(role)
  if (!col) throw new Error('Invalid role')
  return pb.collection(col).update(profileId, data)
}
