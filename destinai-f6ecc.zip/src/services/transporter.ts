import pb from '@/lib/pocketbase/client'

export const getAvailableLoads = () =>
  pb.collection('orders').getFullList({
    filter: "status = 'PENDING' || status = 'WAITING_DRIVER'",
    expand: 'match_id.product_id,match_id.buyer_id,match_id.producer_id,transporter_id',
    sort: '-created',
  })

export const acceptLoad = (orderId: string, transporterId: string) =>
  pb.collection('orders').update(orderId, { status: 'ASSIGNED', transporter_id: transporterId })

export const reserveLoad = (orderId: string, transporterId: string) =>
  pb.collection('orders').update(orderId, {
    status: 'PICKUP_SCHEDULED',
    transporter_id: transporterId,
  })

export const getTransporterProfile = (userId: string) =>
  pb.collection('transporter_profiles').getFirstListItem(`user_id="${userId}"`)
