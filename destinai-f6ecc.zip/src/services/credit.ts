import pb from '@/lib/pocketbase/client'

export interface CreditProduct {
  id: string
  name: string
  institution: string
  type: string
  min_amount: number
  max_amount: number
  interest_rate: number
  term_months: number
  requirements: string
  description: string
  recommended: boolean
}

export const CREDIT_TYPE_LABELS: Record<string, string> = {
  GOV_PROGRAM: 'Programa Governamental',
  COOPERATIVE: 'Cooperativa',
  MICROCREDIT: 'Microcrédito',
  PRIVATE: 'Iniciativa Privada',
}

export const getCreditRecommendations = () =>
  pb.send('/backend/v1/credit/recommendations', { method: 'GET' }) as Promise<{
    products: CreditProduct[]
    ai_recommendation: string
  }>

export function formatCurrency(value: number): string {
  return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
}
