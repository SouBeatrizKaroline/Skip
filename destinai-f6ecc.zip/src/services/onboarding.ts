import pb from '@/lib/pocketbase/client'
import { getCurrentMonth } from '@/lib/formatters'

export interface OnboardingFormData {
  role: string
  name: string
  email: string
  password: string
  company_name: string
  document: string
  buyer_type: string
  vehicle_type: string
  max_capacity_kg: string
  city: string
  state: string
  phone: string
  description: string
  demand_tags: string
  goals: Record<string, { selected: boolean; target: number }>
}

export interface StepProps {
  data: OnboardingFormData
  update: (field: string, value: any) => void
}

const DEFAULT_LAT = -22.9
const DEFAULT_LNG = -47.06

export function createProfile(role: string, userId: string, data: OnboardingFormData) {
  const base: Record<string, any> = {
    user_id: userId,
    latitude: DEFAULT_LAT,
    longitude: DEFAULT_LNG,
    city: data.city,
    state: data.state,
    phone: data.phone,
  }

  if (role === 'PRODUCER') {
    return pb.collection('producer_profiles').create({
      ...base,
      farm_name: data.company_name,
      description: data.description || 'Produtor rural',
    })
  }

  if (role === 'BUYER') {
    return pb.collection('buyer_profiles').create({
      ...base,
      business_name: data.company_name,
      buyer_type: data.buyer_type,
      demand_tags: data.demand_tags || '',
      description: data.description || 'Comprador',
    })
  }

  if (role === 'TRANSPORTER') {
    return pb.collection('transporter_profiles').create({
      ...base,
      company_name: data.company_name,
      vehicle_type: data.vehicle_type,
      max_capacity_kg: Number(data.max_capacity_kg) || 5000,
    })
  }

  throw new Error('Invalid role')
}

export function createGoals(userId: string, goals: OnboardingFormData['goals']) {
  const month = getCurrentMonth()
  const entries = Object.entries(goals).filter(([, g]) => g.selected)
  return Promise.all(
    entries.map(([type, { target }]) =>
      pb.collection('user_goals').create({
        user_id: userId,
        goal_type: type,
        target_value: target,
        current_value: 0,
        month,
      }),
    ),
  )
}

export function completeOnboarding(data: {
  role: string
  city: string
  state: string
  goalTypes: string[]
}) {
  return pb.send('/backend/v1/onboarding/complete', {
    method: 'POST',
    body: JSON.stringify(data),
    headers: { 'Content-Type': 'application/json' },
  })
}
