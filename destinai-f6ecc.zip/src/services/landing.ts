import pb from '@/lib/pocketbase/client'

export interface LandingImpactStats {
  kgSaved: number
  co2Saved: number
  revenueRecovered: number
  mealsGenerated: number
  waterPreserved: number
  productCount: number
  producerCount: number
  buyerCount: number
  transporterCount: number
}

const FALLBACK_STATS: LandingImpactStats = {
  kgSaved: 12400,
  co2Saved: 18700,
  revenueRecovered: 356000,
  mealsGenerated: 41333,
  waterPreserved: 3100000,
  productCount: 87,
  producerCount: 1248,
  buyerCount: 456,
  transporterCount: 189,
}

export async function fetchLandingStats(): Promise<LandingImpactStats> {
  try {
    const stats = await pb.send('/backend/v1/investor-stats', { method: 'GET' })
    return {
      kgSaved: stats.total_kg_saved || FALLBACK_STATS.kgSaved,
      co2Saved: stats.total_co2_saved || FALLBACK_STATS.co2Saved,
      revenueRecovered: stats.total_revenue || FALLBACK_STATS.revenueRecovered,
      mealsGenerated: stats.total_meals || FALLBACK_STATS.mealsGenerated,
      waterPreserved: stats.total_water_preserved || FALLBACK_STATS.waterPreserved,
      productCount: stats.total_matches || FALLBACK_STATS.productCount,
      producerCount: stats.producer_count || FALLBACK_STATS.producerCount,
      buyerCount: stats.buyer_count || FALLBACK_STATS.buyerCount,
      transporterCount: stats.transporter_count || FALLBACK_STATS.transporterCount,
    }
  } catch {
    return FALLBACK_STATS
  }
}

export async function fetchRecentProducts(): Promise<any[]> {
  try {
    return await pb.collection('products').getFullList({
      filter: "status = 'AVAILABLE'",
      sort: '-created',
      limit: 8,
      expand: 'producer_id',
    })
  } catch {
    return []
  }
}

export async function fetchEcosystemLocations() {
  try {
    const [producers, buyers, transporters] = await Promise.all([
      pb
        .collection('producer_profiles')
        .getFullList()
        .catch(() => []),
      pb
        .collection('buyer_profiles')
        .getFullList()
        .catch(() => []),
      pb
        .collection('transporter_profiles')
        .getFullList()
        .catch(() => []),
    ])
    return { producers, buyers, transporters }
  } catch {
    return { producers: [], buyers: [], transporters: [] }
  }
}
