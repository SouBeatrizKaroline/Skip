import pb from '@/lib/pocketbase/client'

export const VISUAL_CONDITION_LABELS: Record<string, string> = {
  RETAIL_STANDARD: 'Padrão varejo',
  MINOR_IMPERFECTIONS: 'Pequenas imperfeições',
  NON_STANDARD: 'Fora do padrão',
  PROCESSING_ONLY: 'Para processamento',
}

export const PRODUCT_STATUS_LABELS: Record<string, string> = {
  AVAILABLE: 'Disponível',
  MATCHED: 'Combinado',
  NEGOTIATING: 'Negociando',
  TRANSPORTING: 'Transportando',
  DELIVERED: 'Entregue',
  EXPIRED: 'Expirado',
}

export const ORDER_STATUS_LABELS: Record<string, string> = {
  PENDING: 'Aguardando coleta',
  WAITING_DRIVER: 'Aguardando motorista',
  ASSIGNED: 'Aguardando coleta',
  PICKUP_SCHEDULED: 'Coleta agendada',
  PICKED_UP: 'Em transporte',
  PICKING_UP: 'Em coleta',
  IN_TRANSIT: 'Em transporte',
  DELIVERED: 'Entregue',
  CANCELLED: 'Cancelado',
}

export const WASTE_RISK_LABELS: Record<string, string> = {
  LOW: 'Baixo Risco',
  MEDIUM: 'Médio Risco',
  HIGH: 'Alto Risco',
  CRITICAL: 'Crítico',
}

export const MATURATION_STAGE_LABELS: Record<string, string> = {
  VERDE: 'Verde',
  PONTO: 'No ponto',
  MADURO: 'Maduro',
  AVANCADO: 'Avançado',
}

export function getProductImage(name: string): string {
  return `https://img.usecurling.com/p/400/300?q=${encodeURIComponent(name)}`
}

export function formatPrice(perKg: number): string {
  return `R$ ${perKg.toFixed(2).replace('.', ',')} / kg`
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`
}

export function computeSmartScore(p: any): number {
  let score = 50
  const conditionScores: Record<string, number> = {
    RETAIL_STANDARD: 30,
    MINOR_IMPERFECTIONS: 20,
    NON_STANDARD: 10,
    PROCESSING_ONLY: 5,
  }
  score += conditionScores[p.visual_condition] || 0
  const riskScores: Record<string, number> = {
    LOW: 20,
    MEDIUM: 10,
    HIGH: 0,
    CRITICAL: -10,
  }
  score += riskScores[p.waste_risk_level] || 0
  if (p.estimated_life_days && p.estimated_life_days > 7) score += 10
  return Math.max(0, Math.min(100, score))
}

export interface DisplayProduct {
  id: string
  name: string
  qty: string
  price: string
  pricePerKg: number
  distance: string
  type: string
  image: string
  producer: string
  date: string
  lat: number
  lon: number
  wasteRiskLevel?: string
  netRevenuePerKg?: number
  costPerKg?: number
  recommendedPriceRange?: string
  smartScore?: number
}

export function toDisplayProduct(p: any): DisplayProduct {
  const producer = p.expand?.producer_id
  return {
    id: p.id,
    name: p.name || '',
    qty: `${p.quantity_kg || 0} kg`,
    price: p.price_per_kg ? `R$ ${p.price_per_kg.toFixed(2).replace('.', ',')}` : '',
    pricePerKg: p.price_per_kg || 0,
    distance: p.city ? `${p.city}${p.state ? ', ' + p.state : ''}` : '',
    type: VISUAL_CONDITION_LABELS[p.visual_condition] || '',
    image: getProductImage(p.name),
    producer: producer?.farm_name || p.city || 'Produtor',
    date: formatDate(p.harvest_date || ''),
    lat: p.latitude || producer?.latitude || 0,
    lon: p.longitude || producer?.longitude || 0,
    wasteRiskLevel: p.waste_risk_level,
    netRevenuePerKg: p.net_revenue_per_kg,
    costPerKg: p.cost_per_kg,
    recommendedPriceRange: p.recommended_price_range,
    smartScore: computeSmartScore(p),
  }
}

export interface DisplayOrder {
  id: string
  title: string
  dest: string
  date: string
  load: string
  reward: string
  status: string
}

export function toDisplayOrder(o: any): DisplayOrder {
  const m = o.expand?.match_id
  const product = m?.expand?.product_id
  const buyer = m?.expand?.buyer_id
  return {
    id: o.id,
    title: `Coleta: ${product?.city || o.pickup_address || 'N/A'}`,
    dest: `Entrega: ${buyer?.city || o.delivery_address || 'N/A'}`,
    date: formatDate(o.created || ''),
    load: `${product?.name || 'Produto'} • ${product?.quantity_kg || 0} kg`,
    reward: o.reward ? `R$ ${o.reward.toFixed(2).replace('.', ',')}` : 'R$ 0,00',
    status: ORDER_STATUS_LABELS[o.status] || o.status || '',
  }
}

export const getProducts = () =>
  pb.collection('products').getFullList({ expand: 'producer_id', sort: '-created' })

export const getAvailableProducts = () =>
  pb
    .collection('products')
    .getFullList({ filter: "status = 'AVAILABLE'", expand: 'producer_id', sort: '-created' })

export const getProduct = (id: string) =>
  pb.collection('products').getOne(id, { expand: 'producer_id' })
export const createProduct = (data: Record<string, any>) => pb.collection('products').create(data)
export const getProductsByProducer = (producerId: string) =>
  pb
    .collection('products')
    .getFullList({ filter: `producer_id = "${producerId}"`, sort: '-created' })

export const getOrders = () =>
  pb.collection('orders').getFullList({
    expand: 'match_id.product_id,match_id.buyer_id,match_id.producer_id,transporter_id',
    sort: '-created',
  })
export const getOrder = (id: string) =>
  pb.collection('orders').getOne(id, {
    expand: 'match_id.product_id,match_id.buyer_id,match_id.producer_id,transporter_id',
  })
export const updateOrderStatus = (id: string, status: string) =>
  pb.collection('orders').update(id, { status })
