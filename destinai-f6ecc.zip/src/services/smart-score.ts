import pb from '@/lib/pocketbase/client'

export interface SmartScoreFactors {
  economic: {
    score: number
    lot_value: number
    logistics_cost: number
    platform_fee: number
    net_revenue: number
    status: 'recommended' | 'not_recommended'
    fee_percentage: number
  }
  logistics: {
    score: number
    nearest_buyer_km: number
    compatible_transporters: number
    capacity_ok: boolean
  }
  perishability: {
    level: 'high' | 'medium' | 'low' | 'critical'
    risk: 'high' | 'medium' | 'low' | 'critical'
    risk_emoji: string
    shelf_life_days: number
    remaining_days: number
    days_since_harvest: number
    used_pct: number
  }
  demand: {
    score: number
    matching_buyers: number
  }
  climate: {
    score: number
    temperature: number
    humidity: number
    condition: string
    alerts: string[]
  }
}

export interface SmartScoreResult {
  smart_score: number
  closing_probability?: number
  factors: SmartScoreFactors
  vivi_justification: string
}

export interface SmartAlert {
  urgency: 'critical' | 'warning' | 'info'
  type: string
  title: string
  message: string
  product_id?: string
  product_name?: string
  match_id?: string
}

export const getSmartScore = (productId: string) =>
  pb.send(`/backend/v1/smart-score/${productId}`, { method: 'POST' }) as Promise<SmartScoreResult>

export const getSmartAlerts = () =>
  pb.send('/backend/v1/smart-alerts', { method: 'GET' }) as Promise<{ alerts: SmartAlert[] }>
