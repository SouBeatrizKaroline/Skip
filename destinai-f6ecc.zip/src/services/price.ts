import pb from '@/lib/pocketbase/client'

export interface PriceIntelligenceRequest {
  name: string
  quantity_kg: number
  visual_condition: string
  price_per_kg: number
  city?: string
  state?: string
}

export interface PriceIntelligenceResult {
  min_price: number
  recommended_price: number
  ideal_price: number
  analysis: string
  factors: {
    regional_avg: number
    condition_adjustment: number
    demand_multiplier: number
  }
}

export const getPriceIntelligence = (data: PriceIntelligenceRequest) =>
  pb.send('/backend/v1/price-intelligence', {
    method: 'POST',
    body: JSON.stringify(data),
    headers: { 'Content-Type': 'application/json' },
  }) as Promise<PriceIntelligenceResult>
