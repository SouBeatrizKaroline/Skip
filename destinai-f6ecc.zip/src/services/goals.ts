import pb from '@/lib/pocketbase/client'

export interface UserGoal {
  id: string
  user_id: string
  goal_type: string
  target_value: number
  current_value: number
  month: string
}

export const GOAL_TYPE_LABELS: Record<string, string> = {
  KG_SAVED: 'Kg salvos',
  REVENUE: 'Receita (R$)',
  CO2_SAVED: 'CO2 evitado (kg)',
  DELIVERIES: 'Entregas',
  MATCHES: 'Matches',
}

export const MONTHS = [
  'Janeiro',
  'Fevereiro',
  'Marco',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
]

export const getGoals = (userId: string) =>
  pb
    .collection('user_goals')
    .getFullList({ filter: `user_id="${userId}"`, sort: '-created' }) as Promise<UserGoal[]>

export const createGoal = (data: {
  user_id: string
  goal_type: string
  target_value: number
  month: string
}) => pb.collection('user_goals').create({ ...data, current_value: 0 })

export const updateGoal = (id: string, data: Partial<UserGoal>) =>
  pb.collection('user_goals').update(id, data)
