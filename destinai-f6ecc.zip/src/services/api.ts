import pb from '@/lib/pocketbase/client'

export const analyzeProduct = (productId: string) =>
  pb.send(`/backend/v1/ai/analyze/${productId}`, { method: 'POST' })

export const getRecommendations = (productId: string) =>
  pb.send(`/backend/v1/recommendations/${productId}`, { method: 'GET' })

export const getImpact = () => pb.send('/backend/v1/impact', { method: 'GET' })

export const getForecast = () => pb.send('/backend/v1/forecast', { method: 'GET' })

export const analyzeVision = (productId: string) =>
  pb.send(`/backend/v1/vision/analyze/${productId}`, { method: 'POST' })

export const getWeather = (city: string, state?: string) =>
  pb.send(
    `/backend/v1/weather?city=${encodeURIComponent(city)}&state=${encodeURIComponent(state || '')}`,
    { method: 'GET' },
  )

export const getRoute = (fromLat: number, fromLon: number, toLat: number, toLon: number) =>
  pb.send(`/backend/v1/route?fromLat=${fromLat}&fromLon=${fromLon}&toLat=${toLat}&toLon=${toLon}`, {
    method: 'GET',
  })

export const sendWhatsApp = (phone: string, message: string) =>
  pb.send('/backend/v1/whatsapp/notify', {
    method: 'POST',
    body: JSON.stringify({ phone, message }),
    headers: { 'Content-Type': 'application/json' },
  })
