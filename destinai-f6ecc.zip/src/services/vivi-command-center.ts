import pb from '@/lib/pocketbase/client'

export interface CommandCenterInsight {
  type: string
  icon: string
  title: string
  message: string
  action_text?: string
  action_url?: string
  priority: string
  vivi_insight?: string
  progress?: number
  current?: number
  target?: number
}

export interface CommandCenterResult {
  insights: CommandCenterInsight[]
  role: string
}

export const getCommandCenter = () =>
  pb.send('/backend/v1/vivi/command-center', { method: 'GET' }) as Promise<CommandCenterResult>
