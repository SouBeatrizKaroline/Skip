import pb from '@/lib/pocketbase/client'

export interface RateTransactionParams {
  type: 'match' | 'order'
  id: string
  rating: number
  rater_role: string
}

export const rateTransaction = (params: RateTransactionParams) =>
  pb.send('/backend/v1/rate-transaction', {
    method: 'POST',
    body: JSON.stringify(params),
    headers: { 'Content-Type': 'application/json' },
  })
