export const TIER_LABELS: Record<string, string> = {
  BRONZE: 'Bronze',
  SILVER: 'Prata',
  GOLD: 'Ouro',
  DIAMOND: 'Diamante',
}

export const TIER_THRESHOLDS = [
  { tier: 'DIAMOND', min: 600 },
  { tier: 'GOLD', min: 300 },
  { tier: 'SILVER', min: 100 },
  { tier: 'BRONZE', min: 0 },
]

export function getTierFromScore(score: number): string {
  for (const t of TIER_THRESHOLDS) {
    if (score >= t.min) return t.tier
  }
  return 'BRONZE'
}
