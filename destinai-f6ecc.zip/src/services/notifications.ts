import { sendWhatsApp } from '@/services/api'

export interface NotificationPayload {
  email: string
  phone: string
  title: string
  message: string
}

export function dispatchNotification(payload: NotificationPayload) {
  window.dispatchEvent(new CustomEvent('destinai-notification', { detail: payload }))
  if (payload.phone) {
    sendWhatsApp(payload.phone, `${payload.title}\n\n${payload.message}`).catch(() => {})
  }
}
