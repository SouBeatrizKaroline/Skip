import pb from '@/lib/pocketbase/client'
import { getSmartAlerts } from '@/services/smart-score'

export interface ViviInsightData {
  hasBuyerMatch: boolean
  hasHighDemand: boolean
  hasWasteRisk: boolean
  hasClimateRisk: boolean
  hasTransporterAvailable: boolean
  recommendationCount: number
  matchCount: number
  topRecommendation?: { buyer_name: string; match_score: number; justification: string }
}

const DEFAULT: ViviInsightData = {
  hasBuyerMatch: false,
  hasHighDemand: false,
  hasWasteRisk: false,
  hasClimateRisk: false,
  hasTransporterAvailable: false,
  recommendationCount: 0,
  matchCount: 0,
}

async function getAlertFlags() {
  try {
    const { alerts = [] } = await getSmartAlerts()
    return {
      hasClimateRisk: alerts.some((a) => a.type === 'climate'),
      hasHighDemand: alerts.some((a) => a.type === 'demand'),
      hasWasteRisk: alerts.some((a) => a.type === 'expiry' && a.urgency === 'critical'),
    }
  } catch {
    return { hasClimateRisk: false, hasHighDemand: false, hasWasteRisk: false }
  }
}

async function hasTransporters(): Promise<boolean> {
  try {
    return (await pb.collection('transporter_profiles').getList(1, 1)).totalItems > 0
  } catch {
    return false
  }
}

export async function getProducerInsights(producerId: string): Promise<ViviInsightData> {
  if (!producerId) return DEFAULT
  const products = await pb.collection('products').getFullList({
    filter: `producer_id="${producerId}" && status != 'DELIVERED' && status != 'EXPIRED'`,
  })
  const hasWasteRisk = products.some(
    (p) => p.waste_risk_level === 'HIGH' || p.waste_risk_level === 'CRITICAL',
  )

  let recommendationCount = 0
  let hasBuyerMatch = false
  let topRec: ViviInsightData['topRecommendation']

  if (products.length > 0) {
    try {
      const recs = await pb.collection('recommendations').getFullList({
        filter: `product_id="${products[0].id}"`,
        sort: '-match_score',
        expand: 'buyer_id',
      })
      recommendationCount = recs.length
      hasBuyerMatch = recs.some((r) => (r.match_score || 0) >= 70)
      if (recs[0]?.expand?.buyer_id) {
        topRec = {
          buyer_name: recs[0].expand.buyer_id.business_name || 'Comprador',
          match_score: recs[0].match_score || 0,
          justification: `Match de ${recs[0].match_score}% com ${recs[0].expand.buyer_id.business_name}`,
        }
      }
    } catch {
      /* intentionally ignored */
    }
  }

  let matchCount = 0
  try {
    const matches = await pb.collection('matches').getFullList({
      filter: `producer_id="${producerId}" && status="PENDING"`,
    })
    matchCount = matches.length
    if (matchCount > 0) hasBuyerMatch = true
  } catch {
    /* intentionally ignored */
  }

  const flags = await getAlertFlags()
  return {
    ...DEFAULT,
    ...flags,
    hasWasteRisk: hasWasteRisk || flags.hasWasteRisk,
    hasBuyerMatch,
    recommendationCount,
    matchCount,
    hasTransporterAvailable: await hasTransporters(),
    topRecommendation: topRec,
  }
}

export async function getBuyerInsights(buyerId: string): Promise<ViviInsightData> {
  if (!buyerId) return DEFAULT
  let recommendationCount = 0
  let hasBuyerMatch = false
  let topRec: ViviInsightData['topRecommendation']

  try {
    const recs = await pb.collection('recommendations').getFullList({
      filter: `buyer_id="${buyerId}"`,
      sort: '-match_score',
      expand: 'product_id',
    })
    recommendationCount = recs.length
    hasBuyerMatch = recs.some((r) => (r.match_score || 0) >= 70)
    if (recs[0]) {
      const name = recs[0].expand?.product_id?.name || 'produto'
      topRec = {
        buyer_name: name,
        match_score: recs[0].match_score || 0,
        justification: `Match de ${recs[0].match_score}% para ${name}`,
      }
    }
  } catch {
    /* intentionally ignored */
  }

  const flags = await getAlertFlags()
  return {
    ...DEFAULT,
    ...flags,
    hasBuyerMatch,
    recommendationCount,
    hasTransporterAvailable: await hasTransporters(),
    topRecommendation: topRec,
  }
}

export async function getTransporterInsights(): Promise<ViviInsightData> {
  let matchCount = 0
  let hasBuyerMatch = false
  try {
    const orders = await pb.collection('orders').getFullList({
      filter: 'status="PENDING"',
      sort: '-created',
    })
    matchCount = orders.length
    hasBuyerMatch = orders.length > 0
  } catch {
    /* intentionally ignored */
  }

  const flags = await getAlertFlags()
  return {
    ...DEFAULT,
    ...flags,
    hasBuyerMatch,
    matchCount,
    hasTransporterAvailable: true,
  }
}
