import pb from '@/lib/pocketbase/client'

export interface InvestorStats {
  total_volume: number
  total_matches: number
  total_users: number
  total_kg_saved: number
  total_revenue: number
  total_co2_saved: number
  total_water_preserved: number
  total_meals: number
  producer_count: number
  buyer_count: number
  transporter_count: number
}

export const getInvestorStats = () =>
  pb.send('/backend/v1/investor-stats', { method: 'GET' }) as Promise<InvestorStats>
