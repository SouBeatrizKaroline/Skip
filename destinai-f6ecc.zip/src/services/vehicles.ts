import pb from '@/lib/pocketbase/client'

export const VEHICLE_TYPE_LABELS: Record<string, string> = {
  MOTORCYCLE: 'Moto',
  UTILITY: 'Utilitário',
  FIORINO: 'Fiorino',
  VAN: 'Van',
  LIGHT_TRUCK: 'Caminhão Leve',
  MEDIUM_TRUCK: 'Caminhão Médio',
  HEAVY_TRUCK: 'Caminhão Pesado',
}

export const AVAILABILITY_LABELS: Record<string, string> = {
  AVAILABLE: 'Disponível',
  BUSY: 'Ocupado',
  OFFLINE: 'Offline',
}

export const getVehicles = (transporterId: string) =>
  pb.collection('vehicles').getFullList({
    filter: `transporter_id="${transporterId}"`,
    sort: '-created',
  })

export const createVehicle = (data: Record<string, any>) => pb.collection('vehicles').create(data)

export const updateVehicle = (id: string, data: Record<string, any>) =>
  pb.collection('vehicles').update(id, data)

export const deleteVehicle = (id: string) => pb.collection('vehicles').delete(id)
