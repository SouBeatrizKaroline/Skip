import { Link } from 'react-router-dom'
import { useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Leaf } from 'lucide-react'

const NotFound = () => {
  const pathname = window.location.pathname

  useEffect(() => {
    if (pathname !== '/' && pathname !== '/login' && pathname !== '/onboarding') {
      console.warn('Página não encontrada:', pathname)
    }
  }, [pathname])

  return (
    <div className="flex-1 flex flex-col items-center justify-center py-20 px-4 animate-fade-in-up">
      <div className="text-center max-w-md">
        <div className="inline-flex items-center gap-2 mb-6">
          <div className="bg-primary text-primary-foreground p-2 rounded-lg">
            <Leaf className="w-6 h-6 fill-current" />
          </div>
          <span className="font-bold text-2xl text-primary">DestinAI</span>
        </div>
        <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Oops! A página que você procura não foi encontrada.
        </p>
        <Button size="lg" className="rounded-full" asChild>
          <Link to="/">Voltar para o início</Link>
        </Button>
      </div>
    </div>
  )
}

export default NotFound
