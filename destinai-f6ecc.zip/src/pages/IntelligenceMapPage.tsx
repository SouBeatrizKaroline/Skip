import { IntelligenceMap } from '@/components/IntelligenceMap'
import { LoadConsolidationAlert } from '@/components/LoadConsolidationAlert'
import { WeatherWidget } from '@/components/WeatherWidget'
import { DemandForecastWidget } from '@/components/DemandForecastWidget'
import { Map, Sparkles } from 'lucide-react'

export default function IntelligenceMapPage() {
  return (
    <div className="max-w-6xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center shrink-0">
          <Map className="w-7 h-7 text-accent" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-primary">Mapa de Inteligência</h1>
          <p className="text-muted-foreground">Visualize oferta, demanda e rotas otimizadas</p>
        </div>
      </div>

      <div className="mb-6">
        <IntelligenceMap />
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <DemandForecastWidget />
        <WeatherWidget city="Campinas" state="SP" />
      </div>

      <LoadConsolidationAlert />

      <div className="mt-6 bg-gradient-to-r from-secondary/10 to-transparent rounded-2xl p-5 border border-secondary/20">
        <div className="flex items-start gap-3">
          <div className="bg-secondary/20 p-2 rounded-full shrink-0">
            <Sparkles className="w-5 h-5 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-primary mb-1">Insight da Vivi 🌱</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              A Vivi recomenda monitorar as áreas em vermelho no mapa — indicam excesso de oferta
              que pode levar ao desperdício. Priorize conexões com compradores em áreas verdes (alta
              demanda) para maximizar o aproveitamento.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
