import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { CreditCard, Sparkles, TrendingUp, CheckCircle2, Loader2 } from 'lucide-react'
import {
  getCreditRecommendations,
  CREDIT_TYPE_LABELS,
  formatCurrency,
  type CreditProduct,
} from '@/services/credit'

export default function CreditHub() {
  const [products, setProducts] = useState<CreditProduct[]>([])
  const [aiRec, setAiRec] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getCreditRecommendations()
      .then((res) => {
        setProducts(res.products || [])
        setAiRec(res.ai_recommendation || '')
      })
      .catch(() => {
        setProducts([])
      })
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="max-w-5xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 bg-secondary/10 rounded-2xl flex items-center justify-center shrink-0 border border-secondary/20">
          <CreditCard className="w-7 h-7 text-secondary" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-primary">Crédito e Crescimento</h1>
          <p className="text-muted-foreground">Linhas de crédito recomendadas para seu perfil</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-secondary" />
        </div>
      ) : (
        <>
          {aiRec && (
            <Card className="p-6 mb-6 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/10 to-transparent">
              <div className="flex items-start gap-3">
                <div className="bg-secondary/20 p-2 rounded-full shrink-0">
                  <Sparkles className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-primary mb-1">Recomendação da Vivi 🌱</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{aiRec}</p>
                </div>
              </div>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {products.map((p) => (
              <Card
                key={p.id}
                className={`p-5 rounded-2xl border-border shadow-subtle ${p.recommended ? 'ring-2 ring-secondary/30' : ''}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg text-primary">{p.name}</h3>
                    <p className="text-xs text-muted-foreground">{p.institution}</p>
                  </div>
                  {p.recommended && (
                    <span className="bg-secondary text-white px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Recomendado
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-3">{p.description}</p>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground font-bold">Taxa</p>
                    <p className="font-bold text-accent">{p.interest_rate}% a.a.</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-bold">Prazo</p>
                    <p className="font-bold text-primary">{p.term_months} meses</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-bold">Mínimo</p>
                    <p className="font-bold text-primary">{formatCurrency(p.min_amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-bold">Máximo</p>
                    <p className="font-bold text-primary">{formatCurrency(p.max_amount)}</p>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    <span className="font-bold">Requisitos:</span> {p.requirements}
                  </p>
                  <span className="inline-block mt-2 text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full font-bold">
                    {CREDIT_TYPE_LABELS[p.type] || p.type}
                  </span>
                </div>
              </Card>
            ))}
          </div>

          {products.length === 0 && (
            <div className="text-center py-16">
              <CreditCard className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma linha de crédito disponível.</p>
            </div>
          )}
        </>
      )}
    </div>
  )
}
