import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ClientResponseError } from 'pocketbase'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Alert, AlertDescription } from '@/components/ui/alert'
import {
  Leaf,
  Mail,
  Lock,
  AlertCircle,
  Loader2,
  Sparkles,
  ArrowRight,
  TrendingUp,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { toast } from '@/hooks/use-toast'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { getPostAuthPath } from '@/lib/role-redirect'
import pb from '@/lib/pocketbase/client'

function getLoginErrorMessage(error: unknown): string {
  if (error instanceof ClientResponseError) {
    if (error.status === 0 || error.isAbort) {
      return 'Não foi possível conectar. Verifique sua internet.'
    }
    if (error.status === 400) {
      return 'E-mail ou senha inválidos. Verifique seus dados e tente novamente.'
    }
    const msg = (error.message || '').toLowerCase()
    if (msg.includes('password') || msg.includes('senha')) {
      return 'Senha incorreta. Tente novamente.'
    }
    return 'Não encontramos uma conta com esses dados.'
  }
  if (error instanceof DOMException && error.name === 'AbortError') {
    return 'Login cancelado. Tente novamente quando estiver pronto.'
  }
  return 'Não foi possível conectar. Verifique sua internet.'
}

const IMPACT_STATS = [
  { value: '2.4M', label: 'kg salvos' },
  { value: '1.800+', label: 'produtores' },
  { value: 'R$ 3.2M', label: 'recuperados' },
]

function BrandPanel() {
  return (
    <div className="relative hidden lg:flex flex-col justify-between min-h-screen overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(135deg, hsl(125 55% 18% / 0.92), hsl(122 39% 30% / 0.78)), url(https://img.usecurling.com/p/1200/1600?q=sustainable%20agriculture%20green%20farm&dpr=2)`,
        }}
      />
      <div className="relative z-10 p-10 xl:p-14">
        <div className="flex items-center gap-3">
          <div className="bg-white/15 backdrop-blur-md p-2.5 rounded-xl border border-white/20">
            <Leaf className="w-7 h-7 text-white" />
          </div>
          <span className="font-bold text-3xl text-white tracking-tight">DestinAI</span>
        </div>
      </div>

      <div className="relative z-10 px-10 xl:px-14 pb-10 space-y-8">
        <div className="space-y-3">
          <h1 className="text-4xl xl:text-5xl font-bold text-white leading-tight">
            Transformando o<br />
            desperdício em
            <br />
            oportunidade.
          </h1>
          <p className="text-lg text-white/80 max-w-md">
            Inteligência artificial conectando produtores, compradores e logística para acabar com o
            desperdício de hortaliças.
          </p>
        </div>

        <div className="flex gap-8 pt-2">
          {IMPACT_STATS.map((stat) => (
            <div key={stat.label}>
              <p className="text-2xl xl:text-3xl font-bold text-white">{stat.value}</p>
              <p className="text-sm text-white/70">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2 text-white/60 text-sm">
          <TrendingUp className="w-4 h-4" />
          <span>Plataforma certificada · AgTech Brasil</span>
        </div>
      </div>
    </div>
  )
}

function ViviInsightBubble() {
  return (
    <div className="flex items-start gap-3 p-4 rounded-2xl bg-gradient-to-br from-secondary/10 to-primary/5 border border-secondary/20 animate-fade-in-up">
      <div className="bg-secondary/15 p-2 rounded-lg shrink-0">
        <Sparkles className="w-5 h-5 text-secondary" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-1.5 mb-0.5">
          <span className="text-sm font-bold text-primary">Vivi</span>
          <span className="text-xs">🌱</span>
        </div>
        <p className="text-sm text-muted-foreground">Olá! Pronto para otimizar seus lotes hoje?</p>
      </div>
    </div>
  )
}

export default function Login() {
  const navigate = useNavigate()
  const { signIn } = useAuth()
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const formSchema = z.object({
    email: z.string().email('E-mail inválido'),
    password: z.string().min(1, 'Senha obrigatória'),
  })

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { email: '', password: '' },
    mode: 'onBlur',
  })

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setLoading(true)
    setError('')
    try {
      const { error } = await signIn(values.email, values.password)
      if (error) {
        const msg = getLoginErrorMessage(error)
        setError(msg)
        toast({ title: 'Erro ao entrar', description: msg, variant: 'destructive' })
        form.setValue('password', '')
        form.setFocus('password')
      } else {
        navigate(getPostAuthPath(pb.authStore.record))
      }
    } catch (err) {
      const msg = getLoginErrorMessage(err)
      setError(msg)
      toast({ title: 'Erro ao entrar', description: msg, variant: 'destructive' })
      form.setValue('password', '')
      form.setFocus('password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-[calc(100dvh-0px)]">
      <BrandPanel />

      <div className="flex-1 flex flex-col items-center justify-center py-12 px-4 bg-background min-h-[100dvh] lg:min-h-screen">
        <div className="w-full max-w-md animate-fade-in-up">
          <div className="lg:hidden text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-4">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <Leaf className="w-6 h-6 fill-current" />
              </div>
              <span className="font-bold text-2xl text-primary">DestinAI</span>
            </div>
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-primary mb-1">Bem-vindo de volta</h1>
            <p className="text-muted-foreground">Entre na sua conta para continuar</p>
          </div>

          <ViviInsightBubble />

          <Card className="p-6 sm:p-8 shadow-elevation border-none mt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="space-y-2">
                      <FormLabel className="text-primary font-bold">E-mail</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <Input
                            type="email"
                            placeholder="seu@email.com"
                            className="bg-muted border-none h-12 pl-11 focus-visible:ring-2 focus-visible:ring-primary"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem className="space-y-2">
                      <div className="flex items-center justify-between">
                        <FormLabel className="text-primary font-bold">Senha</FormLabel>
                        <Link
                          to="/forgot-password"
                          className="text-sm text-accent hover:text-accent/80 hover:underline font-medium transition-colors"
                        >
                          Esqueci minha senha
                        </Link>
                      </div>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <Input
                            type="password"
                            placeholder="••••••••"
                            className="bg-muted border-none h-12 pl-11 focus-visible:ring-2 focus-visible:ring-primary"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {error && (
                  <Alert variant="destructive" className="rounded-xl">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-full h-12 text-base font-bold shadow-elevation transition-all hover:shadow-lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Entrando...
                    </>
                  ) : (
                    <>
                      Entrar
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </Form>

            <div className="mt-6 pt-6 border-t border-border/50">
              <p className="text-center text-sm text-muted-foreground">
                Não tem conta?{' '}
                <Link
                  to="/onboarding"
                  className="font-bold text-primary hover:underline inline-flex items-center gap-1"
                >
                  Criar conta
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </p>
            </div>

            <p className="text-center text-xs text-muted-foreground mt-4">
              Conta demo: producer1@destinai.demo / Skip@Pass
            </p>
          </Card>
        </div>
      </div>
    </div>
  )
}
