import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Bar, BarChart, Line, LineChart, ResponsiveContainer, XAxis, YAxis } from 'recharts'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { TrendingUp, Sprout, Calendar, Sparkles, Map } from 'lucide-react'
import { Link } from 'react-router-dom'
import pb from '@/lib/pocketbase/client'

const monthlyData = [
  { month: 'Jan', producao: 420, desperdicio: 180 },
  { month: 'Fev', producao: 380, desperdicio: 150 },
  { month: 'Mar', producao: 550, desperdicio: 200 },
  { month: 'Abr', producao: 680, desperdicio: 160 },
  { month: 'Mai', producao: 720, desperdicio: 120 },
  { month: 'Jun', producao: 650, desperdicio: 140 },
]

const seasonalTrend = [
  { week: 'S1', previsao: 120 },
  { week: 'S2', previsao: 180 },
  { week: 'S3', previsao: 240 },
  { week: 'S4', previsao: 300 },
  { week: 'S5', previsao: 280 },
  { week: 'S6', previsao: 320 },
]

export default function HarvestIntelligence() {
  const [stats, setStats] = useState({ total: 0, active: 0, avgQuality: 78 })

  useEffect(() => {
    pb.collection('products')
      .getFullList({ fields: 'quantity_kg,status' })
      .then((products) => {
        const total = products.reduce((s, p) => s + (p.quantity_kg || 0), 0)
        const active = products.filter((p) => p.status === 'AVAILABLE').length
        setStats({ total, active, avgQuality: 78 })
      })
      .catch(() => {})
  }, [])

  return (
    <div className="max-w-6xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 bg-secondary/10 rounded-2xl flex items-center justify-center shrink-0">
          <TrendingUp className="w-7 h-7 text-secondary" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-primary">Inteligência de Safra</h1>
          <p className="text-muted-foreground">Tendências e insights da sua região</p>
        </div>
      </div>

      <Link
        to="/intelligence-map"
        className="flex items-center gap-2 text-sm font-bold text-secondary hover:underline mb-6"
      >
        <Map className="w-4 h-4" /> Ver Mapa de Inteligência →
      </Link>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          {
            label: 'Produção total',
            value: `${stats.total} kg`,
            icon: Sprout,
            color: 'text-primary',
            bg: 'bg-primary/10',
          },
          {
            label: 'Lotes ativos',
            value: stats.active,
            icon: Calendar,
            color: 'text-accent',
            bg: 'bg-accent/10',
          },
          {
            label: 'Qualidade média',
            value: `${stats.avgQuality}%`,
            icon: TrendingUp,
            color: 'text-secondary',
            bg: 'bg-secondary/10',
          },
          {
            label: 'Desperdício evitado',
            value: '1.2t',
            icon: Sparkles,
            color: 'text-primary',
            bg: 'bg-primary/10',
          },
        ].map((s, i) => (
          <Card key={i} className="p-5 border-none shadow-subtle rounded-2xl">
            <div className={`w-9 h-9 ${s.bg} rounded-full flex items-center justify-center mb-3`}>
              <s.icon className={`w-4 h-4 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-primary">{s.value}</p>
            <p className="text-xs text-muted-foreground font-medium mt-1">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <Card className="p-6 rounded-[2rem] border-border shadow-subtle">
          <h3 className="font-bold text-lg text-primary mb-1">Produção vs Desperdício</h3>
          <p className="text-xs text-muted-foreground mb-4">Últimos 6 meses (kg)</p>
          <div className="h-64">
            <ChartContainer
              config={{
                producao: { label: 'Produção', color: 'hsl(var(--secondary))' },
                desperdicio: { label: 'Desperdício', color: 'hsl(var(--muted-foreground))' },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <XAxis dataKey="month" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis fontSize={11} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="producao" fill="var(--color-producao)" radius={[4, 4, 0, 0]} />
                  <Bar
                    dataKey="desperdicio"
                    fill="var(--color-desperdicio)"
                    radius={[4, 4, 0, 0]}
                    opacity={0.3}
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </Card>

        <Card className="p-6 rounded-[2rem] border-border shadow-subtle">
          <h3 className="font-bold text-lg text-primary mb-1">Previsão de Safra</h3>
          <p className="text-xs text-muted-foreground mb-4">Próximas 6 semanas (kg)</p>
          <div className="h-64">
            <ChartContainer
              config={{ previsao: { label: 'Previsão', color: 'hsl(var(--secondary))' } }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={seasonalTrend} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <XAxis dataKey="week" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis fontSize={11} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    dataKey="previsao"
                    stroke="var(--color-previsao)"
                    strokeWidth={3}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </Card>
      </div>

      <Card className="p-6 rounded-[2rem] border-border shadow-subtle bg-gradient-to-r from-secondary/10 to-transparent">
        <div className="flex items-start gap-4">
          <div className="bg-secondary/20 p-2 rounded-full shrink-0">
            <Sparkles className="w-5 h-5 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-primary mb-1">Insight da IA</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Baseado nos dados sazonais, a produção de hortaliças deve aumentar 23% nas próximas
              semanas. Recomenda-se cadastrar lotes com antecedência para maximizar as oportunidades
              de match com compradores locais. A demanda por restaurantes na região de Campinas está
              15% acima da média.
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
