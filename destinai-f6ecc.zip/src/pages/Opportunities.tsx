import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Search, MapPin, Package, Navigation2 } from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import {
  getAvailableProducts,
  toDisplayProduct,
  VISUAL_CONDITION_LABELS,
  type DisplayProduct,
} from '@/services/products'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'
import { getRoleProfile } from '@/services/profiles'

function haversineDist(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

export default function Opportunities() {
  const { user } = useAuth()
  const [products, setProducts] = useState<DisplayProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [productType, setProductType] = useState('all')
  const [maxPrice, setMaxPrice] = useState('')
  const [minQty, setMinQty] = useState('')
  const [maxDist, setMaxDist] = useState<number[]>([200])

  const [buyerLat, setBuyerLat] = useState<number | null>(null)
  const [buyerLon, setBuyerLon] = useState<number | null>(null)

  useEffect(() => {
    if (user && user.role === 'BUYER') {
      getRoleProfile(user.role, user.id)
        .then((p) => {
          if (p.latitude && p.longitude) {
            setBuyerLat(p.latitude)
            setBuyerLon(p.longitude)
          }
        })
        .catch(() => {})
    }
  }, [user])

  const loadData = async () => {
    try {
      const data = await getAvailableProducts()
      setProducts(data.map(toDisplayProduct))
    } catch {
      setProducts([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])
  useRealtime('products', () => {
    loadData()
  })

  const filtered = products.filter((p) => {
    if (
      search &&
      !p.name.toLowerCase().includes(search.toLowerCase()) &&
      !p.producer.toLowerCase().includes(search.toLowerCase())
    )
      return false
    if (productType !== 'all' && p.type !== VISUAL_CONDITION_LABELS[productType]) return false
    if (maxPrice && p.pricePerKg > parseFloat(maxPrice)) return false
    if (minQty && (parseInt(p.qty) || 0) < parseInt(minQty)) return false
    if (maxDist[0] < 500) {
      if (buyerLat !== null && buyerLon !== null && p.lat && p.lon) {
        const dist = haversineDist(buyerLat, buyerLon, p.lat, p.lon)
        if (dist > maxDist[0]) return false
      }
    }
    return true
  })

  return (
    <div className="max-w-6xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold text-primary mb-1">Rede de Oportunidades</h1>
        <p className="text-muted-foreground">Explore excedentes disponíveis na sua região</p>
      </div>

      <Card className="p-4 mb-6 rounded-2xl border-border shadow-subtle">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="relative md:col-span-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar produto..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 h-11 bg-muted border-none"
            />
          </div>
          <div className="md:col-span-3">
            <Select value={productType} onValueChange={setProductType}>
              <SelectTrigger className="h-11 bg-muted border-none">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="RETAIL_STANDARD">Padrão varejo</SelectItem>
                <SelectItem value="MINOR_IMPERFECTIONS">Pequenas imperfeições</SelectItem>
                <SelectItem value="NON_STANDARD">Fora do padrão</SelectItem>
                <SelectItem value="PROCESSING_ONLY">Processamento</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2">
            <Input
              type="number"
              placeholder="Preço máx"
              min="0"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              className="h-11 bg-muted border-none"
            />
          </div>
          <div className="md:col-span-2">
            <Input
              type="number"
              placeholder="Qtd mín (kg)"
              min="1"
              value={minQty}
              onChange={(e) => setMinQty(e.target.value)}
              className="h-11 bg-muted border-none"
            />
          </div>
          <div className="md:col-span-2 flex flex-col justify-center px-2">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-muted-foreground">Distância máx</span>
              <span className="text-xs font-bold text-primary">
                {maxDist[0] >= 500 ? 'Ilimitado' : `${maxDist[0]} km`}
              </span>
            </div>
            <Slider
              defaultValue={[200]}
              max={500}
              step={10}
              value={maxDist}
              onValueChange={setMaxDist}
              className="w-full"
            />
          </div>
        </div>
      </Card>

      <Card className="p-0 mb-6 rounded-[2rem] overflow-hidden border-border shadow-subtle">
        <div className="relative h-48 md:h-64 bg-muted">
          <svg
            className="absolute inset-0 w-full h-full"
            viewBox="0 0 400 200"
            preserveAspectRatio="xMidYMid slice"
          >
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path
                  d="M 20 0 L 0 0 0 20"
                  fill="none"
                  stroke="hsl(var(--border))"
                  strokeWidth="0.5"
                />
              </pattern>
            </defs>
            <rect width="400" height="200" fill="url(#grid)" />
            {(() => {
              const bounds = filtered.reduce(
                (acc, p) => ({
                  minLat: Math.min(acc.minLat, p.lat || 90),
                  maxLat: Math.max(acc.maxLat, p.lat || -90),
                  minLon: Math.min(acc.minLon, p.lon || 180),
                  maxLon: Math.max(acc.maxLon, p.lon || -180),
                }),
                { minLat: 90, maxLat: -90, minLon: 180, maxLon: -180 },
              )

              const latRange = Math.max(bounds.maxLat - bounds.minLat, 0.01)
              const lonRange = Math.max(bounds.maxLon - bounds.minLon, 0.01)

              return filtered.slice(0, 50).map((p) => {
                if (!p.lat || !p.lon) return null
                const x = 20 + ((p.lon - bounds.minLon) / lonRange) * 360
                const y = 180 - ((p.lat - bounds.minLat) / latRange) * 160

                return (
                  <g key={p.id}>
                    <circle
                      cx={x}
                      cy={y}
                      r="8"
                      fill="hsl(var(--secondary))"
                      opacity="0.3"
                      className="animate-pulse"
                    />
                    <circle cx={x} cy={y} r="4" fill="hsl(var(--secondary))" />
                  </g>
                )
              })
            })()}
            {buyerLat !== null && buyerLon !== null && (
              <g>
                {(() => {
                  const bounds = filtered.reduce(
                    (acc, p) => ({
                      minLat: Math.min(acc.minLat, p.lat || 90),
                      maxLat: Math.max(acc.maxLat, p.lat || -90),
                      minLon: Math.min(acc.minLon, p.lon || 180),
                      maxLon: Math.max(acc.maxLon, p.lon || -180),
                    }),
                    { minLat: 90, maxLat: -90, minLon: 180, maxLon: -180 },
                  )
                  const latRange = Math.max(bounds.maxLat - bounds.minLat, 0.01)
                  const lonRange = Math.max(bounds.maxLon - bounds.minLon, 0.01)
                  const x = 20 + ((buyerLon - bounds.minLon) / lonRange) * 360
                  const y = 180 - ((buyerLat - bounds.minLat) / latRange) * 160
                  return (
                    <circle
                      cx={x}
                      cy={y}
                      r="5"
                      fill="hsl(var(--primary))"
                      stroke="white"
                      strokeWidth="2"
                    />
                  )
                })()}
              </g>
            )}
          </svg>
          <div className="absolute top-3 left-3 bg-card/90 backdrop-blur px-3 py-1.5 rounded-lg shadow-sm">
            <p className="text-xs font-bold text-primary flex items-center gap-1">
              <Navigation2 className="w-3 h-3 text-secondary" /> {filtered.length} oportunidades no
              mapa
            </p>
          </div>
        </div>
      </Card>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="overflow-hidden rounded-2xl border-none">
              <Skeleton className="h-36 w-full" />
              <div className="p-4 space-y-2">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-4 w-32" />
              </div>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">
            Nenhum produto encontrado com esses filtros.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filtered.map((p) => (
            <Card
              key={p.id}
              className="overflow-hidden border-border hover:shadow-elevation transition-all flex flex-col group rounded-2xl bg-card"
            >
              <div className="relative h-32 overflow-hidden bg-muted">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute top-2 left-2 bg-background/95 backdrop-blur px-2 py-0.5 rounded text-xs font-bold text-primary">
                  {p.type}
                </div>
              </div>
              <div className="p-4 flex-1 flex flex-col">
                <h3 className="font-bold text-lg text-primary">{p.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">
                  {p.qty} • {p.producer}
                </p>
                <div className="mt-auto flex justify-between items-center">
                  {p.pricePerKg > 0 && (
                    <span className="font-bold text-accent">
                      R$ {p.pricePerKg.toFixed(2).replace('.', ',')}/kg
                    </span>
                  )}
                  <Link
                    to={`/buyer/product/${p.id}`}
                    className="text-xs font-bold text-secondary hover:underline"
                  >
                    Ver detalhes
                  </Link>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
