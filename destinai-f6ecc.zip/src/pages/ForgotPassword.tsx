import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Leaf, Mail, ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react'
import pb from '@/lib/pocketbase/client'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      await pb.collection('users').requestPasswordReset(email)
      setSuccess(true)
    } catch (err) {
      setError('Não foi possível enviar o e-mail. Verifique o endereço informado.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center py-12 bg-background min-h-[calc(100dvh-8rem-env(safe-area-inset-top))]">
      <div className="w-full max-w-md px-4 animate-fade-in-up">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="bg-primary text-primary-foreground p-2 rounded-lg">
              <Leaf className="w-6 h-6 fill-current" />
            </div>
            <span className="font-bold text-2xl text-primary">DestinAI</span>
          </div>
          <h1 className="text-2xl font-bold text-primary mb-1">Recuperar senha</h1>
          <p className="text-muted-foreground">Enviaremos um link para o seu e-mail</p>
        </div>

        <Card className="p-8 shadow-elevation border-none">
          {success ? (
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-50 rounded-full">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <p className="text-muted-foreground">
                Se o e-mail existir em nossa base, você receberá um link de recuperação em
                instantes.
              </p>
              <Button asChild className="w-full rounded-full h-12 font-bold">
                <Link to="/login">Voltar para o login</Link>
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-primary font-bold">
                  E-mail
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@email.com"
                    required
                    className="bg-muted border-none h-12 pl-11"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-sm text-red-500 bg-red-50 p-3 rounded-xl">
                  <AlertCircle className="w-4 h-4 shrink-0" /> {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full rounded-full h-14 text-lg font-bold shadow-elevation mt-4"
              >
                {loading ? 'Enviando...' : 'Enviar link de recuperação'}
              </Button>
            </form>
          )}

          <div className="mt-6 text-center">
            <Link
              to="/login"
              className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar para o login
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
