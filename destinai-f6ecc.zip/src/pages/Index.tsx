import { Link, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Leaf, Sprout, Store, Truck, ArrowRight, Sparkles, Shield, TrendingUp } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getDashboardPath } from '@/lib/role-redirect'
import { LandingNav } from '@/components/landing/LandingNav'
import { ImpactCounter } from '@/components/landing/ImpactCounter'
import { ViviSmartCards } from '@/components/landing/ViviSmartCards'
import { EcosystemMapSnapshot } from '@/components/landing/EcosystemMapSnapshot'
import { ActiveBatchesShowcase } from '@/components/landing/ActiveBatchesShowcase'
import { TrustHighlights } from '@/components/landing/TrustHighlights'
import { InvestorSection } from '@/components/landing/InvestorSection'
import { HeroImageSlider } from '@/components/landing/HeroImageSlider'

export default function Index() {
  const { isAuthenticated, user, loading } = useAuth()

  if (!loading && isAuthenticated && user?.role) {
    return <Navigate to={getDashboardPath(user.role)} replace />
  }

  return (
    <div className="flex-1 -mx-4 -my-4 md:-mx-8 md:-my-8">
      <LandingNav />

      {/* Hero */}
      <section className="relative px-6 py-20 md:py-28 bg-gradient-to-br from-background via-background to-primary/5 overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 space-y-6 text-center lg:text-left animate-fade-in-up max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-secondary/10 text-secondary rounded-full text-sm font-bold">
              <Leaf className="w-4 h-4" /> Plataforma AgTech com IA
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-primary leading-[1.1]">
              Todo alimento tem um <span className="text-secondary">destino</span>.<br />A IA
              encontra.
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0">
              Conectamos produtores, compradores e logística para transformar excedentes agrícolas
              em oportunidades de negócio e impacto social.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start pt-2">
              <Button
                size="lg"
                className="rounded-full h-14 px-6 shadow-elevation hover:scale-105 transition-transform"
                asChild
              >
                <Link to="/onboarding">
                  <Sprout className="w-5 h-5 mr-2" /> Sou Produtor
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-full h-14 px-6 border-primary/20 text-primary hover:bg-primary/5 hover:scale-105 transition-transform"
                asChild
              >
                <Link to="/opportunities">
                  <Store className="w-5 h-5 mr-2" /> Sou Comprador
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-full h-14 px-6 border-accent/20 text-accent hover:bg-accent/5 hover:scale-105 transition-transform"
                asChild
              >
                <Link to="/logistics">
                  <Truck className="w-5 h-5 mr-2" /> Sou Transportador
                </Link>
              </Button>
            </div>
          </div>
          <div className="flex-1 w-full max-w-md lg:max-w-none relative animate-fade-in">
            <HeroImageSlider />
          </div>
        </div>
      </section>

      {/* Impact Counter */}
      <section className="py-16 px-6 bg-primary text-primary-foreground rounded-t-[3rem]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-2 text-secondary">Impacto Global em Tempo Real</h2>
            <p className="text-primary-foreground/80">Dados agregados da plataforma</p>
          </div>
          <ImpactCounter />
        </div>
      </section>

      {/* Problem & Solution */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12">
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-destructive">O Problema</h2>
            <p className="text-muted-foreground leading-relaxed">
              Milhões de toneladas de alimentos são desperdiçadas todos os anos. Produtores perdem
              receita por não encontrarem compradores para seus excedentes, e alimentos bons são
              rejeitados por padrões estéticos.
            </p>
          </div>
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-secondary">A Solução</h2>
            <p className="text-muted-foreground leading-relaxed">
              Uma IA que encontra o melhor destino para cada lote, conectando toda a cadeia para
              gerar valor e reduzir o desperdício na origem.
            </p>
          </div>
        </div>
      </section>

      {/* Vivi Smart Cards */}
      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-secondary/10 text-secondary rounded-full text-sm font-bold mb-3">
              <Sparkles className="w-4 h-4" /> Vivi AI
            </div>
            <h2 className="text-3xl font-bold text-primary mb-2">Inteligência Proativa</h2>
            <p className="text-muted-foreground">
              A Vivi 🌱 monitora sua operação e antecipa oportunidades
            </p>
          </div>
          <ViviSmartCards />
        </div>
      </section>

      {/* Active Batches */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
            <div>
              <h2 className="text-3xl font-bold text-primary">Lotes Ativos no Mercado</h2>
              <p className="text-muted-foreground mt-1">Excedentes disponíveis agora</p>
            </div>
            <Button variant="outline" asChild className="rounded-full">
              <Link to="/opportunities">
                Ver todos <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </div>
          <ActiveBatchesShowcase />
        </div>
      </section>

      {/* Ecosystem Map */}
      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-primary mb-2">Rede em Tempo Real</h2>
            <p className="text-muted-foreground">Distribuição geográfica do ecossistema DestinAI</p>
          </div>
          <EcosystemMapSnapshot />
        </div>
      </section>

      {/* Trust & Reputation */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-bold mb-3">
              <Shield className="w-4 h-4" /> Confiança & Reputação
            </div>
            <h2 className="text-3xl font-bold text-primary">Transações Seguras e Transparentes</h2>
          </div>
          <TrustHighlights />
        </div>
      </section>

      {/* Investor/ESG */}
      <section className="py-20 px-6 bg-card">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-accent/10 text-accent rounded-full text-sm font-bold mb-3">
              <TrendingUp className="w-4 h-4" /> Transparência ESG
            </div>
            <h2 className="text-3xl font-bold text-primary">Para Investidores</h2>
            <p className="text-muted-foreground mt-2">Unit economics e impacto mensurável</p>
          </div>
          <InvestorSection />
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-6 bg-primary text-primary-foreground">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary">
            Pronto para transformar o agronegócio?
          </h2>
          <p className="text-primary-foreground/80 text-lg">
            Junte-se a centenas de produtores, compradores e transportadores que já reduzem o
            desperdício com a DestinAI.
          </p>
          <Button
            size="lg"
            className="rounded-full h-14 px-8 bg-secondary text-secondary-foreground hover:bg-secondary/90 hover:scale-105 transition-transform"
            asChild
          >
            <Link to="/onboarding">
              Começar agora <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
