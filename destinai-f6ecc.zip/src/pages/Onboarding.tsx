import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, AlertCircle, Loader2, Sparkles } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { useAuth } from '@/hooks/use-auth'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { getDashboardPath } from '@/lib/role-redirect'
import { toast } from '@/hooks/use-toast'
import { validateDocument, validatePhone } from '@/lib/formatters'
import {
  createProfile,
  createGoals,
  completeOnboarding,
  type OnboardingFormData,
} from '@/services/onboarding'
import { RoleStep } from '@/components/onboarding/RoleStep'
import { AccountStep } from '@/components/onboarding/AccountStep'
import { ProfileStep } from '@/components/onboarding/ProfileStep'
import { GoalsStep } from '@/components/onboarding/GoalsStep'
import pb from '@/lib/pocketbase/client'

const TOTAL_STEPS = 4

const INITIAL_DATA: OnboardingFormData = {
  role: '',
  name: '',
  email: '',
  password: '',
  company_name: '',
  document: '',
  buyer_type: '',
  vehicle_type: '',
  max_capacity_kg: '',
  city: '',
  state: '',
  phone: '',
  description: '',
  demand_tags: '',
  goals: {},
}

export default function Onboarding() {
  const [step, setStep] = useState(0)
  const [transitioning, setTransitioning] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [data, setData] = useState<OnboardingFormData>(INITIAL_DATA)
  const navigate = useNavigate()
  const { signUp } = useAuth()

  useEffect(() => {
    if (
      pb.authStore.isValid &&
      pb.authStore.record?.role &&
      pb.authStore.record?.status !== 'PENDING'
    ) {
      navigate(getDashboardPath(pb.authStore.record.role))
    }
  }, [navigate])

  const update = (field: string, value: any) => setData((prev) => ({ ...prev, [field]: value }))

  const validateStep = (): string | null => {
    switch (step) {
      case 0:
        return data.role ? null : 'Selecione um perfil para continuar'
      case 1: {
        if (data.name.length < 2) return 'Nome muito curto'
        if (!data.email.match(/^.+@.+\..+$/)) return 'E-mail inválido'
        if (data.password.length < 8) return 'A senha deve ter no mínimo 8 caracteres'
        if (data.company_name.length < 2) return 'Nome da empresa muito curto'
        if (!validateDocument(data.document))
          return 'Documento inválido (CPF 11 dígitos ou CNPJ 14 dígitos)'
        return null
      }
      case 2: {
        if (!validatePhone(data.phone)) return 'Telefone inválido'
        if (!data.city.trim()) return 'Cidade é obrigatória'
        if (!data.state.trim()) return 'Estado é obrigatório'
        if (data.role === 'BUYER' && !data.buyer_type) return 'Selecione o tipo de comprador'
        if (data.role === 'TRANSPORTER' && !data.vehicle_type) return 'Selecione o tipo de veículo'
        if (data.role === 'TRANSPORTER' && !data.max_capacity_kg)
          return 'Capacidade máxima é obrigatória'
        return null
      }
      case 3: {
        const count = Object.values(data.goals).filter((g) => g.selected).length
        return count > 0 ? null : 'Selecione pelo menos um objetivo'
      }
      default:
        return null
    }
  }

  const handleNext = () => {
    const err = validateStep()
    if (err) {
      setError(err)
      return
    }
    setError('')
    setTransitioning(true)
    setTimeout(() => {
      setStep((s) => s + 1)
      setTransitioning(false)
    }, 300)
  }

  const handleBack = () => {
    setError('')
    setTransitioning(true)
    setTimeout(() => {
      setStep((s) => s - 1)
      setTransitioning(false)
    }, 300)
  }

  const handleComplete = async () => {
    const err = validateStep()
    if (err) {
      setError(err)
      return
    }
    setLoading(true)
    setError('')
    try {
      const { error: signUpError, isDuplicateEmail } = await signUp({
        email: data.email,
        password: data.password,
        name: data.name,
        role: data.role,
        company_name: data.company_name,
        document: data.document,
      })
      if (signUpError) {
        if (isDuplicateEmail) {
          const msg = 'Este e-mail já está cadastrado. Faça login ou use outro e-mail.'
          setError(msg)
          toast({ title: 'E-mail já cadastrado', description: msg, variant: 'destructive' })
        } else {
          setError(getErrorMessage(signUpError))
        }
        setLoading(false)
        return
      }

      const userId = pb.authStore.record?.id
      if (!userId) {
        setError('Erro ao criar conta')
        setLoading(false)
        return
      }

      await createProfile(data.role, userId, data)

      const goalTypes = Object.entries(data.goals)
        .filter(([, g]) => g.selected)
        .map(([t]) => t)
      await createGoals(userId, data.goals)

      try {
        await completeOnboarding({ role: data.role, city: data.city, state: data.state, goalTypes })
      } catch {
        /* AI insight is best-effort */
      }

      toast({ title: 'Conta criada com sucesso! 🌱', description: 'Bem-vindo ao DestinAI!' })
      navigate(getDashboardPath(data.role))
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  const progress = ((step + 1) / TOTAL_STEPS) * 100
  const stepProps = { data, update }

  return (
    <div className="flex-1 flex flex-col items-center justify-center py-8 bg-background min-h-[calc(100dvh-8rem-env(safe-area-inset-top))]">
      <div className="w-full max-w-2xl px-4 animate-fade-in-up">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-bold text-primary">
              Passo {step + 1} de {TOTAL_STEPS}
            </span>
            <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {transitioning ? (
          <div className="space-y-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <Card className="p-6 sm:p-8 shadow-elevation border-none">
            {step === 0 && <RoleStep {...stepProps} />}
            {step === 1 && <AccountStep {...stepProps} />}
            {step === 2 && <ProfileStep {...stepProps} />}
            {step === 3 && <GoalsStep {...stepProps} />}

            {error && (
              <div className="flex items-center gap-2 text-sm text-red-500 bg-red-50 p-3 rounded-xl mt-4">
                <AlertCircle className="w-4 h-4 shrink-0" /> {error}
              </div>
            )}

            <div className="flex justify-between mt-6">
              {step > 0 ? (
                <Button variant="ghost" onClick={handleBack} disabled={loading || transitioning}>
                  <ChevronLeft className="w-4 h-4 mr-1" /> Voltar
                </Button>
              ) : (
                <div />
              )}

              {step < TOTAL_STEPS - 1 ? (
                <Button
                  onClick={handleNext}
                  disabled={loading || transitioning}
                  className="rounded-full px-8"
                >
                  Continuar
                </Button>
              ) : (
                <Button onClick={handleComplete} disabled={loading} className="rounded-full px-8">
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Criando conta...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" /> Finalizar
                    </>
                  )}
                </Button>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
