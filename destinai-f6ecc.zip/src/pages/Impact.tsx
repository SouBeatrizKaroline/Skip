import { Card } from '@/components/ui/card'
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { useState, useEffect } from 'react'
import { Globe2, Leaf, TrendingUp, Users, Package, Utensils } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import pb from '@/lib/pocketbase/client'
import { getImpact } from '@/services/api'
import { WasteAvoidanceMeter } from '@/components/WasteAvoidanceMeter'
import { NetworkGrowthChart } from '@/components/NetworkGrowthChart'

const barData = [
  { month: 'Jan', recuperado: 400, desperdicio: 240 },
  { month: 'Fev', recuperado: 300, desperdicio: 139 },
  { month: 'Mar', recuperado: 500, desperdicio: 200 },
  { month: 'Abr', recuperado: 700, desperdicio: 150 },
  { month: 'Mai', recuperado: 850, desperdicio: 100 },
]

const pieData = [
  { name: 'Restaurantes', value: 400 },
  { name: 'Indústrias', value: 300 },
  { name: 'Doações', value: 150 },
]
const COLORS = ['hsl(var(--secondary))', 'hsl(var(--primary))', 'hsl(var(--accent))']

export default function Impact() {
  const { user } = useAuth()
  const [metrics, setMetrics] = useState({
    kg_saved: 0,
    co2_saved_kg: 0,
    revenue_recovered: 0,
    connections: 0,
  })

  useEffect(() => {
    let active = true
    if (user) {
      pb.collection('impact_metrics')
        .getFullList({ filter: `user_id = "${user.id}"` })
        .then((list) => {
          if (!active) return
          const kg = list.reduce((a, b) => a + (b.kg_saved || 0), 0)
          const co2 = list.reduce((a, b) => a + (b.co2_saved_kg || 0), 0)
          const rev = list.reduce((a, b) => a + (b.revenue_recovered || 0), 0)
          pb.collection('matches')
            .getFullList({
              filter: `producer_id.user_id="${user.id}" || buyer_id.user_id="${user.id}"`,
            })
            .then((matches) => {
              if (active)
                setMetrics({
                  kg_saved: kg,
                  co2_saved_kg: co2,
                  revenue_recovered: rev,
                  connections: matches.length,
                })
            })
            .catch(() => {
              if (active)
                setMetrics({
                  kg_saved: kg,
                  co2_saved_kg: co2,
                  revenue_recovered: rev,
                  connections: 0,
                })
            })
        })
        .catch(() => {})
    } else {
      getImpact()
        .then((res: any) => {
          if (active)
            setMetrics({
              kg_saved: res.total_kg_saved || 0,
              co2_saved_kg: res.total_co2_saved || 0,
              revenue_recovered: res.total_revenue_recovered || 0,
              connections: res.total_connections || 0,
            })
        })
        .catch(() => {})
    }
    return () => {
      active = false
    }
  }, [user])

  return (
    <div className="max-w-6xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-secondary/10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border border-secondary/20">
            <Globe2 className="w-8 h-8 text-secondary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-primary mb-1">Seu Impacto</h1>
            <p className="text-muted-foreground">O resultado das suas ações na cadeia alimentar.</p>
          </div>
        </div>
        <div className="bg-card px-4 py-2 rounded-full border border-border text-sm font-bold text-primary shadow-sm">
          Últimos 6 meses
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-6 mb-10">
        {[
          {
            label: 'Alimentos salvos',
            value: `${metrics.kg_saved || '8.520'} kg`,
            icon: Package,
            color: 'text-primary',
            bg: 'bg-primary/10',
          },
          {
            label: 'Receita gerada',
            value: `R$ ${metrics.revenue_recovered || '24.680'}`,
            icon: TrendingUp,
            color: 'text-accent',
            bg: 'bg-accent/10',
          },
          {
            label: 'CO2 evitados',
            value: `${metrics.co2_saved_kg || '1.245'} kg`,
            icon: Leaf,
            color: 'text-secondary',
            bg: 'bg-secondary/10',
          },
          {
            label: 'Refeições geradas',
            value: `${Math.round((metrics.kg_saved || 8520) / 0.5)}`,
            icon: Utensils,
            color: 'text-secondary',
            bg: 'bg-secondary/10',
          },
          {
            label: 'Conexões IA',
            value: metrics.connections || '28',
            icon: Users,
            color: 'text-primary',
            bg: 'bg-primary/10',
          },
        ].map((stat, i) => (
          <Card
            key={i}
            className="p-5 border-none shadow-elevation rounded-[2rem] bg-card flex flex-col justify-between"
          >
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center mb-4 ${stat.bg}`}
            >
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <div>
              <p className="text-3xl font-bold text-primary mb-1">{stat.value}</p>
              <p className="text-sm font-bold text-muted-foreground">{stat.label}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8 min-w-0">
        <Card className="p-6 md:p-8 rounded-[2rem] border-border shadow-sm min-w-0">
          <div className="mb-6">
            <h3 className="font-bold text-xl text-primary mb-1">Evolução do impacto</h3>
            <p className="text-sm text-muted-foreground font-medium">
              Comparativo de desperdício vs aproveitamento
            </p>
          </div>
          <div className="h-72">
            <ChartContainer
              config={{
                recuperado: { label: 'Recuperado (kg)', color: 'hsl(var(--secondary))' },
                desperdicio: {
                  label: 'Desperdício Estimado (kg)',
                  color: 'hsl(var(--muted-foreground))',
                },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis
                    dataKey="month"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontWeight: 600 }}
                  />
                  <YAxis
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="recuperado" fill="var(--color-recuperado)" radius={[6, 6, 0, 0]} />
                  <Bar
                    dataKey="desperdicio"
                    fill="var(--color-desperdicio)"
                    radius={[6, 6, 0, 0]}
                    opacity={0.2}
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </Card>

        <Card className="p-6 md:p-8 rounded-[2rem] border-border shadow-sm min-w-0">
          <div className="mb-6 text-center md:text-left">
            <h3 className="font-bold text-xl text-primary mb-1">Destinos Inteligentes</h3>
            <p className="text-sm text-muted-foreground font-medium">
              Para onde foram os alimentos
            </p>
          </div>
          <div className="h-72 flex flex-col items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: '1rem',
                    border: 'none',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-primary">850</span>
              <span className="text-sm text-muted-foreground font-bold">Kg totais</span>
            </div>

            <div className="flex flex-wrap justify-center gap-4 mt-6">
              {pieData.map((d, i) => (
                <div
                  key={d.name}
                  className="flex items-center gap-2 text-sm font-bold text-primary bg-muted/50 px-3 py-1.5 rounded-lg"
                >
                  <div
                    className="w-3 h-3 rounded-full shadow-sm"
                    style={{ backgroundColor: COLORS[i] }}
                  ></div>
                  {d.name}
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <div className="mb-8">
        <NetworkGrowthChart />
      </div>

      <WasteAvoidanceMeter />
    </div>
  )
}
