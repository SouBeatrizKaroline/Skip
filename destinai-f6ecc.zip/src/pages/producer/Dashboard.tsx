import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Plus,
  Leaf,
  TrendingUp,
  Package,
  CreditCard,
  Utensils,
  ChevronRight,
  Sparkles,
} from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import { WeatherWidget } from '@/components/WeatherWidget'
import { DemandForecastWidget } from '@/components/DemandForecastWidget'
import { LoadConsolidationAlert } from '@/components/LoadConsolidationAlert'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { ReputationBadge } from '@/components/ReputationBadge'
import { ViviInsightPanel } from '@/components/ViviInsightPanel'
import { ViviCommandCenter } from '@/components/ViviCommandCenter'
import { PersonalGoalsWidget } from '@/components/PersonalGoalsWidget'
import { AchievementsGallery } from '@/components/AchievementsGallery'
import { FinancialImpactCard } from '@/components/FinancialImpactCard'
import { InvestorView } from '@/components/InvestorView'
import { OversupplyAlert } from '@/components/OversupplyAlert'
import { CreditOpportunityAlert } from '@/components/CreditOpportunityAlert'
import { ReferralCard } from '@/components/ReferralCard'
import { PriorityBadge } from '@/components/PriorityBadge'
import {
  getProductsByProducer,
  getProductImage,
  VISUAL_CONDITION_LABELS,
  formatPrice,
  formatDate,
} from '@/services/products'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'
import pb from '@/lib/pocketbase/client'

export default function ProducerDashboard() {
  const { user } = useAuth()
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [producerId, setProducerId] = useState<string>('')
  const [producerCity, setProducerCity] = useState('')
  const [producerState, setProducerState] = useState('')
  const [impact, setImpact] = useState({
    kg_saved: 0,
    co2_saved_kg: 0,
    revenue_recovered: 0,
    water_preserved_liters: 0,
    meals_generated: 0,
  })
  const [matchCount, setMatchCount] = useState(0)
  const [smartScores, setSmartScores] = useState<Record<string, number>>({})

  useEffect(() => {
    if (user) {
      pb.collection('producer_profiles')
        .getFirstListItem(`user_id="${user.id}"`)
        .then((p) => {
          setProducerId(p.id)
          setProducerCity(p.city || '')
          setProducerState(p.state || '')
        })
        .catch(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [user])

  const loadData = async () => {
    if (!producerId) return
    try {
      const prods = await getProductsByProducer(producerId)
      setProducts(prods)
      const scores: Record<string, number> = {}
      await Promise.all(
        prods.slice(0, 15).map(async (p) => {
          try {
            const ai = await pb.collection('ai_analysis').getFirstListItem(`product_id="${p.id}"`)
            scores[p.id] = ai.quality_score || 0
          } catch {
            /* intentionally ignored */
          }
        }),
      )
      setSmartScores(scores)
    } catch {
      setProducts([])
    } finally {
      setLoading(false)
    }
  }

  const loadImpact = async () => {
    if (!user) return
    try {
      const list = await pb.collection('impact_metrics').getFullList({
        filter: `user_id="${user.id}"`,
      })
      setImpact({
        kg_saved: list.reduce((a, b) => a + (b.kg_saved || 0), 0),
        co2_saved_kg: list.reduce((a, b) => a + (b.co2_saved_kg || 0), 0),
        revenue_recovered: list.reduce((a, b) => a + (b.revenue_recovered || 0), 0),
        water_preserved_liters: list.reduce((a, b) => a + (b.water_preserved_liters || 0), 0),
        meals_generated: list.reduce((a, b) => a + (b.meals_generated || 0), 0),
      })
    } catch {
      /* keep defaults */
    }
  }

  const loadMatches = async () => {
    if (!producerId) return
    try {
      const list = await pb.collection('matches').getFullList({
        filter: `producer_id="${producerId}" && status="PENDING"`,
        sort: '-created',
      })
      setMatchCount(list.length)
    } catch {
      setMatchCount(0)
    }
  }

  useEffect(() => {
    if (producerId) {
      loadData()
      loadMatches()
    }
    loadImpact()
  }, [producerId, user])

  useRealtime('products', () => {
    if (producerId) loadData()
  })
  useRealtime('impact_metrics', () => loadImpact())
  useRealtime('matches', () => {
    if (producerId) loadMatches()
  })
  useRealtime('ai_analysis', () => {
    if (producerId) loadData()
  })
  useRealtime('recommendations', () => {
    if (producerId) loadData()
  })
  useRealtime('user_notifications', () => {
    loadImpact()
  })

  const displayName = user?.name || user?.email?.split('@')[0] || 'Produtor'
  const activeLots = products.filter(
    (p) => p.status === 'AVAILABLE' || p.status === 'NEGOTIATING' || p.status === 'MATCHED',
  ).length
  const mealsGenerated = impact.meals_generated || Math.round((impact.kg_saved || 850) / 0.5)

  return (
    <div className="space-y-8 max-w-5xl mx-auto w-full animate-fade-in-up pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
        <div>
          <h1 className="text-3xl font-bold text-primary">Olá, {displayName}! 👨‍🌾</h1>
          <p className="text-muted-foreground mt-1 text-lg">Que bom te ver por aqui!</p>
          {user?.tier_status && (
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              <ReputationBadge tier={user.tier_status} score={user.reputation_score} size="md" />
              <PriorityBadge tier={user.tier_status} />
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center sm:items-stretch gap-6 bg-card p-6 rounded-[2rem] shadow-elevation border border-border relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
        <div className="w-24 h-24 bg-gradient-to-br from-secondary/40 to-secondary/10 rounded-full flex items-center justify-center shrink-0 border-4 border-card shadow-sm">
          <Leaf className="w-12 h-12 text-secondary" />
        </div>
        <div className="flex-1 text-center sm:text-left flex flex-col justify-center">
          <h2 className="text-xl font-bold text-primary mb-2">Vivi recomenda para você</h2>
          <p className="text-muted-foreground mb-4 max-w-md">
            {matchCount > 0
              ? `Você tem ${matchCount} ${matchCount === 1 ? 'nova oportunidade' : 'novas oportunidades'} de match aguardando sua ação.`
              : 'Encontre novas oportunidades para sua produção. Temos compradores interessados na sua região.'}
          </p>
          <div className="flex gap-3 self-center sm:self-start flex-wrap">
            <Button
              variant="secondary"
              className="rounded-full bg-secondary text-white hover:bg-secondary/90 shadow-md font-bold px-6"
              asChild
            >
              <Link to="/producer/destinations">Ver oportunidades</Link>
            </Button>
            {matchCount > 0 && (
              <Button
                variant="outline"
                className="rounded-full font-bold px-6 border-secondary/30 text-secondary hover:bg-secondary/10"
                asChild
              >
                <Link to="/producer/negotiations">Ver negociações ({matchCount})</Link>
              </Button>
            )}
          </div>
        </div>
      </div>

      {producerCity && <WeatherWidget city={producerCity} state={producerState} />}

      <DemandForecastWidget />

      <LoadConsolidationAlert />

      <ViviInsightPanel role="PRODUCER" producerId={producerId} />

      <CreditOpportunityAlert user={user} products={products} />

      <OversupplyAlert producerId={producerId} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ViviCommandCenter />
        <PersonalGoalsWidget />
      </div>

      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-xl text-primary">Resumo de Impacto</h3>
        <Link
          to="/impact"
          className="text-sm font-bold text-secondary hover:underline flex items-center gap-1"
        >
          Ver relatório <ChevronRight className="w-4 h-4" />
        </Link>
      </div>
      <Link to="/impact" className="grid grid-cols-2 md:grid-cols-4 gap-4 group">
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl hover:shadow-elevation hover:border-primary/20 transition-all">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mb-3">
            <Package className="w-5 h-5 text-primary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">{activeLots}</p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Lotes ativos</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-accent" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">
            R$ {(impact.revenue_recovered || 0).toFixed(0)}
          </p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Receita recuperada</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
            <Leaf className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">
            {impact.co2_saved_kg || 120} kg
          </p>
          <p className="text-sm text-muted-foreground font-medium mt-1">CO₂ evitado</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
            <Utensils className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">{mealsGenerated}</p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Refeições geradas</p>
        </Card>
      </Link>

      <FinancialImpactCard metrics={impact} />

      <InvestorView />

      <Link
        to="/credit"
        className="flex items-center justify-between p-5 bg-gradient-to-r from-secondary/10 to-transparent rounded-2xl border border-secondary/20 mb-6 hover:shadow-elevation transition-all"
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-secondary/15 rounded-xl flex items-center justify-center shrink-0">
            <CreditCard className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <p className="font-bold text-primary">Crédito e Crescimento</p>
            <p className="text-xs text-muted-foreground">
              Linhas de crédito disponíveis para seu perfil
            </p>
          </div>
        </div>
        <Plus className="w-5 h-5 text-secondary" />
      </Link>

      <Button
        size="lg"
        className="w-full h-16 text-lg rounded-2xl shadow-elevation font-bold text-white hover:scale-[1.01] transition-transform"
        asChild
      >
        <Link to="/producer/new-surplus">
          <Plus className="w-6 h-6 mr-2" /> Cadastrar novo excedente
        </Link>
      </Button>

      <AchievementsGallery />

      <ReferralCard user={user} />

      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-xl text-primary">Meus produtos</h3>
          <Link
            to="/dashboard/produtor/produtos"
            className="text-sm font-bold text-secondary hover:underline"
          >
            Ver todos
          </Link>
        </div>
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card
                key={i}
                className="p-4 flex items-center gap-4 border-border rounded-2xl bg-card"
              >
                <Skeleton className="w-20 h-20 rounded-xl" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-6 w-24 rounded-full" />
                </div>
                <Skeleton className="h-8 w-20" />
              </Card>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-12">
            <Leaf className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">Nenhum produto cadastrado ainda.</p>
            <Button asChild className="mt-4">
              <Link to="/producer/new-surplus">
                <Plus className="w-4 h-4 mr-2" /> Cadastrar primeiro excedente
              </Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {products.map((prod) => (
              <Card
                key={prod.id}
                className="p-4 flex items-center gap-4 border-border shadow-none hover:shadow-elevation hover:border-primary/20 transition-all rounded-2xl bg-card"
              >
                <img
                  src={getProductImage(prod.name)}
                  alt={prod.name}
                  loading="lazy"
                  className="w-20 h-20 rounded-xl object-cover"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-primary text-lg truncate">{prod.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {prod.quantity_kg} kg • Colheita: {formatDate(prod.harvest_date || '')}
                  </p>
                  <span className="inline-block mt-2 text-xs bg-secondary/15 text-secondary px-3 py-1 rounded-full font-bold">
                    {VISUAL_CONDITION_LABELS[prod.visual_condition] || ''}
                  </span>
                  {prod.waste_risk_level && (
                    <div className="mt-1">
                      <WasteRiskBadge level={prod.waste_risk_level} size="sm" />
                    </div>
                  )}
                  {smartScores[prod.id] !== undefined && smartScores[prod.id] > 0 && (
                    <div className="mt-1">
                      <span className="text-xs font-bold text-secondary bg-secondary/10 px-2 py-0.5 rounded-full">
                        🌱 Smart Score: {smartScores[prod.id]}
                      </span>
                    </div>
                  )}
                </div>
                <div className="text-right flex flex-col items-end shrink-0">
                  {prod.price_per_kg ? (
                    <p className="font-bold text-base text-accent">
                      {formatPrice(prod.price_per_kg)}
                    </p>
                  ) : null}
                  {prod.net_revenue_per_kg != null && (
                    <p className="text-xs font-bold text-secondary mt-1">
                      Lucro: R$ {prod.net_revenue_per_kg.toFixed(2).replace('.', ',')}/kg
                    </p>
                  )}
                  <div className="mt-2 flex gap-2">
                    <Link
                      to={`/dashboard/produtor/produtos/${prod.id}`}
                      className="text-xs font-bold text-primary bg-primary/10 px-3 py-1 rounded-md hover:bg-primary/20 transition-colors flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" /> Analisar
                    </Link>
                    <Link
                      to="/producer/destinations"
                      className="text-xs font-bold text-secondary bg-secondary/10 px-3 py-1 rounded-md hover:bg-secondary/20 transition-colors"
                    >
                      Ver destinos
                    </Link>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
