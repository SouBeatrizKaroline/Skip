import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { ChevronLeft, Plus, Leaf } from 'lucide-react'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import pb from '@/lib/pocketbase/client'
import {
  getProductsByProducer,
  getProductImage,
  VISUAL_CONDITION_LABELS,
  PRODUCT_STATUS_LABELS,
  formatDate,
  formatPrice,
} from '@/services/products'

export default function Products() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [producerId, setProducerId] = useState('')
  const [filter, setFilter] = useState('ALL')

  useEffect(() => {
    if (user) {
      pb.collection('producer_profiles')
        .getFirstListItem(`user_id="${user.id}"`)
        .then((p) => setProducerId(p.id))
        .catch(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [user])

  const loadData = async () => {
    if (!producerId) return
    try {
      const prods = await getProductsByProducer(producerId)
      setProducts(prods)
    } catch {
      setProducts([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (producerId) loadData()
  }, [producerId])

  useRealtime('products', () => {
    if (producerId) loadData()
  })

  const filtered = filter === 'ALL' ? products : products.filter((p) => p.status === filter)
  const statusFilters = ['ALL', 'AVAILABLE', 'MATCHED', 'NEGOTIATING', 'DELIVERED', 'EXPIRED']

  return (
    <div className="max-w-3xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/dashboard/produtor')}
          className="bg-card p-2 rounded-full shadow-sm hover:shadow-elevation transition-shadow"
        >
          <ChevronLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <h1 className="text-2xl font-bold text-primary ml-4">Meus Produtos</h1>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-2">
        {statusFilters.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
              filter === s
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'bg-card text-muted-foreground hover:bg-muted'
            }`}
          >
            {s === 'ALL' ? 'Todos' : PRODUCT_STATUS_LABELS[s] || s}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-28 w-full rounded-2xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Leaf className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Nenhum produto encontrado.</p>
          <Button asChild className="mt-4">
            <Link to="/producer/new-surplus">
              <Plus className="w-4 h-4 mr-2" /> Cadastrar excedente
            </Link>
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((prod) => (
            <Link key={prod.id} to={`/dashboard/produtor/produtos/${prod.id}`} className="block">
              <Card className="p-4 flex items-center gap-4 border-border shadow-none hover:shadow-elevation hover:border-primary/20 transition-all rounded-2xl bg-card cursor-pointer">
                <img
                  src={getProductImage(prod.name)}
                  alt={prod.name}
                  loading="lazy"
                  className="w-16 h-16 rounded-xl object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-primary truncate">{prod.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {prod.quantity_kg} kg • {formatDate(prod.harvest_date || '')}
                  </p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge variant="secondary" className="text-xs">
                      {PRODUCT_STATUS_LABELS[prod.status] || prod.status}
                    </Badge>
                    <span className="text-xs text-secondary font-bold">
                      {VISUAL_CONDITION_LABELS[prod.visual_condition] || ''}
                    </span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  {prod.price_per_kg ? (
                    <p className="font-bold text-accent text-sm">
                      {formatPrice(prod.price_per_kg)}
                    </p>
                  ) : null}
                  {prod.waste_risk_level && (
                    <div className="mt-1">
                      <WasteRiskBadge level={prod.waste_risk_level} size="sm" />
                    </div>
                  )}
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}

      <Button
        asChild
        size="lg"
        className="w-full h-14 mt-6 rounded-2xl font-bold text-white shadow-elevation"
      >
        <Link to="/producer/new-surplus">
          <Plus className="w-5 h-5 mr-2" /> Cadastrar novo excedente
        </Link>
      </Button>
    </div>
  )
}
