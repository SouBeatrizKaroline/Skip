import { useState, useEffect } from 'react'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import {
  ChevronLeft,
  MapPin,
  Package,
  Calendar,
  Brain,
  Sparkles,
  ArrowRight,
  FileText,
  Send,
  Loader2,
  Leaf,
} from 'lucide-react'
import {
  getProduct,
  getProductImage,
  VISUAL_CONDITION_LABELS,
  WASTE_RISK_LABELS,
  formatDate,
  formatPrice,
} from '@/services/products'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { AiInsightCard } from '@/components/AiInsightCard'
import { askVivi } from '@/services/vivi'
import pb from '@/lib/pocketbase/client'
import { useToast } from '@/hooks/use-toast'
import { useRealtime } from '@/hooks/use-realtime'

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [product, setProduct] = useState<any>(null)
  const [aiAnalysis, setAiAnalysis] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [viviOpen, setViviOpen] = useState(false)
  const [viviMessage, setViviMessage] = useState('')
  const [viviResponse, setViviResponse] = useState('')
  const [viviLoading, setViviLoading] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)

  const loadData = async () => {
    if (!id) return
    try {
      const p = await getProduct(id)
      setProduct(p)
      try {
        const ai = await pb.collection('ai_analysis').getFirstListItem(`product_id="${id}"`)
        setAiAnalysis(ai)
      } catch {
        setAiAnalysis(null)
      }
    } catch {
      toast({ title: 'Erro', description: 'Produto não encontrado.', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [id])
  useRealtime('products', (e) => {
    if (e.record.id === id) loadData()
  })
  useRealtime('ai_analysis', () => {
    if (id) loadData()
  })

  const openVivi = () => {
    const msg = `Me ajude com o produto "${product?.name}" (${product?.quantity_kg}kg, condição: ${VISUAL_CONDITION_LABELS[product?.visual_condition] || ''}, risco: ${WASTE_RISK_LABELS[product?.waste_risk_level] || 'desconhecido'}). Quais as melhores estratégias para evitar desperdício?`
    setViviMessage(msg)
    setViviResponse('')
    setConversationId(null)
    setViviOpen(true)
  }

  const sendVivi = async () => {
    if (!viviMessage.trim()) return
    setViviLoading(true)
    try {
      const res: any = await askVivi(viviMessage, conversationId)
      setViviResponse(res.content || res.choices?.[0]?.message?.content || 'Sem resposta')
      if (res.conversation_id) setConversationId(res.conversation_id)
    } catch {
      setViviResponse('Erro ao conectar com Vivi. Tente novamente.')
    } finally {
      setViviLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto w-full space-y-4 animate-fade-in-up pb-12">
        <Skeleton className="h-10 w-32 rounded-full" />
        <Skeleton className="h-64 w-full rounded-3xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    )
  }

  if (!product) {
    return (
      <div className="max-w-2xl mx-auto w-full text-center py-20 animate-fade-in-up">
        <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
        <p className="text-muted-foreground">Produto não encontrado.</p>
        <Button onClick={() => navigate('/dashboard/produtor/produtos')} className="mt-4">
          Voltar
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => navigate('/dashboard/produtor/produtos')}
          className="bg-card p-2 rounded-full shadow-sm hover:shadow-elevation transition-shadow"
        >
          <ChevronLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <Link
          to="/dashboard/produtor/produtos"
          className="text-sm font-bold text-secondary hover:underline"
        >
          Meus Produtos
        </Link>
      </div>

      <div className="relative rounded-3xl overflow-hidden mb-6 shadow-elevation">
        <img
          src={getProductImage(product.name)}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        {product.waste_risk_level && (
          <div className="absolute top-4 right-4">
            <WasteRiskBadge level={product.waste_risk_level} size="sm" />
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <h1 className="text-3xl font-bold text-primary">{product.name}</h1>
          <p className="text-muted-foreground text-lg mt-1">{formatPrice(product.price_per_kg)}</p>
          <Badge variant="secondary" className="mt-2">
            {VISUAL_CONDITION_LABELS[product.visual_condition] || 'N/A'}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Card className="p-4 rounded-2xl text-center">
            <Package className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary">{product.quantity_kg} kg</p>
            <p className="text-xs text-muted-foreground">Quantidade</p>
          </Card>
          <Card className="p-4 rounded-2xl text-center">
            <Calendar className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary text-sm">{formatDate(product.harvest_date)}</p>
            <p className="text-xs text-muted-foreground">Colheita</p>
          </Card>
          <Card className="p-4 rounded-2xl text-center">
            <MapPin className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary text-sm">{product.city || 'N/A'}</p>
            <p className="text-xs text-muted-foreground">Local</p>
          </Card>
        </div>

        {aiAnalysis ? (
          <Card className="p-5 rounded-2xl border-secondary/20 bg-secondary/5">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-5 h-5 text-secondary" />
              <h3 className="font-bold text-primary">Análise IA da Vivi</h3>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="bg-card p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Qualidade</p>
                <p className="font-bold text-primary text-lg">
                  {aiAnalysis.quality_score || 'N/A'}/100
                </p>
              </div>
              <div className="bg-card p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Validade</p>
                <p className="font-bold text-primary text-lg">
                  {aiAnalysis.shelf_life_days || 'N/A'} dias
                </p>
              </div>
              <div className="bg-card p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Confiança</p>
                <p className="font-bold text-primary text-lg">
                  {aiAnalysis.confidence_score ? `${aiAnalysis.confidence_score}%` : 'N/A'}
                </p>
              </div>
              <div className="bg-card p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Vida útil est.</p>
                <p className="font-bold text-primary text-lg">
                  {product.estimated_life_days || aiAnalysis.shelf_life_days || 'N/A'} dias
                </p>
              </div>
            </div>
            {aiAnalysis.recommended_use && (
              <div className="bg-card p-3 rounded-xl mb-2">
                <p className="text-xs text-muted-foreground font-bold">Uso Recomendado</p>
                <p className="text-sm text-primary mt-1">{aiAnalysis.recommended_use}</p>
              </div>
            )}
            {aiAnalysis.notes && (
              <div className="bg-card p-3 rounded-xl">
                <p className="text-xs text-muted-foreground font-bold">Observações</p>
                <p className="text-sm text-primary mt-1">{aiAnalysis.notes}</p>
              </div>
            )}
          </Card>
        ) : (
          <Card className="p-5 rounded-2xl border-dashed border-border text-center">
            <Sparkles className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-muted-foreground text-sm">Análise IA ainda não disponível.</p>
          </Card>
        )}

        <AiInsightCard visualCondition={product.visual_condition} />

        {product.recommended_price_range && (
          <Card className="p-4 rounded-2xl border-secondary/20 bg-secondary/5">
            <p className="text-sm font-bold text-secondary">Faixa de preço recomendada</p>
            <p className="text-sm text-muted-foreground mt-1">{product.recommended_price_range}</p>
          </Card>
        )}

        {product.net_revenue_per_kg != null && (
          <Card className="p-4 rounded-2xl">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Receita líquida estimada</p>
                <p className="font-bold text-accent text-lg">
                  R$ {product.net_revenue_per_kg.toFixed(2).replace('.', ',')}/kg
                </p>
              </div>
              {product.cost_per_kg != null && (
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Custo</p>
                  <p className="font-bold text-muted-foreground">
                    R$ {product.cost_per_kg.toFixed(2).replace('.', ',')}/kg
                  </p>
                </div>
              )}
            </div>
          </Card>
        )}

        <Button
          onClick={openVivi}
          className="w-full h-14 rounded-2xl text-lg font-bold bg-secondary text-white hover:bg-secondary/90 shadow-elevation"
        >
          <Leaf className="w-5 h-5 mr-2" /> Conversar com Vivi sobre este produto
        </Button>

        <Dialog open={viviOpen} onOpenChange={setViviOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Leaf className="w-5 h-5 text-secondary" /> Vivi 🌱
              </DialogTitle>
            </DialogHeader>
            {viviResponse && (
              <div className="bg-secondary/5 p-3 rounded-xl text-sm text-primary max-h-40 overflow-y-auto">
                {viviResponse}
              </div>
            )}
            <div className="flex gap-2">
              <Input
                value={viviMessage}
                onChange={(e) => setViviMessage(e.target.value)}
                placeholder="Pergunte à Vivi..."
                className="bg-muted border-none"
                onKeyDown={(e) => e.key === 'Enter' && sendVivi()}
              />
              <Button
                onClick={sendVivi}
                disabled={viviLoading}
                size="icon"
                className="bg-secondary text-white hover:bg-secondary/90 shrink-0"
              >
                {viviLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <div className="grid grid-cols-2 gap-3">
          <Button asChild variant="outline" className="h-12 rounded-xl">
            <Link to={`/producer/destinations?id=${product.id}`}>
              <ArrowRight className="w-4 h-4 mr-2" /> Ver destinos
            </Link>
          </Button>
          <Button asChild variant="outline" className="h-12 rounded-xl">
            <Link to="/producer/negotiations">
              <FileText className="w-4 h-4 mr-2" /> Negociações
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
