import { useState, useEffect } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { CheckCircle2, ChevronLeft, MapPin, TrendingUp } from 'lucide-react'
import { MOCK_DESTINATIONS } from '@/lib/mock-data'
import { useToast } from '@/hooks/use-toast'
import { getRecommendations } from '@/services/api'
import { dispatchNotification } from '@/services/notifications'
import { AiInsightCard } from '@/components/AiInsightCard'
import pb from '@/lib/pocketbase/client'

export default function Destinations() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [searchParams] = useSearchParams()
  const id = searchParams.get('id')

  const [dests, setDestinations] = useState<any[]>(MOCK_DESTINATIONS)
  const [productInfo, setProductInfo] = useState({ name: 'cenoura', qty: '150kg' })
  const [visualCondition, setVisualCondition] = useState('')

  useEffect(() => {
    if (id) {
      pb.collection('products')
        .getOne(id)
        .then((p) => {
          setProductInfo({ name: p.name, qty: `${p.quantity_kg}kg` })
          setVisualCondition(p.visual_condition || '')
          return getRecommendations(id)
        })
        .then((res: any) => {
          if (res?.recommendations?.length > 0) {
            setDestinations(
              res.recommendations.map((r: any) => ({
                id: r.buyer_id,
                name: r.business_name,
                location: `${r.city} - ${r.state}`,
                match: r.match_score,
                distance: `${r.distance_km} km`,
                type: r.buyer_type,
                image: `https://img.usecurling.com/p/200/200?q=${encodeURIComponent(r.business_name)}`,
                price: 'R$ 2,80 / kg',
                action: r.buyer_type === 'FOOD_BANK' ? 'Doar' : 'Negociar',
              })),
            )
          }
        })
        .catch(() => {})
    }
  }, [id])

  const handleAction = (action: string) => {
    toast({
      title: 'Proposta enviada! 🎉',
      description: `O comprador foi notificado e a logística pré-agendada.`,
    })
    dispatchNotification({
      email: '',
      phone: '',
      title: 'Nova Proposta do Produtor',
      message: `Proposta de ${action === 'Doar' ? 'doação' : 'negociação'} enviada para ${productInfo.name}.`,
    })
  }

  return (
    <div className="max-w-3xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/producer')}
          className="flex items-center text-sm font-bold text-muted-foreground hover:text-primary transition-colors bg-card p-2 rounded-full shadow-sm"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold text-primary ml-4">Destinos recomendados</h1>
      </div>

      <div className="bg-gradient-to-r from-secondary/20 to-secondary/5 rounded-3xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8 border border-secondary/20 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-32 h-32 bg-secondary/10 rounded-full blur-2xl -z-10 translate-x-1/2 -translate-y-1/2"></div>
        <div className="bg-white p-3 rounded-full shadow-sm shrink-0">
          <CheckCircle2 className="w-8 h-8 text-secondary" />
        </div>
        <div>
          <h2 className="font-bold text-primary text-xl mb-1">Análise concluída com sucesso</h2>
          <p className="text-sm text-primary/80 leading-relaxed">
            A IA encontrou os melhores destinos para o seu lote de{' '}
            <span className="font-bold text-primary">
              {productInfo.qty} de {productInfo.name.toLowerCase()}
            </span>
            . Oportunidades com base na distância, perfil e histórico.
          </p>
        </div>
      </div>

      {visualCondition && (
        <div className="mb-6">
          <AiInsightCard visualCondition={visualCondition} />
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <h3 className="font-bold text-xl text-primary flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" /> Top Matches
        </h3>
      </div>

      <div className="space-y-5">
        {dests.map((dest, i) => (
          <Card
            key={dest.id}
            className="p-4 sm:p-5 flex flex-col sm:flex-row gap-5 border-border shadow-sm hover:shadow-elevation transition-all rounded-3xl group"
          >
            <div className="relative shrink-0">
              <img
                src={dest.image}
                alt={dest.name}
                loading="lazy"
                className="w-full sm:w-32 h-40 sm:h-32 rounded-2xl object-cover"
              />
              <div className="absolute top-2 left-2 bg-background/95 backdrop-blur text-xs font-bold px-2 py-1 rounded-lg text-primary shadow-sm">
                {i + 1}º Opção
              </div>
            </div>

            <div className="flex-1 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-1">
                  <h4 className="font-bold text-primary text-lg group-hover:text-secondary transition-colors">
                    {dest.name}
                  </h4>
                  <Badge className="bg-secondary/20 text-secondary hover:bg-secondary/30 font-bold border-none px-3 py-1 shadow-none text-sm">
                    {dest.match}% Match
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground flex items-center gap-1.5 mb-2 font-medium">
                  <MapPin className="w-4 h-4" /> {dest.distance} • {dest.location}
                </p>
                <div className="inline-block bg-muted px-2 py-1 rounded text-xs font-medium text-muted-foreground">
                  Perfil: {dest.type}
                </div>
              </div>

              <div className="flex justify-between items-end mt-6 sm:mt-0 pt-4 sm:pt-0 border-t sm:border-t-0 border-border">
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">Valor estimado</p>
                  <p className="font-bold text-xl text-accent">{dest.price || 'Doação'}</p>
                </div>
                <Button
                  onClick={() => handleAction(dest.action)}
                  size="lg"
                  className={`rounded-xl font-bold shadow-sm ${dest.action === 'Doar' ? 'bg-primary' : 'bg-secondary hover:bg-secondary/90'}`}
                >
                  {dest.action}
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
