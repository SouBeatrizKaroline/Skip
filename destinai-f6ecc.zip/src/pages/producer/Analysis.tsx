import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Sparkles, Eye } from 'lucide-react'
import { analyzeProduct, analyzeVision } from '@/services/api'
import { ConfidenceBadge } from '@/components/ConfidenceBadge'
import pb from '@/lib/pocketbase/client'

export default function Analysis() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const id = searchParams.get('id')
  const [productName, setProductName] = useState('vegetable')
  const [visionResult, setVisionResult] = useState<{
    visual_condition: string
    confidence_score: number
  } | null>(null)
  const [phase, setPhase] = useState<'scanning' | 'vision' | 'matching'>('scanning')

  useEffect(() => {
    if (id) {
      pb.collection('products')
        .getOne(id)
        .then((p) => {
          setProductName(p.name)
          setPhase('vision')
          return analyzeVision(id)
        })
        .then((res: any) => {
          if (res?.visual_condition) {
            setVisionResult({
              visual_condition: res.visual_condition,
              confidence_score: res.confidence_score || 0,
            })
          }
          setPhase('matching')
          return analyzeProduct(id)
        })
        .then(() => {
          setTimeout(() => navigate(`/producer/destinations?id=${id}`), 2500)
        })
        .catch(() => {
          setTimeout(() => navigate(`/producer/destinations?id=${id}`), 2500)
        })
    } else {
      const timer = setTimeout(() => navigate('/producer/destinations'), 4000)
      return () => clearTimeout(timer)
    }
  }, [id, navigate])

  return (
    <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full text-center space-y-8 min-h-[70dvh] py-12">
      <div className="relative w-56 h-56 rounded-[2.5rem] overflow-hidden shadow-[0_20px_60px_-15px_rgba(76,175,80,0.4)] bg-muted border-4 border-card">
        <img
          src={`https://img.usecurling.com/p/400/400?q=${encodeURIComponent(productName)}&seed=1`}
          alt="Produto"
          className="w-full h-full object-cover"
        />
        <div className="absolute left-0 right-0 h-1.5 bg-secondary shadow-[0_0_20px_4px_rgba(76,175,80,0.9)] animate-scan z-10 rounded-full" />
        <div className="absolute inset-0 bg-secondary/20 animate-pulse z-0 mix-blend-overlay" />
        <div className="absolute top-1/4 left-1/4 w-8 h-8 border-2 border-white/50 rounded-lg animate-pulse" />
        <div
          className="absolute bottom-1/3 right-1/4 w-12 h-12 border-2 border-secondary rounded-lg animate-pulse"
          style={{ animationDelay: '0.5s' }}
        />
      </div>

      <div className="space-y-4 animate-fade-in-up">
        <div className="flex items-center justify-center gap-3 text-primary font-bold text-2xl">
          <div className="bg-secondary/20 p-2 rounded-full">
            <Sparkles
              className="w-6 h-6 text-secondary animate-spin"
              style={{ animationDuration: '3s' }}
            />
          </div>
          {phase === 'vision'
            ? 'Análise Visual IA'
            : phase === 'matching'
              ? 'Buscando Compradores'
              : 'IA Ativada'}
        </div>
        <p className="text-muted-foreground text-lg leading-relaxed max-w-sm mx-auto">
          {phase === 'vision'
            ? 'Classificando qualidade visual e estimando confiança...'
            : phase === 'matching'
              ? 'Cruzando dados de demanda e localização...'
              : 'Iniciando análise...'}
        </p>
      </div>

      {visionResult && (
        <div className="flex flex-col items-center gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-secondary" />
            <span className="font-bold text-primary">
              Classificação: {visionResult.visual_condition.replace(/_/g, ' ').toLowerCase()}
            </span>
          </div>
          <ConfidenceBadge score={visionResult.confidence_score} />
        </div>
      )}

      <div className="w-full max-w-xs bg-muted rounded-full h-3 overflow-hidden shadow-inner">
        <div
          className="bg-gradient-to-r from-secondary/80 to-secondary h-full rounded-full w-full"
          style={{ animation: 'fill 4s cubic-bezier(0.4, 0, 0.2, 1) forwards' }}
        />
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: '@keyframes fill { from { width: 0%; } to { width: 100%; } }',
        }}
      />
    </div>
  )
}
