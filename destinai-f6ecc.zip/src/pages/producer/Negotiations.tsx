import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, Check, X, FileText, MapPin, Package } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import { useToast } from '@/hooks/use-toast'
import pb from '@/lib/pocketbase/client'
import { getMatchesByProducer, updateMatchStatus } from '@/services/matches'
import { dispatchNotification } from '@/services/notifications'
import { InvoiceModal, type InvoiceData } from '@/components/InvoiceModal'

export default function Negotiations() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast } = useToast()
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [producerId, setProducerId] = useState('')
  const [invoiceData, setInvoiceData] = useState<InvoiceData | null>(null)
  const [invoiceOpen, setInvoiceOpen] = useState(false)

  useEffect(() => {
    if (user) {
      pb.collection('producer_profiles')
        .getFirstListItem(`user_id="${user.id}"`)
        .then((p) => setProducerId(p.id))
        .catch(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [user])

  const loadData = async () => {
    if (!producerId) return
    try {
      const data = await getMatchesByProducer(producerId)
      setMatches(data)
    } catch {
      setMatches([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (producerId) loadData()
  }, [producerId])

  useRealtime('matches', () => {
    if (producerId) loadData()
  })

  const handleAccept = async (match: any) => {
    try {
      await updateMatchStatus(match.id, 'CONFIRMED')
      toast({ title: 'Proposta aceita! ✅', description: 'O comprador foi notificado.' })
      const buyer = match.expand?.buyer_id
      const product = match.expand?.product_id
      dispatchNotification({
        email: '',
        phone: buyer?.phone || '',
        title: 'Proposta Aceita',
        message: `Sua proposta para ${product?.name || 'produto'} foi aceita pelo produtor!`,
      })
      loadData()
    } catch {
      toast({ title: 'Erro', description: 'Não foi possível aceitar a proposta.' })
    }
  }

  const handleDecline = async (match: any) => {
    try {
      await updateMatchStatus(match.id, 'CANCELLED')
      toast({ title: 'Proposta recusada', description: 'O comprador foi notificado.' })
      loadData()
    } catch {
      toast({ title: 'Erro', description: 'Não foi possível recusar a proposta.' })
    }
  }

  const handleInvoice = (match: any) => {
    const product = match.expand?.product_id
    const buyer = match.expand?.buyer_id
    const producer = match.expand?.producer_id
    setInvoiceData({
      producerName: producer?.farm_name || user?.name || '',
      producerCompany: user?.company_name || '',
      producerCity: producer?.city || '',
      producerState: producer?.state || '',
      buyerName: buyer?.business_name || '',
      buyerCompany: buyer?.business_name || '',
      buyerCity: buyer?.city || '',
      buyerState: buyer?.state || '',
      productName: product?.name || '',
      quantity: product?.quantity_kg || 0,
      pricePerKg: match.price_agreed || product?.price_per_kg || 0,
      total: (product?.quantity_kg || 0) * (match.price_agreed || product?.price_per_kg || 0),
      matchId: match.id,
    })
    setInvoiceOpen(true)
  }

  const statusConfig: Record<string, { label: string; cls: string }> = {
    PENDING: { label: 'Aguardando', cls: 'bg-accent/15 text-accent' },
    CONFIRMED: { label: 'Confirmado', cls: 'bg-secondary/15 text-secondary' },
    CANCELLED: { label: 'Recusado', cls: 'bg-destructive/15 text-destructive' },
    COMPLETED: { label: 'Concluído', cls: 'bg-primary/15 text-primary' },
  }

  return (
    <div className="max-w-3xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/dashboard/produtor')}
          className="bg-card p-2 rounded-full shadow-sm hover:shadow-elevation transition-shadow"
        >
          <ChevronLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <h1 className="text-2xl font-bold text-primary ml-4">Negociações</h1>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="p-5 rounded-3xl animate-pulse bg-muted h-32" />
          ))}
        </div>
      ) : matches.length === 0 ? (
        <div className="text-center py-20">
          <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Nenhuma negociação ainda.</p>
          <p className="text-sm text-muted-foreground/70 mt-1">
            Quando compradores enviarem propostas, elas aparecerão aqui.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {matches.map((match) => {
            const product = match.expand?.product_id
            const buyer = match.expand?.buyer_id
            const status = statusConfig[match.status] || statusConfig.PENDING
            return (
              <Card key={match.id} className="p-5 rounded-3xl border-border shadow-sm">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-bold text-lg text-primary">{product?.name || 'Produto'}</h3>
                    <p className="text-sm text-muted-foreground">
                      {product?.quantity_kg || 0} kg • R${' '}
                      {(match.price_agreed || 0).toFixed(2).replace('.', ',')}/kg
                    </p>
                  </div>
                  <Badge className={`${status.cls} border-none`}>{status.label}</Badge>
                </div>
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 bg-muted/50 p-2 rounded-xl">
                  <MapPin className="w-4 h-4 shrink-0" />
                  <span className="truncate">
                    {buyer?.business_name || 'Comprador'} • {buyer?.city || ''}/{buyer?.state || ''}
                  </span>
                </div>
                <div className="flex gap-3">
                  {match.status === 'PENDING' && (
                    <>
                      <Button
                        onClick={() => handleAccept(match)}
                        className="flex-1 bg-secondary text-white hover:bg-secondary/90 rounded-xl"
                      >
                        <Check className="w-4 h-4 mr-1" /> Aceitar
                      </Button>
                      <Button
                        onClick={() => handleDecline(match)}
                        variant="outline"
                        className="flex-1 border-destructive/30 text-destructive hover:bg-destructive/5 rounded-xl"
                      >
                        <X className="w-4 h-4 mr-1" /> Recusar
                      </Button>
                    </>
                  )}
                  {match.status === 'CONFIRMED' && (
                    <Button
                      onClick={() => handleInvoice(match)}
                      className="flex-1 bg-primary text-white hover:bg-primary/90 rounded-xl"
                    >
                      <FileText className="w-4 h-4 mr-1" /> Gerar NF-e
                    </Button>
                  )}
                </div>
              </Card>
            )
          })}
        </div>
      )}

      <InvoiceModal open={invoiceOpen} onOpenChange={setInvoiceOpen} data={invoiceData} />
    </div>
  )
}
