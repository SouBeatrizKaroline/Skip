import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { ChevronLeft, ChevronRight, ImagePlus, Loader2, X, Check } from 'lucide-react'
import { ViviContextHelp } from '@/components/ViviContextHelp'
import { PriceRecommendation } from '@/components/PriceRecommendation'
import { EconomicViabilityCard } from '@/components/EconomicViabilityCard'
import { useAuth } from '@/hooks/use-auth'
import pb from '@/lib/pocketbase/client'
import { createProduct } from '@/services/products'
import { useToast } from '@/hooks/use-toast'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

const formSchema = z.object({
  name: z.string().min(1, 'Selecione um produto'),
  quantity: z.coerce.number().min(1, 'A quantidade deve ser maior que zero'),
  price: z.coerce.number().min(0.01, 'O preço deve ser maior que zero'),
  harvestDate: z
    .string()
    .min(1, 'Data de colheita é obrigatória')
    .refine((val) => new Date(val) <= new Date(), 'A data de colheita não pode ser no futuro'),
  condition: z.string().min(1, 'Condição visual é obrigatória'),
  maturationStage: z.string().optional(),
})

export default function NewSurplus() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast } = useToast()

  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [producerId, setProducerId] = useState<string>('')

  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [dragOver, setDragOver] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      quantity: 0,
      price: 0,
      harvestDate: new Date().toISOString().split('T')[0],
      condition: 'MINOR_IMPERFECTIONS',
      maturationStage: '',
    },
  })

  const watchedName = form.watch('name')
  const watchedQty = form.watch('quantity')
  const watchedCondition = form.watch('condition')
  const watchedPrice = form.watch('price')
  const watchedMaturationStage = form.watch('maturationStage')

  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (user) {
      pb.collection('producer_profiles')
        .getFirstListItem(`user_id="${user.id}"`)
        .then((p) => setProducerId(p.id))
        .catch(() => {})
    }
  }, [user])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImageFiles((prev) => [...prev, ...Array.from(e.target.files!)])
    }
  }

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith('image/'))
    if (files.length > 0) setImageFiles((prev) => [...prev, ...files])
  }

  const handleNext = async () => {
    if (step === 1) {
      const valid = await form.trigger(['name', 'quantity', 'price', 'harvestDate'])
      if (!valid) return
    }
    setStep(step + 1)
  }

  const handlePrev = () => setStep(step - 1)

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!producerId) {
      toast({ title: 'Erro', description: 'Perfil de produtor não encontrado.' })
      return
    }

    setLoading(true)
    try {
      const prod = await createProduct({
        producer_id: producerId,
        name: values.name,
        quantity_kg: values.quantity,
        price_per_kg: values.price,
        harvest_date: values.harvestDate,
        visual_condition: values.condition,
        maturation_stage: values.maturationStage || '',
        status: 'AVAILABLE',
      })

      if (imageFiles.length > 0) {
        for (const file of imageFiles) {
          const formData = new FormData()
          formData.append('product_id', prod.id)
          formData.append('image', file)
          await pb.collection('product_images').create(formData)
        }
      }

      navigate(`/producer/analysis?id=${prod.id}`)
    } catch (err) {
      toast({ title: 'Erro', description: 'Falha ao cadastrar excedente.' })
      setLoading(false)
    }
  }

  const STEPS = [
    { title: 'Identificação' },
    { title: 'Estado Visual' },
    { title: 'Fotos' },
    { title: 'Resumo' },
  ]

  return (
    <div className="max-w-2xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/dashboard/produtor')}
          className="flex items-center text-sm font-bold text-muted-foreground hover:text-primary transition-colors bg-card p-2 rounded-full shadow-sm"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold text-primary ml-4">Novo excedente</h1>
      </div>

      <div className="flex items-center justify-between mb-8 relative">
        <div className="absolute left-0 right-0 h-1 bg-muted top-1/2 -translate-y-1/2 z-0"></div>
        {STEPS.map((s, i) => {
          const active = step >= i + 1
          return (
            <div key={i} className="relative z-10 flex flex-col items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${active ? 'bg-secondary text-white shadow-md' : 'bg-card border-2 border-muted text-muted-foreground'}`}
              >
                {step > i + 1 ? <Check className="w-4 h-4" /> : i + 1}
              </div>
              <span
                className={`absolute top-10 text-[10px] sm:text-xs font-bold whitespace-nowrap ${active ? 'text-primary' : 'text-muted-foreground'}`}
              >
                {s.title}
              </span>
            </div>
          )
        })}
      </div>

      <Card className="p-6 sm:p-8 space-y-6 rounded-3xl shadow-elevation border-none mt-12 mb-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            {step === 1 && (
              <div className="space-y-6 animate-fade-in">
                <h2 className="text-xl font-bold text-primary">Informações do Lote</h2>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel className="text-base font-bold text-primary">Produto</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger className="bg-muted border-none h-14 rounded-xl px-4 text-base">
                            <SelectValue placeholder="Selecione o produto" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Cenoura">Cenoura</SelectItem>
                          <SelectItem value="Tomate">Tomate</SelectItem>
                          <SelectItem value="Batata">Batata</SelectItem>
                          <SelectItem value="Alface">Alface</SelectItem>
                          <SelectItem value="Cebola">Cebola</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel className="text-base font-bold text-primary">
                          Quantidade (kg)
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            className="bg-muted border-none h-14 rounded-xl px-4 text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel className="text-base font-bold text-primary">
                          Preço por kg (R$)
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            min="0.01"
                            className="bg-muted border-none h-14 rounded-xl px-4 text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                {watchedName && Number(watchedQty) > 0 && (
                  <PriceRecommendation
                    name={watchedName}
                    quantityKg={Number(watchedQty)}
                    visualCondition={watchedCondition}
                    pricePerKg={Number(watchedPrice)}
                  />
                )}
                <FormField
                  control={form.control}
                  name="maturationStage"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel className="text-base font-bold text-primary">
                        Estágio de Maturação
                      </FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger className="bg-muted border-none h-14 rounded-xl px-4 text-base">
                            <SelectValue placeholder="Selecione o estágio" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="VERDE">Verde</SelectItem>
                          <SelectItem value="PONTO">No ponto</SelectItem>
                          <SelectItem value="MADURO">Maduro</SelectItem>
                          <SelectItem value="AVANCADO">Avançado</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {watchedName && Number(watchedQty) > 0 && Number(watchedPrice) > 0 && (
                  <EconomicViabilityCard
                    quantityKg={Number(watchedQty)}
                    pricePerKg={Number(watchedPrice)}
                  />
                )}
                <FormField
                  control={form.control}
                  name="harvestDate"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel className="text-base font-bold text-primary">
                        Data da colheita
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          max={new Date().toISOString().split('T')[0]}
                          className="bg-muted border-none h-14 rounded-xl px-4 text-base"
                          {...field}
                        />
                      </FormControl>{' '}
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-fade-in">
                <h2 className="text-xl font-bold text-primary">Qual é a condição visual?</h2>
                <FormField
                  control={form.control}
                  name="condition"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value}
                          onValueChange={field.onChange}
                          className="gap-3"
                        >
                          {[
                            {
                              id: 'r1',
                              value: 'RETAIL_STANDARD',
                              label: 'Padrão varejo',
                              desc: 'Perfeito estado estético',
                            },
                            {
                              id: 'r2',
                              value: 'MINOR_IMPERFECTIONS',
                              label: 'Pequenas imperfeições',
                              desc: 'Manchas leves ou formato irregular',
                            },
                            {
                              id: 'r3',
                              value: 'NON_STANDARD',
                              label: 'Fora do padrão comercial',
                              desc: 'Danos estéticos maiores',
                            },
                            {
                              id: 'r4',
                              value: 'PROCESSING_ONLY',
                              label: 'Destinado para processamento',
                              desc: 'Ideal para sucos ou polpas',
                            },
                          ].map((opt) => (
                            <div key={opt.id} className="relative">
                              <RadioGroupItem
                                value={opt.value}
                                id={opt.id}
                                className="peer sr-only"
                              />
                              <Label
                                htmlFor={opt.id}
                                className="flex flex-col cursor-pointer border-2 border-transparent bg-muted rounded-2xl p-4 peer-data-[state=checked]:border-secondary peer-data-[state=checked]:bg-secondary/5 hover:bg-muted/80 transition-all"
                              >
                                <span className="font-bold text-primary mb-1">{opt.label}</span>
                                <span className="text-xs text-muted-foreground font-normal">
                                  {opt.desc}
                                </span>
                              </Label>
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-fade-in">
                <h2 className="text-xl font-bold text-primary">Adicione fotos reais do lote</h2>
                <p className="text-sm text-muted-foreground">
                  A inteligência artificial fará uma análise de qualidade baseada nestas fotos.
                </p>
                <div className="flex gap-4 flex-wrap pb-4">
                  {imageFiles.map((file, i) => (
                    <div key={i} className="relative shrink-0">
                      <img
                        src={URL.createObjectURL(file)}
                        alt={`Preview ${i + 1}`}
                        className="w-32 h-32 rounded-2xl object-cover shadow-sm"
                      />
                      <button
                        type="button"
                        onClick={() => removeImage(i)}
                        className="absolute -top-2 -right-2 bg-destructive text-white rounded-full p-1 shadow-sm"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                  />
                  <div
                    onDragOver={(e) => {
                      e.preventDefault()
                      setDragOver(true)
                    }}
                    onDragLeave={() => setDragOver(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-32 h-32 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all shrink-0 group cursor-pointer ${dragOver ? 'border-secondary bg-secondary/10 text-secondary scale-105' : 'border-border bg-muted/50 text-muted-foreground hover:border-primary hover:text-primary'}`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-colors shadow-sm ${dragOver ? 'bg-secondary/20' : 'bg-card group-hover:bg-primary group-hover:text-primary-foreground'}`}
                    >
                      <ImagePlus className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold">Arraste ou clique</span>
                  </div>
                </div>
                {imageFiles.length === 0 && (
                  <ViviContextHelp context="Cadastre fotos nítidas e com boa iluminação. Mostre algumas unidades em destaque para ajudar a IA a avaliar manchas e imperfeições." />
                )}
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6 animate-fade-in">
                <h2 className="text-xl font-bold text-primary">Tudo certo?</h2>
                <div className="bg-muted p-5 rounded-2xl space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm font-bold text-muted-foreground">Produto</span>
                    <span className="text-sm font-bold text-primary">{form.getValues().name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-bold text-muted-foreground">Quantidade</span>
                    <span className="text-sm font-bold text-primary">
                      {form.getValues().quantity} kg
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-bold text-muted-foreground">Preço/kg</span>
                    <span className="text-sm font-bold text-primary">
                      R$ {Number(form.getValues().price).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-bold text-muted-foreground">Maturação</span>
                    <span className="text-sm font-bold text-primary">
                      {form.getValues().maturationStage || 'Não informado'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-bold text-muted-foreground">Fotos anexadas</span>
                    <span className="text-sm font-bold text-primary">{imageFiles.length}</span>
                  </div>
                </div>
              </div>
            )}
          </form>
        </Form>
      </Card>

      <div className="flex gap-4">
        {step > 1 && (
          <Button
            type="button"
            variant="outline"
            onClick={handlePrev}
            className="h-14 rounded-2xl text-lg font-bold border-2"
          >
            Voltar
          </Button>
        )}
        {step < 4 ? (
          <Button
            type="button"
            onClick={handleNext}
            className="flex-1 h-14 rounded-2xl text-lg font-bold shadow-elevation"
          >
            Continuar <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        ) : (
          <Button
            type="button"
            onClick={form.handleSubmit(onSubmit)}
            disabled={loading}
            className="flex-1 h-14 rounded-2xl text-lg font-bold shadow-elevation text-white bg-secondary hover:bg-secondary/90"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Analisando...
              </>
            ) : (
              'Enviar para análise da IA'
            )}
          </Button>
        )}
      </div>
    </div>
  )
}
