import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Trophy, Medal, Award, Crown, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/use-auth'
import { getLeaderboard, type LeaderboardEntry } from '@/services/leaderboard'
import { ReputationBadge } from '@/components/ReputationBadge'

const ROLE_LABELS: Record<string, string> = {
  PRODUCER: 'Produtores',
  BUYER: 'Compradores',
  TRANSPORTER: 'Transportadores',
}

export default function Ranking() {
  const { user } = useAuth()
  const [entries, setEntries] = useState<LeaderboardEntry[]>([])
  const [myRank, setMyRank] = useState(0)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getLeaderboard()
      .then((res) => {
        setEntries(res.rankings || [])
        setMyRank(res.my_rank || 0)
        setTotal(res.total_users || 0)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [user])

  const podiumIcons = [Crown, Medal, Award]

  return (
    <div className="max-w-4xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center shrink-0 border border-accent/20">
          <Trophy className="w-8 h-8 text-accent" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1">Ranking</h1>
          <p className="text-muted-foreground">
            {ROLE_LABELS[user?.role] || 'Usuários'} • Sua posição: #{myRank} de {total}
          </p>
        </div>
      </div>

      {myRank > 0 && (
        <Card className="p-5 mb-6 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/10 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary/15 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <p className="font-bold text-primary">Sua posição</p>
                <p className="text-sm text-muted-foreground">
                  Continue assim para subir no ranking!
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-secondary">#{myRank}</p>
              <p className="text-xs text-muted-foreground">
                de {total} {(ROLE_LABELS[user?.role] || 'usuários').toLowerCase()}
              </p>
            </div>
          </div>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-20 rounded-2xl" />
          ))}
        </div>
      ) : entries.length === 0 ? (
        <div className="text-center py-20">
          <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">Nenhum dado de ranking disponível ainda.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {entries.map((entry, i) => {
            const PodiumIcon = i < 3 ? podiumIcons[i] : null
            return (
              <Card
                key={entry.user_id}
                className={cn(
                  'p-4 rounded-2xl border-border flex items-center gap-4 transition-all',
                  entry.is_current_user && 'border-secondary/40 bg-secondary/5 shadow-elevation',
                )}
              >
                <div
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center font-bold shrink-0',
                    i === 0
                      ? 'bg-yellow-100 text-yellow-700'
                      : i === 1
                        ? 'bg-gray-100 text-gray-600'
                        : i === 2
                          ? 'bg-orange-100 text-orange-700'
                          : 'bg-muted text-muted-foreground',
                  )}
                >
                  {PodiumIcon ? <PodiumIcon className="w-5 h-5" /> : i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-primary truncate">{entry.name}</p>
                    {entry.is_current_user && (
                      <span className="text-xs bg-secondary text-white px-2 py-0.5 rounded-full">
                        Você
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{entry.company_name || '—'}</p>
                </div>
                <div className="flex items-center gap-3 sm:gap-4 shrink-0">
                  <div className="text-center hidden sm:block">
                    <p className="text-sm font-bold text-primary">{entry.kg_saved}</p>
                    <p className="text-[10px] text-muted-foreground">kg salvos</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-accent">{entry.reputation_score}</p>
                    <p className="text-[10px] text-muted-foreground">pontos</p>
                  </div>
                  {entry.tier_status && <ReputationBadge tier={entry.tier_status} size="sm" />}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
