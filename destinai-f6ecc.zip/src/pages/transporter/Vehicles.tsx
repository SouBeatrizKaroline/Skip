import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Truck, Plus, Trash2, Pencil, Snowflake, Loader2 } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import { useRealtime } from '@/hooks/use-realtime'
import pb from '@/lib/pocketbase/client'
import {
  getVehicles,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  VEHICLE_TYPE_LABELS,
} from '@/services/vehicles'

const EMPTY = {
  vehicle_type: 'VAN',
  plate: '',
  year: '',
  capacity_kg: '',
  capacity_m3: '',
  refrigeration: false,
  allowed_cargo_types: '',
  radius_km: '',
  avg_consumption: '',
  availability_status: 'AVAILABLE',
}

export default function Vehicles() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [vehicles, setVehicles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState<any>(EMPTY)
  const [transporterId, setTransporterId] = useState('')

  const loadData = async () => {
    if (!transporterId) return
    try {
      setVehicles(await getVehicles(transporterId))
    } catch {
      setVehicles([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (user) {
      pb.collection('transporter_profiles')
        .getFirstListItem(`user_id="${user.id}"`)
        .then((p) => setTransporterId(p.id))
        .catch(() => setLoading(false))
    } else setLoading(false)
  }, [user])

  useEffect(() => {
    if (transporterId) loadData()
  }, [transporterId])
  useRealtime('vehicles', () => {
    if (transporterId) loadData()
  })

  const handleSave = async () => {
    setSaving(true)
    try {
      const data = {
        ...form,
        transporter_id: transporterId,
        year: Number(form.year) || 0,
        capacity_kg: Number(form.capacity_kg) || 0,
        capacity_m3: Number(form.capacity_m3) || 0,
        radius_km: Number(form.radius_km) || 0,
        avg_consumption: Number(form.avg_consumption) || 0,
      }
      if (editId) {
        await updateVehicle(editId, data)
        toast({ title: 'Veículo atualizado!' })
      } else {
        await createVehicle(data)
        toast({ title: 'Veículo cadastrado!' })
      }
      setForm(EMPTY)
      setEditId(null)
      setShowForm(false)
    } catch {
      toast({ title: 'Erro ao salvar', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (v: any) => {
    setForm({
      vehicle_type: v.vehicle_type || 'VAN',
      plate: v.plate || '',
      year: String(v.year || ''),
      capacity_kg: String(v.capacity_kg || ''),
      capacity_m3: String(v.capacity_m3 || ''),
      refrigeration: v.refrigeration || false,
      allowed_cargo_types: v.allowed_cargo_types || '',
      radius_km: String(v.radius_km || ''),
      avg_consumption: String(v.avg_consumption || ''),
      availability_status: v.availability_status || 'AVAILABLE',
    })
    setEditId(v.id)
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteVehicle(id)
      toast({ title: 'Veículo removido' })
    } catch {
      toast({ title: 'Erro', variant: 'destructive' })
    }
  }

  const set = (k: string, v: any) => setForm((p: any) => ({ ...p, [k]: v }))

  return (
    <div className="max-w-4xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center shrink-0 border border-primary/20">
            <Truck className="w-7 h-7 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-primary">Gestão de Veículos</h1>
            <p className="text-muted-foreground">Cadastre e gerencie sua frota</p>
          </div>
        </div>
        <Button
          onClick={() => {
            setForm(EMPTY)
            setEditId(null)
            setShowForm(!showForm)
          }}
          className="rounded-xl"
        >
          <Plus className="w-4 h-4 mr-1" /> {showForm ? 'Fechar' : 'Adicionar'}
        </Button>
      </div>

      {showForm && (
        <Card className="p-6 mb-6 rounded-2xl border-border shadow-subtle space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Tipo</Label>
              <Select value={form.vehicle_type} onValueChange={(v) => set('vehicle_type', v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(VEHICLE_TYPE_LABELS).map(([k, v]) => (
                    <SelectItem key={k} value={k}>
                      {v}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Placa</Label>
              <Input
                value={form.plate}
                onChange={(e) => set('plate', e.target.value)}
                placeholder="ABC-1234"
              />
            </div>
            <div>
              <Label>Ano</Label>
              <Input
                type="number"
                value={form.year}
                onChange={(e) => set('year', e.target.value)}
                placeholder="2020"
              />
            </div>
            <div>
              <Label>Capacidade (kg)</Label>
              <Input
                type="number"
                value={form.capacity_kg}
                onChange={(e) => set('capacity_kg', e.target.value)}
                placeholder="5000"
              />
            </div>
            <div>
              <Label>Capacidade (m³)</Label>
              <Input
                type="number"
                value={form.capacity_m3}
                onChange={(e) => set('capacity_m3', e.target.value)}
                placeholder="20"
              />
            </div>
            <div>
              <Label>Raio de operação (km)</Label>
              <Input
                type="number"
                value={form.radius_km}
                onChange={(e) => set('radius_km', e.target.value)}
                placeholder="100"
              />
            </div>
            <div>
              <Label>Consumo médio (km/l)</Label>
              <Input
                type="number"
                value={form.avg_consumption}
                onChange={(e) => set('avg_consumption', e.target.value)}
                placeholder="8"
              />
            </div>
            <div>
              <Label>Tipos de carga permitidos</Label>
              <Input
                value={form.allowed_cargo_types}
                onChange={(e) => set('allowed_cargo_types', e.target.value)}
                placeholder="Hortaliças, Frutas"
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Switch
              checked={form.refrigeration}
              onCheckedChange={(v) => set('refrigeration', v)}
              id="refri"
            />
            <Label htmlFor="refri" className="flex items-center gap-1 cursor-pointer">
              <Snowflake className="w-4 h-4 text-secondary" /> Refrigeração
            </Label>
          </div>
          <Button onClick={handleSave} disabled={saving} className="w-full">
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : editId ? (
              'Atualizar Veículo'
            ) : (
              'Cadastrar Veículo'
            )}
          </Button>
        </Card>
      )}

      {loading ? (
        <div className="text-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
        </div>
      ) : vehicles.length === 0 ? (
        <div className="text-center py-16">
          <Truck className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Nenhum veículo cadastrado.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {vehicles.map((v) => (
            <Card
              key={v.id}
              className="p-5 rounded-2xl border-border shadow-subtle flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                <Truck className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-primary">
                  {VEHICLE_TYPE_LABELS[v.vehicle_type] || v.vehicle_type}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {v.plate || 'Sem placa'} • {v.capacity_kg || 0} kg • {v.capacity_m3 || 0} m³
                </p>
                <div className="flex gap-2 mt-1">
                  {v.refrigeration && (
                    <span className="text-xs bg-secondary/15 text-secondary px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                      <Snowflake className="w-3 h-3" /> Refrigeração
                    </span>
                  )}
                  {v.radius_km && (
                    <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full font-bold">
                      {v.radius_km} km raio
                    </span>
                  )}
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => handleEdit(v)}
                  className="p-2 rounded-lg hover:bg-muted text-primary"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(v.id)}
                  className="p-2 rounded-lg hover:bg-destructive/10 text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
