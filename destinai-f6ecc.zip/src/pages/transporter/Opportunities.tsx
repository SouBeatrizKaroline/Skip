import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Package,
  MapPin,
  Clock,
  Truck,
  Weight,
  Route as RouteIcon,
  Check,
  X,
  Bookmark,
  Navigation2,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import { useRealtime } from '@/hooks/use-realtime'
import {
  getAvailableLoads,
  acceptLoad,
  reserveLoad,
  getTransporterProfile,
} from '@/services/transporter'
import { formatDate } from '@/services/products'

export default function TransporterOpportunities() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [loads, setLoads] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [transporterId, setTransporterId] = useState('')
  const [acting, setActing] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      getTransporterProfile(user.id)
        .then((p) => setTransporterId(p.id))
        .catch(() => setLoading(false))
    } else setLoading(false)
  }, [user])

  const loadData = async () => {
    try {
      setLoads(await getAvailableLoads())
    } catch {
      setLoads([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (transporterId) loadData()
  }, [transporterId])
  useRealtime('orders', () => loadData())

  const handleAccept = async (orderId: string) => {
    setActing(orderId)
    try {
      await acceptLoad(orderId, transporterId)
      toast({ title: 'Carga aceita!', description: 'Dirija-se ao ponto de coleta.' })
      loadData()
    } catch {
      toast({ title: 'Erro ao aceitar', variant: 'destructive' })
    } finally {
      setActing(null)
    }
  }

  const handleReserve = async (orderId: string) => {
    setActing(orderId)
    try {
      await reserveLoad(orderId, transporterId)
      toast({ title: 'Carga reservada!', description: 'Você tem 30 minutos para confirmar.' })
      loadData()
    } catch {
      toast({ title: 'Erro ao reservar', variant: 'destructive' })
    } finally {
      setActing(null)
    }
  }

  const handleRefuse = (orderId: string) => {
    setLoads((prev) => prev.filter((l) => l.id !== orderId))
    toast({ title: 'Carga recusada' })
  }

  return (
    <div className="max-w-4xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center shrink-0 border border-primary/20">
          <Navigation2 className="w-7 h-7 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-primary">Oportunidades de Frete</h1>
          <p className="text-muted-foreground">Cargas disponíveis na sua região</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <Card className="p-4 bg-card border-border rounded-2xl text-center">
          <Package className="w-5 h-5 text-secondary mx-auto mb-1" />
          <p className="text-2xl font-bold text-primary">{loads.length}</p>
          <p className="text-[10px] text-muted-foreground font-bold">Disponíveis</p>
        </Card>
        <Card className="p-4 bg-card border-border rounded-2xl text-center">
          <Truck className="w-5 h-5 text-primary mx-auto mb-1" />
          <p className="text-2xl font-bold text-primary">—</p>
          <p className="text-[10px] text-muted-foreground font-bold">Aceitas</p>
        </Card>
        <Card className="p-4 bg-card border-border rounded-2xl text-center">
          <RouteIcon className="w-5 h-5 text-accent mx-auto mb-1" />
          <p className="text-2xl font-bold text-primary">R$ 0</p>
          <p className="text-[10px] text-muted-foreground font-bold">Ganhos</p>
        </Card>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Skeleton key={i} className="h-48 rounded-2xl" />
          ))}
        </div>
      ) : loads.length === 0 ? (
        <div className="text-center py-16">
          <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Nenhuma carga disponível no momento.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {loads.map((load) => {
            const match = load.expand?.match_id
            const product = match?.expand?.product_id
            const buyer = match?.expand?.buyer_id
            return (
              <Card
                key={load.id}
                className="p-5 rounded-2xl border-border shadow-sm hover:shadow-elevation transition-all bg-card"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="inline-flex px-3 py-1 rounded-lg text-xs font-bold bg-secondary/15 text-secondary border border-secondary/20 mb-2">
                      Disponível
                    </span>
                    <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                      <Clock className="w-4 h-4" /> {formatDate(load.created || '')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground font-bold">Frete</p>
                    <p className="font-bold text-primary text-xl">
                      R$ {(load.reward || 0).toFixed(2).replace('.', ',')}
                    </p>
                  </div>
                </div>
                <div className="relative pl-8 pb-4 border-l-2 border-dashed border-border ml-3 space-y-3">
                  <div className="absolute w-5 h-5 bg-secondary rounded-full -left-[11px] top-0 border-2 border-card" />
                  <div>
                    <p className="font-bold text-sm text-primary">
                      Coleta: {product?.city || load.pickup_address || 'N/A'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {product?.name || 'Produto'} • {product?.quantity_kg || 0} kg
                    </p>
                  </div>
                  <div className="absolute w-5 h-5 bg-primary rounded-full -left-[11px] top-full border-2 border-card flex items-center justify-center">
                    <MapPin className="w-2.5 h-2.5 text-white" />
                  </div>
                  <p className="font-bold text-sm text-primary pt-2">
                    Entrega: {buyer?.city || load.delivery_address || 'N/A'}
                  </p>
                </div>
                <div className="flex gap-2 mb-4 text-xs">
                  <span className="flex items-center gap-1 bg-muted px-2 py-1 rounded-md font-bold text-muted-foreground">
                    <Weight className="w-3 h-3" /> {product?.quantity_kg || 0} kg
                  </span>
                  <span className="flex items-center gap-1 bg-muted px-2 py-1 rounded-md font-bold text-muted-foreground">
                    <Truck className="w-3 h-3" /> {product?.name || 'Carga'}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => handleAccept(load.id)}
                    disabled={acting === load.id}
                    className="flex-1 bg-secondary text-white hover:bg-secondary/90 rounded-xl"
                  >
                    <Check className="w-4 h-4 mr-1" /> Aceitar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleReserve(load.id)}
                    disabled={acting === load.id}
                    className="flex-1 rounded-xl border-accent text-accent hover:bg-accent/10"
                  >
                    <Bookmark className="w-4 h-4 mr-1" /> Reservar
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleRefuse(load.id)}
                    disabled={acting === load.id}
                    className="rounded-xl text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
