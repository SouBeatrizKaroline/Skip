import { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Sparkles, Loader2, CheckCircle2, MapPin, TrendingUp, ChevronLeft } from 'lucide-react'
import pb from '@/lib/pocketbase/client'
import { analyzeProduct, getRecommendations } from '@/services/api'
import { VISUAL_CONDITION_LABELS } from '@/services/products'
import { SmartScoreBadge } from '@/components/SmartScoreBadge'
import { PerishabilityIndicator } from '@/components/PerishabilityIndicator'
import { EconomicBreakdown } from '@/components/EconomicBreakdown'
import { getSmartScore, type SmartScoreResult } from '@/services/smart-score'

const BUYER_TYPE_LABELS: Record<string, string> = {
  RESTAURANT: 'Restaurante',
  INDUSTRY: 'Indústria',
  FOOD_BANK: 'Banco de Alimentos',
  MARKET: 'Mercado',
}

interface AnalysisData {
  quality_score: number
  shelf_life_days: number
  recommended_use: string
  notes: string
  visual_condition: string
  confidence_score?: number
}

interface RecData {
  buyer_id: string
  business_name: string
  buyer_type: string
  city: string
  state: string
  distance_km: number
  match_score: number
  economic_score?: number
  logistics_score?: number
  ai_justification?: string
}

export default function AiDestination() {
  const [searchParams] = useSearchParams()
  const id = searchParams.get('id')
  const [product, setProduct] = useState<any>(null)
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null)
  const [recommendations, setRecommendations] = useState<RecData[]>([])
  const [loading, setLoading] = useState(true)
  const [smartScore, setSmartScore] = useState<SmartScoreResult | null>(null)

  useEffect(() => {
    if (!id) {
      setLoading(false)
      return
    }
    let active = true
    const run = async () => {
      try {
        const p = await pb.collection('products').getOne(id)
        if (!active) return
        setProduct(p)
        let ai = await pb
          .collection('ai_analysis')
          .getFirstListItem(`product_id="${id}"`)
          .catch(() => null)
        if (!ai) {
          await analyzeProduct(id)
          ai = await pb
            .collection('ai_analysis')
            .getFirstListItem(`product_id="${id}"`)
            .catch(() => null)
        }
        if (active && ai) {
          setAnalysis({
            quality_score: ai.quality_score || 0,
            shelf_life_days: ai.shelf_life_days || 0,
            recommended_use: ai.recommended_use || '',
            notes: ai.notes || '',
            visual_condition: p.visual_condition || '',
            confidence_score: ai.confidence_score || 0,
          })
        }
        const recs = await getRecommendations(id).catch(() => ({ recommendations: [] }))
        if (active && recs?.recommendations) setRecommendations(recs.recommendations)
        const score = await getSmartScore(id).catch(() => null)
        if (active && score) setSmartScore(score)
      } catch {
        /* ignore */
      } finally {
        if (active) setLoading(false)
      }
    }
    run()
    return () => {
      active = false
    }
  }, [id])

  if (!id) {
    return (
      <div className="max-w-2xl mx-auto w-full text-center py-20 animate-fade-in-up">
        <Sparkles className="w-12 h-12 text-secondary mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-primary mb-2">Destino Inteligente</h1>
        <p className="text-muted-foreground mb-6">Selecione um produto para análise da IA</p>
        <Button asChild>
          <Link to="/dashboard/produtor">Ver meus produtos</Link>
        </Button>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full text-center space-y-8 py-20">
        <div className="relative w-40 h-40 rounded-[2rem] overflow-hidden shadow-elevation bg-muted border-4 border-card">
          <img
            src={`https://img.usecurling.com/p/400/400?q=${encodeURIComponent(product?.name || 'vegetable')}`}
            alt="Produto"
            className="w-full h-full object-cover"
          />
          <div className="absolute left-0 right-0 h-1.5 bg-secondary shadow-[0_0_20px_4px_rgba(76,175,80,0.9)] animate-scan z-10 rounded-full" />
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-center gap-2 text-primary font-bold text-xl">
            <Sparkles
              className="w-5 h-5 text-secondary animate-spin"
              style={{ animationDuration: '3s' }}
            />
            Vivi está analisando...
          </div>
          <p className="text-muted-foreground">
            Classificando qualidade e buscando compradores ideais
          </p>
        </div>
        <Loader2 className="w-8 h-8 animate-spin text-secondary" />
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto w-full animate-fade-in-up pb-12">
      <Link
        to="/dashboard/produtor"
        className="flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-6"
      >
        <ChevronLeft className="w-5 h-5" /> Voltar
      </Link>
      <div className="bg-gradient-to-r from-secondary/20 to-secondary/5 rounded-3xl p-6 flex items-center gap-4 mb-8 border border-secondary/20">
        <CheckCircle2 className="w-10 h-10 text-secondary shrink-0" />
        <div>
          <h1 className="font-bold text-xl text-primary">Análise concluída!</h1>
          <p className="text-sm text-muted-foreground">
            Vivi encontrou os melhores destinos para o seu lote.
          </p>
        </div>
      </div>
      {analysis && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4 rounded-2xl border-none shadow-subtle text-center">
            <p className="text-3xl font-bold text-secondary">{analysis.quality_score}</p>
            <p className="text-xs text-muted-foreground font-bold mt-1">Qualidade (0-100)</p>
          </Card>
          {analysis.confidence_score ? (
            <Card className="p-4 rounded-2xl border-none shadow-subtle text-center">
              <p className="text-3xl font-bold text-accent">{analysis.confidence_score}%</p>
              <p className="text-xs text-muted-foreground font-bold mt-1">Confiança IA Visual</p>
            </Card>
          ) : null}
          <Card className="p-4 rounded-2xl border-none shadow-subtle text-center">
            <p className="text-3xl font-bold text-primary">{analysis.shelf_life_days}</p>
            <p className="text-xs text-muted-foreground font-bold mt-1">Dias de validade</p>
          </Card>
          <Card className="p-4 rounded-2xl border-none shadow-subtle text-center">
            <p className="text-sm font-bold text-primary leading-tight">
              {VISUAL_CONDITION_LABELS[analysis.visual_condition] || 'N/A'}
            </p>
            <p className="text-xs text-muted-foreground font-bold mt-1">Condição visual</p>
          </Card>
          <Card className="p-4 rounded-2xl border-none shadow-subtle text-center">
            <p className="text-sm font-bold text-accent leading-tight">
              {product?.name || 'Produto'}
            </p>
            <p className="text-xs text-muted-foreground font-bold mt-1">
              {product?.quantity_kg || 0} kg
            </p>
          </Card>
        </div>
      )}
      {smartScore && (
        <>
          <div className="flex items-center justify-between bg-gradient-to-r from-accent/10 to-transparent rounded-2xl p-4 border border-accent/20 mb-8">
            <div>
              <h3 className="font-bold text-primary mb-1">DestinAI Smart Score</h3>
              <p className="text-xs text-muted-foreground">Índice multi-fatorial de inteligência</p>
            </div>
            <SmartScoreBadge score={smartScore.smart_score} size="md" />
          </div>
          <div className="mb-8">
            <PerishabilityIndicator
              level={smartScore.factors.perishability.level}
              risk={smartScore.factors.perishability.risk}
              remainingDays={smartScore.factors.perishability.remaining_days}
              usedPct={smartScore.factors.perishability.used_pct}
              shelfLifeDays={smartScore.factors.perishability.shelf_life_days}
            />
          </div>
          <div className="mb-8">
            <EconomicBreakdown
              lotValue={smartScore.factors.economic.lot_value}
              logisticsCost={smartScore.factors.economic.logistics_cost}
              platformFee={smartScore.factors.economic.platform_fee}
              netRevenue={smartScore.factors.economic.net_revenue}
              status={smartScore.factors.economic.status}
              feePercentage={smartScore.factors.economic.fee_percentage}
              justification={smartScore.vivi_justification}
            />
          </div>
        </>
      )}
      {analysis?.notes && (
        <Card className="p-5 rounded-2xl border-border shadow-subtle mb-8 bg-gradient-to-r from-secondary/10 to-transparent">
          <div className="flex items-start gap-3">
            <div className="bg-secondary/20 p-2 rounded-full shrink-0">
              <Sparkles className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h3 className="font-bold text-primary mb-1">Recomendação da Vivi</h3>
              <p className="text-sm text-muted-foreground">{analysis.notes}</p>
              {analysis.recommended_use && (
                <p className="text-sm text-primary/80 mt-2">
                  <strong>Uso recomendado:</strong> {analysis.recommended_use}
                </p>
              )}
            </div>
          </div>
        </Card>
      )}
      <h2 className="font-bold text-xl text-primary mb-4 flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-accent" /> Destinos recomendados
      </h2>
      <div className="space-y-4">
        {recommendations.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">Nenhuma recomendação encontrada.</p>
        ) : (
          recommendations.map((rec, i) => (
            <Card
              key={rec.buyer_id}
              className="p-4 flex items-center gap-4 border-border shadow-subtle hover:shadow-elevation transition-all rounded-2xl"
            >
              <div className="w-10 h-10 bg-secondary/15 rounded-full flex items-center justify-center font-bold text-secondary shrink-0">
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-primary truncate">{rec.business_name}</h4>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {rec.city} - {rec.state} • {rec.distance_km} km
                </p>
                <Badge className="mt-1 bg-muted text-muted-foreground border-none">
                  {BUYER_TYPE_LABELS[rec.buyer_type] || rec.buyer_type}
                </Badge>
                {rec.ai_justification && (
                  <p className="text-xs text-muted-foreground mt-1 italic">
                    {rec.ai_justification}
                  </p>
                )}
              </div>
              <div className="text-right shrink-0">
                <p className="text-2xl font-bold text-secondary">{rec.match_score}%</p>
                <p className="text-xs text-muted-foreground">match</p>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
