import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { DollarSign, Crown, TrendingUp, Percent, Star, Loader2 } from 'lucide-react'
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { getAdminStats } from '@/services/admin'

export default function Monetization() {
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getAdminStats()
      .then(setStats)
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const commissionPotential = (stats?.totalMatches || 0) * 85
  const premiumRevenue = (stats?.totalUsers || 0) * 29.9 * 0.1
  const sponsoredRevenue = (stats?.totalProducts || 0) * 15
  const totalProjected = commissionPotential + premiumRevenue + sponsoredRevenue

  const chartData = [
    { source: 'Comissões', valor: Math.round(commissionPotential) },
    { source: 'Premium', valor: Math.round(premiumRevenue) },
    { source: 'Patrocínios', valor: Math.round(sponsoredRevenue) },
  ]

  return (
    <div className="max-w-5xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center shrink-0 border border-accent/20">
          <DollarSign className="w-7 h-7 text-accent" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-primary">Monetização</h1>
          <p className="text-muted-foreground">Visão de receita e oportunidades de crescimento</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card className="p-6 rounded-[2rem] border-none shadow-elevation bg-gradient-to-br from-accent/10 to-transparent">
              <div className="w-10 h-10 bg-accent/15 rounded-full flex items-center justify-center mb-3">
                <Percent className="w-5 h-5 text-accent" />
              </div>
              <p className="text-3xl font-bold text-accent">R$ {commissionPotential.toFixed(0)}</p>
              <p className="text-sm font-bold text-muted-foreground">Comissões (1-3% por match)</p>
            </Card>
            <Card className="p-6 rounded-[2rem] border-none shadow-elevation bg-gradient-to-br from-secondary/10 to-transparent">
              <div className="w-10 h-10 bg-secondary/15 rounded-full flex items-center justify-center mb-3">
                <Crown className="w-5 h-5 text-secondary" />
              </div>
              <p className="text-3xl font-bold text-secondary">R$ {premiumRevenue.toFixed(0)}</p>
              <p className="text-sm font-bold text-muted-foreground">
                Assinaturas Premium (R$29,90/mês)
              </p>
            </Card>
            <Card className="p-6 rounded-[2rem] border-none shadow-elevation bg-gradient-to-br from-primary/10 to-transparent">
              <div className="w-10 h-10 bg-primary/15 rounded-full flex items-center justify-center mb-3">
                <Star className="w-5 h-5 text-primary" />
              </div>
              <p className="text-3xl font-bold text-primary">R$ {sponsoredRevenue.toFixed(0)}</p>
              <p className="text-sm font-bold text-muted-foreground">
                Destaques patrocinados (R$15/lote)
              </p>
            </Card>
          </div>

          <Card className="p-6 md:p-8 rounded-[2rem] border-border shadow-sm mb-6">
            <h3 className="font-bold text-xl text-primary mb-1">Receita Projetada Mensal</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Total estimado:{' '}
              <span className="font-bold text-accent">R$ {totalProjected.toFixed(0)}</span>
            </p>
            <div className="h-64">
              <ChartContainer
                config={{ valor: { label: 'Receita (R$)', color: 'hsl(var(--accent))' } }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <XAxis
                      dataKey="source"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontWeight: 600 }}
                    />
                    <YAxis
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="valor" fill="var(--color-valor)" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </Card>

          <Card className="p-6 rounded-[2rem] border-border shadow-sm">
            <h3 className="font-bold text-xl text-primary mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-secondary" /> Tier Premium
            </h3>
            <div className="space-y-3">
              {[
                { feat: 'Análise de IA ilimitada', free: '5/mês', premium: 'Ilimitado' },
                { feat: 'Recomendações prioritárias', free: 'Padrão', premium: 'Primeiro na fila' },
                { feat: 'Destaque nos resultados', free: '—', premium: 'Sim' },
                { feat: 'Relatórios de impacto', free: 'Básico', premium: 'Avançado' },
              ].map((row) => (
                <div
                  key={row.feat}
                  className="flex justify-between items-center p-3 bg-muted/50 rounded-xl"
                >
                  <span className="text-sm font-medium text-primary">{row.feat}</span>
                  <div className="flex gap-4 text-xs">
                    <span className="text-muted-foreground w-20 text-right">{row.free}</span>
                    <span className="text-secondary font-bold w-20 text-right">{row.premium}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </>
      )}
    </div>
  )
}
