import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Shield, Users, Package, Truck, TrendingUp, Leaf, Droplets, Utensils } from 'lucide-react'
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { getAdminStats, type AdminStats } from '@/services/admin'
import { getImpact } from '@/services/api'

const ROLE_LABELS: Record<string, string> = {
  PRODUCER: 'Produtores',
  BUYER: 'Compradores',
  TRANSPORTER: 'Transportadores',
  ADMIN: 'Admins',
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [impact, setImpact] = useState<any>(null)

  useEffect(() => {
    getAdminStats()
      .then(setStats)
      .catch(() => {})
      .finally(() => setLoading(false))
    getImpact()
      .then((res: any) => setImpact(res))
      .catch(() => {})
  }, [])

  const barData = stats
    ? Object.entries(stats.usersByRole).map(([role, count]) => ({
        role: ROLE_LABELS[role] || role,
        usuarios: count,
      }))
    : []

  return (
    <div className="max-w-5xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border border-primary/20">
          <Shield className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1">Painel Administrativo</h1>
          <p className="text-muted-foreground">Monitoramento da plataforma e métricas globais.</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="p-5 rounded-2xl">
              <Skeleton className="w-10 h-10 rounded-full mb-4" />
              <Skeleton className="h-8 w-20 mb-2" />
              <Skeleton className="h-4 w-28" />
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              {
                label: 'Usuários',
                value: stats?.totalUsers || 0,
                icon: Users,
                color: 'text-primary',
                bg: 'bg-primary/10',
              },
              {
                label: 'Produtos',
                value: stats?.totalProducts || 0,
                icon: Package,
                color: 'text-secondary',
                bg: 'bg-secondary/10',
              },
              {
                label: 'Pedidos',
                value: stats?.totalOrders || 0,
                icon: Truck,
                color: 'text-accent',
                bg: 'bg-accent/10',
              },
              {
                label: 'Matches',
                value: stats?.totalMatches || 0,
                icon: TrendingUp,
                color: 'text-primary',
                bg: 'bg-primary/10',
              },
            ].map((s, i) => (
              <Card key={i} className="p-5 border-border shadow-subtle bg-card rounded-2xl">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-4 ${s.bg}`}
                >
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <p className="text-3xl font-bold text-primary">{s.value}</p>
                <p className="text-sm font-bold text-muted-foreground">{s.label}</p>
              </Card>
            ))}
          </div>

          {impact && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
                <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
                  <TrendingUp className="w-5 h-5 text-secondary" />
                </div>
                <p className="text-2xl md:text-3xl font-bold text-primary">
                  R$ {(impact.total_revenue_recovered || 0).toLocaleString('pt-BR')}
                </p>
                <p className="text-sm text-muted-foreground font-medium mt-1">Receita recuperada</p>
              </Card>
              <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                  <Leaf className="w-5 h-5 text-primary" />
                </div>
                <p className="text-2xl md:text-3xl font-bold text-primary">
                  {(impact.total_kg_saved || 0).toLocaleString('pt-BR')} kg
                </p>
                <p className="text-sm text-muted-foreground font-medium mt-1">Alimentos salvos</p>
              </Card>
              <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
                <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center mb-3">
                  <Droplets className="w-5 h-5 text-accent" />
                </div>
                <p className="text-2xl md:text-3xl font-bold text-primary">
                  {(impact.total_water_preserved || 0).toLocaleString('pt-BR')} L
                </p>
                <p className="text-sm text-muted-foreground font-medium mt-1">Água preservada</p>
              </Card>
              <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
                <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
                  <Utensils className="w-5 h-5 text-secondary" />
                </div>
                <p className="text-2xl md:text-3xl font-bold text-primary">
                  {impact.total_meals_generated || 0}
                </p>
                <p className="text-sm text-muted-foreground font-medium mt-1">Refeições geradas</p>
              </Card>
            </div>
          )}

          <Card className="p-6 md:p-8 rounded-[2rem] border-border shadow-sm mb-6">
            <h3 className="font-bold text-xl text-primary mb-1">Usuários por Perfil</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Distribuição de usuários na plataforma
            </p>
            <div className="h-64">
              <ChartContainer
                config={{ usuarios: { label: 'Usuários', color: 'hsl(var(--primary))' } }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis
                      dataKey="role"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontWeight: 600 }}
                    />
                    <YAxis
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="usuarios" fill="var(--color-usuarios)" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </Card>

          <Card className="p-6 rounded-[2rem] border-border shadow-sm">
            <h3 className="font-bold text-xl text-primary mb-4">Usuários Recentes</h3>
            <div className="space-y-3">
              {(stats?.recentUsers || []).map((u) => (
                <div key={u.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-xl">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold text-sm shrink-0">
                    {(u.name || '?').charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-primary truncate">
                      {u.name || 'Sem nome'}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                  </div>
                  <span className="text-xs font-bold bg-secondary/15 text-secondary px-2 py-1 rounded-lg shrink-0">
                    {ROLE_LABELS[u.role] || u.role || 'N/A'}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </>
      )}
    </div>
  )
}
