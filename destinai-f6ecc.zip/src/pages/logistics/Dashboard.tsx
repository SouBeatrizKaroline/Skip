import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Truck,
  MapPin,
  Clock,
  ArrowRight,
  Route as RouteIcon,
  PackageCheck,
  Star,
  Wallet,
  Package,
  TrendingUp,
  Navigation2,
} from 'lucide-react'
import { getOrders, toDisplayOrder, type DisplayOrder } from '@/services/products'
import { useRealtime } from '@/hooks/use-realtime'
import { ViviInsightPanel } from '@/components/ViviInsightPanel'
import { MOCK_ROUTES } from '@/lib/mock-data'

export default function LogisticsDashboard() {
  const [routes, setRoutes] = useState<DisplayOrder[]>([])
  const [allOrders, setAllOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = async () => {
    try {
      const data = await getOrders()
      setAllOrders(data)
      setRoutes(data.map(toDisplayOrder))
    } catch {
      setRoutes(MOCK_ROUTES)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])
  useRealtime('orders', () => {
    loadData()
  })
  useRealtime('matches', () => {
    loadData()
  })

  const availableLoads = allOrders.filter(
    (o) => o.status === 'PENDING' || o.status === 'WAITING_DRIVER',
  ).length
  const completed = allOrders.filter((o) => o.status === 'DELIVERED').length
  const earnings = allOrders
    .filter((o) => o.status === 'DELIVERED')
    .reduce((s, o) => s + (o.reward || 0), 0)
  const reputation = completed > 0 ? Math.min(99, 80 + completed * 2) : 80

  return (
    <div className="max-w-4xl mx-auto w-full animate-fade-in-up pb-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border border-primary/20">
          <RouteIcon className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1">Painel Logístico</h1>
          <p className="text-muted-foreground">Rotas otimizadas para coletas e entregas.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
        <Card className="p-4 bg-card border-border shadow-sm rounded-2xl text-center">
          <div className="w-9 h-9 bg-secondary/10 rounded-full flex items-center justify-center mb-2 mx-auto">
            <Package className="w-4 h-4 text-secondary" />
          </div>
          <p className="text-2xl font-bold text-primary">{availableLoads}</p>
          <p className="text-[10px] text-muted-foreground font-bold">Cargas disponíveis</p>
        </Card>
        <Card className="p-4 bg-card border-border shadow-sm rounded-2xl text-center">
          <div className="w-9 h-9 bg-primary/10 rounded-full flex items-center justify-center mb-2 mx-auto">
            <RouteIcon className="w-4 h-4 text-primary" />
          </div>
          <p className="text-2xl font-bold text-primary">{routes.length}</p>
          <p className="text-[10px] text-muted-foreground font-bold">Rotas ativas</p>
        </Card>
        <Card className="p-4 bg-card border-border shadow-sm rounded-2xl text-center">
          <div className="w-9 h-9 bg-accent/10 rounded-full flex items-center justify-center mb-2 mx-auto">
            <Wallet className="w-4 h-4 text-accent" />
          </div>
          <p className="text-2xl font-bold text-primary">R$ {earnings.toFixed(0)}</p>
          <p className="text-[10px] text-muted-foreground font-bold">Ganhos estimados</p>
        </Card>
        <Card className="p-4 bg-card border-border shadow-sm rounded-2xl text-center">
          <div className="w-9 h-9 bg-secondary/10 rounded-full flex items-center justify-center mb-2 mx-auto">
            <PackageCheck className="w-4 h-4 text-secondary" />
          </div>
          <p className="text-2xl font-bold text-primary">{completed}</p>
          <p className="text-[10px] text-muted-foreground font-bold">Entregas concluídas</p>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-primary to-primary/90 border-none shadow-elevation rounded-2xl text-center text-white">
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center mb-2 mx-auto">
            <Star className="w-4 h-4 text-white" />
          </div>
          <p className="text-2xl font-bold">{reputation}</p>
          <p className="text-[10px] text-white/80 font-bold">Reputação</p>
        </Card>
      </div>

      <ViviInsightPanel role="TRANSPORTER" />

      <div className="mb-3">
        <Link
          to="/transporter/opportunities"
          className="flex items-center justify-between p-4 bg-gradient-to-r from-secondary/10 to-transparent rounded-2xl border border-secondary/20 hover:shadow-elevation transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/15 rounded-xl flex items-center justify-center">
              <Navigation2 className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="font-bold text-primary">Oportunidades de Frete</p>
              <p className="text-xs text-muted-foreground">Cargas disponíveis agora</p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-secondary" />
        </Link>
      </div>

      <div className="mb-6">
        <Link
          to="/transporter/vehicles"
          className="flex items-center justify-between p-4 bg-card rounded-2xl border border-border shadow-sm hover:shadow-elevation transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
              <Truck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-bold text-primary">Gestão de Veículos</p>
              <p className="text-xs text-muted-foreground">Cadastre sua frota</p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-muted-foreground" />
        </Link>
      </div>

      <h2 className="font-bold text-xl text-primary mb-4 px-2">Suas Coletas</h2>
      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="p-5 rounded-[2rem] border-border">
              <div className="flex justify-between mb-4">
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-6 w-20" />
              </div>
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-2/3" />
            </Card>
          ))}
        </div>
      ) : routes.length === 0 ? (
        <div className="text-center py-20">
          <Truck className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Nenhuma rota disponível no momento.</p>
          <Link
            to="/transporter/opportunities"
            className="inline-block mt-4 px-6 py-3 bg-secondary text-white rounded-xl font-bold hover:bg-secondary/90 transition-colors"
          >
            Ver oportunidades de frete
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {routes.map((route) => (
            <Card
              key={route.id}
              className="p-1 border-border shadow-sm hover:shadow-elevation transition-all rounded-[2rem] bg-card group"
            >
              <div className="p-5 sm:p-6 pb-0">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <span
                      className={`inline-flex px-3 py-1 rounded-lg text-xs font-bold mb-3 ${route.status === 'Entregue' ? 'bg-primary/15 text-primary border border-primary/20' : route.status === 'Em transporte' ? 'bg-accent/15 text-accent border border-accent/20' : 'bg-secondary/15 text-secondary border border-secondary/20'}`}
                    >
                      {route.status}
                    </span>
                    <p className="text-sm font-bold text-muted-foreground flex items-center gap-1.5">
                      <Clock className="w-4 h-4" /> {route.date}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground font-bold mb-1">Pagamento</p>
                    <p className="font-bold text-primary text-xl">{route.reward}</p>
                  </div>
                </div>
                <div className="relative pl-8 pb-6 border-l-2 border-dashed border-border ml-3 space-y-4">
                  <div className="absolute w-6 h-6 bg-card border-4 border-secondary rounded-full -left-[14px] top-0 shadow-sm"></div>
                  <div>
                    <p className="font-bold text-base text-primary mb-1">
                      {route.title.replace('Coleta: ', '')}
                    </p>
                    <p className="text-sm text-muted-foreground bg-muted inline-block px-2 py-1 rounded-md font-medium">
                      Carga: {route.load}
                    </p>
                  </div>
                </div>
                <div className="relative pl-8 ml-3 pb-6">
                  <div className="absolute w-6 h-6 bg-primary border-4 border-card rounded-full -left-[14px] top-0 shadow-sm flex items-center justify-center">
                    <MapPin className="w-2.5 h-2.5 text-white" />
                  </div>
                  <p className="font-bold text-base text-primary">
                    {route.dest.replace('Entrega: ', '')}
                  </p>
                </div>
              </div>
              <div className="bg-muted p-2 rounded-b-[1.8rem] m-1 mt-0 text-center">
                <Link
                  to={`/logistics/route/${route.id}`}
                  className="w-full flex items-center justify-center py-3 text-sm font-bold text-primary hover:text-secondary transition-colors"
                >
                  Iniciar navegação <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
