import { useParams, useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  ArrowLeft,
  Navigation,
  CheckCircle2,
  Package,
  MapPin,
  Truck,
  Loader2,
  Route as RouteIcon,
  Clock,
} from 'lucide-react'
import { MOCK_ROUTES } from '@/lib/mock-data'
import { useToast } from '@/hooks/use-toast'
import { useState, useEffect } from 'react'
import pb from '@/lib/pocketbase/client'
import { getOrder, toDisplayOrder, ORDER_STATUS_LABELS } from '@/services/products'
import { getRoute } from '@/services/api'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'

const FLOW = ['PENDING', 'ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED']
const BTN_TEXTS = [
  'Aceitar Coleta',
  'Confirmar Coleta na Origem',
  'Iniciar Entrega',
  'Confirmar Entrega no Destino',
  'Rota Finalizada',
]

export default function RouteDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()
  const { user } = useAuth()
  const [statusIdx, setStatusIdx] = useState(0)
  const [route, setRoute] = useState<any>(MOCK_ROUTES.find((r) => r.id === id) || MOCK_ROUTES[0])
  const [loading, setLoading] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [rawOrder, setRawOrder] = useState<any>(null)
  const [routeInfo, setRouteInfo] = useState<{ distance_km: number; eta_text: string } | null>(null)

  const loadRoute = () => {
    if (id && !id.startsWith('125')) {
      getOrder(id)
        .then((o) => {
          setRawOrder(o)
          setRoute(toDisplayOrder(o))
          setOrderId(o.id)
          setStatusIdx(Math.max(0, FLOW.indexOf(o.status)))
          const match = o.expand?.match_id
          const product = match?.expand?.product_id
          const buyer = match?.expand?.buyer_id
          if (product?.latitude && product?.longitude && buyer?.latitude && buyer?.longitude) {
            getRoute(product.latitude, product.longitude, buyer.latitude, buyer.longitude)
              .then((r: any) => setRouteInfo(r))
              .catch(() => {})
          }
        })
        .catch(() => {})
    }
  }

  useEffect(() => {
    loadRoute()
  }, [id])

  useRealtime('orders', (e) => {
    if (e.record.id === orderId) loadRoute()
  })

  const handleUpdate = async () => {
    if (statusIdx >= 4) return
    setLoading(true)
    const nextStatus = FLOW[statusIdx + 1]
    try {
      if (orderId) {
        const data: Record<string, any> = { status: nextStatus }
        if (statusIdx === 0 && user) {
          try {
            const tp = await pb
              .collection('transporter_profiles')
              .getFirstListItem(`user_id="${user.id}"`)
            data.transporter_id = tp.id
          } catch {
            /* intentionally ignored */
          }
        }
        await pb.collection('orders').update(orderId, data)
      }
      setStatusIdx((s) => s + 1)
      toast({
        title: 'Status atualizado',
        description: `Novo status: ${ORDER_STATUS_LABELS[nextStatus] || nextStatus}`,
      })
    } catch {
      toast({ title: 'Erro', description: 'Não foi possível atualizar o status.' })
    } finally {
      setLoading(false)
    }
  }

  const steps = [
    {
      title: 'Pedido confirmado',
      desc: 'Aguardando transportador',
      icon: CheckCircle2,
      done: true,
    },
    {
      title: 'Coleta: ' + (route.title || '').replace('Coleta: ', ''),
      desc: 'Retirada da carga',
      icon: Package,
      done: statusIdx >= 2,
    },
    { title: 'Em trânsito', desc: 'A caminho do destino', icon: Truck, done: statusIdx >= 3 },
    {
      title: 'Entrega: ' + (route.dest || '').replace('Entrega: ', ''),
      desc: 'Destino final',
      icon: MapPin,
      done: statusIdx >= 4,
    },
  ]

  const pickupAddr = rawOrder?.pickup_address || (route.title || '').replace('Coleta: ', '')
  const deliveryAddr = rawOrder?.delivery_address || (route.dest || '').replace('Entrega: ', '')
  const mapUrl = `https://maps.google.com/maps?saddr=${encodeURIComponent(pickupAddr)}&daddr=${encodeURIComponent(deliveryAddr)}&output=embed`
  const progress = Math.max(0, (statusIdx / 4) * 100)

  return (
    <div className="max-w-2xl mx-auto w-full animate-fade-in-up pb-28">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-sm font-bold text-muted-foreground hover:text-primary transition-colors bg-card w-10 h-10 justify-center rounded-full shadow-sm"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="bg-muted px-4 py-1.5 rounded-full text-sm font-bold text-primary">
          Rota #{route.id}
        </div>
      </div>

      <div className="relative h-72 md:h-80 rounded-[2.5rem] overflow-hidden shadow-elevation mb-8 border-4 border-card bg-muted">
        <iframe
          src={mapUrl}
          className="w-full h-full border-0"
          loading="lazy"
          title="Mapa da rota"
          referrerPolicy="no-referrer-when-downgrade"
        />
        <div className="absolute top-4 left-4 right-4 bg-white/90 backdrop-blur p-4 rounded-2xl shadow-sm flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-xl">
            <Navigation className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-muted-foreground">Próximo destino</p>
            <p className="text-sm font-bold text-primary truncate">
              {statusIdx < 2 ? pickupAddr : deliveryAddr}
            </p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs font-bold text-muted-foreground">Progresso</p>
            <p className="text-sm font-bold text-secondary">{Math.round(progress)}%</p>
          </div>
        </div>
      </div>

      <Card className="p-8 mb-6 rounded-[2rem] border-none shadow-elevation bg-card">
        <h2 className="text-xl font-bold text-primary mb-8">Status da Entrega</h2>
        <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px before:h-full before:w-1 before:bg-muted before:z-0">
          {steps.map((step, i) => (
            <div key={i} className="relative z-10 flex items-start gap-5">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border-4 shadow-sm transition-all duration-300 ${step.done ? 'bg-secondary border-card text-white scale-110' : 'bg-card border-muted text-muted-foreground'}`}
              >
                <step.icon className="w-4 h-4" />
              </div>
              <div className="pt-1">
                <p
                  className={`font-bold text-base transition-colors ${step.done ? 'text-primary' : 'text-muted-foreground'}`}
                >
                  {step.title}
                </p>
                <p className="text-sm text-muted-foreground font-medium mt-0.5">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="p-5 rounded-2xl border-none shadow-sm bg-muted/50">
          <p className="text-xs font-bold text-muted-foreground mb-1">Carga a transportar</p>
          <p className="font-bold text-primary text-base">{route.load}</p>
        </Card>
        <Card className="p-5 rounded-2xl border-none shadow-sm bg-muted/50">
          <p className="text-xs font-bold text-muted-foreground mb-1">Valor do frete</p>
          <p className="font-bold text-accent text-lg">{route.reward}</p>
        </Card>
      </div>

      {routeInfo && (
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="p-5 rounded-2xl border-none shadow-sm bg-secondary/5">
            <div className="flex items-center gap-2 mb-1">
              <RouteIcon className="w-4 h-4 text-secondary" />
              <p className="text-xs font-bold text-muted-foreground">Distância</p>
            </div>
            <p className="font-bold text-primary text-lg">{routeInfo.distance_km} km</p>
          </Card>
          <Card className="p-5 rounded-2xl border-none shadow-sm bg-accent/5">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-accent" />
              <p className="text-xs font-bold text-muted-foreground">ETA</p>
            </div>
            <p className="font-bold text-primary text-lg">{routeInfo.eta_text}</p>
          </Card>
        </div>
      )}

      <div className="fixed bottom-0 md:bottom-auto md:relative inset-x-0 p-4 md:p-0 bg-card/95 backdrop-blur md:bg-transparent border-t md:border-none border-border z-10 pb-[calc(1rem+env(safe-area-inset-bottom))] md:pb-0 shadow-[0_-10px_30px_rgba(0,0,0,0.05)] md:shadow-none">
        <Button
          size="lg"
          disabled={statusIdx >= 4 || loading}
          onClick={handleUpdate}
          className={`w-full h-16 text-lg font-bold rounded-2xl shadow-elevation transition-all ${statusIdx >= 4 ? 'bg-muted text-muted-foreground' : 'bg-primary text-white hover:scale-[1.01]'}`}
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : BTN_TEXTS[statusIdx]}
        </Button>
      </div>
    </div>
  )
}
