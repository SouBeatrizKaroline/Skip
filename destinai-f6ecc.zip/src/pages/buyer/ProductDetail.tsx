import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  ChevronLeft,
  MapPin,
  Package,
  Calendar,
  Loader2,
  Handshake,
  Leaf,
  TrendingUp,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import { useRealtime } from '@/hooks/use-realtime'
import {
  getProduct,
  getProductImage,
  VISUAL_CONDITION_LABELS,
  WASTE_RISK_LABELS,
  formatDate,
  formatPrice,
} from '@/services/products'
import { getBuyerProfile } from '@/services/buyer'
import { createMatch } from '@/services/matches'
import { AiInsightCard } from '@/components/AiInsightCard'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { SmartScoreBadge } from '@/components/SmartScoreBadge'
import pb from '@/lib/pocketbase/client'

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast } = useToast()
  const [product, setProduct] = useState<any>(null)
  const [aiAnalysis, setAiAnalysis] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [buyerId, setBuyerId] = useState('')
  const [proposing, setProposing] = useState(false)
  const [showProposal, setShowProposal] = useState(false)
  const [offeredPrice, setOfferedPrice] = useState(0)

  useEffect(() => {
    if (user) {
      getBuyerProfile(user.id)
        .then((p) => setBuyerId(p.id))
        .catch(() => {})
    }
  }, [user])

  const loadProduct = async () => {
    if (!id) return
    try {
      const p = await getProduct(id)
      setProduct(p)
      setOfferedPrice(p.price_per_kg || 0)
      try {
        const ai = await pb.collection('ai_analysis').getFirstListItem(`product_id="${id}"`)
        setAiAnalysis(ai)
      } catch {
        setAiAnalysis(null)
      }
    } catch {
      toast({ title: 'Erro', description: 'Produto não encontrado.', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadProduct()
  }, [id])

  useRealtime('products', (e) => {
    if (e.record.id === id) loadProduct()
  })
  useRealtime('ai_analysis', () => {
    if (id) loadProduct()
  })

  const handleProposal = async () => {
    if (!product || !buyerId) {
      toast({
        title: 'Erro',
        description: 'Perfil de comprador não encontrado.',
        variant: 'destructive',
      })
      return
    }
    setProposing(true)
    try {
      await createMatch({
        product_id: product.id,
        buyer_id: buyerId,
        producer_id: product.producer_id,
        price_agreed: offeredPrice,
      })
      toast({
        title: 'Proposta enviada! ✅',
        description: 'O produtor foi notificado da sua proposta.',
      })
      setShowProposal(false)
      navigate('/buyer')
    } catch {
      toast({
        title: 'Erro',
        description: 'Não foi possível enviar a proposta.',
        variant: 'destructive',
      })
    } finally {
      setProposing(false)
    }
  }

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto w-full space-y-4 animate-fade-in-up pb-12">
        <Skeleton className="h-10 w-32 rounded-full" />
        <Skeleton className="h-64 w-full rounded-3xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    )
  }

  if (!product) {
    return (
      <div className="max-w-2xl mx-auto w-full text-center py-20 animate-fade-in-up">
        <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
        <p className="text-muted-foreground">Produto não encontrado.</p>
        <Button onClick={() => navigate('/buyer')} className="mt-4">
          Voltar
        </Button>
      </div>
    )
  }

  const producer = product.expand?.producer_id
  const isAvailable = product.status === 'AVAILABLE'

  return (
    <div className="max-w-2xl mx-auto w-full animate-fade-in-up pb-12">
      <button
        onClick={() => navigate('/buyer')}
        className="flex items-center text-sm font-bold text-muted-foreground hover:text-primary transition-colors bg-card p-2 rounded-full shadow-sm mb-6"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <div className="relative rounded-3xl overflow-hidden mb-6 shadow-elevation">
        <img
          src={getProductImage(product.name)}
          alt={product.name}
          className="w-full h-56 object-cover"
        />
        <div className="absolute top-4 right-4 flex gap-2">
          {product.waste_risk_level && (
            <WasteRiskBadge level={product.waste_risk_level} size="sm" />
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <h1 className="text-3xl font-bold text-primary">{product.name}</h1>
          <p className="text-muted-foreground text-lg mt-1">{formatPrice(product.price_per_kg)}</p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Card className="p-4 rounded-2xl border-border text-center">
            <Package className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary">{product.quantity_kg} kg</p>
            <p className="text-xs text-muted-foreground">Quantidade</p>
          </Card>
          <Card className="p-4 rounded-2xl border-border text-center">
            <Calendar className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary text-sm">{formatDate(product.harvest_date)}</p>
            <p className="text-xs text-muted-foreground">Colheita</p>
          </Card>
          <Card className="p-4 rounded-2xl border-border text-center">
            <MapPin className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="font-bold text-primary text-sm">{product.city || 'N/A'}</p>
            <p className="text-xs text-muted-foreground">Localização</p>
          </Card>
        </div>

        <Card className="p-5 rounded-2xl border-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-bold text-primary">{producer?.farm_name || 'Produtor'}</p>
              <p className="text-xs text-muted-foreground">
                {producer?.city || ''}
                {producer?.state ? ', ' + producer.state : ''}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-secondary/15 text-secondary border-none">
              {VISUAL_CONDITION_LABELS[product.visual_condition] || 'N/A'}
            </Badge>
            {product.maturation_stage && (
              <Badge className="bg-primary/10 text-primary border-none">
                Maturação: {product.maturation_stage}
              </Badge>
            )}
          </div>
        </Card>

        {aiAnalysis && (
          <Card className="p-5 rounded-2xl border-border">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-accent" />
              <h3 className="font-bold text-primary">Análise da IA</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-muted p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Qualidade</p>
                <p className="font-bold text-primary text-lg">
                  {aiAnalysis.quality_score || 'N/A'}/100
                </p>
              </div>
              <div className="bg-muted p-3 rounded-xl">
                <p className="text-xs text-muted-foreground">Validade estimada</p>
                <p className="font-bold text-primary text-lg">
                  {aiAnalysis.shelf_life_days || 'N/A'} dias
                </p>
              </div>
            </div>
            {aiAnalysis.recommended_use && (
              <p className="text-sm text-muted-foreground mt-3">
                <span className="font-bold">Uso recomendado:</span> {aiAnalysis.recommended_use}
              </p>
            )}
          </Card>
        )}

        <AiInsightCard visualCondition={product.visual_condition} />

        {product.recommended_price_range && (
          <Card className="p-4 rounded-2xl border-secondary/20 bg-secondary/5">
            <p className="text-sm font-bold text-secondary">Faixa de preço recomendada</p>
            <p className="text-sm text-muted-foreground mt-1">{product.recommended_price_range}</p>
          </Card>
        )}

        {showProposal && (
          <Card className="p-5 rounded-2xl border-accent/20 animate-fade-in-up">
            <h3 className="font-bold text-primary mb-4">Fazer Proposta</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-primary font-bold">Preço oferecido por kg (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={offeredPrice}
                  onChange={(e) => setOfferedPrice(Number(e.target.value))}
                  className="bg-muted border-none h-12"
                />
              </div>
              <div className="bg-muted p-3 rounded-xl">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total estimado</span>
                  <span className="font-bold text-primary">
                    R$ {(offeredPrice * (product.quantity_kg || 0)).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowProposal(false)}
                  className="flex-1 h-12 rounded-xl"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleProposal}
                  disabled={proposing}
                  className="flex-1 h-12 rounded-xl bg-secondary text-white hover:bg-secondary/90"
                >
                  {proposing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Enviando...
                    </>
                  ) : (
                    <>
                      <Handshake className="w-4 h-4 mr-2" /> Enviar Proposta
                    </>
                  )}
                </Button>
              </div>
            </div>
          </Card>
        )}

        {!showProposal && isAvailable && (
          <Button
            onClick={() => setShowProposal(true)}
            className="w-full h-14 rounded-2xl text-lg font-bold shadow-elevation"
          >
            <Handshake className="w-5 h-5 mr-2" /> Fazer Proposta
          </Button>
        )}

        {!isAvailable && (
          <Card className="p-5 rounded-2xl border-border bg-muted/50 text-center">
            <p className="text-muted-foreground font-medium">
              Este produto não está mais disponível para propostas.
            </p>
            <Badge className="mt-2 bg-primary/10 text-primary border-none">
              Status: {product.status}
            </Badge>
          </Card>
        )}
      </div>
    </div>
  )
}
