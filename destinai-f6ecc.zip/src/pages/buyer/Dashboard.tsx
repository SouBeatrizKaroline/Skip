import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Store, Package, TrendingUp, Search, Handshake } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import { getBuyerProfile, getBuyerMatches } from '@/services/buyer'
import {
  getAvailableProducts,
  getProductImage,
  VISUAL_CONDITION_LABELS,
  formatPrice,
  WASTE_RISK_LABELS,
} from '@/services/products'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { ViviInsightPanel } from '@/components/ViviInsightPanel'
import { HotMatchesFeed } from '@/components/HotMatchesFeed'
import { FinancialImpactCard } from '@/components/FinancialImpactCard'
import { AchievementsGallery } from '@/components/AchievementsGallery'
import { ReferralCard } from '@/components/ReferralCard'
import pb from '@/lib/pocketbase/client'

export default function BuyerDashboard() {
  const { user } = useAuth()
  const [products, setProducts] = useState<any[]>([])
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [buyerId, setBuyerId] = useState('')
  const [impact, setImpact] = useState({
    kg_saved: 0,
    co2_saved_kg: 0,
    revenue_recovered: 0,
    water_preserved_liters: 0,
    meals_generated: 0,
  })
  const [search, setSearch] = useState('')

  const loadData = useCallback(async () => {
    try {
      const prods = await getAvailableProducts()
      setProducts(prods)
    } catch {
      setProducts([])
    }
  }, [])

  const loadMatches = useCallback(async () => {
    if (!buyerId) return
    try {
      const data = await getBuyerMatches(buyerId)
      setMatches(data)
    } catch {
      setMatches([])
    }
  }, [buyerId])

  const loadImpact = async () => {
    if (!user) return
    try {
      const list = await pb.collection('impact_metrics').getFullList({
        filter: `user_id="${user.id}"`,
      })
      setImpact({
        kg_saved: list.reduce((a, b) => a + (b.kg_saved || 0), 0),
        co2_saved_kg: list.reduce((a, b) => a + (b.co2_saved_kg || 0), 0),
        revenue_recovered: list.reduce((a, b) => a + (b.revenue_recovered || 0), 0),
        water_preserved_liters: list.reduce((a, b) => a + (b.water_preserved_liters || 0), 0),
        meals_generated: list.reduce((a, b) => a + (b.meals_generated || 0), 0),
      })
    } catch {
      /* keep defaults */
    }
  }

  useEffect(() => {
    if (user) {
      getBuyerProfile(user.id)
        .then((p) => setBuyerId(p.id))
        .catch(() => setLoading(false))
    } else {
      setLoading(false)
    }
    loadImpact()
  }, [user])

  useEffect(() => {
    loadData()
    if (buyerId) loadMatches()
  }, [loadData, loadMatches, buyerId])

  useRealtime('products', () => loadData())
  useRealtime('matches', () => {
    if (buyerId) loadMatches()
  })
  useRealtime('impact_metrics', () => loadImpact())

  const filtered = products.filter(
    (p) =>
      !search ||
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.city?.toLowerCase().includes(search.toLowerCase()),
  )

  const displayName = user?.name || user?.email?.split('@')[0] || 'Comprador'
  const pendingMatches = matches.filter((m) => m.status === 'PENDING').length

  if (loading && products.length === 0) {
    return (
      <div className="space-y-4 max-w-5xl mx-auto w-full animate-fade-in-up pb-8">
        <Skeleton className="h-10 w-64 rounded-xl" />
        <Skeleton className="h-32 w-full rounded-3xl" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
        <Skeleton className="h-96 w-full rounded-3xl" />
      </div>
    )
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto w-full animate-fade-in-up pb-8">
      <div>
        <h1 className="text-3xl font-bold text-primary">Olá, {displayName}! 🛒</h1>
        <p className="text-muted-foreground mt-1 text-lg">
          {pendingMatches > 0
            ? `Você tem ${pendingMatches} proposta(s) pendente(s).`
            : 'Encontre os melhores produtos para seu negócio.'}
        </p>
      </div>

      <div className="flex flex-col sm:flex-row items-center sm:items-stretch gap-6 bg-card p-6 rounded-[2rem] shadow-elevation border border-border relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
        <div className="w-24 h-24 bg-gradient-to-br from-primary/40 to-primary/10 rounded-full flex items-center justify-center shrink-0 border-4 border-card shadow-sm">
          <Store className="w-12 h-12 text-primary" />
        </div>
        <div className="flex-1 text-center sm:text-left flex flex-col justify-center">
          <h2 className="text-xl font-bold text-primary mb-2">Ofertas Disponíveis</h2>
          <p className="text-muted-foreground mb-4 max-w-md">
            {products.length} produtos disponíveis de produtores rurais perto de você.
          </p>
          <Button
            className="rounded-full self-center sm:self-start bg-primary text-white hover:bg-primary/90 shadow-md font-bold px-6"
            asChild
          >
            <Link to="/opportunities">Ver todas as oportunidades</Link>
          </Button>
        </div>
      </div>

      <ViviInsightPanel role="BUYER" buyerId={buyerId} />

      <HotMatchesFeed />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mb-3">
            <Package className="w-5 h-5 text-primary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">{products.length}</p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Disponíveis</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center mb-3">
            <Handshake className="w-5 h-5 text-accent" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">{pendingMatches}</p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Propostas ativas</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">
            R$ {(impact.revenue_recovered || 0).toFixed(0)}
          </p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Receita recuperada</p>
        </Card>
        <Card className="p-5 border-border shadow-subtle bg-card rounded-2xl">
          <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mb-3">
            <Package className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-2xl md:text-3xl font-bold text-primary">{impact.kg_saved || 0} kg</p>
          <p className="text-sm text-muted-foreground font-medium mt-1">Alimentos salvos</p>
        </Card>
      </div>

      <FinancialImpactCard metrics={impact} />

      {matches.length > 0 && (
        <div>
          <h3 className="font-bold text-xl text-primary mb-4">Minhas Propostas</h3>
          <div className="space-y-3">
            {matches.slice(0, 5).map((m) => {
              const product = m.expand?.product_id
              const producer = m.expand?.producer_id
              return (
                <Card key={m.id} className="p-4 rounded-2xl border-border flex items-center gap-4">
                  <img
                    src={getProductImage(product?.name || '')}
                    alt=""
                    loading="lazy"
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-primary truncate">{product?.name || 'Produto'}</p>
                    <p className="text-sm text-muted-foreground">
                      {product?.quantity_kg || 0} kg • {producer?.farm_name || 'Produtor'}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-accent">
                      R$ {(m.price_agreed || 0).toFixed(2).replace('.', ',')}
                    </p>
                    <Badge
                      className={`mt-1 border-none ${
                        m.status === 'PENDING'
                          ? 'bg-accent/15 text-accent'
                          : m.status === 'CONFIRMED'
                            ? 'bg-secondary/15 text-secondary'
                            : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {m.status === 'PENDING'
                        ? 'Aguardando'
                        : m.status === 'CONFIRMED'
                          ? 'Confirmado'
                          : m.status}
                    </Badge>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      )}

      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-xl text-primary">Produtos Disponíveis</h3>
        </div>
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar por produto ou cidade..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-card border border-border rounded-full h-12 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">
              {search ? 'Nenhum produto encontrado.' : 'Nenhum produto disponível no momento.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.slice(0, 10).map((prod) => (
              <Link to={`/buyer/product/${prod.id}`} key={prod.id}>
                <Card className="p-4 rounded-2xl border-border hover:shadow-elevation transition-all flex items-center gap-4">
                  <img
                    src={getProductImage(prod.name)}
                    alt={prod.name}
                    loading="lazy"
                    className="w-20 h-20 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-primary text-lg truncate">{prod.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {prod.quantity_kg} kg • {prod.city || 'N/A'}
                    </p>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className="text-xs bg-secondary/15 text-secondary px-2 py-1 rounded-full font-bold">
                        {VISUAL_CONDITION_LABELS[prod.visual_condition] || ''}
                      </span>
                      {prod.waste_risk_level && (
                        <WasteRiskBadge level={prod.waste_risk_level} size="sm" />
                      )}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-accent">{formatPrice(prod.price_per_kg)}</p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      <AchievementsGallery />
      <ReferralCard user={user} />
    </div>
  )
}
