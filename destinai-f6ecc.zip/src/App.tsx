import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { ErrorBoundary } from '@/components/ErrorBoundary'

import Layout from './components/Layout'
import Index from './pages/Index'
import NotFound from './pages/NotFound'
import Login from './pages/Login'
import Onboarding from './pages/Onboarding'
import ProducerDashboard from './pages/producer/Dashboard'
import NewSurplus from './pages/producer/NewSurplus'
import Analysis from './pages/producer/Analysis'
import Destinations from './pages/producer/Destinations'
import Negotiations from './pages/producer/Negotiations'
import ProducerProducts from './pages/producer/Products'
import ProducerProductDetail from './pages/producer/ProductDetail'
import BuyerDashboard from './pages/buyer/Dashboard'
import ProductDetail from './pages/buyer/ProductDetail'
import LogisticsDashboard from './pages/logistics/Dashboard'
import RouteDetail from './pages/logistics/RouteDetail'
import Impact from './pages/Impact'
import AdminDashboard from './pages/admin/Dashboard'
import ForgotPassword from './pages/ForgotPassword'
import HarvestIntelligence from './pages/HarvestIntelligence'
import Opportunities from './pages/Opportunities'
import AiDestination from './pages/AiDestination'
import Vehicles from './pages/transporter/Vehicles'
import TransporterOpportunities from './pages/transporter/Opportunities'
import CreditHub from './pages/CreditHub'
import Monetization from './pages/Monetization'
import IntelligenceMapPage from './pages/IntelligenceMapPage'
import Ranking from './pages/Ranking'
import { AlertCenter } from '@/components/AlertCenter'

const App = () => (
  <ErrorBoundary>
    <BrowserRouter>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <AlertCenter />
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/onboarding" element={<Onboarding />} />
              <Route element={<ProtectedRoute />}>
                <Route path="/impact" element={<Impact />} />
                <Route path="/harvest-intelligence" element={<HarvestIntelligence />} />
                <Route path="/opportunities" element={<Opportunities />} />
                <Route path="/ai-destination" element={<AiDestination />} />
                <Route path="/credit" element={<CreditHub />} />
                <Route path="/intelligence-map" element={<IntelligenceMapPage />} />
                <Route path="/ranking" element={<Ranking />} />
              </Route>
              <Route element={<ProtectedRoute allowedRoles={['PRODUCER']} />}>
                <Route path="/dashboard/produtor" element={<ProducerDashboard />} />
                <Route path="/dashboard/produtor/new-surplus" element={<NewSurplus />} />
                <Route path="/dashboard/produtor/analysis" element={<Analysis />} />
                <Route path="/dashboard/produtor/destinations" element={<Destinations />} />
                <Route path="/producer" element={<ProducerDashboard />} />
                <Route path="/producer/new-surplus" element={<NewSurplus />} />
                <Route path="/producer/analysis" element={<Analysis />} />
                <Route path="/producer/destinations" element={<Destinations />} />
                <Route path="/producer/negotiations" element={<Negotiations />} />
                <Route path="/dashboard/produtor/produtos" element={<ProducerProducts />} />
                <Route
                  path="/dashboard/produtor/produtos/:id"
                  element={<ProducerProductDetail />}
                />
                <Route path="/producer/produtos" element={<ProducerProducts />} />
                <Route path="/producer/produtos/:id" element={<ProducerProductDetail />} />
              </Route>
              <Route element={<ProtectedRoute allowedRoles={['BUYER']} />}>
                <Route path="/dashboard/comprador" element={<BuyerDashboard />} />
                <Route path="/dashboard/comprador/product/:id" element={<ProductDetail />} />
                <Route path="/buyer" element={<BuyerDashboard />} />
                <Route path="/buyer/product/:id" element={<ProductDetail />} />
              </Route>
              <Route element={<ProtectedRoute allowedRoles={['TRANSPORTER']} />}>
                <Route path="/dashboard/transportador" element={<LogisticsDashboard />} />
                <Route path="/dashboard/transportador/route/:id" element={<RouteDetail />} />
                <Route path="/logistics" element={<LogisticsDashboard />} />
                <Route path="/logistics/route/:id" element={<RouteDetail />} />
                <Route path="/transporter/vehicles" element={<Vehicles />} />
                <Route path="/transporter/opportunities" element={<TransporterOpportunities />} />
              </Route>
              <Route element={<ProtectedRoute allowedRoles={['ADMIN']} />}>
                <Route path="/dashboard/admin" element={<AdminDashboard />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/monetization" element={<Monetization />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </TooltipProvider>
      </AuthProvider>
    </BrowserRouter>
  </ErrorBoundary>
)

export default App
