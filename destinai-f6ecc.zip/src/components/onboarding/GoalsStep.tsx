import { Leaf, DollarSign, Cloud, Truck, Handshake, Check } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import type { StepProps } from '@/services/onboarding'

const GOAL_OPTIONS = [
  { type: 'KG_SAVED', label: 'Reduzir desperdício', unit: 'kg', defaultTarget: 500, icon: Leaf },
  { type: 'REVENUE', label: 'Aumentar receita', unit: 'R$', defaultTarget: 5000, icon: DollarSign },
  { type: 'CO2_SAVED', label: 'Reduzir emissões CO₂', unit: 'kg', defaultTarget: 200, icon: Cloud },
  { type: 'DELIVERIES', label: 'Entregas realizadas', unit: '', defaultTarget: 20, icon: Truck },
  { type: 'MATCHES', label: 'Matches feitos', unit: '', defaultTarget: 10, icon: Handshake },
]

export function GoalsStep({ data, update }: StepProps) {
  const toggleGoal = (type: string, defaultTarget: number) => {
    const current = data.goals[type] || { selected: false, target: defaultTarget }
    update('goals', { ...data.goals, [type]: { ...current, selected: !current.selected } })
  }

  const updateTarget = (type: string, target: number) => {
    const current = data.goals[type] || { selected: false, target: 0 }
    update('goals', { ...data.goals, [type]: { ...current, target } })
  }

  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-primary mb-1">Seus objetivos</h2>
        <p className="text-muted-foreground text-sm">
          Selecione pelo menos um para personalizar sua experiência com a Vivi.
        </p>
      </div>
      <div className="space-y-3">
        {GOAL_OPTIONS.map((goal) => {
          const state = data.goals[goal.type] || { selected: false, target: goal.defaultTarget }
          return (
            <Card
              key={goal.type}
              className={cn(
                'p-4 cursor-pointer transition-all',
                state.selected
                  ? 'border-secondary border-2 bg-secondary/5'
                  : 'hover:border-secondary/50',
              )}
              onClick={() => toggleGoal(goal.type, goal.defaultTarget)}
            >
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                    state.selected
                      ? 'bg-secondary text-secondary-foreground'
                      : 'bg-primary/5 text-primary',
                  )}
                >
                  {state.selected ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <goal.icon className="w-5 h-5" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-primary text-sm">{goal.label}</p>
                </div>
                {state.selected && (
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    {goal.unit && (
                      <span className="text-sm text-muted-foreground">{goal.unit}</span>
                    )}
                    <Input
                      type="number"
                      value={state.target}
                      onChange={(e) => updateTarget(goal.type, Number(e.target.value))}
                      className="w-24 h-9 bg-muted border-none"
                    />
                  </div>
                )}
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
