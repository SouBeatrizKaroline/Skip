import { Sprout, Store, Truck } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import type { StepProps } from '@/services/onboarding'

const ROLES = [
  {
    role: 'PRODUCER',
    icon: Sprout,
    title: 'Sou produtor',
    desc: 'Tenho excedentes para cadastrar e gerar mais valor.',
  },
  {
    role: 'BUYER',
    icon: Store,
    title: 'Sou comprador',
    desc: 'Quero comprar alimentos de qualidade com melhor custo.',
  },
  {
    role: 'TRANSPORTER',
    icon: Truck,
    title: 'Sou transportador',
    desc: 'Quero realizar coletas inteligentes e sustentáveis.',
  },
]

export function RoleStep({ data, update }: StepProps) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">
          Como você participa dessa cadeia?
        </h2>
        <p className="text-muted-foreground">Selecione o seu perfil para continuarmos.</p>
      </div>
      <div className="grid sm:grid-cols-3 gap-4">
        {ROLES.map((item) => (
          <Card
            key={item.role}
            className={cn(
              'p-6 cursor-pointer transition-all flex flex-col items-center text-center gap-4 group',
              data.role === item.role
                ? 'border-secondary border-2 shadow-elevation bg-secondary/5'
                : 'hover:border-secondary hover:shadow-elevation',
            )}
            onClick={() => update('role', item.role)}
          >
            <div
              className={cn(
                'w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300',
                data.role === item.role
                  ? 'bg-secondary text-secondary-foreground scale-110'
                  : 'bg-primary/5 text-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110',
              )}
            >
              <item.icon className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-1 text-primary">{item.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
