import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { formatPhone } from '@/lib/formatters'
import type { StepProps } from '@/services/onboarding'

export function ProfileStep({ data, update }: StepProps) {
  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-primary mb-1">Detalhes do seu perfil</h2>
        <p className="text-muted-foreground text-sm">Informe os dados do seu negócio.</p>
      </div>

      {data.role === 'BUYER' && (
        <div>
          <Label className="text-primary font-bold text-sm">Tipo de comprador</Label>
          <Select value={data.buyer_type} onValueChange={(v) => update('buyer_type', v)}>
            <SelectTrigger className="bg-muted border-none h-12 mt-1">
              <SelectValue placeholder="Selecione o tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="RESTAURANT">Restaurante</SelectItem>
              <SelectItem value="INDUSTRY">Indústria</SelectItem>
              <SelectItem value="FOOD_BANK">Banco de alimentos</SelectItem>
              <SelectItem value="MARKET">Mercado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {data.role === 'TRANSPORTER' && (
        <>
          <div>
            <Label className="text-primary font-bold text-sm">Tipo de veículo</Label>
            <Select value={data.vehicle_type} onValueChange={(v) => update('vehicle_type', v)}>
              <SelectTrigger className="bg-muted border-none h-12 mt-1">
                <SelectValue placeholder="Selecione o veículo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TRUCK">Caminhão</SelectItem>
                <SelectItem value="VAN">Van</SelectItem>
                <SelectItem value="CAR">Carro</SelectItem>
                <SelectItem value="MOTORCYCLE">Moto</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-primary font-bold text-sm">Capacidade máxima (kg)</Label>
            <Input
              type="number"
              value={data.max_capacity_kg}
              onChange={(e) => update('max_capacity_kg', e.target.value)}
              placeholder="Ex: 5000"
              className="bg-muted border-none h-12 mt-1"
            />
          </div>
        </>
      )}

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-primary font-bold text-sm">Cidade</Label>
          <Input
            value={data.city}
            onChange={(e) => update('city', e.target.value)}
            placeholder="Ex: Holambra"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
        <div>
          <Label className="text-primary font-bold text-sm">Estado</Label>
          <Input
            value={data.state}
            onChange={(e) => update('state', e.target.value.toUpperCase())}
            placeholder="Ex: SP"
            maxLength={2}
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
      </div>

      <div>
        <Label className="text-primary font-bold text-sm">Telefone / WhatsApp</Label>
        <Input
          value={data.phone}
          onChange={(e) => update('phone', formatPhone(e.target.value))}
          placeholder="(11) 99999-9999"
          className="bg-muted border-none h-12 mt-1"
        />
      </div>

      {data.role === 'BUYER' && (
        <div>
          <Label className="text-primary font-bold text-sm">Tags de demanda</Label>
          <Input
            value={data.demand_tags}
            onChange={(e) => update('demand_tags', e.target.value)}
            placeholder="Ex: hortaliças, frutas, grãos"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
      )}

      {(data.role === 'PRODUCER' || data.role === 'BUYER') && (
        <div>
          <Label className="text-primary font-bold text-sm">Descrição</Label>
          <Textarea
            value={data.description}
            onChange={(e) => update('description', e.target.value)}
            placeholder="Conte um pouco sobre seu negócio..."
            className="bg-muted border-none mt-1 min-h-[80px]"
          />
        </div>
      )}
    </div>
  )
}
