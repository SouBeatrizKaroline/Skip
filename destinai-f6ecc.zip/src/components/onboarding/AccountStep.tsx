import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { formatDocument } from '@/lib/formatters'
import type { StepProps } from '@/services/onboarding'

export function AccountStep({ data, update }: StepProps) {
  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-primary mb-1">Criar sua conta</h2>
        <p className="text-muted-foreground text-sm">Preencha seus dados para começar.</p>
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-primary font-bold text-sm">Nome completo</Label>
          <Input
            value={data.name}
            onChange={(e) => update('name', e.target.value)}
            placeholder="Ex: João da Silva"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
        <div>
          <Label className="text-primary font-bold text-sm">E-mail</Label>
          <Input
            type="email"
            value={data.email}
            onChange={(e) => update('email', e.target.value)}
            placeholder="seu@email.com"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
        <div>
          <Label className="text-primary font-bold text-sm">Senha</Label>
          <Input
            type="password"
            value={data.password}
            onChange={(e) => update('password', e.target.value)}
            placeholder="Mínimo 8 caracteres"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
        <div>
          <Label className="text-primary font-bold text-sm">Empresa / Propriedade</Label>
          <Input
            value={data.company_name}
            onChange={(e) => update('company_name', e.target.value)}
            placeholder="Ex: Sítio Boa Vista"
            className="bg-muted border-none h-12 mt-1"
          />
        </div>
        <div>
          <Label className="text-primary font-bold text-sm">CPF / CNPJ</Label>
          <Input
            value={data.document}
            onChange={(e) => update('document', formatDocument(e.target.value))}
            placeholder="000.000.000-00"
            className="bg-muted border-none h-12 mt-1"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Digite seu CPF (11 dígitos) ou CNPJ (14 dígitos).
          </p>
        </div>
      </div>
    </div>
  )
}
