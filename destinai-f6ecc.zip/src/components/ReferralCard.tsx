import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Gift, Copy, Check, Share2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface ReferralCardProps {
  user: any
}

export function ReferralCard({ user }: ReferralCardProps) {
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const referralCode =
    user?.referrer_code || `DESTINAI-${(user?.id || '').slice(0, 6).toUpperCase()}`
  const referralLink = `${window.location.origin}/onboarding?ref=${referralCode}`

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    toast({ title: 'Link copiado!', description: 'Compartilhe com seus contatos.' })
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'DestinAI',
          text: 'Junte-se à DestinAI e reduza o desperdício agrícola!',
          url: referralLink,
        })
      } catch {
        /* user cancelled */
      }
    } else {
      handleCopy()
    }
  }

  return (
    <Card className="p-5 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/10 to-transparent">
      <div className="flex items-start gap-3">
        <div className="bg-secondary/20 p-2 rounded-full shrink-0">
          <Gift className="w-5 h-5 text-secondary" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-primary">Convide e Cresça 🌱</h3>
          <p className="text-sm text-muted-foreground mt-1 mb-3">
            Convide produtores, compradores e transportadores. Ganhe pontos de reputação por cada
            indicação!
          </p>
          <div className="flex items-center gap-2 bg-card border border-border rounded-xl p-2 mb-3">
            <code className="flex-1 text-sm font-mono text-secondary truncate">{referralLink}</code>
            <Button size="sm" variant="ghost" onClick={handleCopy} className="shrink-0">
              {copied ? <Check className="w-4 h-4 text-secondary" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
          <Button size="sm" variant="secondary" onClick={handleShare} className="w-full">
            <Share2 className="w-4 h-4 mr-2" /> Compartilhar
          </Button>
        </div>
      </div>
    </Card>
  )
}
