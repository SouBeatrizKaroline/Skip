import { cn } from '@/lib/utils'

interface WasteRiskBadgeProps {
  level?: string
  size?: 'sm' | 'md'
}

const RISK_CONFIG: Record<
  string,
  {
    emoji: string
    label: string
    color: string
    bg: string
    border: string
    flash?: boolean
  }
> = {
  LOW: {
    emoji: '🟢',
    label: 'Baixo Risco',
    color: 'text-secondary',
    bg: 'bg-secondary/10',
    border: 'border-secondary/20',
  },
  MEDIUM: {
    emoji: '🟡',
    label: 'Médio Risco',
    color: 'text-accent',
    bg: 'bg-accent/10',
    border: 'border-accent/20',
  },
  HIGH: {
    emoji: '🟠',
    label: 'Alto Risco',
    color: 'text-orange-600',
    bg: 'bg-orange-50',
    border: 'border-orange-200',
  },
  CRITICAL: {
    emoji: '🔴',
    label: 'Crítico',
    color: 'text-destructive',
    bg: 'bg-destructive/10',
    border: 'border-destructive/20',
    flash: true,
  },
}

export function WasteRiskBadge({ level, size = 'sm' }: WasteRiskBadgeProps) {
  if (!level) return null
  const cfg = RISK_CONFIG[level] || RISK_CONFIG.LOW
  const sizeClass = size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1.5'
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-bold border',
        cfg.color,
        cfg.bg,
        cfg.border,
        sizeClass,
        cfg.flash && 'animate-pulse',
      )}
    >
      <span>{cfg.emoji}</span>
      {cfg.label}
    </span>
  )
}
