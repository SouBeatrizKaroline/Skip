import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { AlertTriangle, MapPin } from 'lucide-react'
import { getOversupplyAlerts, type OversupplyAlertItem } from '@/services/oversupply'
import { useRealtime } from '@/hooks/use-realtime'

interface OversupplyAlertProps {
  producerId: string
}

export function OversupplyAlert({ producerId: _producerId }: OversupplyAlertProps) {
  const [alerts, setAlerts] = useState<OversupplyAlertItem[]>([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    getOversupplyAlerts()
      .then((res) => setAlerts(res.alerts || []))
      .catch(() => setAlerts([]))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    load()
  }, [])

  useRealtime('products', () => load())

  if (loading) return <Skeleton className="h-20 rounded-2xl" />
  if (alerts.length === 0) return null

  return (
    <Card className="p-5 rounded-2xl border-accent/30 bg-gradient-to-br from-accent/5 to-transparent">
      <div className="flex items-center gap-2 mb-3">
        <AlertTriangle className="w-5 h-5 text-accent" />
        <h3 className="font-bold text-primary">Alerta de Excesso de Oferta ⚠️</h3>
      </div>
      <div className="space-y-2">
        {alerts.map((alert, i) => (
          <div key={i} className="bg-card p-3 rounded-xl border border-border">
            <div className="flex items-center justify-between mb-1">
              <p className="font-bold text-sm text-primary">{alert.product_name}</p>
              <span className="text-xs font-bold text-accent bg-accent/10 px-2 py-0.5 rounded-full">
                {alert.count} lotes
              </span>
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
              <MapPin className="w-3 h-3" /> {alert.city} • {alert.total_kg} kg disponíveis
            </p>
            <p className="text-xs text-accent font-medium">{alert.suggested_action}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
