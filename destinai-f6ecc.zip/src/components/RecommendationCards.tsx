import { Card } from '@/components/ui/card'
import { TrendingUp, AlertTriangle, Lightbulb, ArrowRight, Sprout } from 'lucide-react'
import type { ViviInsightData } from '@/services/vivi-insights'

interface RecommendationCardsProps {
  insights: ViviInsightData
}

export function RecommendationCards({ insights }: RecommendationCardsProps) {
  const cards: Array<{
    type: 'opportunity' | 'risk' | 'education'
    title: string
    message: string
    icon: typeof TrendingUp
    color: string
    bg: string
  }> = []

  if (insights.hasBuyerMatch || insights.recommendationCount > 0) {
    const recText = insights.topRecommendation
      ? insights.topRecommendation.justification
      : `${insights.recommendationCount} ${insights.recommendationCount === 1 ? 'oportunidade encontrada' : 'oportunidades encontradas'} para seus produtos.`
    cards.push({
      type: 'opportunity',
      title: 'Oportunidade de Mercado',
      message: recText,
      icon: TrendingUp,
      color: 'text-accent',
      bg: 'bg-accent/10',
    })
  }

  if (insights.hasWasteRisk || insights.hasClimateRisk) {
    const riskParts: string[] = []
    if (insights.hasWasteRisk) riskParts.push('risco de desperdício detectado')
    if (insights.hasClimateRisk) riskParts.push('alerta climático ativo')
    cards.push({
      type: 'risk',
      title: 'Alerta de Risco',
      message: `Atenção: ${riskParts.join(' e ')}. Aja rapidamente para evitar perdas.`,
      icon: AlertTriangle,
      color: 'text-destructive',
      bg: 'bg-destructive/10',
    })
  }

  cards.push({
    type: 'education',
    title: 'Insight Educacional',
    message:
      'Produtos com imperfeições estéticas mantêm 100% dos nutrientes. O upcycling transforma "feios" em polpas, sucos e rações — gerando receita e evitando desperdício.',
    icon: Lightbulb,
    color: 'text-secondary',
    bg: 'bg-secondary/10',
  })

  if (insights.matchCount > 0) {
    cards.unshift({
      type: 'opportunity',
      title: 'Negociações Ativas',
      message: `Você tem ${insights.matchCount} ${insights.matchCount === 1 ? 'negociação pendente' : 'negociações pendentes'} aguardando resposta.`,
      icon: Sprout,
      color: 'text-primary',
      bg: 'bg-primary/10',
    })
  }

  return (
    <div className="space-y-3">
      {cards.map((card, i) => (
        <Card
          key={i}
          className={`p-4 rounded-xl border-none ${card.bg} animate-fade-in-up`}
          style={{ animationDelay: `${i * 100}ms` }}
        >
          <div className="flex items-start gap-3">
            <div
              className={`shrink-0 w-9 h-9 rounded-full flex items-center justify-center ${card.bg}`}
            >
              <card.icon className={`w-4 h-4 ${card.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={`font-bold text-sm ${card.color}`}>{card.title}</p>
              <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{card.message}</p>
            </div>
            <ArrowRight className={`w-4 h-4 ${card.color} shrink-0 mt-1`} />
          </div>
        </Card>
      ))}
    </div>
  )
}
