import { useState, useRef, useEffect } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Sprout, Send, Loader2, Mic, MicOff, ImagePlus, Volume2 } from 'lucide-react'
import { askVivi } from '@/services/vivi'
import { useAuth } from '@/hooks/use-auth'
import { useSpeech } from '@/hooks/use-speech'
import { useToast } from '@/hooks/use-toast'

interface Message {
  role: 'user' | 'ai'
  text: string
}

export function ViviChat() {
  const { isAuthenticated } = useAuth()
  const { speak, startListening, stopListening, isListening, supported } = useSpeech()
  const { toast } = useToast()
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'ai',
      text: 'Oi! Eu sou a Vivi \u{1F331}. Como posso ajudar a reduzir o desperdício hoje?',
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [open, setOpen] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    const handler = () => setOpen(true)
    window.addEventListener('open-vivi-chat', handler)
    return () => window.removeEventListener('open-vivi-chat', handler)
  }, [])

  const handleSend = async () => {
    if (!input.trim() || loading || !isAuthenticated) return
    const userMsg = input
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }])
    setInput('')
    setLoading(true)
    try {
      const res = await askVivi(userMsg, conversationId)
      if (res.conversation_id) setConversationId(res.conversation_id)
      setMessages((prev) => [...prev, { role: 'ai', text: res.content }])
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'ai', text: 'Desculpe, tive um problema. Tente novamente! \u{1F331}' },
      ])
    } finally {
      setLoading(false)
    }
  }

  const handleMic = () => {
    if (isListening) {
      stopListening()
    } else {
      startListening((text) => {
        setInput((prev) => prev + (prev ? ' ' : '') + text)
      })
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    toast({ title: 'Imagem anexada', description: 'A Vivi considerará a imagem na resposta.' })
    setInput((prev) => prev + (prev ? ' ' : '') + `[Imagem: ${file.name}]`)
    e.target.value = ''
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button className="fixed bottom-[calc(6rem+env(safe-area-inset-bottom))] md:bottom-8 right-4 md:right-8 w-14 h-14 bg-secondary text-white rounded-full shadow-elevation flex items-center justify-center hover:scale-105 transition-transform z-50 animate-bounce-subtle outline-none ring-0">
          <Sprout className="w-7 h-7" />
        </button>
      </SheetTrigger>
      <SheetContent
        side="right"
        className="w-full sm:w-[400px] flex flex-col p-0 border-l-0 sm:border-l border-border"
      >
        <SheetHeader className="p-4 border-b bg-card pt-safe">
          <SheetTitle className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-full flex items-center justify-center text-secondary shrink-0">
              <Sprout className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="text-base">Falar com a Vivi</p>
              <p className="text-xs text-muted-foreground font-normal mt-0.5">
                IA Multimodal • AgTech
              </p>
            </div>
          </SheetTitle>
        </SheetHeader>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-background">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'ai' ? 'justify-start' : 'justify-end'}`}>
              <div
                className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed shadow-sm ${
                  m.role === 'ai'
                    ? 'bg-card text-foreground rounded-tl-sm border border-border'
                    : 'bg-primary text-primary-foreground rounded-tr-sm'
                }`}
              >
                <p>{m.text}</p>
                {m.role === 'ai' && (
                  <button
                    onClick={() => speak(m.text)}
                    className="mt-2 flex items-center gap-1 text-xs text-secondary hover:underline"
                  >
                    <Volume2 className="w-3 h-3" /> Ouvir
                  </button>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-card text-foreground rounded-2xl rounded-tl-sm border border-border p-3.5 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-secondary" />
                <span className="text-sm text-muted-foreground">Vivi está pensando...</span>
              </div>
            </div>
          )}
          {!isAuthenticated && (
            <div className="text-center text-sm text-muted-foreground bg-muted p-3 rounded-xl">
              Faça login para conversar com a Vivi 🌱
            </div>
          )}
        </div>
        <div className="p-4 bg-card border-t border-border flex items-center gap-2 pb-safe">
          {supported && (
            <button
              onClick={handleMic}
              className={`shrink-0 w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                isListening
                  ? 'bg-destructive text-white animate-pulse'
                  : 'bg-muted text-primary hover:bg-primary/10'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          )}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0 w-10 h-10 rounded-full bg-muted text-primary hover:bg-primary/10 flex items-center justify-center transition-colors"
          >
            <ImagePlus className="w-4 h-4" />
          </button>
          <input
            type="file"
            accept="image/*"
            className="hidden"
            ref={fileInputRef}
            onChange={handleFileSelect}
          />
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? 'Ouvindo...' : 'Digite ou fale...'}
            className="rounded-full bg-muted border-none h-12 flex-1"
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={loading || !isAuthenticated}
          />
          <Button
            size="icon"
            onClick={handleSend}
            disabled={loading || !isAuthenticated}
            className="rounded-full w-12 h-12 shrink-0 bg-primary hover:bg-primary/90 text-white"
          >
            <Send className="w-5 h-5 ml-1" />
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
