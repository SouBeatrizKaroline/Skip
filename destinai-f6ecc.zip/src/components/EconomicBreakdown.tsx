import { Card } from '@/components/ui/card'
import { CheckCircle2, XCircle, TrendingUp, Truck, Percent, Wallet } from 'lucide-react'
import { cn } from '@/lib/utils'

interface EconomicBreakdownProps {
  lotValue: number
  logisticsCost: number
  platformFee: number
  netRevenue: number
  status: 'recommended' | 'not_recommended'
  feePercentage: number
  justification?: string
}

export function EconomicBreakdown({
  lotValue,
  logisticsCost,
  platformFee,
  netRevenue,
  status,
  feePercentage,
  justification,
}: EconomicBreakdownProps) {
  const isRecommended = status === 'recommended'
  const fmt = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
  const items = [
    { label: 'Valor Bruto', value: fmt(lotValue), icon: Wallet, color: 'text-primary' },
    {
      label: 'Custo Logística',
      value: `- ${fmt(logisticsCost)}`,
      icon: Truck,
      color: 'text-muted-foreground',
    },
    {
      label: `Taxa Plataforma (${feePercentage}%)`,
      value: `- ${fmt(platformFee)}`,
      icon: Percent,
      color: 'text-muted-foreground',
    },
  ]

  return (
    <Card
      className={cn(
        'p-5 rounded-2xl border',
        isRecommended
          ? 'border-secondary/20 bg-secondary/5'
          : 'border-destructive/20 bg-destructive/5',
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-primary flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" /> Resumo Financeiro
        </h3>
        <span
          className={cn(
            'text-sm font-bold flex items-center gap-1',
            isRecommended ? 'text-secondary' : 'text-destructive',
          )}
        >
          {isRecommended ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
          {isRecommended ? 'Operação Recomendada 🟢' : 'Operação Não Recomendada 🔴'}
        </span>
      </div>
      <div className="space-y-2 mb-4">
        {items.map((item, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground flex items-center gap-2">
              <item.icon className={cn('w-4 h-4', item.color)} /> {item.label}
            </span>
            <span className={cn('font-bold', item.color)}>{item.value}</span>
          </div>
        ))}
      </div>
      <div
        className={cn(
          'flex items-center justify-between p-3 rounded-xl',
          isRecommended ? 'bg-secondary/10' : 'bg-destructive/10',
        )}
      >
        <span className="font-bold text-primary">Lucro Líquido</span>
        <span
          className={cn('text-xl font-bold', isRecommended ? 'text-secondary' : 'text-destructive')}
        >
          {fmt(netRevenue)}
        </span>
      </div>
      {justification && (
        <p className="text-xs text-muted-foreground mt-3 leading-relaxed">{justification}</p>
      )}
    </Card>
  )
}
