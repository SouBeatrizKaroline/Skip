import { useState, useEffect, useCallback } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getAchievements, type Achievement } from '@/services/achievements'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'

export function AchievementsGallery() {
  const { isAuthenticated } = useAuth()
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!isAuthenticated) return
    try {
      const res = await getAchievements()
      setAchievements(res.achievements || [])
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [isAuthenticated])

  useEffect(() => {
    load()
  }, [load])

  useRealtime('impact_metrics', () => load())
  useRealtime('matches', () => load())

  if (loading) return <Skeleton className="h-48 rounded-2xl" />

  const unlocked = achievements.filter((a) => a.unlocked)

  return (
    <Card className="p-5 rounded-2xl border-border shadow-subtle">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-5 h-5 text-accent" />
        <h3 className="font-bold text-primary">Conquistas</h3>
        <span className="text-xs text-muted-foreground">
          ({unlocked.length}/{achievements.length})
        </span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {achievements.map((a) => (
          <div
            key={a.slug}
            className={cn(
              'p-3 rounded-xl border text-center transition-all',
              a.unlocked ? 'border-accent/30 bg-accent/5 shadow-sm' : 'border-border opacity-60',
            )}
          >
            <div className="text-3xl mb-1">{a.unlocked ? a.icon : '🔒'}</div>
            <p className="text-xs font-bold text-primary">{a.name}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{a.description}</p>
            {!a.unlocked && (
              <div className="mt-2">
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-accent rounded-full transition-all"
                    style={{ width: `${a.progress}%` }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">{a.progress}%</p>
              </div>
            )}
            {a.unlocked && (
              <span className="inline-block mt-1 text-[10px] font-bold text-accent">
                ✓ Desbloqueado
              </span>
            )}
          </div>
        ))}
      </div>
    </Card>
  )
}
