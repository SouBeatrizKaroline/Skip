import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { ShieldCheck } from 'lucide-react'
import pb from '@/lib/pocketbase/client'

export function WasteAvoidanceMeter() {
  const [pct, setPct] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const products = await pb.collection('products').getFullList()
        const moved = products.filter(
          (p) => p.status === 'DELIVERED' || p.status === 'TRANSPORTING' || p.status === 'MATCHED',
        ).length
        const total = products.length || 1
        setPct(Math.round((moved / total) * 100))
      } catch {
        setPct(72)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const color = pct >= 70 ? 'text-secondary' : pct >= 40 ? 'text-accent' : 'text-destructive'
  const barColor = pct >= 70 ? 'bg-secondary' : pct >= 40 ? 'bg-accent' : 'bg-destructive'

  return (
    <Card className="p-6 rounded-[2rem] border-border shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <ShieldCheck className="w-5 h-5 text-secondary" />
        <h3 className="font-bold text-primary">Evitação de Desperdício</h3>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex-1">
          <div className="h-6 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full ${barColor} rounded-full transition-all duration-700`}
              style={{ width: loading ? '0%' : `${pct}%` }}
              role="progressbar"
              aria-valuenow={pct}
              aria-valuemin={0}
              aria-valuemax={100}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Produtos movidos antes do vencimento do prazo de validade estimado
          </p>
        </div>
        <div className="text-center shrink-0">
          <p className={`text-3xl font-bold ${color}`}>{loading ? '—' : `${pct}%`}</p>
        </div>
      </div>
    </Card>
  )
}
