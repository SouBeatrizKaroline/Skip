import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { FileText, Leaf, Printer } from 'lucide-react'

export interface InvoiceData {
  producerName: string
  producerCompany: string
  producerCity: string
  producerState: string
  buyerName: string
  buyerCompany: string
  buyerCity: string
  buyerState: string
  productName: string
  quantity: number
  pricePerKg: number
  total: number
  matchId: string
}

export function InvoiceModal({
  open,
  onOpenChange,
  data,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  data: InvoiceData | null
}) {
  if (!data) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-primary flex items-center gap-2">
            <FileText className="w-5 h-5" /> NF-e Simplificada
          </DialogTitle>
        </DialogHeader>
        <div className="border-2 border-border rounded-2xl overflow-hidden">
          <div className="bg-primary text-primary-foreground p-4 flex items-center gap-3">
            <Leaf className="w-8 h-8" />
            <div>
              <p className="font-bold text-lg">DestinAI</p>
              <p className="text-xs opacity-80">Nota Fiscal Eletrônica Simplificada</p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-xs opacity-80">Nº</p>
              <p className="font-bold">#{data.matchId.slice(-6).toUpperCase()}</p>
            </div>
          </div>
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-muted p-3 rounded-xl">
                <p className="text-[10px] font-bold text-muted-foreground mb-1">PRODUTOR</p>
                <p className="font-bold text-sm text-primary">{data.producerName}</p>
                <p className="text-xs text-muted-foreground">{data.producerCompany}</p>
                <p className="text-xs text-muted-foreground">
                  {data.producerCity}/{data.producerState}
                </p>
              </div>
              <div className="bg-muted p-3 rounded-xl">
                <p className="text-[10px] font-bold text-muted-foreground mb-1">COMPRADOR</p>
                <p className="font-bold text-sm text-primary">{data.buyerName}</p>
                <p className="text-xs text-muted-foreground">{data.buyerCompany}</p>
                <p className="text-xs text-muted-foreground">
                  {data.buyerCity}/{data.buyerState}
                </p>
              </div>
            </div>
            <div className="border-t border-border pt-3">
              <p className="text-[10px] font-bold text-muted-foreground mb-2">DESCRIMINAÇÃO</p>
              <div className="flex justify-between text-sm">
                <span className="text-primary font-medium">{data.productName}</span>
                <span className="text-muted-foreground">{data.quantity} kg</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-muted-foreground">Valor por kg</span>
                <span className="text-primary">
                  R$ {data.pricePerKg.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>
            <div className="border-t border-border pt-3 flex justify-between items-center">
              <span className="font-bold text-primary">VALOR TOTAL</span>
              <span className="font-bold text-2xl text-accent">
                R$ {data.total.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <div className="bg-secondary/5 border border-secondary/20 p-3 rounded-xl">
              <p className="text-xs text-secondary font-bold mb-1">ISENÇÃO FISCAL</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Operação amparada pela Lei nº 11.947/2009. Produtos isentos de tributação para fins
                de impacto social rural e doação. Agricultura familiar em conformidade.
              </p>
            </div>
          </div>
        </div>
        <Button variant="outline" className="w-full" onClick={() => window.print()}>
          <Printer className="w-4 h-4 mr-2" /> Imprimir / Salvar PDF
        </Button>
      </DialogContent>
    </Dialog>
  )
}
