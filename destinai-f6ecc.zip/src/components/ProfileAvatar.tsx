import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Button } from '@/components/ui/button'
import { LogOut, User, MapPin, Bell, Sprout } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import pb from '@/lib/pocketbase/client'
import { getRoleProfile, updateUser, updateRoleProfile } from '@/services/profiles'
import { RoleAvatar } from '@/components/RoleAvatar'
import { useRealtime } from '@/hooks/use-realtime'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

const profileSchema = z.object({
  name: z.string().min(2, 'Nome muito curto'),
  company: z.string().min(2, 'Empresa muito curta'),
  phone: z.string(),
  lat: z.coerce.number(),
  lng: z.coerce.number(),
})

export function ProfileAvatar() {
  const { user, signOut } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState('')
  const [notifProposals, setNotifProposals] = useState(true)
  const [viviAlerts, setViviAlerts] = useState(true)
  const [avatarFile, setAvatarFile] = useState<File | null>(null)

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: '', company: '', phone: '', lat: 0, lng: 0 },
  })

  useRealtime(
    'users',
    (e) => {
      if (e.record.id === user?.id) {
        pb.collection('users')
          .authRefresh()
          .catch(() => {})
      }
    },
    !!user,
  )

  useEffect(() => {
    if (!open || !user) return
    form.setValue('name', user.name || '')
    form.setValue('company', user.company_name || '')
    setNotifProposals(localStorage.getItem('pref_notif') !== 'false')
    setViviAlerts(localStorage.getItem('pref_vivi') !== 'false')
    if (user.role && user.role !== 'ADMIN') {
      getRoleProfile(user.role, user.id)
        .then((p) => {
          form.setValue('phone', p.phone || '')
          form.setValue('lat', p.latitude || 0)
          form.setValue('lng', p.longitude || 0)
          setProfileId(p.id)
        })
        .catch(() => {})
    }
  }, [open, user, form])

  const onSubmit = async (values: z.infer<typeof profileSchema>) => {
    if (!user) return
    setSaving(true)
    try {
      if (avatarFile) {
        const formData = new FormData()
        formData.append('avatar', avatarFile)
        await pb.collection('users').update(user.id, formData)
        try {
          await pb.collection('users').authRefresh()
        } catch {
          /* avatar uploaded but auth refresh failed */
        }
      }
      await updateUser(user.id, { name: values.name, company_name: values.company })
      if (profileId && user.role && user.role !== 'ADMIN') {
        await updateRoleProfile(user.role, profileId, {
          phone: values.phone,
          latitude: values.lat,
          longitude: values.lng,
        })
      }
      localStorage.setItem('pref_notif', notifProposals.toString())
      localStorage.setItem('pref_vivi', viviAlerts.toString())
      toast({ title: 'Perfil atualizado com sucesso!' })
      setAvatarFile(null)
      setOpen(false)
    } catch {
      toast({ title: 'Erro ao salvar perfil' })
    } finally {
      setSaving(false)
    }
  }

  const handleLogout = () => {
    signOut()
    setOpen(false)
    navigate('/')
  }

  if (!user) return null

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="cursor-pointer hover:opacity-80 transition-opacity shrink-0">
          <RoleAvatar user={user} size="sm" className="border-2 border-primary/20" />
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-primary flex items-center gap-2">
            <User className="w-5 h-5" /> Configurações do Perfil
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-0">
            <Tabs defaultValue="account">
              <TabsList className="grid grid-cols-3 w-full">
                <TabsTrigger value="account">Conta</TabsTrigger>
                <TabsTrigger value="location">Localização</TabsTrigger>
                <TabsTrigger value="prefs">Preferências</TabsTrigger>
              </TabsList>
              <TabsContent value="account" className="space-y-4 pt-4">
                <div className="flex items-center gap-3">
                  {avatarFile ? (
                    <img
                      src={URL.createObjectURL(avatarFile)}
                      alt="Avatar"
                      className="w-16 h-16 rounded-full object-cover border-2 border-primary/20"
                    />
                  ) : (
                    <RoleAvatar user={user} size="md" className="border-2 border-primary/20" />
                  )}
                  <div className="flex-1">
                    <Label className="text-primary font-bold text-sm">Foto de perfil</Label>
                    <p className="text-xs text-muted-foreground mb-1">PNG ou JPG, máx 5MB</p>
                    <input
                      type="file"
                      accept="image/png,image/jpeg"
                      className="text-xs file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:bg-primary file:text-primary-foreground file:cursor-pointer"
                      onChange={(e) => setAvatarFile(e.target.files?.[0] || null)}
                    />
                  </div>
                </div>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-primary font-bold">Nome</FormLabel>
                      <FormControl>
                        <Input className="bg-muted border-none h-11" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-primary font-bold">Empresa</FormLabel>
                      <FormControl>
                        <Input className="bg-muted border-none h-11" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="space-y-2">
                  <Label className="text-primary font-bold">E-mail</Label>
                  <Input
                    value={user.email || ''}
                    disabled
                    className="bg-muted border-none h-11 opacity-60"
                  />
                </div>
                {user.role !== 'ADMIN' && (
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-primary font-bold">Telefone</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="(00) 00000-0000"
                            className="bg-muted border-none h-11"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </TabsContent>
              <TabsContent value="location" className="space-y-4 pt-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">Usada pela IA para calcular matches.</span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="lat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-primary font-bold">Latitude</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            className="bg-muted border-none h-11"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lng"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-primary font-bold">Longitude</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            className="bg-muted border-none h-11"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </TabsContent>
              <TabsContent value="prefs" className="space-y-4 pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium text-primary">Notificar propostas</span>
                  </div>
                  <Switch checked={notifProposals} onCheckedChange={setNotifProposals} />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sprout className="w-4 h-4 text-secondary" />
                    <span className="text-sm font-medium text-primary">Alertas da Vivi IA</span>
                  </div>
                  <Switch checked={viviAlerts} onCheckedChange={setViviAlerts} />
                </div>
              </TabsContent>
            </Tabs>
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleLogout}
                className="flex-1 h-12 rounded-xl border-destructive/30 text-destructive hover:bg-destructive/5"
              >
                <LogOut className="w-4 h-4 mr-2" /> Sair
              </Button>
              <Button type="submit" disabled={saving} className="flex-1 h-12 rounded-xl">
                {saving ? 'Salvando...' : 'Salvar'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
