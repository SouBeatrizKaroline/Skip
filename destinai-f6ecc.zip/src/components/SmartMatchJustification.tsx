import { Card } from '@/components/ui/card'
import { MapPin, DollarSign, Shield, Zap } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SmartMatchJustificationProps {
  smartScore?: number
  distanceKm?: number
  priceAgreed?: number
  matchScore?: number
}

export function SmartMatchJustification({
  smartScore,
  distanceKm,
  priceAgreed,
  matchScore,
}: SmartMatchJustificationProps) {
  if (smartScore === undefined && matchScore === undefined) return null

  const score = smartScore ?? matchScore ?? 0
  const isBestMatch = score >= 70

  const factors = [
    {
      icon: MapPin,
      label: 'Distância',
      value: distanceKm ? `${distanceKm.toFixed(0)} km` : '—',
      good: distanceKm ? distanceKm < 50 : false,
    },
    {
      icon: DollarSign,
      label: 'Preço Acordado',
      value: priceAgreed ? `R$ ${priceAgreed.toFixed(2)}` : '—',
      good: priceAgreed ? priceAgreed > 0 : false,
    },
    {
      icon: Shield,
      label: 'Confiabilidade',
      value: `${Math.min(score, 100)}%`,
      good: score >= 70,
    },
  ]

  return (
    <Card
      className={cn(
        'p-4 rounded-2xl border',
        isBestMatch ? 'border-secondary/30 bg-secondary/5' : 'border-border',
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-bold text-sm text-primary">Justificativa do Match</h4>
        {isBestMatch && (
          <span className="flex items-center gap-1 text-xs font-bold text-secondary bg-secondary/10 px-2 py-1 rounded-full">
            <Zap className="w-3 h-3" /> Best Match
          </span>
        )}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {factors.map((f, i) => (
          <div key={i} className="text-center bg-card p-2 rounded-lg border border-border">
            <f.icon
              className={cn(
                'w-4 h-4 mx-auto mb-1',
                f.good ? 'text-secondary' : 'text-muted-foreground',
              )}
            />
            <p className="text-xs font-bold text-primary">{f.value}</p>
            <p className="text-[10px] text-muted-foreground">{f.label}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
