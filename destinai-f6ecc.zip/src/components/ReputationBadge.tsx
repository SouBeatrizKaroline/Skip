import { cn } from '@/lib/utils'
import { Crown, Award, Medal, Star } from 'lucide-react'

interface ReputationBadgeProps {
  tier?: string
  score?: number
  size?: 'sm' | 'md'
}

const TIER_CONFIG: Record<
  string,
  {
    label: string
    icon: typeof Crown
    color: string
    bg: string
    border: string
  }
> = {
  BRONZE: {
    label: 'Bronze',
    icon: Medal,
    color: 'text-orange-600',
    bg: 'bg-orange-50',
    border: 'border-orange-200',
  },
  SILVER: {
    label: 'Prata',
    icon: Award,
    color: 'text-gray-600',
    bg: 'bg-gray-50',
    border: 'border-gray-200',
  },
  GOLD: {
    label: 'Ouro',
    icon: Star,
    color: 'text-yellow-600',
    bg: 'bg-yellow-50',
    border: 'border-yellow-200',
  },
  DIAMOND: {
    label: 'Diamante',
    icon: Crown,
    color: 'text-cyan-600',
    bg: 'bg-cyan-50',
    border: 'border-cyan-200',
  },
}

export function ReputationBadge({ tier, score, size = 'sm' }: ReputationBadgeProps) {
  if (!tier) return null
  const cfg = TIER_CONFIG[tier] || TIER_CONFIG.BRONZE
  const Icon = cfg.icon
  const sizeClass = size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1.5'
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-bold border',
        cfg.color,
        cfg.bg,
        cfg.border,
        sizeClass,
      )}
    >
      <Icon className={size === 'sm' ? 'w-3 h-3' : 'w-4 h-4'} />
      {cfg.label}
      {score !== undefined && <span className="opacity-70">({score})</span>}
    </span>
  )
}
