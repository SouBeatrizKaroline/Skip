import { useState, useEffect, useCallback } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Flame, Clock, MapPin, ArrowRight, Zap } from 'lucide-react'
import { Link } from 'react-router-dom'
import pb from '@/lib/pocketbase/client'
import { useRealtime } from '@/hooks/use-realtime'
import { getProductImage } from '@/services/products'

export function HotMatchesFeed() {
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const recs = await pb.collection('recommendations').getFullList({
        filter: 'match_score > 85',
        sort: '-match_score',
        expand: 'product_id,buyer_id',
      })
      setMatches(recs.slice(0, 4))
    } catch {
      setMatches([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  useRealtime('recommendations', () => load())
  useRealtime('matches', () => load())

  if (loading) return <Skeleton className="h-48 rounded-2xl" />
  if (matches.length === 0) return null

  return (
    <Card className="p-5 rounded-2xl border-accent/20 bg-gradient-to-br from-accent/5 to-transparent">
      <div className="flex items-center gap-2 mb-4">
        <Flame className="w-5 h-5 text-accent" />
        <h3 className="font-bold text-primary">Matches em Alta ⚡</h3>
        <span className="ml-auto text-xs font-bold text-accent bg-accent/10 px-2 py-1 rounded-full">
          {matches.length} oportunidades
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {matches.map((m) => {
          const product = m.expand?.product_id
          const buyer = m.expand?.buyer_id
          return (
            <Link to="/opportunities" key={m.id} className="block">
              <div className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border hover:border-accent/30 transition-all">
                <img
                  src={getProductImage(product?.name || '')}
                  alt=""
                  loading="lazy"
                  className="w-12 h-12 rounded-lg object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm text-primary truncate">
                      {product?.name || 'Produto'}
                    </p>
                    <span className="text-xs font-bold text-white bg-accent px-1.5 py-0.5 rounded-full shrink-0">
                      {m.match_score}%
                    </span>
                    {m.match_score >= 90 && (
                      <span className="text-xs font-bold text-secondary bg-secondary/10 px-1.5 py-0.5 rounded-full shrink-0 flex items-center gap-0.5">
                        <Zap className="w-2.5 h-2.5" /> Top
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3" /> {buyer?.city || product?.city || 'N/A'}
                  </p>
                  <p className="text-xs text-accent font-bold flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3" /> Tempo limitado!
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </div>
            </Link>
          )
        })}
      </div>
    </Card>
  )
}
