import { cn } from '@/lib/utils'

interface PerishabilityIndicatorProps {
  level: 'high' | 'medium' | 'low' | 'critical'
  risk: 'high' | 'medium' | 'low' | 'critical'
  remainingDays: number
  usedPct: number
  shelfLifeDays: number
}

const LEVEL_LABELS = {
  high: 'Alta Perecibilidade',
  medium: 'Perecibilidade Média',
  low: 'Baixa Perecibilidade',
}

const RISK_CONFIG = {
  critical: {
    color: 'text-destructive',
    bg: 'bg-destructive/10',
    bar: 'bg-destructive',
    border: 'border-destructive/20',
    emoji: '🔴',
    label: 'Critical Risk',
  },
  high: {
    color: 'text-orange-500',
    bg: 'bg-orange-50',
    bar: 'bg-orange-500',
    border: 'border-orange-200',
    emoji: '🟠',
    label: 'High Risk',
  },
  medium: {
    color: 'text-accent',
    bg: 'bg-accent/10',
    bar: 'bg-accent',
    border: 'border-accent/20',
    emoji: '🟡',
    label: 'Medium Risk',
  },
  low: {
    color: 'text-secondary',
    bg: 'bg-secondary/10',
    bar: 'bg-secondary',
    border: 'border-secondary/20',
    emoji: '🟢',
    label: 'Low Risk',
  },
}

export function PerishabilityIndicator({
  level,
  risk,
  remainingDays,
  usedPct,
  shelfLifeDays,
}: PerishabilityIndicatorProps) {
  const cfg = RISK_CONFIG[risk] || RISK_CONFIG.low
  return (
    <div className={cn('rounded-2xl border p-4', cfg.bg, cfg.border)}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold text-muted-foreground">{LEVEL_LABELS[level]}</span>
        <span className={cn('text-sm font-bold flex items-center gap-1', cfg.color)}>
          {cfg.emoji} {cfg.label}
        </span>
      </div>
      <div className="flex items-center gap-3 mb-2">
        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={cn('h-full rounded-full transition-all', cfg.bar)}
            style={{ width: `${Math.min(100, usedPct)}%` }}
          />
        </div>
        <span className="text-xs font-bold text-muted-foreground shrink-0">{usedPct}% usado</span>
      </div>
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>Validade total: {shelfLifeDays} dias</span>
        <span className={cn('font-bold', cfg.color)}>{remainingDays} dias restantes</span>
      </div>
    </div>
  )
}
