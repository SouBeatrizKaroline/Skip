import { useState, useEffect, useCallback } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Sprout, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getCommandCenter, type CommandCenterInsight } from '@/services/vivi-command-center'
import { useAuth } from '@/hooks/use-auth'

export function ViviCommandCenter() {
  const { isAuthenticated } = useAuth()
  const [insights, setInsights] = useState<CommandCenterInsight[]>([])
  const [loading, setLoading] = useState(true)
  const [index, setIndex] = useState(0)

  const load = useCallback(async () => {
    if (!isAuthenticated) return
    try {
      const res = await getCommandCenter()
      setInsights(res.insights || [])
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [isAuthenticated])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    if (insights.length <= 1) return
    const interval = setInterval(() => {
      setIndex((i) => (i + 1) % insights.length)
    }, 8000)
    return () => clearInterval(interval)
  }, [insights.length])

  if (loading) return <Skeleton className="h-32 rounded-2xl" />
  if (insights.length === 0) return null

  const current = insights[index] || insights[0]

  return (
    <Card className="p-5 rounded-2xl border-secondary/20 bg-gradient-to-br from-secondary/10 via-primary/5 to-transparent shadow-subtle">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="bg-secondary/15 p-1.5 rounded-lg">
            <Sprout className="w-4 h-4 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-primary">Central da Vivi 🌱</h3>
            <p className="text-[10px] text-muted-foreground">Comando proativo</p>
          </div>
        </div>
        {insights.length > 1 && (
          <div className="flex gap-1">
            <button
              onClick={() => setIndex((i) => (i - 1 + insights.length) % insights.length)}
              className="p-1 rounded-full hover:bg-muted"
            >
              <ChevronLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <button
              onClick={() => setIndex((i) => (i + 1) % insights.length)}
              className="p-1 rounded-full hover:bg-muted"
            >
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        )}
      </div>
      <div className="space-y-2">
        <div className="flex items-start gap-2">
          <span className="text-2xl shrink-0">{current.icon}</span>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-sm text-primary">{current.title}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{current.message}</p>
          </div>
        </div>
        {current.vivi_insight && (
          <div className="flex items-start gap-1.5 p-2 bg-secondary/5 rounded-lg">
            <Sparkles className="w-3 h-3 text-secondary shrink-0 mt-0.5" />
            <p className="text-xs text-secondary italic">{current.vivi_insight}</p>
          </div>
        )}
        {current.progress !== undefined && (
          <div className="mt-2">
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-secondary rounded-full transition-all"
                style={{ width: `${current.progress}%` }}
              />
            </div>
            <p className="text-[10px] text-muted-foreground mt-1 text-center">
              {current.current} / {current.target}
            </p>
          </div>
        )}
      </div>
      {insights.length > 1 && (
        <div className="flex gap-1 mt-3 justify-center">
          {insights.map((_, i) => (
            <div
              key={i}
              className={cn(
                'h-1.5 rounded-full transition-all',
                i === index ? 'w-6 bg-secondary' : 'w-1.5 bg-muted',
              )}
            />
          ))}
        </div>
      )}
    </Card>
  )
}
