import { Link, useLocation } from 'react-router-dom'
import {
  Home,
  Search,
  Map,
  BarChart3,
  Shield,
  TrendingUp,
  Handshake,
  CreditCard,
  DollarSign,
  Truck,
  Trophy,
  Package,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/use-auth'
import { useNotifications } from '@/hooks/use-notifications'

interface NavItem {
  name: string
  icon: typeof Home
  path: string
}

const ROLE_NAV: Record<string, NavItem[]> = {
  PRODUCER: [
    { name: 'Início', icon: Home, path: '/dashboard/produtor' },
    { name: 'Produtos', icon: Package, path: '/dashboard/produtor/produtos' },
    { name: 'Negociações', icon: Handshake, path: '/producer/negotiations' },
    { name: 'Oportunidades', icon: Search, path: '/opportunities' },
    { name: 'Impacto', icon: BarChart3, path: '/impact' },
  ],
  BUYER: [
    { name: 'Oportunidades', icon: Search, path: '/opportunities' },
    { name: 'Safra', icon: TrendingUp, path: '/harvest-intelligence' },
    { name: 'Ranking', icon: Trophy, path: '/ranking' },
    { name: 'Impacto', icon: BarChart3, path: '/impact' },
  ],
  TRANSPORTER: [
    { name: 'Logística', icon: Map, path: '/logistics' },
    { name: 'Veículos', icon: Truck, path: '/transporter/vehicles' },
    { name: 'Ranking', icon: Trophy, path: '/ranking' },
    { name: 'Impacto', icon: BarChart3, path: '/impact' },
  ],
  ADMIN: [
    { name: 'Admin', icon: Shield, path: '/dashboard/admin' },
    { name: 'Monetização', icon: DollarSign, path: '/monetization' },
    { name: 'Ranking', icon: Trophy, path: '/ranking' },
    { name: 'Impacto', icon: BarChart3, path: '/impact' },
  ],
}

function useNavItems(): NavItem[] {
  const { user } = useAuth()
  return ROLE_NAV[user?.role] || ROLE_NAV.PRODUCER
}

export function Sidebar() {
  const location = useLocation()
  const items = useNavItems()
  return (
    <aside className="hidden md:flex flex-col w-20 hover:w-64 fixed inset-y-0 left-0 bg-card border-r border-border z-40 pt-24 shadow-elevation transition-all duration-300 overflow-hidden group">
      <nav className="flex flex-col gap-2 px-2">
        {items.map((item) => {
          const isActive = location.pathname.startsWith(item.path)
          return (
            <Link
              key={item.name}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl transition-all whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
                isActive
                  ? 'bg-primary text-primary-foreground font-semibold shadow-subtle'
                  : 'text-muted-foreground hover:bg-muted hover:text-primary',
              )}
              title={item.name}
              aria-label={item.name}
              aria-current={isActive ? 'page' : undefined}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                {item.name}
              </span>
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}

export function BottomNav() {
  const location = useLocation()
  const items = useNavItems()
  const { unreadCount } = useNotifications()
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 bg-card/90 backdrop-blur-md border-t border-border z-40 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      <div className="pt-2">
        <div className="flex justify-around items-center p-2">
          {items.map((item) => {
            const isActive = location.pathname.startsWith(item.path)
            return (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  'flex flex-col items-center p-2 rounded-xl min-w-[64px] transition-colors relative focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                  isActive ? 'text-primary' : 'text-muted-foreground',
                )}
                title={item.name}
                aria-label={item.name}
                aria-current={isActive ? 'page' : undefined}
              >
                <div className={cn('mb-1 p-1 rounded-full relative', isActive && 'bg-primary/10')}>
                  <item.icon className="w-6 h-6" />
                  {unreadCount > 0 && item.name === 'Negociações' && (
                    <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] bg-accent text-white text-[9px] font-bold rounded-full flex items-center justify-center px-1 border border-card">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-bold">{item.name}</span>
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
