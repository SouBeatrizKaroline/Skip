import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Wallet, Truck, Percent, TrendingUp, Scale, Coins } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getSmartScore } from '@/services/smart-score'

interface EconomicViabilityCardProps {
  quantityKg: number
  pricePerKg: number
  productId?: string
  estimatedDistanceKm?: number
}

export function EconomicViabilityCard({
  quantityKg,
  pricePerKg,
  productId,
  estimatedDistanceKm = 50,
}: EconomicViabilityCardProps) {
  const [smartData, setSmartData] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!productId) return
    setLoading(true)
    getSmartScore(productId)
      .then(setSmartData)
      .catch(() => setSmartData(null))
      .finally(() => setLoading(false))
  }, [productId])

  if (loading) return <Skeleton className="h-40 rounded-2xl" />

  const grossValue = quantityKg * pricePerKg
  const fee = grossValue * 0.02
  const logisticCost = smartData?.factors?.economic?.logistics_cost ?? estimatedDistanceKm * 2.5
  const netProfit = grossValue - fee - logisticCost
  const costPerKg = quantityKg > 0 ? (logisticCost + fee) / quantityKg : 0
  const netPerKg = quantityKg > 0 ? netProfit / quantityKg : 0
  const isProfit = netProfit > 0

  const fmt = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
  const items = [
    { label: 'Valor Bruto', value: fmt(grossValue), icon: Wallet, color: 'text-primary' },
    {
      label: 'Custo Logístico',
      value: `- ${fmt(logisticCost)}`,
      icon: Truck,
      color: 'text-muted-foreground',
    },
    {
      label: 'Taxa DestinAI (2%)',
      value: `- ${fmt(fee)}`,
      icon: Percent,
      color: 'text-muted-foreground',
    },
    { label: 'Custo por kg', value: fmt(costPerKg), icon: Scale, color: 'text-muted-foreground' },
    {
      label: 'Receita Líquida/kg',
      value: fmt(netPerKg),
      icon: Coins,
      color: isProfit ? 'text-secondary' : 'text-destructive',
    },
  ]

  return (
    <Card
      className={cn(
        'p-5 rounded-2xl border',
        isProfit ? 'border-secondary/20 bg-secondary/5' : 'border-destructive/20 bg-destructive/5',
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-primary flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" /> Viabilidade Econômica
        </h3>
        <span className={cn('text-sm font-bold', isProfit ? 'text-secondary' : 'text-destructive')}>
          {isProfit ? 'Lucrativo 🟢' : 'Prejuízo 🔴'}
        </span>
      </div>
      <div className="space-y-2 mb-4">
        {items.map((item, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground flex items-center gap-2">
              <item.icon className={cn('w-4 h-4', item.color)} /> {item.label}
            </span>
            <span className={cn('font-bold', item.color)}>{item.value}</span>
          </div>
        ))}
      </div>
      <div
        className={cn(
          'flex items-center justify-between p-3 rounded-xl',
          isProfit ? 'bg-secondary/10' : 'bg-destructive/10',
        )}
      >
        <span className="font-bold text-primary">Lucro Líquido Estimado</span>
        <span className={cn('text-xl font-bold', isProfit ? 'text-secondary' : 'text-destructive')}>
          {fmt(netProfit)}
        </span>
      </div>
    </Card>
  )
}
