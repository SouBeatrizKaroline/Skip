import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { BarChart3, TrendingUp, Users, Leaf, Package, ChevronDown, ChevronUp } from 'lucide-react'
import { getInvestorStats, type InvestorStats } from '@/services/investor-stats'

export function InvestorView() {
  const [expanded, setExpanded] = useState(false)
  const [stats, setStats] = useState<InvestorStats | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (expanded && !stats) {
      setLoading(true)
      getInvestorStats()
        .then(setStats)
        .catch(() => {})
        .finally(() => setLoading(false))
    }
  }, [expanded, stats])

  return (
    <Card className="p-5 rounded-2xl border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center justify-between w-full"
      >
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-primary">Visão de Investidor</h3>
        </div>
        {expanded ? (
          <ChevronUp className="w-5 h-5 text-muted-foreground" />
        ) : (
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        )}
      </button>
      {expanded && (
        <div className="mt-4">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))}
            </div>
          ) : stats ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Metric
                icon={TrendingUp}
                label="Volume Transacionado"
                value={`R$ ${(stats.total_volume || 0).toLocaleString('pt-BR')}`}
                color="text-accent"
              />
              <Metric
                icon={Users}
                label="Rede de Usuários"
                value={String(stats.total_users || 0)}
                color="text-primary"
              />
              <Metric
                icon={Package}
                label="Alimentos Salvos"
                value={`${(stats.total_kg_saved || 0).toLocaleString('pt-BR')} kg`}
                color="text-secondary"
              />
              <Metric
                icon={Leaf}
                label="CO₂ Evitado"
                value={`${(stats.total_co2_saved || 0).toLocaleString('pt-BR')} kg`}
                color="text-secondary"
              />
              <Metric
                icon={TrendingUp}
                label="Receita Gerada"
                value={`R$ ${(stats.total_revenue || 0).toLocaleString('pt-BR')}`}
                color="text-accent"
              />
              <Metric
                icon={Users}
                label="Produtores"
                value={String(stats.producer_count || 0)}
                color="text-primary"
              />
              <Metric
                icon={Users}
                label="Compradores"
                value={String(stats.buyer_count || 0)}
                color="text-primary"
              />
              <Metric
                icon={Users}
                label="Transportadores"
                value={String(stats.transporter_count || 0)}
                color="text-primary"
              />
            </div>
          ) : null}
        </div>
      )}
    </Card>
  )
}

function Metric({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Users
  label: string
  value: string
  color: string
}) {
  return (
    <div className="bg-card p-3 rounded-xl border border-border">
      <Icon className={`w-4 h-4 ${color} mb-1`} />
      <p className="text-lg font-bold text-primary">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}
