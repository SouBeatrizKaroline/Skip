import { Leaf, Sprout, ShoppingBasket, Truck } from 'lucide-react'
import { cn } from '@/lib/utils'
import pb from '@/lib/pocketbase/client'

type RoleKey = 'PRODUCER' | 'BUYER' | 'TRANSPORTER' | 'ADMIN'

const ROLE_STYLES: Record<RoleKey, { Icon: typeof Leaf; gradient: string; iconColor: string }> = {
  PRODUCER: {
    Icon: Sprout,
    gradient: 'from-primary/20 to-primary/5',
    iconColor: 'text-primary',
  },
  BUYER: {
    Icon: ShoppingBasket,
    gradient: 'from-secondary/20 to-secondary/5',
    iconColor: 'text-secondary',
  },
  TRANSPORTER: {
    Icon: Truck,
    gradient: 'from-accent/20 to-accent/5',
    iconColor: 'text-accent',
  },
  ADMIN: {
    Icon: Leaf,
    gradient: 'from-primary/20 to-primary/5',
    iconColor: 'text-primary',
  },
}

const SIZE_CLASSES: Record<string, string> = {
  sm: 'w-8 h-8',
  md: 'w-16 h-16',
  lg: 'w-20 h-20',
}

const ICON_SIZES: Record<string, string> = {
  sm: 'w-4 h-4',
  md: 'w-8 h-8',
  lg: 'w-10 h-10',
}

export function RoleAvatar({
  user,
  size = 'sm',
  className,
}: {
  user: any
  size?: keyof typeof SIZE_CLASSES
  className?: string
}) {
  if (user?.avatar) {
    const url = pb.files.getURL(user, user.avatar)
    return (
      <img
        src={url}
        alt="Avatar"
        className={cn(SIZE_CLASSES[size], 'rounded-full object-cover', className)}
      />
    )
  }

  const role = (user?.role as RoleKey) || 'ADMIN'
  const style = ROLE_STYLES[role] || ROLE_STYLES.ADMIN
  const { Icon } = style

  return (
    <div
      className={cn(
        SIZE_CLASSES[size],
        'rounded-full bg-gradient-to-br flex items-center justify-center',
        style.gradient,
        className,
      )}
    >
      <Icon className={cn(ICON_SIZES[size], style.iconColor)} strokeWidth={1.5} />
    </div>
  )
}
