import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Navigation2, Filter } from 'lucide-react'
import pb from '@/lib/pocketbase/client'
import { computeBounds, toXY, clusterMarkers } from '@/lib/map-utils'
import { cn } from '@/lib/utils'

const ROLE_COLORS: Record<string, string> = {
  producer: 'hsl(var(--secondary))',
  buyer: 'hsl(var(--accent))',
  transporter: 'hsl(var(--primary))',
}

export function IntelligenceMap() {
  const [data, setData] = useState({
    producers: [] as any[],
    buyers: [] as any[],
    transporters: [] as any[],
    products: [] as any[],
    matches: [] as any[],
  })
  const [loading, setLoading] = useState(true)
  const [showHeatmap, setShowHeatmap] = useState(true)
  const [filters, setFilters] = useState({
    producers: true,
    buyers: true,
    transporters: true,
    routes: true,
  })

  useEffect(() => {
    const load = async () => {
      try {
        const [p, b, t, pr, m] = await Promise.all([
          pb
            .collection('producer_profiles')
            .getFullList()
            .catch(() => []),
          pb
            .collection('buyer_profiles')
            .getFullList()
            .catch(() => []),
          pb
            .collection('transporter_profiles')
            .getFullList()
            .catch(() => []),
          pb
            .collection('products')
            .getFullList({ filter: "status = 'AVAILABLE' || status = 'MATCHED'" })
            .catch(() => []),
          pb
            .collection('matches')
            .getFullList({
              expand: 'product_id,buyer_id,producer_id',
              filter: "status = 'CONFIRMED' || status = 'PENDING'",
            })
            .catch(() => []),
        ])
        setData({ producers: p, buyers: b, transporters: t, products: pr, matches: m })
      } catch {
        /* ignore */
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  if (loading) return <Skeleton className="h-96 w-full rounded-3xl" />

  const allCoords = [
    ...data.producers.map((p) => ({ lat: p.latitude || 0, lon: p.longitude || 0 })),
    ...data.buyers.map((b) => ({ lat: b.latitude || 0, lon: b.longitude || 0 })),
  ].filter((c) => c.lat !== 0 || c.lon !== 0)

  if (allCoords.length === 0) {
    return (
      <Card className="p-0 rounded-[2rem] overflow-hidden border-border shadow-subtle">
        <div className="h-96 flex items-center justify-center text-muted-foreground">
          Sem dados de localização disponíveis
        </div>
      </Card>
    )
  }

  const bounds = computeBounds(allCoords)
  const project = (lat: number, lon: number) => toXY(lat, lon, bounds)

  const rawMarkers = [
    ...(filters.producers
      ? data.producers.map((p) => ({
          ...project(p.latitude || 0, p.longitude || 0),
          type: 'producer',
        }))
      : []),
    ...(filters.buyers
      ? data.buyers.map((b) => ({ ...project(b.latitude || 0, b.longitude || 0), type: 'buyer' }))
      : []),
    ...(filters.transporters
      ? data.transporters.map((t) => ({
          ...project(t.latitude || 0, t.longitude || 0),
          type: 'transporter',
        }))
      : []),
  ].filter((p) => p.x >= 0 && p.y >= 0)

  const markers = clusterMarkers(rawMarkers)
  const heatPoints = [
    ...data.buyers.map((b) => ({ ...project(b.latitude || 0, b.longitude || 0), color: 'green' })),
    ...data.products.map((p) => ({ ...project(p.latitude || 0, p.longitude || 0), color: 'red' })),
  ].filter((p) => p.x >= 0 && p.y >= 0)

  const FilterBtn = ({
    k,
    label,
    color,
  }: {
    k: keyof typeof filters
    label: string
    color: string
  }) => (
    <button
      onClick={() => setFilters((f) => ({ ...f, [k]: !f[k] }))}
      className={cn(
        'px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5',
        filters[k] ? 'bg-card shadow-sm' : 'bg-muted/50 opacity-50',
      )}
      aria-pressed={filters[k]}
      aria-label={`Alternar ${label}`}
    >
      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
      {label}
    </button>
  )

  return (
    <Card className="p-0 rounded-[2rem] overflow-hidden border-border shadow-subtle">
      <div className="relative h-96 md:h-[500px] bg-muted">
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 600 400"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <pattern id="imap-grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path
                d="M 30 0 L 0 0 0 30"
                fill="none"
                stroke="hsl(var(--border))"
                strokeWidth="0.5"
              />
            </pattern>
            <radialGradient id="heat-green">
              <stop offset="0%" stopColor="hsl(var(--secondary))" stopOpacity="0.4" />
              <stop offset="100%" stopColor="hsl(var(--secondary))" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="heat-red">
              <stop offset="0%" stopColor="hsl(var(--destructive))" stopOpacity="0.3" />
              <stop offset="100%" stopColor="hsl(var(--destructive))" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="600" height="400" fill="url(#imap-grid)" />
          {showHeatmap &&
            heatPoints.map((hp, i) => (
              <circle
                key={`heat-${i}`}
                cx={hp.x}
                cy={hp.y}
                r="40"
                fill={hp.color === 'green' ? 'url(#heat-green)' : 'url(#heat-red)'}
              />
            ))}
          {filters.routes &&
            data.matches.map((m, i) => {
              const prod = m.expand?.product_id || m.expand?.producer_id
              const buyer = m.expand?.buyer_id
              if (!prod || !buyer) return null
              const p1 = project(prod.latitude || 0, prod.longitude || 0)
              const p2 = project(buyer.latitude || 0, buyer.longitude || 0)
              return (
                <line
                  key={`route-${i}`}
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke="hsl(var(--accent))"
                  strokeWidth="2"
                  strokeDasharray="5,3"
                  opacity="0.5"
                />
              )
            })}
          {markers.map((p, i) => (
            <g key={`pt-${i}`}>
              <circle
                cx={p.x}
                cy={p.y}
                r={p.isCluster ? 14 : 10}
                fill={ROLE_COLORS[p.type]}
                opacity="0.2"
                className="animate-pulse"
              />
              <circle
                cx={p.x}
                cy={p.y}
                r={p.isCluster ? 8 : 5}
                fill={ROLE_COLORS[p.type]}
                stroke="white"
                strokeWidth="1.5"
              />
              {p.isCluster && (
                <text
                  x={p.x}
                  y={p.y + 3}
                  textAnchor="middle"
                  fontSize="9"
                  fontWeight="bold"
                  fill="white"
                >
                  {p.count}
                </text>
              )}
            </g>
          ))}
        </svg>
        <div className="absolute top-3 left-3 bg-card/90 backdrop-blur px-3 py-2 rounded-xl shadow-sm max-w-[70%]">
          <p className="text-xs font-bold text-primary flex items-center gap-1.5 mb-1">
            <Navigation2 className="w-3 h-3 text-secondary" /> Mapa de Inteligência
          </p>
          <div className="flex gap-1.5 flex-wrap">
            <FilterBtn k="producers" label="Produtores" color="hsl(var(--secondary))" />
            <FilterBtn k="buyers" label="Compradores" color="hsl(var(--accent))" />
            <FilterBtn k="transporters" label="Transport." color="hsl(var(--primary))" />
            <FilterBtn k="routes" label="Rotas" color="hsl(var(--accent))" />
          </div>
        </div>
        <button
          onClick={() => setShowHeatmap(!showHeatmap)}
          className="absolute top-3 right-3 bg-card/90 backdrop-blur px-3 py-2 rounded-xl shadow-sm text-xs font-bold text-primary hover:bg-card transition-colors"
          aria-pressed={showHeatmap}
          aria-label="Alternar mapa de calor"
        >
          <Filter className="w-3 h-3 inline mr-1" />
          {showHeatmap ? 'Ocultar Calor' : 'Mostrar Calor'}
        </button>
        <div className="absolute bottom-3 right-3 bg-card/90 backdrop-blur px-3 py-2 rounded-xl shadow-sm">
          <div className="flex gap-3 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-secondary/30" /> Alta Demanda
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-destructive/30" /> Excesso Oferta
            </span>
          </div>
        </div>
      </div>
    </Card>
  )
}
