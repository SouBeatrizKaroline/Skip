import { cn } from '@/lib/utils'

interface SmartScoreBadgeProps {
  score: number
  size?: 'sm' | 'md' | 'lg'
  showLabel?: boolean
}

export function SmartScoreBadge({ score, size = 'md', showLabel = true }: SmartScoreBadgeProps) {
  const colorClass =
    score >= 70 ? 'text-secondary' : score >= 40 ? 'text-accent' : 'text-destructive'
  const bgClass =
    score >= 70 ? 'bg-secondary/10' : score >= 40 ? 'bg-accent/10' : 'bg-destructive/10'
  const ringClass =
    score >= 70 ? 'ring-secondary/30' : score >= 40 ? 'ring-accent/30' : 'ring-destructive/30'
  const label = score >= 70 ? 'Excelente' : score >= 40 ? 'Moderado' : 'Crítico'
  const sizeClass =
    size === 'lg'
      ? 'w-24 h-24 text-3xl'
      : size === 'sm'
        ? 'w-14 h-14 text-lg'
        : 'w-20 h-20 text-2xl'
  const circumference = 2 * Math.PI * 42
  const offset = circumference - (score / 100) * circumference

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={cn(
          'relative rounded-full flex items-center justify-center font-bold ring-2',
          sizeClass,
          colorClass,
          ringClass,
          bgClass,
        )}
      >
        {size !== 'sm' && (
          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="currentColor"
              strokeWidth="6"
              opacity="0.1"
            />
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="currentColor"
              strokeWidth="6"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
              className="transition-all duration-700"
            />
          </svg>
        )}
        <span className="relative z-10">{score}</span>
      </div>
      {showLabel && <span className={cn('text-xs font-bold', colorClass)}>{label}</span>}
    </div>
  )
}
