import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Mail, MessageCircle, CheckCircle2, Send } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { NotificationPayload } from '@/services/notifications'

export function NotificationModal() {
  const [open, setOpen] = useState(false)
  const [payload, setPayload] = useState<NotificationPayload | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as NotificationPayload
      setPayload(detail)
      setOpen(true)
      toast({
        title: 'Notificações enviadas! 📢',
        description: `Simulação enviada para ${detail.email || detail.phone || 'destinatário'}`,
      })
    }
    window.addEventListener('destinai-notification', handler)
    return () => window.removeEventListener('destinai-notification', handler)
  }, [toast])

  if (!payload) return null

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-primary flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-secondary" />
            Notificações Simuladas
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="flex items-start gap-3 p-4 bg-muted rounded-2xl">
            <div className="bg-blue-500/10 p-2 rounded-full shrink-0">
              <Mail className="w-5 h-5 text-blue-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-primary">E-mail Simulado</p>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                Para: {payload.email || 'N/A'}
              </p>
              <p className="text-xs text-muted-foreground mt-2 bg-card p-2 rounded-lg">
                {payload.message}
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-secondary/5 border border-secondary/20 rounded-2xl">
            <div className="bg-secondary/10 p-2 rounded-full shrink-0">
              <Send className="w-5 h-5 text-secondary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-primary flex items-center gap-1.5">
                WhatsApp Enviado <CheckCircle2 className="w-3.5 h-3.5 text-secondary" />
              </p>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                Para: {payload.phone || 'N/A'}
              </p>
              <p className="text-xs text-muted-foreground mt-2 bg-card p-2 rounded-lg">
                {payload.message}
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
