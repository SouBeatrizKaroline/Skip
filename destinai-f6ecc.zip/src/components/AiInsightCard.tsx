import { Card } from '@/components/ui/card'
import { Sprout, Lightbulb, ArrowRight } from 'lucide-react'

const INSIGHTS: Record<string, { title: string; desc: string; recommendation: string }> = {
  MINOR_IMPERFECTIONS: {
    title: 'Altos níveis de beta-caroteno preservados',
    desc: 'Apesar do formato irregular, os nutrientes essenciais estão 100% intactos. A clorofila e os antioxidantes não são afetados pela aparência estética.',
    recommendation: 'Indústria de Sopas, Bancos de Alimentos',
  },
  NON_STANDARD: {
    title: 'Valor nutricional mantido — ideal para upcycling',
    desc: 'Produtos fora do padrão estético mantêm fibra, vitaminas e minerais. Perfeitos para transformação e aproveitamento integral (downcycling).',
    recommendation: 'Ração Animal, Compostagem, Processamento Industrial',
  },
  PROCESSING_ONLY: {
    title: 'Compostos fenólicos concentrados',
    desc: 'Produtos próximos ao vencimento concentram compostos bioativos. Excelentes para extração de nutrientes e processamento imediato.',
    recommendation: 'Indústria de Sucos, Polpas, Conservas',
  },
  RETAIL_STANDARD: {
    title: 'Excelente estado nutricional',
    desc: 'Produto em perfeito estado estético e nutricional, pronto para comercialização no varejo tradicional.',
    recommendation: 'Varejo, Restaurantes, Mercados',
  },
}

export function AiInsightCard({ visualCondition }: { visualCondition: string }) {
  const insight = INSIGHTS[visualCondition]
  if (!insight) return null

  return (
    <Card className="p-4 bg-secondary/5 border-secondary/20 rounded-2xl">
      <div className="flex gap-3">
        <div className="bg-secondary/20 p-2 rounded-full shrink-0 h-fit">
          <Sprout className="w-5 h-5 text-secondary" />
        </div>
        <div className="flex-1 space-y-2">
          <p className="font-bold text-sm text-primary flex items-center gap-1">
            <Lightbulb className="w-4 h-4 text-accent" />
            Insight Científico da Vivi 🌱
          </p>
          <p className="text-sm font-bold text-primary">{insight.title}</p>
          <p className="text-sm text-muted-foreground leading-relaxed">{insight.desc}</p>
          <div className="flex items-center gap-1.5 text-xs font-bold text-secondary bg-secondary/10 p-2 rounded-lg">
            <ArrowRight className="w-3 h-3 shrink-0" />
            <span>Destinos recomendados: {insight.recommendation}</span>
          </div>
        </div>
      </div>
    </Card>
  )
}
