import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { TrendingUp } from 'lucide-react'
import { getForecast } from '@/services/api'

export function DemandForecastWidget() {
  const [forecast, setForecast] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getForecast()
      .then(setForecast)
      .catch(() => setForecast(null))
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <Card className="p-5 rounded-2xl border-border shadow-subtle">
        <Skeleton className="h-6 w-48 mb-4" />
        <div className="grid grid-cols-3 gap-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      </Card>
    )
  }

  if (!forecast) return null

  const items = forecast.forecast || forecast.items || forecast.predictions || []
  if (!Array.isArray(items) || items.length === 0) return null

  return (
    <Card className="p-5 rounded-2xl border-border shadow-subtle bg-card">
      <div className="flex items-center gap-2 mb-4">
        <div className="bg-accent/10 p-1.5 rounded-lg">
          <TrendingUp className="w-4 h-4 text-accent" />
        </div>
        <h3 className="font-bold text-primary">Previsão de Demanda</h3>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {items.slice(0, 4).map((item: any, i: number) => (
          <div key={i} className="bg-muted/50 p-3 rounded-xl text-center">
            <p className="text-xs font-bold text-muted-foreground mb-1">
              {item.product || item.name || item.category || '—'}
            </p>
            <p className="text-lg font-bold text-primary">
              {item.demand_kg || item.quantity || item.predicted || '—'} kg
            </p>
            {item.trend && (
              <p
                className={`text-[10px] font-bold ${item.trend === 'up' ? 'text-secondary' : 'text-destructive'}`}
              >
                {item.trend === 'up' ? '↑' : '↓'} {item.change || ''}
              </p>
            )}
          </div>
        ))}
      </div>
    </Card>
  )
}
