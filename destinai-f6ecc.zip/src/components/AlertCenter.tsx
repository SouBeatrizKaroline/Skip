import { useState, useEffect, useMemo } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import {
  Bell,
  AlertTriangle,
  Info,
  CheckCircle,
  Sprout,
  Cloud,
  ShoppingBag,
  Truck,
  Target,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/use-auth'
import { getSmartAlerts, type SmartAlert } from '@/services/smart-score'

const URGENCY_CONFIG = {
  critical: {
    color: 'text-destructive',
    bg: 'bg-destructive/10',
    icon: AlertTriangle,
    label: 'Crítico',
  },
  warning: { color: 'text-accent', bg: 'bg-accent/10', icon: AlertTriangle, label: 'Atenção' },
  info: { color: 'text-secondary', bg: 'bg-secondary/10', icon: Info, label: 'Info' },
}

const CATEGORY_CONFIG: Record<string, { label: string; icon: typeof Cloud }> = {
  Climate: { label: 'Climate', icon: Cloud },
  Market: { label: 'Mercado', icon: ShoppingBag },
  Logistics: { label: 'Logística', icon: Truck },
  Opportunity: { label: 'Oportunidade', icon: Target },
}

function mapCategory(type: string): string {
  if (type === 'climate') return 'Climate'
  if (type === 'demand') return 'Market'
  if (type === 'expiry') return 'Logistics'
  if (type === 'match') return 'Opportunity'
  return 'Opportunity'
}

export function AlertCenter() {
  const { isAuthenticated } = useAuth()
  const [open, setOpen] = useState(false)
  const [alerts, setAlerts] = useState<SmartAlert[]>([])
  const [loading, setLoading] = useState(false)
  const [activeCategory, setActiveCategory] = useState('Todos')

  useEffect(() => {
    if (!isAuthenticated) return
    const fetchAlerts = () => {
      setLoading(true)
      getSmartAlerts()
        .then((res) => setAlerts(res.alerts || []))
        .catch(() => {})
        .finally(() => setLoading(false))
    }
    fetchAlerts()
    const interval = setInterval(fetchAlerts, 60000)
    return () => clearInterval(interval)
  }, [isAuthenticated])

  const categories = useMemo(() => {
    const cats = new Set(alerts.map((a) => mapCategory(a.type)))
    return ['Todos', ...Array.from(cats)]
  }, [alerts])

  const filteredAlerts = useMemo(() => {
    if (activeCategory === 'Todos') return alerts
    return alerts.filter((a) => mapCategory(a.type) === activeCategory)
  }, [alerts, activeCategory])

  if (!isAuthenticated) return null
  const criticalCount = alerts.filter((a) => a.urgency === 'critical').length

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button className="fixed bottom-20 right-4 z-40 w-12 h-12 rounded-full bg-primary text-white shadow-elevation flex items-center justify-center md:bottom-8 hover:scale-105 transition-transform">
          <Bell className="w-5 h-5" />
          {criticalCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-destructive text-white text-xs flex items-center justify-center font-bold">
              {criticalCount}
            </span>
          )}
        </button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-primary flex items-center gap-2">
            <Sprout className="w-5 h-5 text-secondary" /> Central de Alertas da Vivi 🌱
          </SheetTitle>
        </SheetHeader>
        <div className="flex gap-2 flex-wrap mt-4 mb-2">
          {categories.map((cat) => {
            const cfg = CATEGORY_CONFIG[cat]
            const isActive = activeCategory === cat
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1',
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'bg-muted text-muted-foreground hover:bg-primary/10',
                )}
              >
                {cfg && <cfg.icon className="w-3 h-3" />}
                {cat}
              </button>
            )
          })}
        </div>
        <div className="space-y-3 mt-2">
          {loading ? (
            <p className="text-center text-muted-foreground py-8">Carregando alertas...</p>
          ) : filteredAlerts.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-10 h-10 text-secondary mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                Tudo em ordem! Nenhum alerta no momento.
              </p>
            </div>
          ) : (
            filteredAlerts.map((alert, i) => {
              const cfg = URGENCY_CONFIG[alert.urgency] || URGENCY_CONFIG.info
              const cat = mapCategory(alert.type)
              const CatIcon = CATEGORY_CONFIG[cat]?.icon || Info
              return (
                <div key={i} className={cn('p-3 rounded-xl border', cfg.bg, 'border-border')}>
                  <div className="flex items-start gap-2">
                    <cfg.icon className={cn('w-4 h-4 shrink-0 mt-0.5', cfg.color)} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-bold text-sm text-primary">{alert.title}</p>
                        <div className="flex gap-1 shrink-0">
                          <Badge variant="outline" className={cn('text-xs', cfg.color)}>
                            {cfg.label}
                          </Badge>
                          <Badge variant="outline" className="text-xs text-muted-foreground">
                            <CatIcon className="w-3 h-3 mr-1" />
                            {cat}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{alert.message}</p>
                      <div className="flex items-start gap-1.5 mt-2 p-2 bg-secondary/5 rounded-lg">
                        <Sprout className="w-3 h-3 text-secondary shrink-0 mt-0.5" />
                        <p className="text-xs text-secondary italic">
                          Vivi Insight: {alert.message}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
