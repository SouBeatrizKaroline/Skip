import { CheckCircle2, XCircle } from 'lucide-react'
import { cn } from '@/lib/utils'

export function EconomicIndicator({
  netRevenue,
  lotValue,
}: {
  netRevenue: number
  lotValue: number
}) {
  const ratio = lotValue > 0 ? netRevenue / lotValue : 0
  const isPositive = netRevenue > 0 && ratio > 0.4

  return (
    <div
      className={cn(
        'flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm',
        isPositive
          ? 'bg-green-50 text-green-700 border border-green-200'
          : 'bg-red-50 text-red-700 border border-red-200',
      )}
    >
      {isPositive ? (
        <CheckCircle2 className="w-4 h-4 shrink-0" />
      ) : (
        <XCircle className="w-4 h-4 shrink-0" />
      )}
      {isPositive ? 'Operação Recomendada' : 'Operação Não Recomendada'}
    </div>
  )
}
