import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import {
  Cloud,
  CloudRain,
  Sun,
  CloudSun,
  AlertTriangle,
  Wind,
  Droplets,
  Loader2,
} from 'lucide-react'
import { getWeather } from '@/services/api'

interface WeatherData {
  city: string
  temperature: number | null
  humidity: number | null
  condition: string
  wind_speed: number | null
  alerts: string[]
}

export function WeatherWidget({ city, state }: { city: string; state?: string }) {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!city) {
      setLoading(false)
      return
    }
    getWeather(city, state)
      .then((data: any) => setWeather(data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [city, state])

  if (loading) {
    return (
      <Card className="p-4 rounded-2xl border-border shadow-subtle flex items-center gap-3">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Carregando clima...</span>
      </Card>
    )
  }

  if (!weather || weather.temperature === null) return null

  const Icon = weather.condition.includes('limpo')
    ? Sun
    : weather.condition.includes('Chuva') || weather.condition.includes('Tempestade')
      ? CloudRain
      : weather.condition.includes('nublado')
        ? CloudSun
        : Cloud

  return (
    <Card className="p-4 rounded-2xl border-border shadow-subtle">
      <div className="flex items-center gap-3 mb-2">
        <div className="bg-primary/10 p-2 rounded-xl">
          <Icon className="w-5 h-5 text-accent" />
        </div>
        <div>
          <p className="font-bold text-lg text-primary">{weather.temperature}°C</p>
          <p className="text-xs text-muted-foreground">
            {weather.condition} • {weather.city}
          </p>
        </div>
      </div>
      <div className="flex gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <Droplets className="w-3 h-3" /> {weather.humidity}%
        </span>
        {weather.wind_speed !== null && (
          <span className="flex items-center gap-1">
            <Wind className="w-3 h-3" /> {weather.wind_speed} km/h
          </span>
        )}
      </div>
      {weather.alerts.length > 0 && (
        <div className="mt-2 space-y-1">
          {weather.alerts.map((alert, i) => (
            <div
              key={i}
              className="flex items-start gap-1.5 text-xs text-accent bg-accent/10 p-2 rounded-lg"
            >
              <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
              <span>{alert}</span>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
