import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { forwardRef } from 'react'

interface FloatingInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string
  error?: string
}

export const FloatingInput = forwardRef<HTMLInputElement, FloatingInputProps>(
  ({ label, error, className, id, ...props }, ref) => {
    const inputId = id || `floating-${label.toLowerCase().replace(/\s/g, '-')}`
    return (
      <div className="relative">
        <Input
          ref={ref}
          id={inputId}
          placeholder=" "
          className={cn(
            'peer h-14 pt-4 px-4 bg-muted border-none rounded-xl',
            error && 'border-2 border-destructive/50',
            className,
          )}
          {...props}
        />
        <Label
          htmlFor={inputId}
          className="absolute left-4 top-4 text-muted-foreground transition-all pointer-events-none peer-focus:top-2 peer-focus:text-xs peer-focus:text-primary peer-[:not(:placeholder-shown)]:top-2 peer-[:not(:placeholder-shown)]:text-xs"
        >
          {label}
        </Label>
        {error && <p className="text-xs text-destructive mt-1">{error}</p>}
      </div>
    )
  },
)
FloatingInput.displayName = 'FloatingInput'
