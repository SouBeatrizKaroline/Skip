import { useState, useEffect, useCallback } from 'react'
import { Card } from '@/components/ui/card'
import { Sprout, RefreshCw } from 'lucide-react'
import { RecommendationCards } from '@/components/RecommendationCards'
import { useRealtime } from '@/hooks/use-realtime'
import {
  getProducerInsights,
  getBuyerInsights,
  getTransporterInsights,
  type ViviInsightData,
} from '@/services/vivi-insights'

interface ViviInsightPanelProps {
  role: string
  producerId?: string
  buyerId?: string
}

export function ViviInsightPanel({ role, producerId, buyerId }: ViviInsightPanelProps) {
  const [insights, setInsights] = useState<ViviInsightData | null>(null)
  const [loading, setLoading] = useState(true)

  const loadInsights = useCallback(async () => {
    try {
      let data: ViviInsightData
      if (role === 'PRODUCER' && producerId) {
        data = await getProducerInsights(producerId)
      } else if (role === 'BUYER' && buyerId) {
        data = await getBuyerInsights(buyerId)
      } else if (role === 'TRANSPORTER') {
        data = await getTransporterInsights()
      } else {
        setLoading(false)
        return
      }
      setInsights(data)
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [role, producerId, buyerId])

  useEffect(() => {
    loadInsights()
  }, [loadInsights])

  useRealtime('ai_analysis', () => loadInsights())
  useRealtime('matches', () => loadInsights())
  useRealtime('recommendations', () => loadInsights())

  return (
    <Card className="p-5 rounded-2xl border-secondary/20 bg-gradient-to-br from-secondary/5 to-transparent shadow-subtle">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="bg-secondary/15 p-2 rounded-lg">
            <Sprout className="w-5 h-5 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-primary">Vivi Insights 🌱</h3>
            <p className="text-xs text-muted-foreground">
              Recomendações inteligentes em tempo real
            </p>
          </div>
        </div>
        {loading && <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />}
      </div>
      {insights && <RecommendationCards insights={insights} />}
    </Card>
  )
}
