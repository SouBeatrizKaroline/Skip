import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { ShieldCheck, AlertCircle } from 'lucide-react'

export function ConfidenceBadge({ score }: { score: number }) {
  const isHigh = score >= 75
  const isMedium = score >= 50 && score < 75

  return (
    <Badge
      className={cn(
        'border-none font-bold flex items-center gap-1',
        isHigh
          ? 'bg-secondary/20 text-secondary'
          : isMedium
            ? 'bg-accent/20 text-accent'
            : 'bg-destructive/15 text-destructive',
      )}
    >
      {isHigh ? <ShieldCheck className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
      IA {score}% confiança
    </Badge>
  )
}
