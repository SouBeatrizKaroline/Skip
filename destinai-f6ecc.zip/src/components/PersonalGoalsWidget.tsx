import { useState, useEffect, useCallback } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Target, Plus } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useToast } from '@/hooks/use-toast'
import pb from '@/lib/pocketbase/client'
import { useRealtime } from '@/hooks/use-realtime'
import { GOAL_TYPE_LABELS, MONTHS } from '@/services/goals'

export function PersonalGoalsWidget() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [goals, setGoals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [goalType, setGoalType] = useState('KG_SAVED')
  const [target, setTarget] = useState('1000')

  const load = useCallback(async () => {
    if (!user) return
    try {
      const list = await pb
        .collection('user_goals')
        .getFullList({ filter: `user_id="${user.id}"`, sort: '-created' })
      setGoals(list)
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [user])

  useEffect(() => {
    load()
  }, [load])

  useRealtime('user_goals', () => load())
  useRealtime('impact_metrics', () => load())

  const handleSave = async () => {
    if (!user) return
    try {
      await pb.collection('user_goals').create({
        user_id: user.id,
        goal_type: goalType,
        target_value: parseFloat(target),
        current_value: 0,
        month: MONTHS[new Date().getMonth()],
      })
      toast({ title: 'Meta definida! 🎯' })
      setShowForm(false)
      load()
    } catch {
      toast({ title: 'Erro ao salvar meta', variant: 'destructive' })
    }
  }

  if (loading) return null

  return (
    <Card className="p-5 rounded-2xl border-border shadow-subtle">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-secondary" />
          <h3 className="font-bold text-primary">Metas Mensais</h3>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => setShowForm(!showForm)}
          className="text-secondary"
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      {showForm && (
        <div className="flex gap-2 mb-3">
          <Select value={goalType} onValueChange={setGoalType}>
            <SelectTrigger className="h-9 bg-muted border-none">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(GOAL_TYPE_LABELS).map(([k, v]) => (
                <SelectItem key={k} value={k}>
                  {v}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="number"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="h-9 bg-muted border-none w-24"
          />
          <Button size="sm" onClick={handleSave} className="bg-secondary text-white">
            OK
          </Button>
        </div>
      )}
      {goals.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">
          Defina sua primeira meta mensal! 🌱
        </p>
      ) : (
        <div className="space-y-3">
          {goals.map((g) => {
            const progress =
              g.target_value > 0
                ? Math.min(100, Math.round(((g.current_value || 0) / g.target_value) * 100))
                : 0
            return (
              <div key={g.id}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-primary">
                    {GOAL_TYPE_LABELS[g.goal_type] || g.goal_type}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {g.current_value || 0} / {g.target_value}
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-secondary rounded-full transition-all"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {progress}% • {g.month}
                </p>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
