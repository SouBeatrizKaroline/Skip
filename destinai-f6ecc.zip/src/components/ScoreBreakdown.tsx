import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'

interface ScoreBreakdownProps {
  compatibility: number
  economic: number
  logistics: number
  justification?: string
}

export function ScoreBreakdown({
  compatibility,
  economic,
  logistics,
  justification,
}: ScoreBreakdownProps) {
  const scores = [
    { label: 'Compatibilidade', score: compatibility, bg: 'bg-secondary', text: 'text-secondary' },
    { label: 'Econômico', score: economic, bg: 'bg-accent', text: 'text-accent' },
    { label: 'Logística', score: logistics, bg: 'bg-primary', text: 'text-primary' },
  ]

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        {scores.map((s) => (
          <Card key={s.label} className="p-3 text-center rounded-xl border-border">
            <p className={cn('text-2xl font-bold', s.text)}>{s.score}</p>
            <p className="text-[10px] text-muted-foreground font-bold mt-1">{s.label}</p>
            <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', s.bg)}
                style={{ width: `${s.score}%` }}
              />
            </div>
          </Card>
        ))}
      </div>
      {justification && (
        <div className="bg-secondary/5 border border-secondary/20 rounded-xl p-3">
          <p className="text-xs font-bold text-secondary mb-1">Vivi Insight 🌱</p>
          <p className="text-xs text-muted-foreground leading-relaxed">{justification}</p>
        </div>
      )}
    </div>
  )
}
