import { Card } from '@/components/ui/card'
import { TrendingUp, TrendingDown, Minus, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'

interface PriceIntelligenceComparisonProps {
  pricePerKg: number
  recommendedPriceRange?: string
  costPerKg?: number
  netRevenuePerKg?: number
}

export function PriceIntelligenceComparison({
  pricePerKg,
  recommendedPriceRange,
  costPerKg,
  netRevenuePerKg,
}: PriceIntelligenceComparisonProps) {
  const fmt = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`

  let rangeMin: number | null = null
  let rangeMax: number | null = null
  if (recommendedPriceRange) {
    const matches = recommendedPriceRange.match(/[\d,]+\.?\d*/g)
    if (matches && matches.length >= 2) {
      rangeMin = parseFloat(matches[0].replace(',', '.'))
      rangeMax = parseFloat(matches[1].replace(',', '.'))
    }
  }

  let position: 'below' | 'within' | 'above' | 'unknown' = 'unknown'
  if (rangeMin !== null && rangeMax !== null) {
    if (pricePerKg < rangeMin) position = 'below'
    else if (pricePerKg > rangeMax) position = 'above'
    else position = 'within'
  }

  const positionConfig = {
    below: {
      icon: TrendingDown,
      label: 'Abaixo do recomendado — potencial de aumento',
      color: 'text-destructive',
      bg: 'bg-destructive/10',
    },
    within: {
      icon: Minus,
      label: 'Dentro da faixa ideal de preço',
      color: 'text-secondary',
      bg: 'bg-secondary/10',
    },
    above: {
      icon: TrendingUp,
      label: 'Acima do recomendado — risco de baixa demanda',
      color: 'text-accent',
      bg: 'bg-accent/10',
    },
    unknown: {
      icon: Sparkles,
      label: 'Sem faixa de referência disponível',
      color: 'text-muted-foreground',
      bg: 'bg-muted',
    },
  }
  const cfg = positionConfig[position]
  const Icon = cfg.icon

  return (
    <Card className="p-5 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/5 to-transparent">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-4 h-4 text-secondary" />
        <p className="font-bold text-sm text-primary">Price Intelligence da Vivi</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
        <div className="bg-card p-3 rounded-xl border border-border text-center">
          <p className="text-xs text-muted-foreground font-bold mb-1">Seu Preço</p>
          <p className="font-bold text-primary">{fmt(pricePerKg || 0)}</p>
        </div>
        <div className="bg-card p-3 rounded-xl border border-border text-center">
          <p className="text-xs text-muted-foreground font-bold mb-1">Faixa Recomendada</p>
          <p className="font-bold text-secondary text-sm">{recommendedPriceRange || '—'}</p>
        </div>
        {costPerKg !== undefined && costPerKg > 0 && (
          <div className="bg-card p-3 rounded-xl border border-border text-center">
            <p className="text-xs text-muted-foreground font-bold mb-1">Custo/kg</p>
            <p className="font-bold text-muted-foreground">{fmt(costPerKg)}</p>
          </div>
        )}
        {netRevenuePerKg !== undefined && (
          <div className="bg-card p-3 rounded-xl border border-border text-center">
            <p className="text-xs text-muted-foreground font-bold mb-1">Lucro Líquido/kg</p>
            <p
              className={cn(
                'font-bold',
                (netRevenuePerKg || 0) > 0 ? 'text-secondary' : 'text-destructive',
              )}
            >
              {fmt(netRevenuePerKg || 0)}
            </p>
          </div>
        )}
      </div>
      <div className={cn('flex items-center gap-2 p-3 rounded-xl', cfg.bg)}>
        <Icon className={cn('w-4 h-4', cfg.color)} />
        <span className={cn('text-sm font-bold', cfg.color)}>{cfg.label}</span>
      </div>
    </Card>
  )
}
