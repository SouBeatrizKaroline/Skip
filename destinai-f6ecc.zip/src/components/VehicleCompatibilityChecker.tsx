import { Card } from '@/components/ui/card'
import { CheckCircle2, XCircle, Weight, Box, Snowflake } from 'lucide-react'
import { cn } from '@/lib/utils'

interface VehicleCompatibilityCheckerProps {
  vehicleCapacityKg: number
  vehicleCapacityM3: number
  vehicleRefrigeration: boolean
  lotWeightKg: number
  lotVolumeM3?: number
  lotNeedsRefrigeration?: boolean
}

export function VehicleCompatibilityChecker({
  vehicleCapacityKg,
  vehicleCapacityM3,
  vehicleRefrigeration,
  lotWeightKg,
  lotVolumeM3 = 0,
  lotNeedsRefrigeration = false,
}: VehicleCompatibilityCheckerProps) {
  const weightOk = vehicleCapacityKg >= lotWeightKg
  const volumeOk = vehicleCapacityM3 >= lotVolumeM3
  const refOk = !lotNeedsRefrigeration || vehicleRefrigeration
  const allOk = weightOk && volumeOk && refOk

  const checks = [
    {
      label: 'Capacidade (kg)',
      detail: `${vehicleCapacityKg} ≥ ${lotWeightKg}`,
      ok: weightOk,
      icon: Weight,
    },
    {
      label: 'Volume (m³)',
      detail: `${vehicleCapacityM3} ≥ ${lotVolumeM3}`,
      ok: volumeOk,
      icon: Box,
    },
    {
      label: 'Refrigeração',
      detail: lotNeedsRefrigeration
        ? vehicleRefrigeration
          ? 'Disponível'
          : 'Necessária'
        : 'Não requerida',
      ok: refOk,
      icon: Snowflake,
    },
  ]

  return (
    <Card
      className={cn(
        'p-4 rounded-2xl border',
        allOk ? 'border-secondary/20 bg-secondary/5' : 'border-destructive/20 bg-destructive/5',
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-bold text-sm text-primary">Compatibilidade do Veículo</h4>
        <span
          className={cn(
            'text-xs font-bold flex items-center gap-1',
            allOk ? 'text-secondary' : 'text-destructive',
          )}
        >
          {allOk ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
          {allOk ? 'Compatível' : 'Incompatível'}
        </span>
      </div>
      <div className="space-y-2">
        {checks.map((c, i) => (
          <div key={i} className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground flex items-center gap-2">
              <c.icon className="w-3.5 h-3.5" /> {c.label}
            </span>
            <span
              className={cn(
                'font-bold flex items-center gap-1',
                c.ok ? 'text-secondary' : 'text-destructive',
              )}
            >
              {c.ok ? (
                <CheckCircle2 className="w-3.5 h-3.5" />
              ) : (
                <XCircle className="w-3.5 h-3.5" />
              )}
              {c.detail}
            </span>
          </div>
        ))}
      </div>
    </Card>
  )
}
