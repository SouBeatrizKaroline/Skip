import { Card } from '@/components/ui/card'
import { TrendingUp, Package, Leaf, Droplets, Utensils } from 'lucide-react'

interface FinancialImpactCardProps {
  metrics: {
    kg_saved: number
    co2_saved_kg: number
    revenue_recovered: number
    water_preserved_liters?: number
    meals_generated?: number
  }
}

export function FinancialImpactCard({ metrics }: FinancialImpactCardProps) {
  const fmt = (v: number) => v.toLocaleString('pt-BR')
  const items = [
    {
      icon: TrendingUp,
      label: 'Receita Recuperada',
      value: `R$ ${fmt(metrics.revenue_recovered || 0)}`,
      color: 'text-accent',
      bg: 'bg-accent/10',
    },
    {
      icon: Package,
      label: 'Alimentos Salvos',
      value: `${fmt(metrics.kg_saved || 0)} kg`,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      icon: Utensils,
      label: 'Refeições Geradas',
      value: fmt(metrics.meals_generated || Math.round((metrics.kg_saved || 0) / 0.5)),
      color: 'text-secondary',
      bg: 'bg-secondary/10',
    },
    {
      icon: Leaf,
      label: 'CO₂ Evitado',
      value: `${fmt(metrics.co2_saved_kg || 0)} kg`,
      color: 'text-secondary',
      bg: 'bg-secondary/10',
    },
    {
      icon: Droplets,
      label: 'Água Preservada',
      value: `${fmt(metrics.water_preserved_liters || 0)} L`,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
  ]

  return (
    <Card className="p-6 rounded-[2rem] border-secondary/20 bg-gradient-to-br from-secondary/5 to-transparent shadow-subtle">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-5 h-5 text-secondary" />
        <h3 className="font-bold text-primary">Impacto Financeiro</h3>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {items.map((item, i) => (
          <div key={i} className="flex flex-col gap-2">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center ${item.bg}`}>
              <item.icon className={`w-4 h-4 ${item.color}`} />
            </div>
            <p className="text-lg font-bold text-primary">{item.value}</p>
            <p className="text-xs text-muted-foreground font-medium">{item.label}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
