import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Sparkles } from 'lucide-react'
import { getPriceIntelligence } from '@/services/price'

interface PriceRecommendationProps {
  name: string
  quantityKg: number
  visualCondition: string
  pricePerKg: number
  city?: string
  state?: string
}

export function PriceRecommendation({
  name,
  quantityKg,
  visualCondition,
  pricePerKg,
  city,
  state,
}: PriceRecommendationProps) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!name || !quantityKg || !visualCondition) return
    setLoading(true)
    getPriceIntelligence({
      name,
      quantity_kg: quantityKg,
      visual_condition: visualCondition,
      price_per_kg: pricePerKg,
      city,
      state,
    })
      .then(setData)
      .catch(() => setData(null))
      .finally(() => setLoading(false))
  }, [name, quantityKg, visualCondition, pricePerKg, city, state])

  if (loading) return <Skeleton className="h-24 rounded-2xl" />
  if (!data) return null

  const fmt = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`

  return (
    <Card className="p-4 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/5 to-transparent">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-4 h-4 text-secondary" />
        <p className="font-bold text-sm text-primary">Preço Recomendado pela Vivi</p>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="text-center">
          <p className="text-xs text-muted-foreground font-bold">Mínimo</p>
          <p className="font-bold text-destructive text-sm">{fmt(data.min_price)}</p>
        </div>
        <div className="text-center bg-secondary/10 rounded-lg py-1">
          <p className="text-xs text-secondary font-bold">Recomendado</p>
          <p className="font-bold text-secondary">{fmt(data.recommended_price)}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground font-bold">Ideal</p>
          <p className="font-bold text-secondary text-sm">{fmt(data.ideal_price)}</p>
        </div>
      </div>
      {data.analysis && (
        <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{data.analysis}</p>
      )}
    </Card>
  )
}
