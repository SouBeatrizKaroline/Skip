import { Crown, Star } from 'lucide-react'
import { cn } from '@/lib/utils'

export function PremiumBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 bg-gradient-to-r from-amber-400 to-orange-500 text-white px-2 py-0.5 rounded-md text-xs font-bold shadow-sm',
        className,
      )}
    >
      <Crown className="w-3 h-3" /> Premium
    </span>
  )
}

export function SponsoredBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 bg-accent/90 text-white px-2 py-0.5 rounded-md text-xs font-bold shadow-sm',
        className,
      )}
    >
      <Star className="w-3 h-3 fill-current" /> Destaque
    </span>
  )
}
