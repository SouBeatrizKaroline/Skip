import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CreditCard, Sparkles, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

interface CreditOpportunityAlertProps {
  user: any
  products: any[]
}

export function CreditOpportunityAlert({ user, products }: CreditOpportunityAlertProps) {
  const reputationScore = user?.reputation_score || 0
  const hasHighWasteRisk = products.some(
    (p) => p.waste_risk_level === 'HIGH' || p.waste_risk_level === 'CRITICAL',
  )
  const hasActiveLots = products.some(
    (p) => p.status === 'AVAILABLE' || p.status === 'NEGOTIATING' || p.status === 'MATCHED',
  )

  if (reputationScore < 100 || !hasHighWasteRisk || !hasActiveLots) return null

  return (
    <Card className="p-5 rounded-2xl border-secondary/30 bg-gradient-to-r from-secondary/10 to-transparent animate-fade-in-up">
      <div className="flex items-start gap-3">
        <div className="bg-secondary/20 p-2 rounded-full shrink-0">
          <CreditCard className="w-5 h-5 text-secondary" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-bold text-primary">Oportunidade de Crédito Detectada</h3>
            <Sparkles className="w-4 h-4 text-secondary" />
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Sua boa reputação ({reputationScore} pts) e lotes com alto risco de desperdício
            qualificam você para linhas de crédito especiais. Invista em armazenagem ou logística
            para salvar seus produtos!
          </p>
          <Button variant="secondary" size="sm" asChild className="rounded-full">
            <Link to="/credit">
              Ver linhas de crédito <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </Button>
        </div>
      </div>
    </Card>
  )
}
