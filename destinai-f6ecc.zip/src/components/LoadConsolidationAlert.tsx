import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Package, TrendingDown, Leaf, ChevronRight } from 'lucide-react'
import { getLoadConsolidation, type ConsolidationGroup } from '@/services/economic'

export function LoadConsolidationAlert() {
  const [groups, setGroups] = useState<ConsolidationGroup[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getLoadConsolidation()
      .then((res) => setGroups(res.consolidation_groups || []))
      .catch(() => setGroups([]))
      .finally(() => setLoading(false))
  }, [])

  if (loading || groups.length === 0) return null

  return (
    <Card className="p-5 rounded-2xl border-secondary/20 bg-gradient-to-r from-secondary/5 to-transparent">
      <div className="flex items-center gap-2 mb-3">
        <div className="bg-secondary/15 p-1.5 rounded-lg">
          <Package className="w-4 h-4 text-secondary" />
        </div>
        <h3 className="font-bold text-primary">Consolidação de Carga Detectada</h3>
      </div>
      <div className="space-y-3">
        {groups.slice(0, 2).map((group, i) => (
          <div
            key={i}
            className="flex items-center justify-between p-3 bg-card rounded-xl border border-border"
          >
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-primary truncate">
                {group.products.map((p) => p.name).join(', ')}
              </p>
              <p className="text-xs text-muted-foreground">
                {group.products.length} lotes • {group.total_kg} kg • {group.products[0]?.city}
              </p>
              <p className="text-xs text-secondary font-bold mt-0.5">
                A Vivi recomenda consolidar para economizar{' '}
                {((group.estimated_savings / group.total_value) * 100).toFixed(0)}%
              </p>
            </div>
            <div className="flex gap-3 shrink-0 items-center">
              <div className="text-center">
                <p className="text-xs font-bold text-secondary flex items-center gap-0.5">
                  <TrendingDown className="w-3 h-3" /> R$ {group.estimated_savings.toFixed(0)}
                </p>
                <p className="text-[10px] text-muted-foreground">Economia</p>
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-secondary flex items-center gap-0.5">
                  <Leaf className="w-3 h-3" /> {(group.total_kg * 1.5).toFixed(0)}kg
                </p>
                <p className="text-[10px] text-muted-foreground">CO₂ evitado</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
