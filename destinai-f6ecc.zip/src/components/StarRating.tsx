import { useState } from 'react'
import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { rateTransaction } from '@/services/ratings'

interface StarRatingProps {
  type: 'match' | 'order'
  recordId: string
  raterRole: string
  initialRating?: number
  size?: 'sm' | 'md' | 'lg'
}

export function StarRating({
  type,
  recordId,
  raterRole,
  initialRating = 0,
  size = 'md',
}: StarRatingProps) {
  const [rating, setRating] = useState(initialRating)
  const [hover, setHover] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  const sizeClass = size === 'lg' ? 'w-8 h-8' : size === 'sm' ? 'w-4 h-4' : 'w-6 h-6'

  const handleClick = async (value: number) => {
    if (submitting || (initialRating > 0 && initialRating === rating)) return
    setSubmitting(true)
    try {
      await rateTransaction({ type, id: recordId, rating: value, rater_role: raterRole })
      setRating(value)
      toast({ title: 'Avaliação enviada!', description: 'Obrigado pelo seu feedback.' })
    } catch {
      toast({ title: 'Erro', description: 'Não foi possível enviar a avaliação.' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={() => handleClick(star)}
          onMouseEnter={() => setHover(star)}
          onMouseLeave={() => setHover(0)}
          disabled={submitting}
          className="transition-transform hover:scale-110 disabled:opacity-50"
        >
          <Star
            className={cn(
              sizeClass,
              (hover || rating) >= star
                ? 'fill-accent text-accent'
                : 'fill-muted text-muted-foreground',
            )}
          />
        </button>
      ))}
      {rating > 0 && (
        <span className="ml-2 text-sm font-bold text-muted-foreground">{rating.toFixed(1)}</span>
      )}
    </div>
  )
}
