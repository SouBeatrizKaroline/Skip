import { cn } from '@/lib/utils'
import { Zap } from 'lucide-react'

interface PriorityBadgeProps {
  tier?: string
  size?: 'sm' | 'md'
}

export function PriorityBadge({ tier, size = 'sm' }: PriorityBadgeProps) {
  if (!tier || (tier !== 'GOLD' && tier !== 'DIAMOND')) return null

  const sizeClass = size === 'sm' ? 'text-xs px-2 py-1' : 'text-sm px-3 py-1.5'
  const iconSize = size === 'sm' ? 'w-3 h-3' : 'w-4 h-4'

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-bold border animate-fade-in',
        tier === 'DIAMOND'
          ? 'text-cyan-600 bg-cyan-50 border-cyan-200'
          : 'text-yellow-600 bg-yellow-50 border-yellow-200',
        sizeClass,
      )}
    >
      <Zap className={iconSize} />
      Prioridade
    </span>
  )
}
