import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { MapPin } from 'lucide-react'
import { fetchRecentProducts } from '@/services/landing'
import { toDisplayProduct } from '@/services/products'
import { WasteRiskBadge } from '@/components/WasteRiskBadge'
import { SmartScoreBadge } from '@/components/SmartScoreBadge'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'

const MOCK_BATCHES = [
  {
    id: 'm1',
    name: 'Tomate',
    quantity_kg: 200,
    price_per_kg: 2.5,
    visual_condition: 'NON_STANDARD',
    waste_risk_level: 'HIGH',
    estimated_life_days: 3,
    city: 'Petrolina',
    state: 'PE',
    harvest_date: '2026-07-10',
    expand: { producer_id: { farm_name: 'Fazenda Sol Nascente' } },
  },
  {
    id: 'm2',
    name: 'Cenoura',
    quantity_kg: 150,
    price_per_kg: 2.8,
    visual_condition: 'MINOR_IMPERFECTIONS',
    waste_risk_level: 'MEDIUM',
    estimated_life_days: 7,
    city: 'Holambra',
    state: 'SP',
    harvest_date: '2026-07-11',
    expand: { producer_id: { farm_name: 'Sítio Boa Vista' } },
  },
  {
    id: 'm3',
    name: 'Banana',
    quantity_kg: 300,
    price_per_kg: 1.9,
    visual_condition: 'RETAIL_STANDARD',
    waste_risk_level: 'LOW',
    estimated_life_days: 10,
    city: 'Mogi Guaçu',
    state: 'SP',
    harvest_date: '2026-07-09',
    expand: { producer_id: { farm_name: 'Agro Vale' } },
  },
  {
    id: 'm4',
    name: 'Alface',
    quantity_kg: 50,
    price_per_kg: 3.2,
    visual_condition: 'RETAIL_STANDARD',
    waste_risk_level: 'CRITICAL',
    estimated_life_days: 2,
    city: 'Campinas',
    state: 'SP',
    harvest_date: '2026-07-12',
    expand: { producer_id: { farm_name: 'Horta Verde' } },
  },
]

export function ActiveBatchesShowcase() {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { isAuthenticated } = useAuth()

  const load = async () => {
    const data = await fetchRecentProducts()
    setProducts(data.length > 0 ? data : MOCK_BATCHES)
    setLoading(false)
  }

  useEffect(() => {
    load()
  }, [])
  useRealtime('products', load, isAuthenticated)

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-64 rounded-2xl" />
        ))}
      </div>
    )
  }

  const display = products.slice(0, 8).map(toDisplayProduct)

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {display.map((p) => (
        <Card
          key={p.id}
          className="overflow-hidden rounded-2xl hover:shadow-elevation transition-shadow group"
        >
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={p.image}
              alt={`Lote de ${p.name} - ${p.qty}`}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute top-2 left-2">
              <WasteRiskBadge level={p.wasteRiskLevel} />
            </div>
            <div className="absolute top-2 right-2">
              <SmartScoreBadge score={p.smartScore || 50} size="sm" showLabel={false} />
            </div>
          </div>
          <div className="p-3 space-y-1.5">
            <h4 className="font-bold text-sm text-primary truncate">{p.name}</h4>
            <p className="text-xs text-muted-foreground flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3 shrink-0" /> {p.distance}
            </p>
            <div className="flex items-center justify-between pt-1">
              <span className="text-sm font-bold text-accent">{p.price}</span>
              <span className="text-xs text-muted-foreground">{p.qty}</span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
