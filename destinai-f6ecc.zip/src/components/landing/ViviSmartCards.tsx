import { Card } from '@/components/ui/card'
import { AlertTriangle, TrendingUp, Truck, Sparkles } from 'lucide-react'

const SMART_CARDS = [
  {
    emoji: '🌱',
    icon: AlertTriangle,
    type: 'Alerta de Risco',
    title: '5 toneladas de tomate em Petrolina',
    detail:
      'Janela de validade de 48h detectada. Ação imediata recomendada para evitar perda total do lote.',
    accent: 'text-destructive',
    bg: 'bg-destructive/5',
    border: 'border-destructive/20',
  },
  {
    emoji: '💰',
    icon: TrendingUp,
    type: 'Inteligência de Preço',
    title: 'Preços da banana subiram 15%',
    detail:
      'Em sua região, o preço médio da banana aumentou esta semana. Momento ideal para negociar excedentes.',
    accent: 'text-accent',
    bg: 'bg-accent/5',
    border: 'border-accent/20',
  },
  {
    emoji: '🚛',
    icon: Truck,
    type: 'Match Logístico',
    title: 'Caminhão de retorno disponível',
    detail:
      'Encontrado um caminhão com trajeto de retorno compatível com sua rota. Economia de até 40% no frete.',
    accent: 'text-primary',
    bg: 'bg-primary/5',
    border: 'border-primary/20',
  },
]

export function ViviSmartCards() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-6">
        {SMART_CARDS.map((card, i) => (
          <Card
            key={i}
            className={`p-5 rounded-2xl ${card.bg} ${card.border} border hover:shadow-elevation transition-shadow animate-fade-in-up`}
            style={{ animationDelay: `${i * 0.15}s` }}
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl" role="img" aria-label={card.type}>
                {card.emoji}
              </span>
              <div className={`flex items-center gap-1 text-xs font-bold ${card.accent}`}>
                <card.icon className="w-3.5 h-3.5" />
                {card.type}
              </div>
            </div>
            <h4 className="font-bold text-primary mb-2">{card.title}</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">{card.detail}</p>
          </Card>
        ))}
      </div>
      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Sparkles className="w-4 h-4 text-secondary" />
        <span>
          Insights em tempo real gerados pela <strong className="text-primary">Vivi</strong> 🌱 —
          sua consultora de IA agrícola
        </span>
      </div>
    </div>
  )
}
