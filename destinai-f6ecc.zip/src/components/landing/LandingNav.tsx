import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Leaf, Store, Truck, BarChart3, LogIn, Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip'

const NAV_LINKS = [
  {
    to: '/opportunities',
    icon: Store,
    label: 'Marketplace',
    tip: 'Explore excedentes disponíveis',
  },
  { to: '/logistics', icon: Truck, label: 'Logística', tip: 'Rotas e transportadores' },
  { to: '/impact', icon: BarChart3, label: 'Impacto', tip: 'Métricas de impacto ESG' },
]

export function LandingNav() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 w-full bg-card/80 backdrop-blur-lg border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
        <Link
          to="/"
          className="flex items-center gap-2 font-bold text-lg text-primary cursor-pointer"
        >
          <div className="bg-primary/10 p-1.5 rounded-lg">
            <Leaf className="w-5 h-5 text-primary" />
          </div>
          Destin<span className="text-secondary">AI</span>
        </Link>

        <div className="hidden md:flex items-center gap-6">
          {NAV_LINKS.map((link) => (
            <Tooltip key={link.to}>
              <TooltipTrigger asChild>
                <Link
                  to={link.to}
                  className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5"
                >
                  <link.icon className="w-4 h-4" /> {link.label}
                </Link>
              </TooltipTrigger>
              <TooltipContent>{link.tip}</TooltipContent>
            </Tooltip>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link to="/login">
              <LogIn className="w-4 h-4 mr-1" /> Entrar
            </Link>
          </Button>
          <Button asChild size="sm" className="rounded-full">
            <Link to="/onboarding">Participar</Link>
          </Button>
        </div>

        <button
          className="md:hidden p-2 text-primary rounded-lg hover:bg-muted transition-colors"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Abrir menu"
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-card animate-fade-in-down">
          <div className="px-4 py-4 space-y-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-primary hover:bg-muted transition-colors"
              >
                <link.icon className="w-4 h-4" /> {link.label}
              </Link>
            ))}
            <div className="pt-2 flex flex-col gap-2">
              <Button
                asChild
                variant="outline"
                size="sm"
                className="w-full rounded-full"
                onClick={() => setMobileOpen(false)}
              >
                <Link to="/login">
                  <LogIn className="w-4 h-4 mr-1" /> Entrar
                </Link>
              </Button>
              <Button
                asChild
                size="sm"
                className="w-full rounded-full"
                onClick={() => setMobileOpen(false)}
              >
                <Link to="/onboarding">Participar</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
