import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Navigation2, MapPin } from 'lucide-react'
import { fetchEcosystemLocations } from '@/services/landing'
import { computeBounds, toXY, clusterMarkers } from '@/lib/map-utils'

const ROLE_COLORS: Record<string, string> = {
  producer: 'hsl(var(--secondary))',
  buyer: 'hsl(var(--accent))',
  primary: 'hsl(var(--primary))',
}

export function EcosystemMapSnapshot() {
  const [data, setData] = useState<{ producers: any[]; buyers: any[]; transporters: any[] } | null>(
    null,
  )
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchEcosystemLocations().then((d) => {
      setData(d)
      setLoading(false)
    })
  }, [])

  if (loading) return <Skeleton className="h-80 md:h-96 w-full rounded-3xl" />
  if (!data) return null

  const allCoords = [
    ...data.producers.map((p) => ({ lat: p.latitude || 0, lon: p.longitude || 0 })),
    ...data.buyers.map((b) => ({ lat: b.latitude || 0, lon: b.longitude || 0 })),
    ...data.transporters.map((t) => ({ lat: t.latitude || 0, lon: t.longitude || 0 })),
  ].filter((c) => c.lat !== 0 || c.lon !== 0)

  if (allCoords.length === 0) {
    return (
      <Card className="p-0 rounded-3xl overflow-hidden">
        <div className="h-80 flex flex-col items-center justify-center text-muted-foreground gap-2">
          <MapPin className="w-8 h-8 text-secondary" />
          <p>Mapa em construção — participantes estão se cadastrando!</p>
        </div>
      </Card>
    )
  }

  const bounds = computeBounds(allCoords)
  const project = (lat: number, lon: number) => toXY(lat, lon, bounds)
  const markers = clusterMarkers(
    [
      ...data.producers.map((p) => ({
        ...project(p.latitude || 0, p.longitude || 0),
        type: 'producer',
      })),
      ...data.buyers.map((b) => ({ ...project(b.latitude || 0, b.longitude || 0), type: 'buyer' })),
      ...data.transporters.map((t) => ({
        ...project(t.latitude || 0, t.longitude || 0),
        type: 'primary',
      })),
    ].filter((m) => m.x >= 0 && m.y >= 0),
  )

  return (
    <Card className="p-0 rounded-3xl overflow-hidden shadow-subtle">
      <div className="relative h-80 md:h-96 bg-muted">
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 600 400"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <pattern id="eco-grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path
                d="M 30 0 L 0 0 0 30"
                fill="none"
                stroke="hsl(var(--border))"
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="600" height="400" fill="url(#eco-grid)" />
          {markers.map((m, i) => (
            <g key={`m-${i}`}>
              <circle
                cx={m.x}
                cy={m.y}
                r={m.isCluster ? 14 : 10}
                fill={ROLE_COLORS[m.type]}
                opacity="0.2"
                className="animate-pulse"
              />
              <circle
                cx={m.x}
                cy={m.y}
                r={m.isCluster ? 8 : 5}
                fill={ROLE_COLORS[m.type]}
                stroke="white"
                strokeWidth="1.5"
              />
              {m.isCluster && (
                <text
                  x={m.x}
                  y={m.y + 3}
                  textAnchor="middle"
                  fontSize="9"
                  fontWeight="bold"
                  fill="white"
                >
                  {m.count}
                </text>
              )}
            </g>
          ))}
        </svg>
        <div className="absolute top-3 left-3 bg-card/90 backdrop-blur px-3 py-2 rounded-xl shadow-sm">
          <p className="text-xs font-bold text-primary flex items-center gap-1.5">
            <Navigation2 className="w-3 h-3 text-secondary" /> Ecossistema Ativo
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">
            {allCoords.length} participantes no mapa
          </p>
        </div>
        <div className="absolute bottom-3 left-3 flex gap-2 text-[10px] flex-wrap">
          <span className="flex items-center gap-1 bg-card/90 px-2 py-1 rounded-lg shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-secondary" /> Produtores
          </span>
          <span className="flex items-center gap-1 bg-card/90 px-2 py-1 rounded-lg shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-accent" /> Compradores
          </span>
          <span className="flex items-center gap-1 bg-card/90 px-2 py-1 rounded-lg shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-primary" /> Transport.
          </span>
        </div>
      </div>
    </Card>
  )
}
