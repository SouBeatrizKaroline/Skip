import { useState, useEffect, useRef } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { Leaf, CloudOff, DollarSign, Utensils, Droplets } from 'lucide-react'
import { fetchLandingStats, type LandingImpactStats } from '@/services/landing'
import { useRealtime } from '@/hooks/use-realtime'
import { useAuth } from '@/hooks/use-auth'

function useCountUp(target: number, duration = 1500) {
  const [value, setValue] = useState(0)
  const rafRef = useRef<number>(0)
  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setValue(target * eased)
      if (progress < 1) rafRef.current = requestAnimationFrame(animate)
    }
    rafRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(rafRef.current)
  }, [target, duration])
  return value
}

function formatNumber(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return Math.round(n).toLocaleString('pt-BR')
}

function CounterItem({
  icon: Icon,
  value,
  label,
  color,
}: {
  icon: typeof Leaf
  value: number
  label: string
  color: string
}) {
  const animated = useCountUp(value)
  return (
    <div className="flex flex-col items-center text-center">
      <div className={`${color} mb-2`}>
        <Icon className="w-7 h-7" />
      </div>
      <p className="text-3xl md:text-4xl font-bold text-primary-foreground tabular-nums">
        {formatNumber(animated)}
      </p>
      <p className="text-sm text-primary-foreground/70 mt-1">{label}</p>
    </div>
  )
}

export function ImpactCounter() {
  const [stats, setStats] = useState<LandingImpactStats | null>(null)
  const { isAuthenticated } = useAuth()

  useEffect(() => {
    fetchLandingStats().then(setStats)
  }, [])

  const reload = () => fetchLandingStats().then(setStats)
  useRealtime('impact_metrics', reload, isAuthenticated)
  useRealtime('products', reload, isAuthenticated)
  useRealtime('matches', reload, isAuthenticated)

  if (!stats) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 max-w-5xl mx-auto">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-6 max-w-5xl mx-auto">
      <CounterItem
        icon={Leaf}
        value={stats.kgSaved}
        label="Kg reaproveitados"
        color="text-secondary"
      />
      <CounterItem
        icon={CloudOff}
        value={stats.co2Saved}
        label="CO₂ evitado (kg)"
        color="text-secondary"
      />
      <CounterItem
        icon={DollarSign}
        value={stats.revenueRecovered}
        label="Receita recuperada"
        color="text-accent"
      />
      <CounterItem
        icon={Utensils}
        value={stats.mealsGenerated}
        label="Refeições geradas"
        color="text-primary-foreground"
      />
      <CounterItem
        icon={Droplets}
        value={stats.waterPreserved}
        label="Litros de água"
        color="text-primary-foreground"
      />
    </div>
  )
}
