import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { TrendingUp, Users, Leaf, Package, DollarSign, Percent } from 'lucide-react'
import { fetchLandingStats, type LandingImpactStats } from '@/services/landing'

export function InvestorSection() {
  const [stats, setStats] = useState<LandingImpactStats | null>(null)
  useEffect(() => {
    fetchLandingStats().then(setStats)
  }, [])

  const metrics = stats
    ? [
        {
          icon: Users,
          label: 'Produtores Ativos',
          value: stats.producerCount.toLocaleString('pt-BR'),
          color: 'text-primary',
        },
        {
          icon: Users,
          label: 'Compradores Conectados',
          value: stats.buyerCount.toLocaleString('pt-BR'),
          color: 'text-primary',
        },
        {
          icon: Users,
          label: 'Transportadores',
          value: stats.transporterCount.toLocaleString('pt-BR'),
          color: 'text-primary',
        },
        {
          icon: Package,
          label: 'Lotes Processados',
          value: stats.productCount.toLocaleString('pt-BR'),
          color: 'text-accent',
        },
        {
          icon: Leaf,
          label: 'Kg Salvos do Desperdício',
          value: `${stats.kgSaved.toLocaleString('pt-BR')} kg`,
          color: 'text-secondary',
        },
        {
          icon: DollarSign,
          label: 'Receita Recuperada',
          value: `R$ ${stats.revenueRecovered.toLocaleString('pt-BR')}`,
          color: 'text-accent',
        },
      ]
    : []

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {!stats
          ? [1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-28 rounded-2xl" />)
          : metrics.map((m, i) => (
              <Card key={i} className="p-4 rounded-2xl">
                <m.icon className={`w-5 h-5 ${m.color} mb-2`} />
                <p className="text-2xl font-bold text-primary">{m.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{m.label}</p>
              </Card>
            ))}
      </div>
      <Card className="p-5 rounded-2xl bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
        <div className="flex items-start gap-3">
          <div className="bg-primary/10 p-2.5 rounded-xl shrink-0">
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-primary">Infraestrutura Digital para o Agronegócio</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              DestinAI opera como infraestrutura digital para a comercialização agrícola, conectando
              toda a cadeia produtiva. Nossa tecnologia reduz desperdício na origem, otimiza
              logística e maximiza o valor de cada lote.
            </p>
            <div className="flex gap-4 pt-2 flex-wrap">
              <div className="flex items-center gap-1.5 text-sm">
                <Percent className="w-4 h-4 text-accent" />
                <span className="text-muted-foreground">Take-rate competitivo</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <Leaf className="w-4 h-4 text-secondary" />
                <span className="text-muted-foreground">Impacto ESG mensurável</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
