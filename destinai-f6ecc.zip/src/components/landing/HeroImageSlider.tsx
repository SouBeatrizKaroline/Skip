import { useState, useEffect, useMemo } from 'react'
import { Leaf } from 'lucide-react'
import { cn } from '@/lib/utils'

const VEGETABLE_IMAGES = [
  'https://img.usecurling.com/p/800/800?q=fresh%20carrots%20harvest&color=orange&dpr=2',
  'https://img.usecurling.com/p/800/800?q=ripe%20red%20tomatoes&color=red&dpr=2',
  'https://img.usecurling.com/p/800/800?q=fresh%20potatoes%20harvest&color=yellow&dpr=2',
  'https://img.usecurling.com/p/800/800?q=green%20zucchini%20vegetable&color=green&dpr=2',
  'https://img.usecurling.com/p/800/800?q=fresh%20harvest%20vegetables%20basket&color=green&dpr=2',
  'https://img.usecurling.com/p/800/800?q=vegetable%20plantation%20farm%20field&color=green&dpr=2',
  'https://img.usecurling.com/p/800/800?q=greenhouse%20organic%20farming&color=green&dpr=2',
  'https://img.usecurling.com/p/800/800?q=fresh%20greens%20market%20stall&color=green&dpr=2',
]

const FALLBACK_IMAGE =
  'https://img.usecurling.com/p/800/800?q=green%20leaves%20nature%20harvest&color=green&dpr=2'

type LoadState = 'loading' | 'loaded' | 'error'

export function HeroImageSlider() {
  const selectedImage = useMemo(
    () => VEGETABLE_IMAGES[Math.floor(Math.random() * VEGETABLE_IMAGES.length)],
    [],
  )

  const [imageState, setImageState] = useState<LoadState>('loading')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="relative aspect-square w-full max-w-[320px] sm:max-w-[380px] lg:max-w-[440px] mx-auto">
      <div className="absolute inset-0 rounded-full bg-secondary/5 animate-pulse" />

      {imageState === 'loading' && (
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 flex items-center justify-center z-10">
          <Leaf className="w-12 h-12 text-primary/30 animate-bounce-subtle" />
        </div>
      )}

      <div className="absolute inset-0 rounded-full overflow-hidden bg-gradient-to-br from-primary/5 to-secondary/5 shadow-2xl">
        <img
          src={imageState === 'error' ? FALLBACK_IMAGE : selectedImage}
          alt="Cena agrícola: hortaliças e produção rural"
          loading="eager"
          onLoad={() => setImageState('loaded')}
          onError={() => setImageState('error')}
          style={{ objectFit: 'cover', objectPosition: 'center' }}
          className={cn(
            'absolute inset-0 h-full w-full transition-opacity duration-500 ease-in-out',
            imageState === 'loaded' || imageState === 'error' ? 'opacity-100' : 'opacity-0',
            (imageState === 'loaded' || imageState === 'error') && mounted && 'animate-fade-in',
          )}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/20 via-transparent to-transparent pointer-events-none" />
      </div>
    </div>
  )
}
