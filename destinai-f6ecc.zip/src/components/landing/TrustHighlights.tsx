import { Card } from '@/components/ui/card'
import { ShieldCheck, Star, BadgeCheck, TrendingUp } from 'lucide-react'
import { ReputationBadge } from '@/components/ReputationBadge'

const TRUST_FEATURES = [
  {
    icon: ShieldCheck,
    title: 'Transações Seguras',
    desc: 'Sistema de reputação baseado em avaliações reais entre produtores, compradores e transportadores.',
  },
  {
    icon: BadgeCheck,
    title: 'Perfis Verificados',
    desc: 'Documentação validada e selos de confiança para todos os participantes da rede.',
  },
  {
    icon: Star,
    title: 'Sistema de Pontos',
    desc: 'Cada negociação concluída acumula pontos que desbloqueiam benefícios e melhores taxas.',
  },
  {
    icon: TrendingUp,
    title: 'Reputação Transparente',
    desc: 'Histórico público de negociações, avaliações e métricas de impacto de cada participante.',
  },
]

export function TrustHighlights() {
  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {TRUST_FEATURES.map((f, i) => (
          <Card
            key={i}
            className="p-5 rounded-2xl hover:shadow-elevation transition-shadow animate-fade-in-up"
            style={{ animationDelay: `${i * 0.1}s` }}
          >
            <div className="bg-primary/10 p-2.5 rounded-xl w-fit mb-3">
              <f.icon className="w-5 h-5 text-primary" />
            </div>
            <h4 className="font-bold text-primary mb-1.5">{f.title}</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
          </Card>
        ))}
      </div>
      <div className="flex flex-wrap items-center justify-center gap-3 p-4 bg-card rounded-2xl border border-border">
        <span className="text-sm font-bold text-muted-foreground mr-2">Níveis de Reputação:</span>
        <ReputationBadge tier="BRONZE" score={120} />
        <ReputationBadge tier="SILVER" score={280} />
        <ReputationBadge tier="GOLD" score={450} />
        <ReputationBadge tier="DIAMOND" score={720} />
      </div>
    </div>
  )
}
