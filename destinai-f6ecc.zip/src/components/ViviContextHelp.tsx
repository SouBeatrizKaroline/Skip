import { Card } from '@/components/ui/card'
import { Sprout } from 'lucide-react'

const TIPS: { keywords: string[]; tip: string }[] = [
  {
    keywords: ['foto', 'imagem', 'câmera', 'upload', 'nítida', 'iluminação'],
    tip: 'Cadastre fotos nítidas e com boa iluminação. Mostre algumas unidades em destaque para ajudar a IA a avaliar manchas e imperfeições.',
  },
  {
    keywords: ['comprador', 'comprar', 'oportunidade', 'buscar', 'hortaliça'],
    tip: 'Como comprador, filtre por distância e condição visual. Lotes com pequenas imperfeições costumam ter o melhor custo-benefício e qualidade nutricional equivalente.',
  },
  {
    keywords: ['produtor', 'excedente', 'cadastrar', 'lote', 'colheita'],
    tip: 'Cadastre seu excedente com precisão. A IA encontra o melhor destino baseado na condição visual, quantidade e localização. Produtos com imperfeições têm grande demanda na indústria!',
  },
  {
    keywords: ['negocia', 'proposta', 'preço', 'valor', 'doar'],
    tip: 'Ao negociar, considere que produtos fora do padrão estético mantêm 100% do valor nutricional. Use isso como argumento para justificar o preço justo.',
  },
  {
    keywords: ['logística', 'transporte', 'coleta', 'entrega', 'rota'],
    tip: 'O planejamento logístico eficiente reduz custos e desperdício. Agrupe coletas próximas e mantenha o veículo refrigerado para preservar a qualidade.',
  },
]

function findTip(context: string): string {
  const lower = context.toLowerCase()
  for (const t of TIPS) {
    if (t.keywords.some((k) => lower.includes(k))) return t.tip
  }
  return 'Cadastre seus excedentes com fotos nítidas e dados precisos. A Vivi 🌱 encontra o melhor destino para cada lote, maximizando valor e reduzindo desperdício.'
}

export function ViviContextHelp({ context }: { context: string }) {
  const tip = findTip(context)
  return (
    <Card className="p-4 bg-secondary/5 border-secondary/20 rounded-2xl">
      <div className="flex gap-3">
        <div className="bg-secondary/20 p-2 rounded-full shrink-0 h-fit">
          <Sprout className="w-5 h-5 text-secondary" />
        </div>
        <div className="flex-1">
          <p className="font-bold text-sm text-primary mb-1">Dica da Vivi 🌱</p>
          <p className="text-sm text-muted-foreground leading-relaxed">{tip}</p>
        </div>
      </div>
    </Card>
  )
}
