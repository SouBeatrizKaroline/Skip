import { Link } from 'react-router-dom'
import {
  Leaf as LeafIcon,
  Bell as BellIcon,
  LogOut as LogOutIcon,
  MessageSquare,
  CheckCheck,
  Trash2,
} from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useNotifications } from '@/hooks/use-notifications'
import { ProfileAvatar } from '@/components/ProfileAvatar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'

export function Header({ isPublic }: { isPublic: boolean }) {
  const { signOut, user } = useAuth()
  const { notifications, unreadCount, markAllRead, clearAll } = useNotifications()

  return (
    <header className="fixed top-0 inset-x-0 h-[calc(4rem+env(safe-area-inset-top))] pt-safe overflow-hidden bg-card/90 backdrop-blur-md border-b border-border z-50 flex items-center justify-between px-4 md:px-8 shadow-sm">
      <Link
        to="/"
        className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity cursor-pointer"
      >
        <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
          <LeafIcon className="w-5 h-5 fill-current" />
        </div>
        <span className="font-bold text-xl tracking-tight">DestinAI</span>
      </Link>

      {!isPublic && (
        <div className="flex items-center gap-3">
          <button
            onClick={() => window.dispatchEvent(new Event('open-vivi-chat'))}
            className="p-2 text-muted-foreground hover:bg-muted rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            title="Chat com a Vivi"
            aria-label="Abrir chat com a Vivi"
          >
            <MessageSquare className="w-5 h-5" />
          </button>
          <Popover>
            <PopoverTrigger asChild>
              <button
                className="relative p-2 text-muted-foreground hover:bg-muted rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={`Notificações${unreadCount > 0 ? `, ${unreadCount} não lidas` : ''}`}
              >
                <BellIcon className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-accent text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1 border-2 border-card">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="p-3 border-b border-border flex items-center justify-between">
                <span className="font-bold text-sm text-primary">Notificações</span>
                {notifications.length > 0 && (
                  <div className="flex gap-2">
                    <button
                      onClick={markAllRead}
                      className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1"
                    >
                      <CheckCheck className="w-3.5 h-3.5" /> Lidas
                    </button>
                    <button
                      onClick={clearAll}
                      className="text-xs text-muted-foreground hover:text-destructive flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Limpar
                    </button>
                  </div>
                )}
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">
                    <BellIcon className="w-8 h-8 mx-auto mb-2 text-muted-foreground/30" />
                    <p>Nenhuma notificação ainda.</p>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`p-3 border-b border-border last:border-0 ${!n.read ? 'bg-primary/5' : ''}`}
                    >
                      <p className="font-bold text-sm text-primary">{n.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{n.message}</p>
                      <p className="text-[10px] text-muted-foreground/60 mt-1">
                        {new Date(n.timestamp).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </PopoverContent>
          </Popover>
          <button
            onClick={() => {
              signOut()
              window.location.href = '/'
            }}
            className="p-2 text-muted-foreground hover:bg-muted rounded-full transition-colors hidden sm:block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            title="Sair"
            aria-label="Sair da conta"
          >
            <LogOutIcon className="w-5 h-5" />
          </button>
          {user && (
            <div className="flex items-center gap-2">
              <span className="hidden sm:block text-sm font-bold text-primary max-w-[120px] truncate">
                {user.name || user.email}
              </span>
              <ProfileAvatar />
            </div>
          )}
        </div>
      )}
      {isPublic && (
        <div className="flex gap-2 sm:gap-4">
          <Link
            to="/login"
            className="text-sm font-bold text-primary py-2 px-4 hover:bg-primary/5 rounded-full transition-colors hidden sm:block"
          >
            Entrar
          </Link>
          <Link
            to="/onboarding"
            className="text-sm font-bold bg-primary text-primary-foreground py-2 px-4 rounded-full shadow-elevation hover:bg-primary/90 transition-transform hover:scale-95"
          >
            Criar conta
          </Link>
        </div>
      )}
    </header>
  )
}
