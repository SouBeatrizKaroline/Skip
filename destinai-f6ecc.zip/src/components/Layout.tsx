import { Outlet, useLocation } from 'react-router-dom'
import { Sidebar, BottomNav } from './Navigation'
import { Header } from './Header'
import { ViviChat } from './ViviChat'
import { NotificationModal } from './NotificationModal'
import { cn } from '@/lib/utils'

export default function Layout() {
  const location = useLocation()
  const isPublic =
    location.pathname === '/' ||
    location.pathname === '/onboarding' ||
    location.pathname === '/login' ||
    location.pathname === '/forgot-password'

  return (
    <div className="flex min-h-dvh bg-background text-foreground font-sans overflow-x-hidden">
      <style
        dangerouslySetInnerHTML={{
          __html: `
        @keyframes scan { 0% { top: 0%; } 100% { top: calc(100% - 6px); } }
        .animate-scan { animation: scan 2s ease-in-out infinite alternate; }
        @keyframes bounce-subtle { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
        .animate-bounce-subtle { animation: bounce-subtle 2s ease-in-out infinite; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `,
        }}
      />
      {!isPublic && <Sidebar />}
      <div
        className={cn(
          'flex-1 flex flex-col min-w-0 transition-all min-h-dvh',
          !isPublic && 'md:ml-20 pb-[calc(4rem+env(safe-area-inset-bottom))] md:pb-0',
        )}
      >
        {!isPublic && <Header isPublic={false} />}
        <main
          className={cn(
            'flex-1 flex flex-col relative z-0 min-w-0 max-w-full px-4 pb-4 md:px-8 md:pb-8',
            !isPublic && 'pt-[calc(4rem+env(safe-area-inset-top))]',
          )}
        >
          <Outlet />
        </main>
      </div>
      {!isPublic && <BottomNav />}
      {!isPublic && <ViviChat />}
      {!isPublic && <NotificationModal />}
    </div>
  )
}
