import { useState, useRef, useEffect, useCallback } from 'react'

export function useSpeech() {
  const [isListening, setIsListening] = useState(false)
  const recognitionRef = useRef<any>(null)

  const supported =
    typeof window !== 'undefined' &&
    ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)

  const speak = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(text)
      u.lang = 'pt-BR'
      u.rate = 1.1
      window.speechSynthesis.speak(u)
    }
  }, [])

  const startListening = useCallback(
    (onResult: (text: string) => void) => {
      if (!supported) return
      const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      const rec = new SR()
      rec.lang = 'pt-BR'
      rec.continuous = false
      rec.interimResults = false
      rec.onresult = (e: any) => {
        const text = e.results[0][0].transcript
        onResult(text)
      }
      rec.onend = () => setIsListening(false)
      rec.onerror = () => setIsListening(false)
      rec.start()
      setIsListening(true)
      recognitionRef.current = rec
    },
    [supported],
  )

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop()
    setIsListening(false)
  }, [])

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop()
      if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    }
  }, [])

  return { speak, startListening, stopListening, isListening, supported }
}
