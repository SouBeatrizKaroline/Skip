import { useState, useEffect, useCallback } from 'react'

export interface AppNotification {
  id: string
  title: string
  message: string
  timestamp: number
  read: boolean
}

const STORAGE_KEY = 'destinai_notifications'

function loadFromStorage(): AppNotification[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

function saveToStorage(notifications: AppNotification[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications))
  } catch {
    /* ignore */
  }
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<AppNotification[]>(loadFromStorage)

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail
      const notif: AppNotification = {
        id: Date.now().toString(),
        title: detail.title || 'Notificação',
        message: detail.message || '',
        timestamp: Date.now(),
        read: false,
      }
      setNotifications((prev) => {
        const updated = [notif, ...prev].slice(0, 20)
        saveToStorage(updated)
        return updated
      })
    }
    window.addEventListener('destinai-notification', handler)
    return () => window.removeEventListener('destinai-notification', handler)
  }, [])

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAllRead = useCallback(() => {
    setNotifications((prev) => {
      const updated = prev.map((n) => ({ ...n, read: true }))
      saveToStorage(updated)
      return updated
    })
  }, [])

  const clearAll = useCallback(() => {
    setNotifications([])
    saveToStorage([])
  }, [])

  return { notifications, unreadCount, markAllRead, clearAll }
}
