migrate(
  (app) => {
    try {
      app.findAuthRecordByEmail('_pb_users_auth_', 'producer1@destinai.demo')
      return
    } catch (_) {}

    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    const cities = [
      { name: 'Holambra', state: 'SP', lat: -22.6833, lon: -47.0667 },
      { name: 'Campinas', state: 'SP', lat: -22.9099, lon: -47.0626 },
      { name: 'Sumaré', state: 'SP', lat: -22.8219, lon: -47.2678 },
      { name: 'Mogi Guaçu', state: 'SP', lat: -22.3676, lon: -46.9456 },
      { name: 'Lavras', state: 'MG', lat: -21.2286, lon: -44.9947 },
      { name: 'Patos de Minas', state: 'MG', lat: -18.5789, lon: -46.5153 },
      { name: 'Cristalina', state: 'GO', lat: -16.7753, lon: -47.6144 },
      { name: 'Petrolina', state: 'PE', lat: -9.3986, lon: -40.5009 },
    ]
    const prodNames = [
      'Sítio Boa Vista',
      'Fazenda Sol Nascente',
      'Agro Vale',
      'Horta Verde',
      'Sítio Esperança',
      'Fazenda Santa Helena',
      'Chácara do Vale',
      'Agropecuária Florescer',
      'Sítio Raízes',
      'Fazenda Três Marias',
      'Horta Viva',
      'Sítio São Jorge',
      'Fazenda Primavera',
      'Agro Sustentável',
      'Sítio do Sol',
      'Fazenda Boa Sorte',
      'Chácara Floresta',
      'Sítio Pão de Açúcar',
      'Fazenda Horizonte',
      'Agro Campina',
    ]
    const buyerNames = [
      'Restaurante Sabor & Vida',
      'Agroindústria Natural',
      'Banco de Alimentos SP',
      'Supermercado Económico',
      'Cozinha Comunitária',
      'Indústria de Sucos Fresh',
      'Restaurante Tempero Verde',
      'Mercearia Bem-Estar',
      'Cooperativa de Alimentos',
      'Restaurante Raiz',
      'Indústria de Polpas Tropical',
      'Banco de Alimentos Campinas',
      'Supermercado Todo Dia',
      'Restaurante Fogão de Pedra',
      'Agroindústria Vale Verde',
      'Cozinha Social Esperança',
      'Mercearia Natural Vida',
      'Indústria de Conservas Sol',
      'Restaurante Sabor Caseiro',
      'Cooperativa Agro Familiar',
      'Supermercado Preço Bom',
      'Banco de Alimentos Mogiana',
      'Restaurante Verdejar',
      'Indústria Alimentícia Atlas',
      'Mercearia do Campo',
      'Restaurante Tempero de Casa',
      'Cozinha Comunitária União',
      'Agroindústria Cerrado',
      'Supermercado Poupança',
      'Restaurante Quintal Verde',
    ]
    const buyerTypes = [
      'RESTAURANT',
      'INDUSTRY',
      'FOOD_BANK',
      'MARKET',
      'RESTAURANT',
      'INDUSTRY',
      'RESTAURANT',
      'MARKET',
      'FOOD_BANK',
      'RESTAURANT',
      'INDUSTRY',
      'FOOD_BANK',
      'MARKET',
      'RESTAURANT',
      'INDUSTRY',
      'FOOD_BANK',
      'MARKET',
      'INDUSTRY',
      'RESTAURANT',
      'FOOD_BANK',
      'MARKET',
      'FOOD_BANK',
      'RESTAURANT',
      'INDUSTRY',
      'MARKET',
      'RESTAURANT',
      'FOOD_BANK',
      'INDUSTRY',
      'MARKET',
      'RESTAURANT',
    ]
    const transpNames = [
      'Expresso Carga Pesada',
      'Transportes Rápidos SP',
      'Logística Verde',
      'Frete Campinas',
      'Transportadora Vale',
      'Expresso Mogiana',
      'Carga & Cia',
      'LogTrans Holambra',
      'Transportes Minas',
      'Frete Express Interior',
    ]
    const vehTypes = [
      'TRUCK',
      'VAN',
      'TRUCK',
      'VAN',
      'TRUCK',
      'TRUCK',
      'VAN',
      'TRUCK',
      'TRUCK',
      'VAN',
    ]
    const productNames = [
      'Cenoura',
      'Tomate',
      'Batata',
      'Alface',
      'Beterraba',
      'Cebola',
      'Abobrinha',
      'Pepino',
      'Pimentão',
      'Repolho',
      'Mandioca',
      'Brócolis',
      'Couve',
      'Espinafre',
      'Rúcula',
      'Abóbora',
      'Chuchu',
      'Quiabo',
      'Berinjela',
      'Maxixe',
    ]
    const conditions = ['RETAIL_STANDARD', 'MINOR_IMPERFECTIONS', 'NON_STANDARD', 'PROCESSING_ONLY']
    const statuses = ['AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'MATCHED', 'NEGOTIATING', 'DELIVERED']
    const demandTagsList = [
      'Cenoura,Tomate,Batata',
      'Alface,Couve,Espinafre',
      'Beterraba,Cebola,Repolho',
      'Abobrinha,Pepino,Pimentão',
      'Mandioca,Abóbora,Chuchu',
      'Cenoura,Beterraba,Mandioca',
      'Tomate,Pimentão,Quiabo',
      'Alface,Rúcula,Brócolis',
      'Batata,Cebola,Repolho',
      'Berinjela,Abobrinha,Maxixe',
    ]

    function createUser(email, name, role, company) {
      const u = new Record(usersCol)
      u.setEmail(email)
      u.setPassword('Skip@Pass')
      u.setVerified(true)
      u.set('name', name)
      u.set('role', role)
      u.set('company_name', company)
      u.set('status', 'ACTIVE')
      app.save(u)
      return u
    }

    try {
      app.findAuthRecordByEmail('_pb_users_auth_', 'jhay.dev@outlook.com')
    } catch (_) {
      createUser('jhay.dev@outlook.com', 'Admin DestinAI', 'ADMIN', 'DestinAI')
    }

    const prodCol = app.findCollectionByNameOrId('producer_profiles')
    const producerIds = []
    for (let i = 0; i < 20; i++) {
      const c = cities[i % cities.length]
      const u = createUser(
        'producer' + (i + 1) + '@destinai.demo',
        'Produtor ' + (i + 1),
        'PRODUCER',
        prodNames[i],
      )
      const p = new Record(prodCol)
      p.set('user_id', u.id)
      p.set('farm_name', prodNames[i])
      p.set('latitude', c.lat + (Math.random() - 0.5) * 0.2)
      p.set('longitude', c.lon + (Math.random() - 0.5) * 0.2)
      p.set('city', c.name)
      p.set('state', c.state)
      p.set('phone', '+55 19 9' + String(10000000 + i * 111111).slice(0, 8))
      p.set('description', 'Produtor rural dedicado à agricultura sustentável em ' + c.name)
      app.save(p)
      producerIds.push({
        id: p.id,
        lat: p.get('latitude'),
        lon: p.get('longitude'),
        city: c.name,
        state: c.state,
      })
    }

    const buyerCol = app.findCollectionByNameOrId('buyer_profiles')
    const buyerIds = []
    for (let i = 0; i < 30; i++) {
      const c = cities[i % cities.length]
      const u = createUser(
        'buyer' + (i + 1) + '@destinai.demo',
        'Comprador ' + (i + 1),
        'BUYER',
        buyerNames[i],
      )
      const b = new Record(buyerCol)
      b.set('user_id', u.id)
      b.set('business_name', buyerNames[i])
      b.set('buyer_type', buyerTypes[i])
      b.set('latitude', c.lat + (Math.random() - 0.5) * 0.3)
      b.set('longitude', c.lon + (Math.random() - 0.5) * 0.3)
      b.set('city', c.name)
      b.set('state', c.state)
      b.set('phone', '+55 19 9' + String(20000000 + i * 111111).slice(0, 8))
      b.set('demand_tags', demandTagsList[i % demandTagsList.length])
      b.set('description', buyerNames[i] + ' buscando hortaliças de qualidade')
      app.save(b)
      buyerIds.push({
        id: b.id,
        lat: b.get('latitude'),
        lon: b.get('longitude'),
        city: c.name,
        state: c.state,
      })
    }

    const transpCol = app.findCollectionByNameOrId('transporter_profiles')
    const transpIds = []
    for (let i = 0; i < 10; i++) {
      const c = cities[i % cities.length]
      const u = createUser(
        'transporter' + (i + 1) + '@destinai.demo',
        'Transportador ' + (i + 1),
        'TRANSPORTER',
        transpNames[i],
      )
      const t = new Record(transpCol)
      t.set('user_id', u.id)
      t.set('company_name', transpNames[i])
      t.set('vehicle_type', vehTypes[i])
      t.set('max_capacity_kg', vehTypes[i] === 'TRUCK' ? 5000 : 1500)
      t.set('latitude', c.lat)
      t.set('longitude', c.lon)
      t.set('city', c.name)
      t.set('state', c.state)
      t.set('phone', '+55 19 9' + String(30000000 + i * 111111).slice(0, 8))
      app.save(t)
      transpIds.push({ id: t.id, city: c.name, state: c.state })
    }

    const productsCol = app.findCollectionByNameOrId('products')
    const productIds = []
    let pc = 0
    for (const prod of producerIds) {
      for (let j = 0; j < 5; j++) {
        const name = productNames[pc % productNames.length]
        const qty = 50 + Math.floor(Math.random() * 300)
        const price = 1.5 + Math.round(Math.random() * 300) / 100
        const p = new Record(productsCol)
        p.set('producer_id', prod.id)
        p.set('name', name)
        p.set('quantity_kg', qty)
        p.set('harvest_date', '2026-05-' + String(20 + (pc % 10)).padStart(2, '0'))
        p.set('visual_condition', conditions[pc % conditions.length])
        p.set('status', statuses[pc % statuses.length])
        p.set('price_per_kg', price)
        p.set('description', 'Lote de ' + name + ' - ' + qty + 'kg disponíveis')
        p.set('latitude', prod.lat)
        p.set('longitude', prod.lon)
        p.set('city', prod.city)
        p.set('state', prod.state)
        app.save(p)
        productIds.push({ id: p.id, producer_id: prod.id, name, qty, price, city: prod.city })
        pc++
      }
    }

    const matchesCol = app.findCollectionByNameOrId('matches')
    const matchIds = []
    for (let i = 0; i < 15; i++) {
      const prod = productIds[(i * 7) % productIds.length]
      const buyer = buyerIds[i]
      const m = new Record(matchesCol)
      m.set('product_id', prod.id)
      m.set('buyer_id', buyer.id)
      m.set('producer_id', prod.producer_id)
      m.set('status', i < 8 ? 'CONFIRMED' : 'PENDING')
      m.set('price_agreed', prod.price)
      app.save(m)
      matchIds.push({ id: m.id, product: prod, buyer })
    }

    const ordersCol = app.findCollectionByNameOrId('orders')
    const orderStatuses = ['PENDING', 'ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED']
    for (let i = 0; i < 8; i++) {
      const m = matchIds[i]
      const t = transpIds[i % transpIds.length]
      const o = new Record(ordersCol)
      o.set('match_id', m.id)
      o.set('transporter_id', t.id)
      o.set('status', orderStatuses[i % orderStatuses.length])
      o.set('pickup_address', m.product.city + ' - ' + m.product.state)
      o.set('delivery_address', m.buyer.city + ' - ' + m.buyer.state)
      o.set('reward', 80 + Math.floor(Math.random() * 200))
      app.save(o)
    }
  },
  (app) => {
    const emails = []
    for (let i = 1; i <= 20; i++) emails.push('producer' + i + '@destinai.demo')
    for (let i = 1; i <= 30; i++) emails.push('buyer' + i + '@destinai.demo')
    for (let i = 1; i <= 10; i++) emails.push('transporter' + i + '@destinai.demo')
    for (const e of emails) {
      try {
        app.delete(app.findAuthRecordByEmail('_pb_users_auth_', e))
      } catch (_) {}
    }
  },
)
