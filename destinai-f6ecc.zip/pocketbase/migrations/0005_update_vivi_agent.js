migrate(
  (app) => {
    $ai.agents.deleteTools(app, 'vivi', ['buyer_profiles'])
    $ai.agents.putTools(app, 'vivi', [
      { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
      { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
      { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
    ])
  },
  (app) => {
    $ai.agents.deleteTools(app, 'vivi', ['recommendations', 'impact_metrics'])
    $ai.agents.putTools(app, 'vivi', [
      { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
      { collection: 'buyer_profiles', perms: { read: true, list: true }, actAs: 'admin' },
    ])
  },
)
