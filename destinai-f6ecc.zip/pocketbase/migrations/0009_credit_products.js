migrate(
  (app) => {
    const col = new Collection({
      name: 'credit_products',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.role = 'ADMIN'",
      updateRule: "@request.auth.role = 'ADMIN'",
      deleteRule: "@request.auth.role = 'ADMIN'",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'institution', type: 'text', required: true },
        {
          name: 'type',
          type: 'select',
          values: ['GOV_PROGRAM', 'COOPERATIVE', 'MICROCREDIT', 'PRIVATE'],
          maxSelect: 1,
        },
        { name: 'min_amount', type: 'number' },
        { name: 'max_amount', type: 'number' },
        { name: 'interest_rate', type: 'number' },
        { name: 'term_months', type: 'number' },
        { name: 'requirements', type: 'text' },
        { name: 'description', type: 'text' },
        { name: 'recommended_roles', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [],
    })
    app.save(col)

    var products = [
      {
        name: 'Plano Safra 2026',
        institution: 'Governo Federal',
        type: 'GOV_PROGRAM',
        min_amount: 5000,
        max_amount: 300000,
        interest_rate: 4.5,
        term_months: 24,
        requirements: 'DAP ativa, producao rural comprovada',
        description: 'Credito rural subsidiado para custeio e investimento na producao agricola.',
        recommended_roles: 'PRODUCER',
      },
      {
        name: 'Pronaf Microcredito',
        institution: 'Governo Federal',
        type: 'MICROCREDIT',
        min_amount: 1000,
        max_amount: 20000,
        interest_rate: 2.0,
        term_months: 12,
        requirements: 'Agricultor familiar, DAP ativa',
        description: 'Microcredito para agricultores familiares de baixa renda.',
        recommended_roles: 'PRODUCER',
      },
      {
        name: 'Credito Cooperativo Agro',
        institution: 'Cooperativa de Credito Rural',
        type: 'COOPERATIVE',
        min_amount: 3000,
        max_amount: 150000,
        interest_rate: 8.5,
        term_months: 36,
        requirements: 'Ser cooperado, garantia real',
        description: 'Financiamento cooperativo com taxas reduzidas para membros.',
        recommended_roles: 'PRODUCER,BUYER',
      },
      {
        name: 'Fundo Constitucional FCO',
        institution: 'Banco do Brasil',
        type: 'GOV_PROGRAM',
        min_amount: 10000,
        max_amount: 500000,
        interest_rate: 6.0,
        term_months: 60,
        requirements: 'Projeto viavel, garantia',
        description:
          'Fundo Constitucional de Financiamento do Centro-Oeste para investimento agro.',
        recommended_roles: 'PRODUCER',
      },
      {
        name: 'Antecipacao de Recebiveis',
        institution: 'Banco Digital',
        type: 'PRIVATE',
        min_amount: 2000,
        max_amount: 100000,
        interest_rate: 12.0,
        term_months: 6,
        requirements: 'Historico de vendas na plataforma',
        description: 'Antecipacao de recebiveis baseada nas vendas realizadas no DestinAI.',
        recommended_roles: 'BUYER,TRANSPORTER',
      },
      {
        name: 'Microcredito Empresarial',
        institution: 'Instituicao Financeira',
        type: 'MICROCREDIT',
        min_amount: 500,
        max_amount: 15000,
        interest_rate: 10.0,
        term_months: 18,
        requirements: 'CPF/CNPJ, comprovante de renda',
        description: 'Microcredito para pequenos negocios e transportadores autonomos.',
        recommended_roles: 'BUYER,TRANSPORTER',
      },
    ]

    var creditCol = app.findCollectionByNameOrId('credit_products')
    for (var i = 0; i < products.length; i++) {
      var p = products[i]
      try {
        app.findFirstRecordByData('credit_products', 'name', p.name)
      } catch (_) {
        var r = new Record(creditCol)
        r.set('name', p.name)
        r.set('institution', p.institution)
        r.set('type', p.type)
        r.set('min_amount', p.min_amount)
        r.set('max_amount', p.max_amount)
        r.set('interest_rate', p.interest_rate)
        r.set('term_months', p.term_months)
        r.set('requirements', p.requirements)
        r.set('description', p.description)
        r.set('recommended_roles', p.recommended_roles)
        app.save(r)
      }
    }
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId('credit_products'))
    } catch (_) {}
  },
)
