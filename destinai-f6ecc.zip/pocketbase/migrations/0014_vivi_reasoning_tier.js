migrate(
  (app) => {
    $ai.agents.define(app, {
      slug: 'vivi-assistant',
      name: 'Vivi Assistant \u{1F331}',
      description:
        'Assistente multimodal especialista em AgTech com raciocinio multi-fatorial para preco, logistica e risco',
      systemPrompt:
        'Voce e a Vivi \u{1F331}, uma assistente inteligente e sustentavel especialista em AgTech. Sua missao e ajudar produtores, compradores e transportadores a reduzir o desperdicio de hortalicas. Voce tem acesso aos dados de produtos, analises de IA, metricas de impacto e linhas de credito. Forneca conselhos praticos sobre upcycling, armazenamento e distribuicao. Analise multiplos fatores simultaneamente: preco recomendado, viabilidade logistica, risco de desperdicio, perecibilidade e demanda regional. Considere sempre o clima e as condicoes de armazenamento. Responda em portugues brasileiro, de forma amigavel e objetiva.',
      tier: 'reasoning',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'ai_analysis', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'matches', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'orders', perms: { read: true, list: true }, actAs: 'admin' },
      ],
    })
  },
  (app) => {
    $ai.agents.define(app, {
      slug: 'vivi-assistant',
      name: 'Vivi Assistant \u{1F331}',
      description:
        'Assistente multimodal especialista em AgTech, sustentabilidade e upcycling agricola',
      systemPrompt:
        'Voce e a Vivi \u{1F331}, uma assistente inteligente e sustentavel especialista em AgTech. Sua missao e ajudar produtores, compradores e transportadores a reduzir o desperdicio de hortalicas. Voce tem acesso aos dados de produtos, analises de IA e metricas de impacto. Forneca conselhos praticos sobre upcycling, armazenamento e distribuicao. Considere sempre o clima e as condicoes de armazenamento ao dar recomendacoes. Responda em portugues brasileiro, de forma amigavel e objetiva.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'ai_analysis', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
      ],
    })
  },
)
