migrate(
  (app) => {
    var updates = [
      {
        name: 'users',
        listRule:
          "@request.auth.id != '' && (id = @request.auth.id || @request.auth.role = 'ADMIN')",
        viewRule:
          "@request.auth.id != '' && (id = @request.auth.id || @request.auth.role = 'ADMIN')",
        updateRule:
          "@request.auth.id != '' && (id = @request.auth.id || @request.auth.role = 'ADMIN')",
      },
      {
        name: 'producer_profiles',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      {
        name: 'buyer_profiles',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      {
        name: 'transporter_profiles',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      { name: 'products', listRule: "@request.auth.id != ''", viewRule: "@request.auth.id != ''" },
      {
        name: 'product_images',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      {
        name: 'ai_analysis',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      {
        name: 'recommendations',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
      { name: 'matches', listRule: "@request.auth.id != ''", viewRule: "@request.auth.id != ''" },
      { name: 'orders', listRule: "@request.auth.id != ''", viewRule: "@request.auth.id != ''" },
      {
        name: 'impact_metrics',
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
      },
    ]

    for (var i = 0; i < updates.length; i++) {
      var u = updates[i]
      var col = app.findCollectionByNameOrId(u.name)
      if (u.listRule !== undefined) col.listRule = u.listRule
      if (u.viewRule !== undefined) col.viewRule = u.viewRule
      if (u.updateRule !== undefined) col.updateRule = u.updateRule
      app.save(col)
    }
  },
  (app) => {
    var reverts = [
      {
        name: 'users',
        listRule: 'id = @request.auth.id',
        viewRule: 'id = @request.auth.id',
        updateRule: 'id = @request.auth.id',
      },
      { name: 'producer_profiles', listRule: '', viewRule: '' },
      { name: 'buyer_profiles', listRule: '', viewRule: '' },
      { name: 'transporter_profiles', listRule: '', viewRule: '' },
      { name: 'products', listRule: '', viewRule: '' },
      { name: 'product_images', listRule: '', viewRule: '' },
      { name: 'ai_analysis', listRule: '', viewRule: '' },
      { name: 'recommendations', listRule: '', viewRule: '' },
      { name: 'matches', listRule: '', viewRule: '' },
      { name: 'orders', listRule: '', viewRule: '' },
      { name: 'impact_metrics', listRule: '', viewRule: '' },
    ]

    for (var i = 0; i < reverts.length; i++) {
      var r = reverts[i]
      var col = app.findCollectionByNameOrId(r.name)
      col.listRule = r.listRule
      col.viewRule = r.viewRule
      if (r.updateRule !== undefined) col.updateRule = r.updateRule
      app.save(col)
    }
  },
)
