migrate(
  (app) => {
    var matchesCol = app.findCollectionByNameOrId('matches')
    if (!matchesCol.fields.getByName('producer_rating')) {
      matchesCol.fields.add(new NumberField({ name: 'producer_rating', min: 0, max: 5 }))
    }
    if (!matchesCol.fields.getByName('buyer_rating')) {
      matchesCol.fields.add(new NumberField({ name: 'buyer_rating', min: 0, max: 5 }))
    }
    app.save(matchesCol)

    var ordersCol = app.findCollectionByNameOrId('orders')
    if (!ordersCol.fields.getByName('rating')) {
      ordersCol.fields.add(new NumberField({ name: 'rating', min: 0, max: 5 }))
    }
    app.save(ordersCol)

    var usersCol = app.findCollectionByNameOrId('users')
    if (!usersCol.fields.getByName('referrer_code')) {
      usersCol.fields.add(new TextField({ name: 'referrer_code' }))
    }
    if (!usersCol.fields.getByName('referred_by')) {
      usersCol.fields.add(new TextField({ name: 'referred_by' }))
    }
    app.save(usersCol)
  },
  (app) => {
    var matchesCol = app.findCollectionByNameOrId('matches')
    var pr = matchesCol.fields.getByName('producer_rating')
    if (pr) matchesCol.fields.remove(pr)
    var br = matchesCol.fields.getByName('buyer_rating')
    if (br) matchesCol.fields.remove(br)
    app.save(matchesCol)

    var ordersCol = app.findCollectionByNameOrId('orders')
    var r = ordersCol.fields.getByName('rating')
    if (r) ordersCol.fields.remove(r)
    app.save(ordersCol)

    var usersCol = app.findCollectionByNameOrId('users')
    var rc = usersCol.fields.getByName('referrer_code')
    if (rc) usersCol.fields.remove(rc)
    var rb = usersCol.fields.getByName('referred_by')
    if (rb) usersCol.fields.remove(rb)
    app.save(usersCol)
  },
)
