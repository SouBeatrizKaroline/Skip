migrate(
  (app) => {
    var productsCol = app.findCollectionByNameOrId('products')
    if (!productsCol.fields.getByName('waste_risk_level')) {
      productsCol.fields.add(
        new SelectField({
          name: 'waste_risk_level',
          values: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'],
          maxSelect: 1,
        }),
      )
    }
    if (!productsCol.fields.getByName('predicted_shelf_life')) {
      productsCol.fields.add(new NumberField({ name: 'predicted_shelf_life' }))
    }
    if (!productsCol.fields.getByName('recommended_price_range')) {
      productsCol.fields.add(new TextField({ name: 'recommended_price_range' }))
    }
    app.save(productsCol)

    var usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    if (!usersCol.fields.getByName('reputation_score')) {
      usersCol.fields.add(new NumberField({ name: 'reputation_score' }))
    }
    if (!usersCol.fields.getByName('tier_status')) {
      usersCol.fields.add(
        new SelectField({
          name: 'tier_status',
          values: ['BRONZE', 'SILVER', 'GOLD', 'DIAMOND'],
          maxSelect: 1,
        }),
      )
    }
    app.save(usersCol)

    var impactCol = app.findCollectionByNameOrId('impact_metrics')
    if (!impactCol.fields.getByName('water_preserved_liters')) {
      impactCol.fields.add(new NumberField({ name: 'water_preserved_liters' }))
    }
    if (!impactCol.fields.getByName('meals_generated')) {
      impactCol.fields.add(new NumberField({ name: 'meals_generated' }))
    }
    app.save(impactCol)
  },
  (app) => {
    var productsCol = app.findCollectionByNameOrId('products')
    var pFields = ['waste_risk_level', 'predicted_shelf_life', 'recommended_price_range']
    for (var i = 0; i < pFields.length; i++) {
      var f = productsCol.fields.getByName(pFields[i])
      if (f) productsCol.fields.remove(f)
    }
    app.save(productsCol)

    var usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    var uFields = ['reputation_score', 'tier_status']
    for (var j = 0; j < uFields.length; j++) {
      var f2 = usersCol.fields.getByName(uFields[j])
      if (f2) usersCol.fields.remove(f2)
    }
    app.save(usersCol)

    var impactCol = app.findCollectionByNameOrId('impact_metrics')
    var iFields = ['water_preserved_liters', 'meals_generated']
    for (var k = 0; k < iFields.length; k++) {
      var f3 = impactCol.fields.getByName(iFields[k])
      if (f3) impactCol.fields.remove(f3)
    }
    app.save(impactCol)
  },
)
