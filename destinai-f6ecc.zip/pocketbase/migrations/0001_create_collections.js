migrate(
  (app) => {
    const autoFields = [
      { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
      { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
    ]

    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    if (!usersCol.fields.getByName('role')) {
      usersCol.fields.add(
        new SelectField({
          name: 'role',
          values: ['PRODUCER', 'BUYER', 'TRANSPORTER', 'ADMIN'],
          maxSelect: 1,
        }),
      )
    }
    if (!usersCol.fields.getByName('company_name')) {
      usersCol.fields.add(new TextField({ name: 'company_name' }))
    }
    if (!usersCol.fields.getByName('document')) {
      usersCol.fields.add(new TextField({ name: 'document' }))
    }
    if (!usersCol.fields.getByName('status')) {
      usersCol.fields.add(
        new SelectField({
          name: 'status',
          values: ['ACTIVE', 'INACTIVE', 'PENDING'],
          maxSelect: 1,
        }),
      )
    }
    app.save(usersCol)

    const producerProfiles = new Collection({
      name: 'producer_profiles',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'farm_name', type: 'text', required: true },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        { name: 'phone', type: 'text' },
        { name: 'description', type: 'text' },
        {
          name: 'avatar',
          type: 'file',
          maxSelect: 1,
          maxSize: 5242880,
          mimeTypes: ['image/jpeg', 'image/png'],
        },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_producer_profiles_user_id ON producer_profiles (user_id)'],
    })
    app.save(producerProfiles)

    const buyerProfiles = new Collection({
      name: 'buyer_profiles',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'business_name', type: 'text', required: true },
        {
          name: 'buyer_type',
          type: 'select',
          values: ['RESTAURANT', 'INDUSTRY', 'FOOD_BANK', 'MARKET'],
          maxSelect: 1,
        },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        { name: 'phone', type: 'text' },
        { name: 'demand_tags', type: 'text' },
        { name: 'description', type: 'text' },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_buyer_profiles_user_id ON buyer_profiles (user_id)'],
    })
    app.save(buyerProfiles)

    const transporterProfiles = new Collection({
      name: 'transporter_profiles',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'company_name', type: 'text', required: true },
        {
          name: 'vehicle_type',
          type: 'select',
          values: ['TRUCK', 'VAN', 'CAR', 'MOTORCYCLE'],
          maxSelect: 1,
        },
        { name: 'max_capacity_kg', type: 'number' },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        { name: 'phone', type: 'text' },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_transporter_profiles_user_id ON transporter_profiles (user_id)'],
    })
    app.save(transporterProfiles)

    const prodColId = app.findCollectionByNameOrId('producer_profiles').id
    const buyerColId = app.findCollectionByNameOrId('buyer_profiles').id
    const transpColId = app.findCollectionByNameOrId('transporter_profiles').id

    const products = new Collection({
      name: 'products',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.role = 'PRODUCER'",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'producer_id',
          type: 'relation',
          required: true,
          collectionId: prodColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'name', type: 'text', required: true },
        { name: 'quantity_kg', type: 'number', required: true },
        { name: 'harvest_date', type: 'date' },
        {
          name: 'visual_condition',
          type: 'select',
          values: ['RETAIL_STANDARD', 'MINOR_IMPERFECTIONS', 'NON_STANDARD', 'PROCESSING_ONLY'],
          maxSelect: 1,
        },
        {
          name: 'status',
          type: 'select',
          values: ['AVAILABLE', 'MATCHED', 'NEGOTIATING', 'TRANSPORTING', 'DELIVERED', 'EXPIRED'],
          maxSelect: 1,
        },
        { name: 'price_per_kg', type: 'number' },
        { name: 'description', type: 'text' },
        { name: 'latitude', type: 'number' },
        { name: 'longitude', type: 'number' },
        { name: 'city', type: 'text' },
        { name: 'state', type: 'text' },
        ...autoFields,
      ],
      indexes: [
        'CREATE INDEX idx_products_producer_id ON products (producer_id)',
        'CREATE INDEX idx_products_status ON products (status)',
        'CREATE INDEX idx_products_visual_condition ON products (visual_condition)',
      ],
    })
    app.save(products)

    const productColId = app.findCollectionByNameOrId('products').id
    const productsCol = new Collection({
      name: 'product_images',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'product_id',
          type: 'relation',
          required: true,
          collectionId: productColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'image',
          type: 'file',
          required: true,
          maxSelect: 1,
          maxSize: 5242880,
          mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
        },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_product_images_product_id ON product_images (product_id)'],
    })
    app.save(productsCol)

    const aiAnalysis = new Collection({
      name: 'ai_analysis',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'product_id',
          type: 'relation',
          required: true,
          collectionId: productColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'quality_score', type: 'number' },
        { name: 'shelf_life_days', type: 'number' },
        { name: 'recommended_use', type: 'text' },
        { name: 'notes', type: 'text' },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_ai_analysis_product_id ON ai_analysis (product_id)'],
    })
    app.save(aiAnalysis)

    const recommendations = new Collection({
      name: 'recommendations',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'product_id',
          type: 'relation',
          required: true,
          collectionId: productColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'buyer_id',
          type: 'relation',
          required: true,
          collectionId: buyerColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'match_score', type: 'number' },
        { name: 'distance_km', type: 'number' },
        {
          name: 'status',
          type: 'select',
          values: ['PENDING', 'ACCEPTED', 'REJECTED'],
          maxSelect: 1,
        },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_recommendations_product_id ON recommendations (product_id)'],
    })
    app.save(recommendations)

    const matches = new Collection({
      name: 'matches',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.role = 'BUYER'",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'product_id',
          type: 'relation',
          required: true,
          collectionId: productColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'buyer_id',
          type: 'relation',
          required: true,
          collectionId: buyerColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'producer_id',
          type: 'relation',
          required: true,
          collectionId: prodColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'status',
          type: 'select',
          values: ['PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED'],
          maxSelect: 1,
        },
        { name: 'price_agreed', type: 'number' },
        ...autoFields,
      ],
      indexes: [
        'CREATE INDEX idx_matches_product_id ON matches (product_id)',
        'CREATE INDEX idx_matches_buyer_id ON matches (buyer_id)',
      ],
    })
    app.save(matches)

    const matchColId = app.findCollectionByNameOrId('matches').id
    const orders = new Collection({
      name: 'orders',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'match_id',
          type: 'relation',
          required: true,
          collectionId: matchColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'transporter_id',
          type: 'relation',
          required: true,
          collectionId: transpColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'status',
          type: 'select',
          values: ['PENDING', 'ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED', 'CANCELLED'],
          maxSelect: 1,
        },
        { name: 'pickup_address', type: 'text' },
        { name: 'delivery_address', type: 'text' },
        { name: 'reward', type: 'number' },
        ...autoFields,
      ],
      indexes: [
        'CREATE INDEX idx_orders_match_id ON orders (match_id)',
        'CREATE INDEX idx_orders_transporter_id ON orders (transporter_id)',
      ],
    })
    app.save(orders)

    const impactMetrics = new Collection({
      name: 'impact_metrics',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && user_id = @request.auth.id",
      deleteRule: "@request.auth.id != '' && user_id = @request.auth.id",
      fields: [
        {
          name: 'user_id',
          type: 'relation',
          required: true,
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          cascadeDelete: true,
        },
        { name: 'kg_saved', type: 'number' },
        { name: 'co2_saved_kg', type: 'number' },
        { name: 'revenue_recovered', type: 'number' },
        { name: 'month', type: 'text' },
        ...autoFields,
      ],
      indexes: ['CREATE INDEX idx_impact_metrics_user_id ON impact_metrics (user_id)'],
    })
    app.save(impactMetrics)
  },
  (app) => {
    const cols = [
      'impact_metrics',
      'orders',
      'matches',
      'recommendations',
      'ai_analysis',
      'product_images',
      'products',
      'transporter_profiles',
      'buyer_profiles',
      'producer_profiles',
    ]
    for (const name of cols) {
      try {
        app.delete(app.findCollectionByNameOrId(name))
      } catch (_) {}
    }
  },
)
