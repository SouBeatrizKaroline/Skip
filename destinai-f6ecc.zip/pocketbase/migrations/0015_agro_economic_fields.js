migrate(
  (app) => {
    var productsCol = app.findCollectionByNameOrId('products')
    if (!productsCol.fields.getByName('maturation_stage'))
      productsCol.fields.add(new TextField({ name: 'maturation_stage' }))
    if (!productsCol.fields.getByName('estimated_life_days'))
      productsCol.fields.add(new NumberField({ name: 'estimated_life_days' }))
    if (!productsCol.fields.getByName('cost_per_kg'))
      productsCol.fields.add(new NumberField({ name: 'cost_per_kg' }))
    if (!productsCol.fields.getByName('net_revenue_per_kg'))
      productsCol.fields.add(new NumberField({ name: 'net_revenue_per_kg' }))
    app.save(productsCol)

    var matchesCol = app.findCollectionByNameOrId('matches')
    if (!matchesCol.fields.getByName('commission_fee'))
      matchesCol.fields.add(new NumberField({ name: 'commission_fee' }))
    if (!matchesCol.fields.getByName('estimated_net_profit'))
      matchesCol.fields.add(new NumberField({ name: 'estimated_net_profit' }))
    if (!matchesCol.fields.getByName('smart_score'))
      matchesCol.fields.add(new NumberField({ name: 'smart_score' }))
    app.save(matchesCol)
  },
  (app) => {
    var productsCol = app.findCollectionByNameOrId('products')
    var pFields = ['maturation_stage', 'estimated_life_days', 'cost_per_kg', 'net_revenue_per_kg']
    for (var i = 0; i < pFields.length; i++) {
      var f = productsCol.fields.getByName(pFields[i])
      if (f) productsCol.fields.remove(f)
    }
    app.save(productsCol)

    var matchesCol = app.findCollectionByNameOrId('matches')
    var mFields = ['commission_fee', 'estimated_net_profit', 'smart_score']
    for (var j = 0; j < mFields.length; j++) {
      var f2 = matchesCol.fields.getByName(mFields[j])
      if (f2) matchesCol.fields.remove(f2)
    }
    app.save(matchesCol)
  },
)
