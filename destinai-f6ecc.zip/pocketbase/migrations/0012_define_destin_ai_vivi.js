migrate(
  (app) => {
    $ai.agents.define(app, {
      slug: 'destin-ai-vivi',
      name: 'DestinAI Vivi 🌱',
      description:
        'Motor de decisão inteligente especializado em AgTech, logística agrícola e viabilidade econômica',
      systemPrompt:
        'Você é a Vivi 🌱, o motor de decisão inteligente da DestinAI. Sua missão é otimizar a redução de desperdício de hortaliças calculando scores de Compatibilidade, Viabilidade Econômica e Logística (0-100). Para cada recomendação, forneça uma justificativa textual clara explicando os fatores que influenciaram o score (proximidade, refrigeração, capacidade, demanda). Considere sempre: distância entre produtor e comprador, custo logístico, taxa da plataforma (1-3%), margem líquida, capacidade do transportador, e compatibilidade de carga. Indique "Operação Recomendada" quando a margem for positiva e "Não Recomendada" quando negativa. Responda em português brasileiro de forma objetiva e profissional.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'orders', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'vehicles', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'matches', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
      ],
      memory: [
        {
          type: 'text',
          payload: {
            text: 'DestinAI é uma plataforma AgTech que usa IA para reduzir desperdício de hortaliças. Conecta produtores rurais, compradores alternativos e operadores logísticos. O motor de decisão calcula três scores: Compatibilidade (match entre produto e demanda do comprador), Viabilidade Econômica (valor do lote - custo logístico - taxa plataforma = margem líquida), e Logística (distância, capacidade, refrigeração). Taxa da plataforma: 1% para lotes >R$5000, 2% para >R$1000, 3% para menores. Custo logístico: R$2,50/km. Refeições potenciais: 1kg = 2 refeições.',
          },
        },
      ],
    })
  },
  (app) => {
    try {
      $ai.agents.delete(app, 'destin-ai-vivi')
    } catch (_) {}
  },
)
