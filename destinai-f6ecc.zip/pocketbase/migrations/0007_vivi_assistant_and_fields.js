migrate(
  (app) => {
    const aiCol = app.findCollectionByNameOrId('ai_analysis')
    if (!aiCol.fields.getByName('confidence_score')) {
      aiCol.fields.add(new NumberField({ name: 'confidence_score' }))
      app.save(aiCol)
    }

    $ai.agents.define(app, {
      slug: 'vivi-assistant',
      name: 'Vivi Assistant \u{1F331}',
      description:
        'Assistente multimodal especialista em AgTech, sustentabilidade e upcycling agricola',
      systemPrompt:
        'Voce e a Vivi \u{1F331}, uma assistente inteligente e sustentavel especialista em AgTech. Sua missao e ajudar produtores, compradores e transportadores a reduzir o desperdicio de hortalicas. Voce tem acesso aos dados de produtos, analises de IA e metricas de impacto. Forneca conselhos praticos sobre upcycling, armazenamento e distribuicao. Considere sempre o clima e as condicoes de armazenamento ao dar recomendacoes. Responda em portugues brasileiro, de forma amigavel e objetiva.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'ai_analysis', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
      ],
      memory: [
        {
          type: 'text',
          payload: {
            text: 'DestinAI e uma plataforma que usa IA para reduzir o desperdicio de hortalicas. Conecta produtores com excedentes a compradores alternativos e operadores logisticos. Fluxo: cadastro -> analise visual IA -> recomendacoes -> match -> logistica -> entrega. Metricas: kg salvos, CO2 evitado, receita recuperada.',
          },
        },
        {
          type: 'faq',
          payload: {
            qa: [
              {
                question: 'Como evitar desperdicio de folhosas em alta umidade?',
                answer:
                  'Em alta umidade, folhosas como alface e rúcula degradam rapidamente. Priorize distribuição imediata, mantenha refrigeração entre 2-4°C e use embalagens perfuradas para ventilação.',
              },
              {
                question: 'O que e upcycling alimentar?',
                answer:
                  'Upcycling e transformar alimentos que seriam desperdicados em novos produtos de maior valor. Ex: tomates maduros em molhos, frutas em polpas, vegetais em sopas.',
              },
              {
                question: 'Como funciona a analise visual por IA?',
                answer:
                  'A IA analisa fotos do produto, classifica a condicao visual (Padrao varejo, Imperfeicoes menores, Fora do padrao, Processamento) e atribui uma pontuacao de confianca de 0 a 100.',
              },
            ],
          },
        },
      ],
    })
  },
  (app) => {
    try {
      $ai.agents.delete(app, 'vivi-assistant')
    } catch (_) {}
    try {
      const aiCol = app.findCollectionByNameOrId('ai_analysis')
      const f = aiCol.fields.getByName('confidence_score')
      if (f) {
        aiCol.fields.remove(f)
        app.save(aiCol)
      }
    } catch (_) {}
  },
)
