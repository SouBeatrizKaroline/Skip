migrate(
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')

    if (!usersCol.fields.getByName('role')) {
      usersCol.fields.add(
        new SelectField({
          name: 'role',
          values: ['PRODUCER', 'BUYER', 'TRANSPORTER', 'ADMIN'],
          maxSelect: 1,
        }),
      )
    }
    if (!usersCol.fields.getByName('company_name')) {
      usersCol.fields.add(new TextField({ name: 'company_name' }))
    }
    if (!usersCol.fields.getByName('document')) {
      usersCol.fields.add(new TextField({ name: 'document' }))
    }
    if (!usersCol.fields.getByName('status')) {
      usersCol.fields.add(
        new SelectField({
          name: 'status',
          values: ['ACTIVE', 'INACTIVE', 'PENDING'],
          maxSelect: 1,
        }),
      )
    }
    app.save(usersCol)
  },
  (app) => {
    const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
    const fieldsToRemove = ['role', 'company_name', 'document', 'status']
    for (const fieldName of fieldsToRemove) {
      const field = usersCol.fields.getByName(fieldName)
      if (field) usersCol.fields.remove(field)
    }
    app.save(usersCol)
  },
)
