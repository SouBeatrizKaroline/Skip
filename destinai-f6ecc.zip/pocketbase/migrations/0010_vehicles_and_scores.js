migrate(
  (app) => {
    const transpColId = app.findCollectionByNameOrId('transporter_profiles').id

    const vehicles = new Collection({
      name: 'vehicles',
      type: 'base',
      listRule: "@request.auth.id != ''",
      viewRule: "@request.auth.id != ''",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'transporter_id',
          type: 'relation',
          required: true,
          collectionId: transpColId,
          maxSelect: 1,
          cascadeDelete: true,
        },
        {
          name: 'vehicle_type',
          type: 'select',
          values: [
            'MOTORCYCLE',
            'UTILITY',
            'FIORINO',
            'VAN',
            'LIGHT_TRUCK',
            'MEDIUM_TRUCK',
            'HEAVY_TRUCK',
          ],
          maxSelect: 1,
        },
        { name: 'plate', type: 'text' },
        { name: 'year', type: 'number' },
        { name: 'capacity_kg', type: 'number' },
        { name: 'capacity_m3', type: 'number' },
        { name: 'refrigeration', type: 'bool' },
        { name: 'allowed_cargo_types', type: 'text' },
        { name: 'radius_km', type: 'number' },
        { name: 'avg_consumption', type: 'number' },
        {
          name: 'availability_status',
          type: 'select',
          values: ['AVAILABLE', 'BUSY', 'OFFLINE'],
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE INDEX idx_vehicles_transporter_id ON vehicles (transporter_id)'],
    })
    app.save(vehicles)

    const recCol = app.findCollectionByNameOrId('recommendations')
    if (!recCol.fields.getByName('compatibility_score'))
      recCol.fields.add(new NumberField({ name: 'compatibility_score' }))
    if (!recCol.fields.getByName('economic_score'))
      recCol.fields.add(new NumberField({ name: 'economic_score' }))
    if (!recCol.fields.getByName('logistics_score'))
      recCol.fields.add(new NumberField({ name: 'logistics_score' }))
    if (!recCol.fields.getByName('ai_justification'))
      recCol.fields.add(new TextField({ name: 'ai_justification' }))
    app.save(recCol)
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId('vehicles'))
    } catch (_) {}
    const recCol = app.findCollectionByNameOrId('recommendations')
    var fields = ['compatibility_score', 'economic_score', 'logistics_score', 'ai_justification']
    for (var i = 0; i < fields.length; i++) {
      var f = recCol.fields.getByName(fields[i])
      if (f) recCol.fields.remove(f)
    }
    app.save(recCol)
  },
)
