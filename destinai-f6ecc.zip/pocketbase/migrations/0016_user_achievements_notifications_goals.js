migrate(
  (app) => {
    var autoFields = [
      { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
      { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
    ]

    app.save(
      new Collection({
        name: 'user_achievements',
        type: 'base',
        listRule: '@request.auth.id != "" && user_id = @request.auth.id',
        viewRule: '@request.auth.id != "" && user_id = @request.auth.id',
        createRule: '@request.auth.id != ""',
        updateRule: '@request.auth.id != "" && user_id = @request.auth.id',
        deleteRule: '@request.auth.id != "" && user_id = @request.auth.id',
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'achievement_slug', type: 'text', required: true },
          { name: 'unlocked_at', type: 'autodate', onCreate: true, onUpdate: false },
          ...autoFields,
        ],
        indexes: ['CREATE INDEX idx_user_achievements_user_id ON user_achievements (user_id)'],
      }),
    )

    app.save(
      new Collection({
        name: 'user_notifications',
        type: 'base',
        listRule: '@request.auth.id != "" && user_id = @request.auth.id',
        viewRule: '@request.auth.id != "" && user_id = @request.auth.id',
        createRule: '@request.auth.id != ""',
        updateRule: '@request.auth.id != "" && user_id = @request.auth.id',
        deleteRule: '@request.auth.id != "" && user_id = @request.auth.id',
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          { name: 'title', type: 'text', required: true },
          { name: 'message', type: 'text' },
          {
            name: 'type',
            type: 'select',
            values: ['CLIMATE', 'MARKET', 'LOGISTICS', 'OPPORTUNITY', 'ACHIEVEMENT'],
            maxSelect: 1,
          },
          { name: 'is_read', type: 'bool' },
          { name: 'vivi_insight', type: 'text' },
          ...autoFields,
        ],
        indexes: ['CREATE INDEX idx_user_notifications_user_id ON user_notifications (user_id)'],
      }),
    )

    app.save(
      new Collection({
        name: 'user_goals',
        type: 'base',
        listRule: '@request.auth.id != "" && user_id = @request.auth.id',
        viewRule: '@request.auth.id != "" && user_id = @request.auth.id',
        createRule: '@request.auth.id != ""',
        updateRule: '@request.auth.id != "" && user_id = @request.auth.id',
        deleteRule: '@request.auth.id != "" && user_id = @request.auth.id',
        fields: [
          {
            name: 'user_id',
            type: 'relation',
            required: true,
            collectionId: '_pb_users_auth_',
            maxSelect: 1,
            cascadeDelete: true,
          },
          {
            name: 'goal_type',
            type: 'select',
            values: ['KG_SAVED', 'REVENUE', 'CO2_SAVED', 'DELIVERIES', 'MATCHES'],
            maxSelect: 1,
          },
          { name: 'target_value', type: 'number', required: true },
          { name: 'current_value', type: 'number' },
          { name: 'month', type: 'text' },
          ...autoFields,
        ],
        indexes: ['CREATE INDEX idx_user_goals_user_id ON user_goals (user_id)'],
      }),
    )
  },
  (app) => {
    var names = ['user_achievements', 'user_notifications', 'user_goals']
    for (var i = 0; i < names.length; i++) {
      try {
        app.delete(app.findCollectionByNameOrId(names[i]))
      } catch (_) {}
    }
  },
)
