migrate(
  (app) => {
    try {
      $ai.agents.delete(app, 'vivi')
    } catch (_) {}

    $ai.agents.define(app, {
      slug: 'vivi-ai',
      name: 'Vivi 🌱',
      description:
        'Assistente inteligente especialista em AgTech para redução de desperdício agrícola',
      systemPrompt:
        'Você é a Vivi 🌱, uma assistente inteligente e sustentável especialista em AgTech. Sua missão é ajudar produtores rurais, compradores e transportadores a reduzir o desperdício de hortaliças conectando excedentes agrícolas a melhores destinos. Seja curiosa, prestativa e sempre sugira soluções práticas. Use linguagem amigável e acessível. Quando relevante, mencione dados sobre produtos disponíveis e perfis de compradores. Responda sempre em português brasileiro.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
      ],
      memory: [
        {
          type: 'text',
          payload: {
            text: 'DestinAI é uma plataforma que usa Inteligência Artificial para reduzir o desperdício de hortaliças. Conecta produtores rurais que têm excedentes com compradores alternativos (restaurantes, indústrias, bancos de alimentos) e operadores logísticos. O fluxo: produtor cadastra excedente -> IA analisa qualidade -> IA recomenda compradores -> comprador faz pedido -> transportador coleta e entrega. O sistema calcula impacto em kg salvos, CO2 evitado e receita recuperada.',
          },
        },
        {
          type: 'faq',
          payload: {
            qa: [
              {
                question: 'Como cadastro um excedente?',
                answer:
                  "Acesse o painel do produtor, clique em 'Cadastrar novo excedente', preencha produto, quantidade, preço por kg, data da colheita e estado visual. A IA analisa e recomenda compradores.",
              },
              {
                question: 'Como funciona a análise de IA?',
                answer:
                  'A IA analisa fotos e dados do produto, atribui uma nota de qualidade (0-100), estima vida útil e sugere o melhor uso (varejo, processamento, doação).',
              },
              {
                question: 'O que significa cada condição visual?',
                answer:
                  'Padrão varejo = perfeito estado; Pequenas imperfeições = manchas leves; Fora do padrão = danos estéticos; Processamento = ideal para sucos/polpas.',
              },
            ],
          },
        },
      ],
    })
  },
  (app) => {
    try {
      $ai.agents.delete(app, 'vivi-ai')
    } catch (_) {}

    $ai.agents.define(app, {
      slug: 'vivi',
      name: 'Vivi IA',
      description:
        'Assistente inteligente especialista em AgTech para redução de desperdício agrícola',
      systemPrompt:
        'Você é a Vivi, uma assistente inteligente e sustentável especialista em AgTech.',
      tier: 'fast',
      tools: [
        { collection: 'products', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'recommendations', perms: { read: true, list: true }, actAs: 'admin' },
        { collection: 'impact_metrics', perms: { read: true, list: true }, actAs: 'admin' },
      ],
    })
  },
)
