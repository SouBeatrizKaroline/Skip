migrate(
  (app) => {
    const col = app.findCollectionByNameOrId('transporter_profiles')

    app
      .db()
      .newQuery(
        "UPDATE transporter_profiles SET vehicle_type = 'MEDIUM_TRUCK' WHERE vehicle_type = 'TRUCK'",
      )
      .execute()
    app
      .db()
      .newQuery(
        "UPDATE transporter_profiles SET vehicle_type = 'UTILITY' WHERE vehicle_type = 'CAR'",
      )
      .execute()

    const oldVT = col.fields.getByName('vehicle_type')
    if (oldVT) col.fields.remove(oldVT)
    col.fields.add(
      new SelectField({
        name: 'vehicle_type',
        values: [
          'MOTORCYCLE',
          'UTILITY',
          'FIORINO',
          'VAN',
          'LIGHT_TRUCK',
          'MEDIUM_TRUCK',
          'HEAVY_TRUCK',
        ],
        maxSelect: 1,
      }),
    )

    if (!col.fields.getByName('plate')) col.fields.add(new TextField({ name: 'plate' }))
    if (!col.fields.getByName('year')) col.fields.add(new NumberField({ name: 'year' }))
    if (!col.fields.getByName('capacity_m3'))
      col.fields.add(new NumberField({ name: 'capacity_m3' }))
    if (!col.fields.getByName('refrigeration'))
      col.fields.add(new BoolField({ name: 'refrigeration' }))
    if (!col.fields.getByName('allowed_cargo_types'))
      col.fields.add(new TextField({ name: 'allowed_cargo_types' }))
    if (!col.fields.getByName('radius_km')) col.fields.add(new NumberField({ name: 'radius_km' }))
    if (!col.fields.getByName('avg_consumption'))
      col.fields.add(new NumberField({ name: 'avg_consumption' }))

    app.save(col)
  },
  (app) => {
    const col = app.findCollectionByNameOrId('transporter_profiles')
    var newFields = [
      'plate',
      'year',
      'capacity_m3',
      'refrigeration',
      'allowed_cargo_types',
      'radius_km',
      'avg_consumption',
    ]
    for (var i = 0; i < newFields.length; i++) {
      var field = col.fields.getByName(newFields[i])
      if (field) col.fields.remove(field)
    }
    var vt = col.fields.getByName('vehicle_type')
    if (vt) col.fields.remove(vt)
    col.fields.add(
      new SelectField({
        name: 'vehicle_type',
        values: ['TRUCK', 'VAN', 'CAR', 'MOTORCYCLE'],
        maxSelect: 1,
      }),
    )
    app.save(col)
  },
)
