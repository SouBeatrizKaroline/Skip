migrate(
  (app) => {
    const matchesCol = app.findCollectionByNameOrId('matches')
    if (!matchesCol.fields.getByName('net_revenue'))
      matchesCol.fields.add(new NumberField({ name: 'net_revenue' }))
    if (!matchesCol.fields.getByName('platform_fee'))
      matchesCol.fields.add(new NumberField({ name: 'platform_fee' }))
    if (!matchesCol.fields.getByName('logistic_cost'))
      matchesCol.fields.add(new NumberField({ name: 'logistic_cost' }))
    app.save(matchesCol)

    const ordersCol = app.findCollectionByNameOrId('orders')
    var oldStatus = ordersCol.fields.getByName('status')
    if (oldStatus) ordersCol.fields.remove(oldStatus)
    ordersCol.fields.add(
      new SelectField({
        name: 'status',
        values: [
          'PENDING',
          'WAITING_DRIVER',
          'ASSIGNED',
          'PICKUP_SCHEDULED',
          'PICKED_UP',
          'PICKING_UP',
          'IN_TRANSIT',
          'DELIVERED',
          'CANCELLED',
        ],
        maxSelect: 1,
      }),
    )
    app.save(ordersCol)
  },
  (app) => {
    const matchesCol = app.findCollectionByNameOrId('matches')
    var fields = ['net_revenue', 'platform_fee', 'logistic_cost']
    for (var i = 0; i < fields.length; i++) {
      var f = matchesCol.fields.getByName(fields[i])
      if (f) matchesCol.fields.remove(f)
    }
    app.save(matchesCol)

    var ordersCol = app.findCollectionByNameOrId('orders')
    var st = ordersCol.fields.getByName('status')
    if (st) ordersCol.fields.remove(st)
    ordersCol.fields.add(
      new SelectField({
        name: 'status',
        values: ['PENDING', 'ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED', 'CANCELLED'],
        maxSelect: 1,
      }),
    )
    app.save(ordersCol)
  },
)
