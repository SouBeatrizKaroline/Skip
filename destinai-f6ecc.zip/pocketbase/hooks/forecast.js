routerAdd(
  'GET',
  '/backend/v1/forecast',
  (e) => {
    const monthNames = [
      'Janeiro',
      'Fevereiro',
      'Março',
      'Abril',
      'Maio',
      'Junho',
      'Julho',
      'Agosto',
      'Setembro',
      'Outubro',
      'Novembro',
      'Dezembro',
    ]
    const now = new Date()
    const currentMonth = monthNames[now.getMonth()]

    const trends = [
      { product: 'Cenoura', demand_index: 85, supply_index: 70, trend: 'up' },
      { product: 'Tomate', demand_index: 92, supply_index: 55, trend: 'up' },
      { product: 'Batata', demand_index: 78, supply_index: 82, trend: 'stable' },
      { product: 'Alface', demand_index: 70, supply_index: 88, trend: 'down' },
      { product: 'Beterraba', demand_index: 65, supply_index: 60, trend: 'up' },
      { product: 'Cebola', demand_index: 80, supply_index: 65, trend: 'up' },
      { product: 'Abóbora', demand_index: 60, supply_index: 75, trend: 'down' },
      { product: 'Pimentão', demand_index: 88, supply_index: 50, trend: 'up' },
    ]

    return e.json(200, {
      current_month: currentMonth,
      season:
        now.getMonth() >= 2 && now.getMonth() <= 5
          ? 'Outono'
          : now.getMonth() >= 6 && now.getMonth() <= 8
            ? 'Inverno'
            : now.getMonth() >= 9 && now.getMonth() <= 11
              ? 'Primavera'
              : 'Verão',
      trends: trends,
      insights:
        'Alta demanda por hortaliças nesta estação. Tomate e pimentão com maior déficit de oferta. Oportunidade para produtores de cenoura e beterraba.',
    })
  },
  $apis.requireAuth(),
)
