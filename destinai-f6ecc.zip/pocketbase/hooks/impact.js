routerAdd(
  'GET',
  '/backend/v1/impact',
  (e) => {
    let products = []
    try {
      products = $app.findRecordsByFilter(
        'products',
        "status = 'DELIVERED' || status = 'MATCHED' || status = 'TRANSPORTING'",
        '-created',
        10000,
        0,
      )
    } catch (_) {}

    let totalKg = 0
    let totalRevenue = 0
    for (const p of products) {
      const kg = p.get('quantity_kg') || 0
      const price = p.get('price_per_kg') || 0
      totalKg += kg
      totalRevenue += kg * price
    }

    const totalCo2 = totalKg * 1.5
    const totalWater = totalKg * 200
    const totalMeals = Math.round(totalKg * 2)

    let matches = 0
    try {
      matches = $app.countRecords('matches')
    } catch (_) {}

    return e.json(200, {
      total_kg_saved: Math.round(totalKg),
      total_co2_saved: Math.round(totalCo2),
      total_revenue_recovered: Math.round(totalRevenue),
      total_water_preserved: Math.round(totalWater),
      total_meals_generated: totalMeals,
      total_connections: matches,
      total_products: products.length,
    })
  },
  $apis.requireAuth(),
)
