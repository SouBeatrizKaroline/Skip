onRecordAfterCreateSuccess((e) => {
  var match = e.record
  var product = null,
    producer = null
  try {
    product = $app.findRecordById('products', match.getString('product_id'))
    producer = $app.findRecordById('producer_profiles', match.getString('producer_id'))
  } catch (_) {
    return e.next()
  }

  var productName = product ? product.getString('name') : 'produto'
  var qty = product ? product.get('quantity_kg') : 0
  var producerPhone = producer ? producer.getString('phone') : ''

  var apiKey = $secrets.get('WHATSAPP_API_KEY') || ''
  var apiUrl = $secrets.get('WHATSAPP_API_URL') || ''

  if (apiKey && apiUrl && producerPhone) {
    try {
      $http.send({
        url: apiUrl,
        method: 'POST',
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: producerPhone,
          text:
            '\u{1F331} DestinAI: Nova proposta recebida! ' +
            qty +
            'kg de ' +
            productName +
            '. Acesse a plataforma para revisar.',
        }),
        timeout: 10,
      })
    } catch (_) {}
  }

  return e.next()
}, 'matches')
