routerAdd(
  'POST',
  '/backend/v1/vision/analyze/{productId}',
  (e) => {
    const productId = e.request.pathValue('productId')
    if (!productId) return e.badRequestError('productId is required')

    let product
    try {
      product = $app.findRecordById('products', productId)
    } catch (_) {
      return e.notFoundError('product not found')
    }

    let images = []
    try {
      images = $app.findRecordsByFilter(
        'product_images',
        'product_id="' + productId + '"',
        '-created',
        5,
        0,
      )
    } catch (_) {}

    const baseUrl = $secrets.get('PB_INSTANCE_URL') || $secrets.get('SITE_URL') || ''
    let visualCondition = product.getString('visual_condition') || 'MINOR_IMPERFECTIONS'
    let confidenceScore = 65
    let analysisNotes = 'Analise visual baseada nos dados do produto.'

    if (images.length > 0 && baseUrl) {
      const imgRecord = images[0]
      const imgField = imgRecord.getString('image')
      const imgUrl = baseUrl + '/api/files/product_images/' + imgRecord.id + '/' + imgField

      try {
        const reply = $ai.chat({
          model: 'fast',
          messages: [
            {
              role: 'system',
              content:
                'You are an agricultural quality analyst. Analyze the product image and classify its visual condition. Respond ONLY with JSON: {"visual_condition": "RETAIL_STANDARD|MINOR_IMPERFECTIONS|NON_STANDARD|PROCESSING_ONLY", "confidence_score": 0-100, "notes": "brief Portuguese description"}. RETAIL_STANDARD=perfect, MINOR_IMPERFECTIONS=minor flaws, NON_STANDARD=significant damage, PROCESSING_ONLY=only for processing.',
            },
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text:
                    'Product: ' +
                    product.getString('name') +
                    ', Quantity: ' +
                    product.get('quantity_kg') +
                    'kg',
                },
                { type: 'image_url', image_url: { url: imgUrl } },
              ],
            },
          ],
        })

        const content = reply.choices[0].message.content
        const jsonMatch = content.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0])
          if (parsed.visual_condition) visualCondition = parsed.visual_condition
          if (parsed.confidence_score) confidenceScore = parsed.confidence_score
          if (parsed.notes) analysisNotes = parsed.notes
        }
      } catch (err) {
        $app.logger().warn('Vision analysis failed', 'productId', productId, 'err', err.message)
        analysisNotes = 'Analise visual nao disponivel. Classificacao manual mantida.'
      }
    }

    product.set('visual_condition', visualCondition)
    $app.save(product)

    try {
      const aiCol = $app.findCollectionByNameOrId('ai_analysis')
      const aiRecord = new Record(aiCol)
      aiRecord.set('product_id', productId)
      aiRecord.set('quality_score', confidenceScore)
      aiRecord.set('shelf_life_days', Math.floor(confidenceScore / 10) + 3)
      aiRecord.set('recommended_use', 'Analise visual automatizada por IA')
      aiRecord.set('notes', analysisNotes)
      aiRecord.set('confidence_score', confidenceScore)
      $app.save(aiRecord)
    } catch (_) {}

    return e.json(200, {
      product_id: productId,
      visual_condition: visualCondition,
      confidence_score: confidenceScore,
      notes: analysisNotes,
    })
  },
  $apis.requireAuth(),
)
