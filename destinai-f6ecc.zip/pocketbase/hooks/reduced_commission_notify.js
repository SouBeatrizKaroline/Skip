onRecordAfterUpdateSuccess((e) => {
  var match = e.record
  var oldStatus = e.record.original().getString('status')
  var newStatus = match.getString('status')
  if (oldStatus === newStatus) return e.next()
  if (newStatus !== 'COMPLETED') return e.next()

  function notifyIfHighTier(userId, commissionRate) {
    try {
      var user = $app.findRecordById('users', userId)
      var tier = user.getString('tier_status') || 'BRONZE'
      if (tier !== 'GOLD' && tier !== 'DIAMOND') return

      var notifCol = $app.findCollectionByNameOrId('user_notifications')
      var notif = new Record(notifCol)
      notif.set('user_id', userId)
      notif.set('title', 'Comissao Reduzida! ')
      notif.set(
        'message',
        'Como usuario ' +
          tier +
          ', voce recebeu uma comissao reduzida de ' +
          commissionRate +
          '% nesta transacao!',
      )
      notif.set('type', 'ACHIEVEMENT')
      notif.set('is_read', false)
      notif.set(
        'vivi_insight',
        'Parabens! Seu tier ' +
          tier +
          ' garante beneficios exclusivos. Continue assim para manter seus privilegios.',
      )
      $app.save(notif)
    } catch (_) {}
  }

  try {
    var producer = $app.findRecordById('producer_profiles', match.getString('producer_id'))
    notifyIfHighTier(producer.getString('user_id'), '2')
  } catch (_) {}

  try {
    var buyer = $app.findRecordById('buyer_profiles', match.getString('buyer_id'))
    notifyIfHighTier(buyer.getString('user_id'), '2')
  } catch (_) {}

  return e.next()
}, 'matches')
