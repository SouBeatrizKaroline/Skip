onRecordAfterUpdateSuccess((e) => {
  var nameChanged = e.record.getString('name') !== e.record.original().getString('name')
  var dateChanged =
    e.record.getString('harvest_date') !== e.record.original().getString('harvest_date')
  var condChanged =
    e.record.getString('visual_condition') !== e.record.original().getString('visual_condition')
  if (!nameChanged && !dateChanged && !condChanged) return e.next()

  var product = e.record
  var prodName = (product.getString('name') || '').toLowerCase()
  var harvestDate = product.getString('harvest_date')
  var condition = product.getString('visual_condition') || 'MINOR_IMPERFECTIONS'

  var HIGH = [
    'alface',
    'tomate',
    'couve',
    'espinafre',
    'rucula',
    'agriao',
    'pepino',
    'abobrinha',
    'berinjela',
    'pimentao',
    'brocolis',
    'couve-flor',
    'cheiro',
    'repolho',
    'acelga',
  ]
  var MED = [
    'cenoura',
    'beterraba',
    'rabanete',
    'chuchu',
    'vagem',
    'ervilha',
    'milho',
    'nabo',
    'mandioquinha',
  ]
  var maxShelf = 21
  for (var i = 0; i < HIGH.length; i++) {
    if (prodName.indexOf(HIGH[i]) >= 0) {
      maxShelf = 5
      break
    }
  }
  if (maxShelf === 21) {
    for (var j = 0; j < MED.length; j++) {
      if (prodName.indexOf(MED[j]) >= 0) {
        maxShelf = 10
        break
      }
    }
  }

  var condAdj = {
    RETAIL_STANDARD: 1.0,
    MINOR_IMPERFECTIONS: 0.8,
    NON_STANDARD: 0.6,
    PROCESSING_ONLY: 0.4,
  }
  maxShelf = Math.round(maxShelf * (condAdj[condition] || 0.7))

  var daysSince = 0
  if (harvestDate) {
    daysSince = Math.floor((Date.now() - new Date(harvestDate).getTime()) / 86400000)
  }
  var usedPct = maxShelf > 0 ? Math.min(100, (daysSince / maxShelf) * 100) : 0

  var riskLevel = 'LOW'
  if (usedPct >= 80) riskLevel = 'CRITICAL'
  else if (usedPct >= 50) riskLevel = 'HIGH'
  else if (usedPct >= 30) riskLevel = 'MEDIUM'

  try {
    var rec = $app.findRecordById('products', product.id)
    rec.set('waste_risk_level', riskLevel)
    rec.set('predicted_shelf_life', maxShelf)
    $app.saveNoValidate(rec)
  } catch (_) {}

  return e.next()
}, 'products')
