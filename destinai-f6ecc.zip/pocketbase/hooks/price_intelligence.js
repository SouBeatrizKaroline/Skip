routerAdd(
  'POST',
  '/backend/v1/price-intelligence',
  (e) => {
    var body = e.requestInfo().body || {}
    var name = (body.name || '').trim()
    var qty = body.quantity_kg || 0
    var condition = body.visual_condition || 'MINOR_IMPERFECTIONS'
    var city = body.city || ''
    var state = body.state || ''
    if (!name) return e.badRequestError('name is required')

    var regionalAvg = 0
    var count = 0
    try {
      var filter = 'name ~ "' + name + '"'
      if (city) filter += ' && city = "' + city + '"'
      var existing = $app.findRecordsByFilter('products', filter, '-created', 50, 0)
      for (var i = 0; i < existing.length; i++) {
        var p = existing[i].get('price_per_kg')
        if (p > 0) {
          regionalAvg += p
          count++
        }
      }
    } catch (_) {}
    if (count > 0) regionalAvg = regionalAvg / count

    if (regionalAvg === 0) {
      var defaults = { Cenoura: 4.5, Tomate: 6.0, Batata: 3.5, Alface: 3.0, Cebola: 4.0 }
      regionalAvg = defaults[name] || 5.0
    }

    var condAdj = {
      RETAIL_STANDARD: 1.2,
      MINOR_IMPERFECTIONS: 1.0,
      NON_STANDARD: 0.7,
      PROCESSING_ONLY: 0.5,
    }
    var adj = condAdj[condition] || 1.0

    var demandMult = 1.0
    try {
      var buyers = $app.findRecordsByFilter('buyer_profiles', '', '-created', 500, 0)
      var matching = 0
      var nameLower = name.toLowerCase()
      for (var j = 0; j < buyers.length; j++) {
        var tags = (buyers[j].getString('demand_tags') || '').toLowerCase()
        if (tags.indexOf(nameLower) >= 0) matching++
      }
      if (matching >= 3) demandMult = 1.15
      else if (matching >= 1) demandMult = 1.05
    } catch (_) {}

    var basePrice = regionalAvg * adj * demandMult
    var minPrice = Math.round(basePrice * 0.7 * 100) / 100
    var recPrice = Math.round(basePrice * 100) / 100
    var idealPrice = Math.round(basePrice * 1.3 * 100) / 100

    var analysis = 'Preco calculado com base em ' + count + ' produtos similares na regiao'
    if (demandMult > 1) analysis += ' e alta demanda detectada (' + matching + ' compradores)'

    return e.json(200, {
      min_price: minPrice,
      recommended_price: recPrice,
      ideal_price: idealPrice,
      analysis: analysis,
      factors: {
        regional_avg: Math.round(regionalAvg * 100) / 100,
        condition_adjustment: adj,
        demand_multiplier: demandMult,
      },
    })
  },
  $apis.requireAuth(),
)
