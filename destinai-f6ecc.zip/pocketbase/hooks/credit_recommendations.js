routerAdd(
  'GET',
  '/backend/v1/credit/recommendations',
  (e) => {
    const userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')

    let products = []
    try {
      products = $app.findRecordsByFilter('credit_products', '', '-created', 50, 0)
    } catch (_) {}

    let impactMetrics = []
    try {
      impactMetrics = $app.findRecordsByFilter(
        'impact_metrics',
        'user_id = "' + userId + '"',
        '-created',
        12,
        0,
      )
    } catch (_) {}

    var totalKgSaved = 0
    var totalRevenue = 0
    for (var i = 0; i < impactMetrics.length; i++) {
      totalKgSaved += impactMetrics[i].get('kg_saved') || 0
      totalRevenue += impactMetrics[i].get('revenue_recovered') || 0
    }
    var userRole = e.auth.getString('role') || ''

    var aiRecommendation = ''
    try {
      var productNames = []
      for (var j = 0; j < products.length; j++) {
        productNames.push(products[j].getString('name'))
      }
      var reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Voce e um consultor financeiro rural. Responda em portugues em 1-2 frases qual produto de credito e mais adequado.',
          },
          {
            role: 'user',
            content:
              'Perfil: ' +
              userRole +
              ', Kg salvos: ' +
              totalKgSaved +
              ', Receita: R$' +
              totalRevenue +
              '. Produtos: ' +
              productNames.join(', '),
          },
        ],
      })
      aiRecommendation = reply.choices[0].message.content
    } catch (err) {
      $app.logger().warn('AI credit recommendation failed', 'err', err.message)
    }

    var result = []
    for (var k = 0; k < products.length; k++) {
      var p = products[k]
      var recRolesStr = p.getString('recommended_roles') || ''
      var recRoles = recRolesStr.split(',').map(function (r) {
        return r.trim()
      })
      var isRecommended =
        recRoles.indexOf(userRole) >= 0 || recRoles.length === 0 || recRoles[0] === ''
      result.push({
        id: p.id,
        name: p.getString('name'),
        institution: p.getString('institution'),
        type: p.getString('type'),
        min_amount: p.get('min_amount') || 0,
        max_amount: p.get('max_amount') || 0,
        interest_rate: p.get('interest_rate') || 0,
        term_months: p.get('term_months') || 0,
        requirements: p.getString('requirements'),
        description: p.getString('description'),
        recommended: isRecommended,
      })
    }

    return e.json(200, { products: result, ai_recommendation: aiRecommendation })
  },
  $apis.requireAuth(),
)
