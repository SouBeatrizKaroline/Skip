routerAdd(
  'GET',
  '/backend/v1/smart-alerts',
  (e) => {
    var HIGH = [
      'alface',
      'tomate',
      'couve',
      'espinafre',
      'rucula',
      'agriao',
      'pepino',
      'abobrinha',
      'berinjela',
      'pimentao',
      'brocolis',
      'couve-flor',
      'cheiro',
      'repolho',
      'acelga',
    ]
    var MED = [
      'cenoura',
      'beterraba',
      'rabanete',
      'chuchu',
      'vagem',
      'ervilha',
      'milho',
      'nabo',
      'mandioquinha',
    ]

    var products = []
    try {
      products = $app.findRecordsByFilter(
        'products',
        "status != 'DELIVERED' && status != 'EXPIRED'",
        '-created',
        200,
        0,
      )
    } catch (_) {}

    var matches = []
    try {
      matches = $app.findRecordsByFilter('matches', "status = 'PENDING'", '-created', 10, 0)
    } catch (_) {}

    var alerts = []

    for (var i = 0; i < products.length; i++) {
      var p = products[i]
      var prodName = (p.getString('name') || '').toLowerCase()
      var harvestDate = p.getString('harvest_date')

      var perishLevel = 'low'
      var maxShelf = 21
      for (var j = 0; j < HIGH.length; j++) {
        if (prodName.indexOf(HIGH[j]) >= 0) {
          perishLevel = 'high'
          maxShelf = 5
          break
        }
      }
      if (perishLevel === 'low') {
        for (var k = 0; k < MED.length; k++) {
          if (prodName.indexOf(MED[k]) >= 0) {
            perishLevel = 'medium'
            maxShelf = 10
            break
          }
        }
      }

      var daysSince = 0
      if (harvestDate) {
        daysSince = Math.floor((Date.now() - new Date(harvestDate).getTime()) / 86400000)
      }
      var remaining = Math.max(0, maxShelf - daysSince)
      var usedPct = maxShelf > 0 ? Math.min(100, (daysSince / maxShelf) * 100) : 0

      if (remaining <= 1 && perishLevel === 'high') {
        alerts.push({
          urgency: 'critical',
          type: 'expiry',
          title: 'Lote cr\u00edtico expirando!',
          message:
            p.getString('name') +
            ' vence em menos de 24h. A Vivi recomenda acelerar a venda imediatamente.',
          product_id: p.id,
          product_name: p.getString('name'),
        })
      } else if (usedPct >= 80 && perishLevel !== 'low') {
        alerts.push({
          urgency: 'critical',
          type: 'expiry',
          title: 'Risco de vencimento alto',
          message:
            p.getString('name') +
            ' tem ' +
            remaining +
            ' dias restantes. A Vivi recomenda priorizar este lote.',
          product_id: p.id,
          product_name: p.getString('name'),
        })
      } else if (usedPct >= 50 && perishLevel === 'high') {
        alerts.push({
          urgency: 'warning',
          type: 'expiry',
          title: 'Aten\u00e7\u00e3o \u00e0 validade',
          message: p.getString('name') + ' tem ' + remaining + ' dias de validade restantes.',
          product_id: p.id,
          product_name: p.getString('name'),
        })
      }

      var pLat = p.get('latitude') || 0
      var pLon = p.get('longitude') || 0
      if (pLat !== 0 || pLon !== 0) {
        try {
          var wRes = $http.send({
            url:
              'https://api.open-meteo.com/v1/forecast?latitude=' +
              pLat +
              '&longitude=' +
              pLon +
              '&current=temperature_2m,relative_humidity_2m',
            method: 'GET',
            timeout: 8,
          })
          if (wRes.statusCode === 200 && wRes.json && wRes.json.current) {
            var temp = wRes.json.current.temperature_2m
            var humid = wRes.json.current.relative_humidity_2m
            if (temp > 30 && perishLevel === 'high') {
              alerts.push({
                urgency: 'critical',
                type: 'climate',
                title: 'Risco clim\u00e1tico detectado',
                message:
                  'Temperatura de ' +
                  Math.round(temp) +
                  '\u00b0C para ' +
                  p.getString('name') +
                  '. A Vivi recomenda acelerar a log\u00edstica.',
                product_id: p.id,
                product_name: p.getString('name'),
              })
            }
            if (humid > 85 && perishLevel === 'high') {
              alerts.push({
                urgency: 'warning',
                type: 'climate',
                title: 'Alta umidade',
                message:
                  'Umidade de ' +
                  humid +
                  '% para ' +
                  p.getString('name') +
                  '. Risco de deteriora\u00e7\u00e3o.',
                product_id: p.id,
                product_name: p.getString('name'),
              })
            }
          }
        } catch (_) {}
      }
    }

    for (var m = 0; m < matches.length; m++) {
      alerts.push({
        urgency: 'info',
        type: 'match',
        title: 'Nova correspond\u00eancia',
        message:
          'Um novo match foi encontrado. A Vivi recomenda conferir as negocia\u00e7\u00f5es.',
        match_id: matches[m].id,
      })
    }

    var recommendations = []
    try {
      recommendations = $app.findRecordsByFilter(
        'recommendations',
        'match_score >= 90',
        '-created',
        5,
        0,
      )
    } catch (_) {}

    for (var r = 0; r < recommendations.length; r++) {
      alerts.push({
        urgency: 'info',
        type: 'match',
        title: 'Match excepcional encontrado!',
        message:
          'A Vivi encontrou um comprador com ' +
          recommendations[r].get('match_score') +
          '% de compatibilidade. A Vivi recomenda aceitar esta oportunidade.',
        product_id: recommendations[r].getString('product_id'),
      })
    }

    alerts.push({
      urgency: 'info',
      type: 'demand',
      title: 'Demanda regional em alta',
      message:
        'A Vivi detectou aumento na demanda por hortali\u00e7as na regi\u00e3o. Considere cadastrar novos lotes.',
    })

    var order = { critical: 0, warning: 1, info: 2 }
    alerts.sort(function (a, b) {
      return (order[a.urgency] || 3) - (order[b.urgency] || 3)
    })

    return e.json(200, { alerts: alerts })
  },
  $apis.requireAuth(),
)
