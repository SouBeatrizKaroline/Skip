routerAdd(
  'GET',
  '/backend/v1/recommendations/{productId}',
  (e) => {
    const productId = e.request.pathValue('productId')
    if (!productId) return e.badRequestError('productId is required')

    let product
    try {
      product = $app.findRecordById('products', productId)
    } catch (_) {
      return e.notFoundError('product not found')
    }

    const prodLat = product.get('latitude') || 0
    const prodLon = product.get('longitude') || 0
    const prodName = product.getString('name').toLowerCase()
    const qty = product.get('quantity_kg') || 0
    const pricePerKg = product.get('price_per_kg') || 0
    const lotValue = qty * pricePerKg

    let buyers = []
    try {
      buyers = $app.findRecordsByFilter('buyer_profiles', '', '-created', 500, 0)
    } catch (_) {}

    const R = 6371
    const scored = []
    for (const buyer of buyers) {
      const bLat = buyer.get('latitude') || 0
      const bLon = buyer.get('longitude') || 0
      const dLat = ((bLat - prodLat) * Math.PI) / 180
      const dLon = ((bLon - prodLon) * Math.PI) / 180
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((prodLat * Math.PI) / 180) *
          Math.cos((bLat * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2)
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
      const distance = R * c

      const tags = (buyer.getString('demand_tags') || '').toLowerCase()
      let demandMatch = 0
      if (tags.indexOf(prodName) >= 0) demandMatch = 20
      else if (
        tags.split(',').some(function (t) {
          return prodName.indexOf(t.trim()) >= 0 || t.trim().indexOf(prodName) >= 0
        })
      )
        demandMatch = 10

      const distScore = Math.max(0, 80 - distance * 2)
      const matchScore = Math.min(100, Math.round(distScore + demandMatch))

      const logisticsCost = Math.round(distance * 2.5 * 100) / 100
      const feePct = 0.02
      const platformFee = Math.round(lotValue * feePct * 100) / 100
      const netRevenue = Math.round((lotValue - logisticsCost - platformFee) * 100) / 100
      const economicScore =
        lotValue > 0 ? Math.min(100, Math.max(0, Math.round((netRevenue / lotValue) * 100))) : 0
      const logisticsScore = Math.max(0, Math.round(100 - distance * 3))

      scored.push({
        buyer_id: buyer.id,
        business_name: buyer.getString('business_name'),
        buyer_type: buyer.getString('buyer_type'),
        city: buyer.getString('city'),
        state: buyer.getString('state'),
        distance_km: Math.round(distance * 10) / 10,
        match_score: matchScore,
        economic_score: economicScore,
        logistics_score: logisticsScore,
        demand_tags: buyer.getString('demand_tags'),
        financial: {
          lot_value: lotValue,
          logistics_cost: logisticsCost,
          platform_fee: platformFee,
          net_revenue: netRevenue,
          fee_percentage: feePct * 100,
        },
      })
    }

    scored.sort(function (a, b) {
      return b.match_score - a.match_score
    })
    const top3 = scored.slice(0, 3)

    var justifications = []
    try {
      var promptParts = []
      for (var i = 0; i < top3.length; i++) {
        promptParts.push(
          i +
            1 +
            '. ' +
            top3[i].business_name +
            ' - Match: ' +
            top3[i].match_score +
            '%, Economico: ' +
            top3[i].economic_score +
            '%, Logistica: ' +
            top3[i].logistics_score +
            '%, ' +
            top3[i].distance_km +
            'km',
        )
      }
      var reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Voce e a Vivi, especialista em logistica agricola. Para cada destino, de uma frase curta em portugues justificando a recomendacao, comecando obrigatoriamente com "A Vivi recomenda". Inclua dados especificos como distancia, margem de lucro e clima. Separe cada justificativa com |||',
          },
          {
            role: 'user',
            content:
              'Produto: ' +
              product.getString('name') +
              ', ' +
              qty +
              'kg. Destinos:\n' +
              promptParts.join('\n'),
          },
        ],
      })
      justifications = reply.choices[0].message.content.split('|||')
    } catch (err) {
      $app.logger().warn('AI justification failed', 'err', err.message)
    }

    for (var j = 0; j < top3.length; j++) {
      top3[j].ai_justification = (
        justifications[j] || 'Compatibilidade baseada em proximidade e viabilidade economica.'
      ).trim()
      try {
        const col = $app.findCollectionByNameOrId('recommendations')
        const r = new Record(col)
        r.set('product_id', productId)
        r.set('buyer_id', top3[j].buyer_id)
        r.set('match_score', top3[j].match_score)
        r.set('distance_km', top3[j].distance_km)
        r.set('compatibility_score', top3[j].match_score)
        r.set('economic_score', top3[j].economic_score)
        r.set('logistics_score', top3[j].logistics_score)
        r.set('ai_justification', top3[j].ai_justification || '')
        r.set('status', 'PENDING')
        $app.save(r)
      } catch (_) {}
    }

    return e.json(200, { product_id: productId, recommendations: top3 })
  },
  $apis.requireAuth(),
)
