onRecordAfterUpdateSuccess((e) => {
  var match = e.record
  var oldStatus = e.record.original().getString('status')
  var newStatus = match.getString('status')
  if (oldStatus === newStatus) return e.next()
  if (newStatus !== 'COMPLETED') return e.next()

  var productId = match.getString('product_id')
  var producerId = match.getString('producer_id')
  var buyerId = match.getString('buyer_id')
  var priceAgreed = match.get('price_agreed') || 0

  var qty = 0
  try {
    var product = $app.findRecordById('products', productId)
    qty = product.get('quantity_kg') || 0
  } catch (_) {}

  var co2Saved = Math.round(qty * 1.5)
  var waterSaved = Math.round(qty * 200)
  var mealsGenerated = Math.round(qty * 2)
  var revenue = Math.round(qty * priceAgreed)

  var monthNames = [
    'Janeiro',
    'Fevereiro',
    'Marco',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
  ]
  var currentMonth = monthNames[new Date().getMonth()]

  function upsertImpact(userId) {
    if (!userId) return
    try {
      var existing = $app.findRecordsByFilter(
        'impact_metrics',
        'user_id = "' + userId + '" && month = "' + currentMonth + '"',
        '-created',
        1,
        0,
      )
      if (existing.length > 0) {
        var rec = existing[0]
        rec.set('kg_saved', (rec.get('kg_saved') || 0) + qty)
        rec.set('co2_saved_kg', (rec.get('co2_saved_kg') || 0) + co2Saved)
        rec.set('revenue_recovered', (rec.get('revenue_recovered') || 0) + revenue)
        rec.set('water_preserved_liters', (rec.get('water_preserved_liters') || 0) + waterSaved)
        rec.set('meals_generated', (rec.get('meals_generated') || 0) + mealsGenerated)
        $app.saveNoValidate(rec)
      } else {
        var col = $app.findCollectionByNameOrId('impact_metrics')
        var newRec = new Record(col)
        newRec.set('user_id', userId)
        newRec.set('kg_saved', qty)
        newRec.set('co2_saved_kg', co2Saved)
        newRec.set('revenue_recovered', revenue)
        newRec.set('water_preserved_liters', waterSaved)
        newRec.set('meals_generated', mealsGenerated)
        newRec.set('month', currentMonth)
        $app.saveNoValidate(newRec)
      }
    } catch (_) {}
  }

  try {
    var producer = $app.findRecordById('producer_profiles', producerId)
    upsertImpact(producer.getString('user_id'))
  } catch (_) {}

  try {
    var buyer = $app.findRecordById('buyer_profiles', buyerId)
    upsertImpact(buyer.getString('user_id'))
  } catch (_) {}

  return e.next()
}, 'matches')
