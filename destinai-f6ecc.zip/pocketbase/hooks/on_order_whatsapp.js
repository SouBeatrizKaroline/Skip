onRecordAfterUpdateSuccess((e) => {
  var order = e.record
  var oldStatus = e.record.original().getString('status')
  var newStatus = order.getString('status')
  if (oldStatus === newStatus) return e.next()

  var notifyStatuses = ['ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED']
  if (notifyStatuses.indexOf(newStatus) < 0) return e.next()

  var match = null,
    product = null,
    buyer = null
  try {
    match = $app.findRecordById('matches', order.getString('match_id'))
    product = $app.findRecordById('products', match.getString('product_id'))
    buyer = $app.findRecordById('buyer_profiles', match.getString('buyer_id'))
  } catch (_) {
    return e.next()
  }

  var buyerPhone = buyer ? buyer.getString('phone') : ''
  var productName = product ? product.getString('name') : 'produto'

  var messages = {
    ASSIGNED: '\u{1F69A} DestinAI: Transportador designado para seu pedido de ' + productName + '.',
    PICKED_UP:
      '\u{1F4E6} DestinAI: Carga coletada! Seu pedido de ' + productName + ' esta a caminho.',
    IN_TRANSIT: '\u{1F69B} DestinAI: Seu pedido de ' + productName + ' esta em transito.',
    DELIVERED: '\u{2705} DestinAI: Pedido de ' + productName + ' entregue com sucesso!',
  }

  var apiKey = $secrets.get('WHATSAPP_API_KEY') || ''
  var apiUrl = $secrets.get('WHATSAPP_API_URL') || ''

  if (apiKey && apiUrl && buyerPhone && messages[newStatus]) {
    try {
      $http.send({
        url: apiUrl,
        method: 'POST',
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: buyerPhone, text: messages[newStatus] }),
        timeout: 10,
      })
    } catch (_) {}
  }

  return e.next()
}, 'orders')
