routerAdd(
  'POST',
  '/backend/v1/rate-transaction',
  (e) => {
    var body = e.requestInfo().body || {}
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')

    var type = body.type || ''
    var recordId = body.id || ''
    var rating = parseInt(body.rating) || 0
    var raterRole = body.rater_role || ''

    if (rating < 1 || rating > 5) return e.badRequestError('rating must be 1-5')
    if (!type || !recordId) return e.badRequestError('type and id are required')

    var repPoints = (rating - 3) * 5

    function updateReputation(targetUserId, points) {
      try {
        var user = $app.findRecordById('users', targetUserId)
        var score = user.get('reputation_score') || 0
        score += points
        if (score < 0) score = 0
        user.set('reputation_score', score)
        var tier = 'BRONZE'
        if (score >= 600) tier = 'DIAMOND'
        else if (score >= 300) tier = 'GOLD'
        else if (score >= 100) tier = 'SILVER'
        user.set('tier_status', tier)
        $app.saveNoValidate(user)
      } catch (_) {}
    }

    if (type === 'match') {
      try {
        var match = $app.findRecordById('matches', recordId)
        if (match.getString('status') !== 'COMPLETED')
          return e.badRequestError('match must be completed to rate')
        if (raterRole === 'PRODUCER') {
          match.set('producer_rating', rating)
          try {
            var buyer = $app.findRecordById('buyer_profiles', match.getString('buyer_id'))
            updateReputation(buyer.getString('user_id'), repPoints)
          } catch (_) {}
        } else if (raterRole === 'BUYER') {
          match.set('buyer_rating', rating)
          try {
            var producer = $app.findRecordById('producer_profiles', match.getString('producer_id'))
            updateReputation(producer.getString('user_id'), repPoints)
          } catch (_) {}
        }
        $app.saveNoValidate(match)
      } catch (err) {
        return e.badRequestError('match not found')
      }
    } else if (type === 'order') {
      try {
        var order = $app.findRecordById('orders', recordId)
        if (order.getString('status') !== 'DELIVERED')
          return e.badRequestError('order must be delivered to rate')
        order.set('rating', rating)
        try {
          var transporter = $app.findRecordById(
            'transporter_profiles',
            order.getString('transporter_id'),
          )
          updateReputation(transporter.getString('user_id'), repPoints)
        } catch (_) {}
        $app.saveNoValidate(order)
      } catch (err) {
        return e.badRequestError('order not found')
      }
    } else {
      return e.badRequestError('type must be match or order')
    }

    return e.json(200, { success: true, rating: rating })
  },
  $apis.requireAuth(),
)
