routerAdd(
  'GET',
  '/backend/v1/vivi/command-center',
  (e) => {
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')
    var role = e.auth.get('role') || 'PRODUCER'
    var insights = []

    try {
      var products = $app.findRecordsByFilter(
        'products',
        "status != 'DELIVERED' && status != 'EXPIRED' && (waste_risk_level = 'HIGH' || waste_risk_level = 'CRITICAL')",
        '-created',
        5,
        0,
      )
      if (products.length > 0) {
        var p = products[0]
        insights.push({
          type: 'expiry_alert',
          icon: '\u23F0',
          title: 'Lote crítico expirando!',
          message: p.getString('name') + ' está em risco crítico de desperdício.',
          action_text: 'Ver destinos',
          action_url: '/producer/destinations',
          priority: 'high',
          vivi_insight:
            'A Vivi detectou que ' +
            p.getString('name') +
            ' tem risco alto. Acelere a comercialização! \uD83C\uDF31',
        })
      }
    } catch (_) {}

    try {
      var recs = $app.findRecordsByFilter(
        'recommendations',
        'match_score >= 85',
        '-match_score',
        5,
        0,
      )
      if (recs.length > 0) {
        var r = recs[0]
        var prod = $app.findRecordById('products', r.getString('product_id'))
        insights.push({
          type: 'hot_match',
          icon: '\uD83D\uDD25',
          title: 'Match de ' + (r.get('match_score') || 0) + '% encontrado!',
          message: prod.getString('name') + ' tem um comprador altamente compatível.',
          action_text: 'Ver oportunidade',
          action_url: '/opportunities',
          priority: 'high',
          vivi_insight:
            'A Vivi encontrou uma oportunidade excepcional! Não perca esta chance. \uD83C\uDF31',
        })
      }
    } catch (_) {}

    if (role === 'BUYER') {
      try {
        var bp = $app.findFirstRecordByFilter('buyer_profiles', 'user_id = "' + userId + '"')
        var tags = bp.getString('demand_tags') || ''
        if (tags) {
          var tagList = tags
            .split(',')
            .map(function (t) {
              return t.trim().toLowerCase()
            })
            .filter(function (t) {
              return t
            })
          var allProds = $app.findRecordsByFilter(
            'products',
            "status = 'AVAILABLE'",
            '-created',
            50,
            0,
          )
          for (var pi = 0; pi < allProds.length; pi++) {
            var pn = allProds[pi].getString('name').toLowerCase()
            for (var ti = 0; ti < tagList.length; ti++) {
              if (pn.indexOf(tagList[ti]) >= 0 || tagList[ti].indexOf(pn) >= 0) {
                insights.push({
                  type: 'recommended_purchase',
                  icon: '\uD83D\uDED2',
                  title: 'Compra recomendada pela Vivi',
                  message:
                    allProds[pi].getString('name') +
                    ' - ' +
                    (allProds[pi].get('quantity_kg') || 0) +
                    'kg disponível',
                  action_text: 'Ver produto',
                  action_url: '/buyer/product/' + allProds[pi].id,
                  priority: 'high',
                  vivi_insight:
                    'A Vivi encontrou ' +
                    allProds[pi].getString('name') +
                    ' que corresponde às suas demandas! \uD83C\uDF31',
                })
                break
              }
            }
            if (insights.length > 3) break
          }
        }
      } catch (_) {}
    }

    try {
      var monthNames = [
        'Janeiro',
        'Fevereiro',
        'Marco',
        'Abril',
        'Maio',
        'Junho',
        'Julho',
        'Agosto',
        'Setembro',
        'Outubro',
        'Novembro',
        'Dezembro',
      ]
      var currentMonth = monthNames[new Date().getMonth()]
      var goals = $app.findRecordsByFilter(
        'user_goals',
        'user_id = "' + userId + '" && month = "' + currentMonth + '"',
        '-created',
        5,
        0,
      )
      if (goals.length > 0) {
        var g = goals[0]
        var prog =
          g.get('target_value') > 0
            ? Math.min(
                100,
                Math.round(((g.get('current_value') || 0) / g.get('target_value')) * 100),
              )
            : 0
        insights.push({
          type: 'goal_progress',
          icon: '\uD83C\uDFAF',
          title: 'Progresso da meta mensal',
          message: prog + '% da sua meta',
          progress: prog,
          current: g.get('current_value') || 0,
          target: g.get('target_value') || 0,
          priority: 'medium',
          vivi_insight: 'A Vivi está acompanhando seu progresso. Continue assim! \uD83C\uDF31',
        })
      }
    } catch (_) {}

    if (insights.length < 2) {
      try {
        var reply = $ai.chat({
          model: 'fast',
          messages: [
            {
              role: 'system',
              content:
                'Voce e a Vivi, assistente de AgTech. De uma dica curta e proativa em portugues para um ' +
                role +
                ' sobre reducao de desperdicio. Maximo 2 frases.',
            },
            { role: 'user', content: 'Dica do dia.' },
          ],
        })
        insights.push({
          type: 'daily_insight',
          icon: '\uD83D\uDCA1',
          title: 'Insight do dia da Vivi',
          message: reply.choices[0].message.content,
          priority: 'low',
          vivi_insight: reply.choices[0].message.content,
        })
      } catch (_) {}
    }

    return e.json(200, { insights: insights, role: role })
  },
  $apis.requireAuth(),
)
