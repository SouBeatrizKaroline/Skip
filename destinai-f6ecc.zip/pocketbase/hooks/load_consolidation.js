routerAdd(
  'GET',
  '/backend/v1/load-consolidation',
  (e) => {
    let products = []
    try {
      products = $app.findRecordsByFilter(
        'products',
        "status = 'AVAILABLE' || status = 'MATCHED'",
        '-created',
        500,
        0,
      )
    } catch (_) {}

    var groups = []
    var used = {}

    for (var i = 0; i < products.length; i++) {
      if (used[products[i].id]) continue
      var p1 = products[i]
      var lat1 = p1.get('latitude') || 0
      var lon1 = p1.get('longitude') || 0
      var group = [p1]
      used[p1.id] = true

      for (var j = i + 1; j < products.length; j++) {
        if (used[products[j].id]) continue
        var p2 = products[j]
        var lat2 = p2.get('latitude') || 0
        var lon2 = p2.get('longitude') || 0

        var R = 6371
        var dLat = ((lat2 - lat1) * Math.PI) / 180
        var dLon = ((lon2 - lon1) * Math.PI) / 180
        var a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2)
        var cc = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        var dist = R * cc

        if (dist <= 20 && p1.getString('city') === p2.getString('city')) {
          group.push(p2)
          used[p2.id] = true
        }
      }

      if (group.length > 1) {
        var totalKg = 0
        var totalValue = 0
        var productInfos = []
        for (var k = 0; k < group.length; k++) {
          totalKg += group[k].get('quantity_kg') || 0
          totalValue += (group[k].get('quantity_kg') || 0) * (group[k].get('price_per_kg') || 0)
          productInfos.push({
            id: group[k].id,
            name: group[k].getString('name'),
            quantity_kg: group[k].get('quantity_kg'),
            city: group[k].getString('city'),
            state: group[k].getString('state'),
          })
        }
        groups.push({
          products: productInfos,
          total_kg: totalKg,
          total_value: Math.round(totalValue * 100) / 100,
          estimated_savings: Math.round(totalValue * 0.15 * 100) / 100,
        })
      }
    }

    return e.json(200, { consolidation_groups: groups })
  },
  $apis.requireAuth(),
)
