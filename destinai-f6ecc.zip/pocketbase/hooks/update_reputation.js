onRecordAfterUpdateSuccess((e) => {
  var match = e.record
  var oldStatus = e.record.original().getString('status')
  var newStatus = match.getString('status')
  if (oldStatus === newStatus) return e.next()
  if (newStatus !== 'COMPLETED') return e.next()

  function updateUserRep(userId, points) {
    try {
      var user = $app.findRecordById('users', userId)
      var score = user.get('reputation_score') || 0
      score += points
      user.set('reputation_score', score)
      var tier = 'BRONZE'
      if (score >= 600) tier = 'DIAMOND'
      else if (score >= 300) tier = 'GOLD'
      else if (score >= 100) tier = 'SILVER'
      user.set('tier_status', tier)
      $app.saveNoValidate(user)
    } catch (_) {}
  }

  try {
    var producer = $app.findRecordById('producer_profiles', match.getString('producer_id'))
    updateUserRep(producer.getString('user_id'), 10)
  } catch (_) {}

  try {
    var buyer = $app.findRecordById('buyer_profiles', match.getString('buyer_id'))
    updateUserRep(buyer.getString('user_id'), 10)
  } catch (_) {}

  return e.next()
}, 'matches')
