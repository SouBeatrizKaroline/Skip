routerAdd(
  'POST',
  '/backend/v1/ask-vivi',
  (e) => {
    try {
      var body = e.requestInfo().body || {}
      var userId = e.auth ? e.auth.id : ''
      if (!userId) return e.unauthorizedError('auth required')
      if (!body.message || !body.message.trim()) return e.badRequestError('message is required')

      var weatherContext = ''
      try {
        var profile = null
        try {
          profile = $app.findFirstRecordByFilter('producer_profiles', "user_id = '" + userId + "'")
        } catch (_) {}
        if (!profile) {
          try {
            profile = $app.findFirstRecordByFilter('buyer_profiles', "user_id = '" + userId + "'")
          } catch (_) {}
        }

        if (profile && profile.getString('city')) {
          var city = profile.getString('city')
          var state = profile.getString('state') || ''
          var searchQ = state ? city + ', ' + state : city
          var geoRes = $http.send({
            url:
              'https://geocoding-api.open-meteo.com/v1/search?name=' +
              encodeURIComponent(searchQ) +
              '&countryCode=BR&count=1',
            method: 'GET',
            timeout: 5,
          })
          if (
            geoRes.statusCode === 200 &&
            geoRes.json &&
            geoRes.json.results &&
            geoRes.json.results.length > 0
          ) {
            var lat = geoRes.json.results[0].latitude
            var lon = geoRes.json.results[0].longitude
            var wRes = $http.send({
              url:
                'https://api.open-meteo.com/v1/forecast?latitude=' +
                lat +
                '&longitude=' +
                lon +
                '&current=temperature_2m,relative_humidity_2m,weather_code',
              method: 'GET',
              timeout: 5,
            })
            if (wRes.statusCode === 200 && wRes.json && wRes.json.current) {
              weatherContext =
                '[Contexto climatico: ' +
                wRes.json.current.temperature_2m +
                'C, ' +
                wRes.json.current.relative_humidity_2m +
                '% umidade em ' +
                city +
                '] '
            }
          }
        }
      } catch (_) {}

      var result = $ai.agent('vivi-assistant').chat({
        user_id: userId,
        conversation_id: body.conversation_id || null,
        message: weatherContext + body.message,
      })

      return e.json(200, {
        conversation_id: result.conversation_id,
        content: result.content,
        citations: result.citations,
        message_id: result.message_id,
      })
    } catch (err) {
      if (err instanceof SkipAiConfigError)
        return e.json(503, { error: 'IA temporariamente indisponivel' })
      if (err instanceof SkipAiAgentsError) {
        var status1 = err.status || 500
        return e.json(status1, { error: status1 >= 500 ? 'falha no agente' : err.message })
      }
      if (err instanceof SkipAiError) {
        var status2 = err.status || 502
        return e.json(status2, {
          error: status2 >= 500 ? 'IA temporariamente indisponivel' : err.message,
        })
      }
      throw err
    }
  },
  $apis.requireAuth(),
)
