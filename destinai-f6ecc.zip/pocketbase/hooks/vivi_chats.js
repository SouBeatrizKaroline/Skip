routerAdd(
  'GET',
  '/backend/v1/vivi/chats',
  (e) => {
    const userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')
    const limit = parseInt((e.requestInfo().query || {}).limit || '20', 10) || 20
    return e.json(
      200,
      $ai.agent('vivi-assistant').listConversations({ user_id: userId, limit: limit }),
    )
  },
  $apis.requireAuth(),
)
