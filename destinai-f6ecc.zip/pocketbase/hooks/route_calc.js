routerAdd(
  'GET',
  '/backend/v1/route',
  (e) => {
    const query = e.requestInfo().query || {}
    var fromLat = parseFloat(query.fromLat)
    var fromLon = parseFloat(query.fromLon)
    var toLat = parseFloat(query.toLat)
    var toLon = parseFloat(query.toLon)
    if (isNaN(fromLat) || isNaN(fromLon) || isNaN(toLat) || isNaN(toLon)) {
      return e.badRequestError('Valid fromLat, fromLon, toLat, toLon are required')
    }

    try {
      var res = $http.send({
        url:
          'https://router.project-osrm.org/route/v1/driving/' +
          fromLon +
          ',' +
          fromLat +
          ';' +
          toLon +
          ',' +
          toLat +
          '?overview=false',
        method: 'GET',
        timeout: 15,
      })
      if (res.statusCode === 200 && res.json && res.json.routes && res.json.routes.length > 0) {
        var route = res.json.routes[0]
        var distKm = Math.round(route.distance / 10) / 10
        var durMin = Math.round(route.duration / 60)
        return e.json(200, {
          distance_km: distKm,
          duration_min: durMin,
          eta_text:
            durMin < 60 ? durMin + ' min' : Math.floor(durMin / 60) + 'h ' + (durMin % 60) + 'min',
        })
      }
    } catch (_) {}

    var R = 6371
    var dLat = ((toLat - fromLat) * Math.PI) / 180
    var dLon = ((toLon - fromLon) * Math.PI) / 180
    var a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((fromLat * Math.PI) / 180) *
        Math.cos((toLat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2)
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    var fallbackKm = Math.round(R * c * 10) / 10
    var fallbackMin = Math.round((fallbackKm / 40) * 60)
    return e.json(200, {
      distance_km: fallbackKm,
      duration_min: fallbackMin,
      eta_text:
        fallbackMin < 60
          ? fallbackMin + ' min'
          : Math.floor(fallbackMin / 60) + 'h ' + (fallbackMin % 60) + 'min',
      fallback: true,
    })
  },
  $apis.requireAuth(),
)
