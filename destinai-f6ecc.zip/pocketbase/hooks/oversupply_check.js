routerAdd(
  'GET',
  '/backend/v1/oversupply-check',
  (e) => {
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')

    var alerts = []
    try {
      var products = $app.findRecordsByFilter(
        'products',
        "status = 'AVAILABLE'",
        '-created',
        500,
        0,
      )

      var groups = {}
      for (var i = 0; i < products.length; i++) {
        var p = products[i]
        var name = (p.getString('name') || '').toLowerCase().trim()
        var city = (p.getString('city') || '').toLowerCase().trim()
        var key = name + '|' + city
        if (!groups[key]) {
          groups[key] = {
            product_name: p.getString('name'),
            city: p.getString('city') || 'Não informado',
            count: 0,
            total_kg: 0,
            products: [],
          }
        }
        groups[key].count++
        groups[key].total_kg += p.get('quantity_kg') || 0
        groups[key].products.push({
          id: p.id,
          name: p.getString('name'),
          quantity_kg: p.get('quantity_kg') || 0,
          price_per_kg: p.get('price_per_kg') || 0,
          waste_risk_level: p.getString('waste_risk_level'),
        })
      }

      for (var k in groups) {
        if (groups[k].count >= 3) {
          var g = groups[k]
          var suggestedAction =
            'Considere reduzir o preco em 10-15% ou direcionar para Banco de Alimentos'
          if (g.count >= 5) {
            suggestedAction =
              'CRITICO: Reduza preco em 20% ou redirecione imediatamente para processamento industrial'
          }
          alerts.push({
            product_name: g.product_name,
            city: g.city,
            count: g.count,
            total_kg: g.total_kg,
            suggested_action: suggestedAction,
            products: g.products,
          })
        }
      }
    } catch (_) {}

    return e.json(200, { alerts: alerts })
  },
  $apis.requireAuth(),
)
