routerAdd(
  'POST',
  '/backend/v1/whatsapp/notify',
  (e) => {
    var body = e.requestInfo().body || {}
    var phone = (body.phone || '').trim()
    var message = (body.message || '').trim()
    if (!phone || !message) return e.badRequestError('phone and message are required')

    var apiKey = $secrets.get('WHATSAPP_API_KEY') || ''
    var apiUrl = $secrets.get('WHATSAPP_API_URL') || ''

    if (!apiKey || !apiUrl) {
      return e.json(200, {
        success: true,
        simulated: true,
        phone: phone,
        message: 'Notificacao simulada (WhatsApp API nao configurada)',
      })
    }

    try {
      var res = $http.send({
        url: apiUrl,
        method: 'POST',
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: phone, text: message }),
        timeout: 15,
      })
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return e.json(200, { success: true, simulated: false, phone: phone })
      }
      $app.logger().warn('WhatsApp API error', 'status', res.statusCode, 'phone', phone)
      return e.json(200, {
        success: true,
        simulated: true,
        phone: phone,
        message: 'Fallback simulado',
      })
    } catch (err) {
      $app.logger().error('WhatsApp send failed', 'err', err.message, 'phone', phone)
      return e.json(200, {
        success: true,
        simulated: true,
        phone: phone,
        message: 'Fallback simulado',
      })
    }
  },
  $apis.requireAuth(),
)
