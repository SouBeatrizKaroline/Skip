routerAdd(
  'GET',
  '/backend/v1/leaderboard',
  (e) => {
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')
    var role = e.auth.get('role') || 'PRODUCER'

    var users = []
    try {
      users = $app.findRecordsByFilter(
        'users',
        "role = '" + role + "' && status = 'ACTIVE'",
        '-reputation_score',
        100,
        0,
      )
    } catch (_) {}

    var rankings = []
    for (var i = 0; i < users.length; i++) {
      var u = users[i]
      var kgSaved = 0,
        co2Saved = 0,
        revenue = 0,
        meals = 0
      try {
        var metrics = $app.findRecordsByFilter(
          'impact_metrics',
          'user_id = "' + u.id + '"',
          '-created',
          100,
          0,
        )
        for (var j = 0; j < metrics.length; j++) {
          kgSaved += metrics[j].get('kg_saved') || 0
          co2Saved += metrics[j].get('co2_saved_kg') || 0
          revenue += metrics[j].get('revenue_recovered') || 0
          meals += metrics[j].get('meals_generated') || 0
        }
      } catch (_) {}

      rankings.push({
        user_id: u.id,
        name: u.getString('name') || u.getString('email'),
        company_name: u.getString('company_name') || '',
        role: u.getString('role'),
        reputation_score: u.get('reputation_score') || 0,
        tier_status: u.getString('tier_status') || 'BRONZE',
        kg_saved: kgSaved,
        co2_saved_kg: co2Saved,
        revenue_recovered: revenue,
        meals_generated: meals,
        rank: i + 1,
        is_current_user: u.id === userId,
      })
    }

    var myRank = 0
    for (var k = 0; k < rankings.length; k++) {
      if (rankings[k].is_current_user) {
        myRank = k + 1
        break
      }
    }

    return e.json(200, {
      role: role,
      rankings: rankings,
      my_rank: myRank,
      total_users: rankings.length,
    })
  },
  $apis.requireAuth(),
)
