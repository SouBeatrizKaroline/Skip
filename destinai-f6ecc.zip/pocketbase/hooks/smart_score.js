routerAdd(
  'POST',
  '/backend/v1/smart-score/{productId}',
  (e) => {
    const productId = e.request.pathValue('productId')
    if (!productId) return e.badRequestError('productId is required')
    let product
    try {
      product = $app.findRecordById('products', productId)
    } catch (_) {
      return e.notFoundError('product not found')
    }

    const prodName = (product.getString('name') || '').toLowerCase()
    const qty = product.get('quantity_kg') || 0
    const pricePerKg = product.get('price_per_kg') || 0
    const lotValue = Math.round(qty * pricePerKg * 100) / 100
    const condition = product.getString('visual_condition')
    const harvestDate = product.getString('harvest_date')
    const prodLat = product.get('latitude') || 0
    const prodLon = product.get('longitude') || 0

    var HIGH = [
      'alface',
      'tomate',
      'couve',
      'espinafre',
      'rucula',
      'agriao',
      'pepino',
      'abobrinha',
      'berinjela',
      'pimentao',
      'brocolis',
      'couve-flor',
      'cheiro',
      'repolho',
      'acelga',
    ]
    var MED = [
      'cenoura',
      'beterraba',
      'rabanete',
      'chuchu',
      'vagem',
      'ervilha',
      'milho',
      'nabo',
      'mandioquinha',
    ]
    var perishLevel = 'low'
    var maxShelf = 21
    for (var i = 0; i < HIGH.length; i++) {
      if (prodName.indexOf(HIGH[i]) >= 0) {
        perishLevel = 'high'
        maxShelf = 5
        break
      }
    }
    if (perishLevel === 'low') {
      for (var j = 0; j < MED.length; j++) {
        if (prodName.indexOf(MED[j]) >= 0) {
          perishLevel = 'medium'
          maxShelf = 10
          break
        }
      }
    }
    var condAdj = {
      RETAIL_STANDARD: 1.0,
      MINOR_IMPERFECTIONS: 0.8,
      NON_STANDARD: 0.6,
      PROCESSING_ONLY: 0.4,
    }
    maxShelf = Math.round(maxShelf * (condAdj[condition] || 0.7))
    var daysSince = 0
    if (harvestDate) {
      daysSince = Math.floor((Date.now() - new Date(harvestDate).getTime()) / 86400000)
    }
    var remaining = Math.max(0, maxShelf - daysSince)
    var usedPct = maxShelf > 0 ? Math.min(100, Math.round((daysSince / maxShelf) * 100)) : 0
    var risk = 'low'
    var emoji = '\u{1F7E2}'
    if (usedPct >= 90) {
      risk = 'critical'
      emoji = '\u{1F534}'
    } else if (usedPct >= 70) {
      risk = 'high'
      emoji = '\u{1F7E0}'
    } else if (usedPct >= 40) {
      risk = 'medium'
      emoji = '\u{1F7E1}'
    }
    var perishScore = Math.max(0, 100 - usedPct)

    var weather = { temperature: 0, humidity: 0, condition: 'Indispon\u00edvel', alerts: [] }
    if (prodLat !== 0 || prodLon !== 0) {
      try {
        var wRes = $http.send({
          url:
            'https://api.open-meteo.com/v1/forecast?latitude=' +
            prodLat +
            '&longitude=' +
            prodLon +
            '&current=temperature_2m,relative_humidity_2m,weather_code',
          method: 'GET',
          timeout: 10,
        })
        if (wRes.statusCode === 200 && wRes.json && wRes.json.current) {
          var c = wRes.json.current
          weather.temperature = Math.round(c.temperature_2m)
          weather.humidity = c.relative_humidity_2m
          var code = c.weather_code
          weather.condition =
            code === 0
              ? 'C\u00e9u limpo'
              : code <= 3
                ? 'Parcialmente nublado'
                : code <= 48
                  ? 'Nevoa'
                  : code <= 67
                    ? 'Chuva'
                    : code <= 82
                      ? 'Pancadas'
                      : 'Tempestade'
          if (c.temperature_2m > 30 && perishLevel === 'high')
            weather.alerts.push('Onda de calor: acelerar venda para evitar deteriora\u00e7\u00e3o')
          if (c.relative_humidity_2m > 85 && perishLevel === 'high')
            weather.alerts.push('Alta umidade: risco de deteriora\u00e7\u00e3o')
          if (code >= 95)
            weather.alerts.push('Tempestade prevista: planeje coletas com anteced\u00eancia')
        }
      } catch (_) {}
    }
    var climateScore = 100
    if (weather.temperature > 30) climateScore -= 25
    else if (weather.temperature > 25) climateScore -= 10
    if (weather.humidity > 85) climateScore -= 15
    if (weather.condition.indexOf('Tempestade') >= 0) climateScore -= 20
    else if (weather.condition.indexOf('Chuva') >= 0) climateScore -= 10
    climateScore = Math.max(0, climateScore)

    var buyers = []
    try {
      buyers = $app.findRecordsByFilter('buyer_profiles', '', '-created', 500, 0)
    } catch (_) {}
    var nearestDist = 9999
    var matchingBuyers = 0
    for (var k = 0; k < buyers.length; k++) {
      var bLat = buyers[k].get('latitude') || 0
      var bLon = buyers[k].get('longitude') || 0
      var dLat = ((bLat - prodLat) * Math.PI) / 180
      var dLon = ((bLon - prodLon) * Math.PI) / 180
      var a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((prodLat * Math.PI) / 180) *
          Math.cos((bLat * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2)
      var dist = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
      if (dist < nearestDist) nearestDist = dist
      var tags = (buyers[k].getString('demand_tags') || '').toLowerCase()
      if (tags.indexOf(prodName) >= 0) matchingBuyers++
    }

    var transporters = []
    try {
      transporters = $app.findRecordsByFilter('transporter_profiles', '', '-created', 100, 0)
    } catch (_) {}
    var compatibleTrans = 0
    for (var t = 0; t < transporters.length; t++) {
      if ((transporters[t].get('max_capacity_kg') || 0) >= qty) compatibleTrans++
    }

    var logisticsScore = Math.max(0, Math.round(100 - nearestDist * 3))
    var logisticsCost = Math.round(nearestDist * 2.5 * 100) / 100
    var feePct = 0.02
    var platformFee = Math.round(lotValue * feePct * 100) / 100
    var netRev = Math.round((lotValue - logisticsCost - platformFee) * 100) / 100
    var econScore =
      lotValue > 0 ? Math.min(100, Math.max(0, Math.round((netRev / lotValue) * 100))) : 0
    var econStatus = netRev > 0 && netRev / lotValue > 0.7 ? 'recommended' : 'not_recommended'
    var demandScore = Math.min(100, matchingBuyers * 30 + 40)
    var smartScore = Math.round(
      0.25 * econScore +
        0.25 * logisticsScore +
        0.2 * perishScore +
        0.15 * demandScore +
        0.15 * climateScore,
    )

    var justification =
      'A Vivi recomenda acelerar a comercializa\u00e7\u00e3o deste lote baseado na an\u00e1lise multi-fatorial.'
    try {
      var reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Voc\u00ea \u00e9 a Vivi, especialista em AgTech. Responda em portugu\u00eas em UMA frase come\u00e7ando obrigatoriamente com "A Vivi recomenda". Inclua dados: dist\u00e2ncia, margem de lucro, clima e perecibilidade.',
          },
          {
            role: 'user',
            content:
              'Produto: ' +
              product.getString('name') +
              ', ' +
              qty +
              'kg, Smart Score: ' +
              smartScore +
              '/100, Dist\u00e2ncia: ' +
              Math.round(nearestDist) +
              'km, Lucro: R$' +
              netRev +
              ', Clima: ' +
              weather.temperature +
              '\u00b0C, Perecibilidade: ' +
              perishLevel +
              ', Risco: ' +
              risk +
              ', Transportadores compat\u00edveis: ' +
              compatibleTrans,
          },
        ],
      })
      justification = reply.choices[0].message.content
    } catch (err) {
      $app.logger().warn('Smart score AI failed', 'err', err.message)
    }

    try {
      var col = $app.findCollectionByNameOrId('ai_analysis')
      var rec = new Record(col)
      rec.set('product_id', productId)
      rec.set('quality_score', smartScore)
      rec.set('shelf_life_days', remaining)
      rec.set(
        'recommended_use',
        perishLevel === 'high'
          ? 'Venda imediata - alta perecibilidade'
          : perishLevel === 'medium'
            ? 'Venda em at\u00e9 7 dias'
            : 'Venda em at\u00e9 21 dias',
      )
      rec.set('notes', justification)
      rec.set('confidence_score', climateScore)
      $app.save(rec)
    } catch (_) {}

    var closingProbability = Math.min(
      100,
      Math.round(demandScore * 0.3 + logisticsScore * 0.2 + econScore * 0.3 + perishScore * 0.2),
    )

    try {
      var prodRec = $app.findRecordById('products', productId)
      prodRec.set('estimated_life_days', remaining)
      prodRec.set(
        'cost_per_kg',
        qty > 0 ? Math.round(((logisticsCost + platformFee) / qty) * 100) / 100 : 0,
      )
      prodRec.set('net_revenue_per_kg', qty > 0 ? Math.round((netRev / qty) * 100) / 100 : 0)
      $app.saveNoValidate(prodRec)
    } catch (_) {}

    return e.json(200, {
      closing_probability: closingProbability,
      smart_score: smartScore,
      factors: {
        economic: {
          score: econScore,
          lot_value: lotValue,
          logistics_cost: logisticsCost,
          platform_fee: platformFee,
          net_revenue: netRev,
          status: econStatus,
          fee_percentage: feePct * 100,
        },
        logistics: {
          score: logisticsScore,
          nearest_buyer_km: Math.round(nearestDist * 10) / 10,
          compatible_transporters: compatibleTrans,
          capacity_ok: compatibleTrans > 0,
        },
        perishability: {
          level: perishLevel,
          risk: risk,
          risk_emoji: emoji,
          shelf_life_days: maxShelf,
          remaining_days: remaining,
          days_since_harvest: daysSince,
          used_pct: usedPct,
        },
        demand: { score: demandScore, matching_buyers: matchingBuyers },
        climate: {
          score: climateScore,
          temperature: weather.temperature,
          humidity: weather.humidity,
          condition: weather.condition,
          alerts: weather.alerts,
        },
      },
      vivi_justification: justification,
    })
  },
  $apis.requireAuth(),
)
