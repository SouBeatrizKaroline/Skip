onRecordAfterCreateSuccess((e) => {
  const record = e.record

  if (record.getString('avatar')) return e.next()

  let rows = []
  try {
    rows = $app
      .db()
      .newQuery('SELECT rawUser FROM _externalAuths WHERE recordRef = {:userId} LIMIT 1')
      .bind({ userId: record.id })
      .all()
  } catch (_) {
    return e.next()
  }

  if (!rows || rows.length === 0) return e.next()

  let rawUser = {}
  try {
    const rawStr = rows[0].rawUser || ''
    rawUser = JSON.parse(rawStr)
  } catch (_) {
    return e.next()
  }

  const avatarUrl = rawUser.picture || rawUser.avatar_url || ''
  if (!avatarUrl) return e.next()

  try {
    const file = $filesystem.fileFromURL(avatarUrl, 15)
    const userRecord = $app.findRecordById('users', record.id)
    userRecord.set('avatar', file)
    $app.saveNoValidate(userRecord)
  } catch (err) {
    $app.logger().error('avatar sync failed', 'userId', record.id, 'error', err.message)
  }

  return e.next()
}, 'users')
