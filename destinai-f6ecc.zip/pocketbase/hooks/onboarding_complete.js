routerAdd(
  'POST',
  '/backend/v1/onboarding/complete',
  (e) => {
    try {
      var body = e.requestInfo().body || {}
      var userId = e.auth ? e.auth.id : ''
      if (!userId) return e.unauthorizedError('auth required')

      var role = body.role || ''
      var city = body.city || ''
      var state = body.state || ''
      var goalTypes = body.goalTypes || []

      var locationText = city && state ? city + '/' + state : city || 'Brasil'

      var roleLabels = {
        PRODUCER: 'produtor rural',
        BUYER: 'comprador',
        TRANSPORTER: 'transportador',
      }
      var roleLabel = roleLabels[role] || 'usuario'

      var goalLabels = {
        KG_SAVED: 'reduzir desperdicio',
        REVENUE: 'aumentar receita',
        CO2_SAVED: 'reduzir emissoes de CO2',
        DELIVERIES: 'realizar entregas',
        MATCHES: 'fazer matches',
      }
      var goalParts = []
      for (var i = 0; i < goalTypes.length; i++) {
        var label = goalLabels[goalTypes[i]] || goalTypes[i]
        goalParts.push(label)
      }
      var goalText = goalParts.join(', ')

      var prompt =
        'Gere uma mensagem de boas-vindas curta e motivacional (maximo 200 caracteres) para um novo ' +
        roleLabel +
        ' da plataforma DestinAI em ' +
        locationText +
        '.'
      if (goalText) prompt += ' Objetivos: ' + goalText + '.'
      prompt += ' Seja especifico e encorajador. Assine como Vivi.'

      var insight = ''
      try {
        var result = $ai.agent('vivi-assistant').chat({
          user_id: userId,
          conversation_id: null,
          message: prompt,
        })
        insight = result.content || ''
      } catch (aiErr) {
        insight =
          'Bem-vindo ao DestinAI! Estou aqui para ajudar voce a reduzir o desperdicio e aumentar seus resultados. - Vivi'
      }

      if (!insight) {
        insight =
          'Bem-vindo ao DestinAI! Estou aqui para ajudar voce a reduzir o desperdicio e aumentar seus resultados. - Vivi'
      }

      var notifCol = $app.findCollectionByNameOrId('user_notifications')
      var notif = new Record(notifCol)
      notif.set('user_id', userId)
      notif.set('title', 'Bem-vindo ao DestinAI!')
      notif.set(
        'message',
        'Sua conta foi criada com sucesso. A Vivi esta pronta para ajudar voce a reduzir o desperdicio!',
      )
      notif.set('type', 'OPPORTUNITY')
      notif.set('is_read', false)
      notif.set('vivi_insight', insight)
      $app.save(notif)

      return e.json(200, { success: true, insight: insight })
    } catch (err) {
      return e.json(500, { error: 'Erro ao processar onboarding' })
    }
  },
  $apis.requireAuth(),
)
