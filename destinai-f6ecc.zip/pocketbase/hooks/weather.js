routerAdd(
  'GET',
  '/backend/v1/weather',
  (e) => {
    const query = e.requestInfo().query || {}
    const city = (query.city || '').trim()
    const state = (query.state || '').trim()
    if (!city) return e.badRequestError('city is required')

    let lat = 0,
      lon = 0
    try {
      const searchQ = state ? city + ', ' + state : city
      const geoRes = $http.send({
        url:
          'https://geocoding-api.open-meteo.com/v1/search?name=' +
          encodeURIComponent(searchQ) +
          '&countryCode=BR&count=1&language=pt',
        method: 'GET',
        timeout: 10,
      })
      if (
        geoRes.statusCode === 200 &&
        geoRes.json &&
        geoRes.json.results &&
        geoRes.json.results.length > 0
      ) {
        lat = geoRes.json.results[0].latitude
        lon = geoRes.json.results[0].longitude
      }
    } catch (_) {}

    if (lat === 0 && lon === 0) {
      return e.json(200, {
        city: city,
        temperature: null,
        humidity: null,
        condition: 'Indisponivel',
        wind_speed: null,
        alerts: [],
      })
    }

    var wd = {
      city: city,
      temperature: 0,
      humidity: 0,
      condition: 'Limpo',
      wind_speed: 0,
      alerts: [],
    }
    try {
      var wRes = $http.send({
        url:
          'https://api.open-meteo.com/v1/forecast?latitude=' +
          lat +
          '&longitude=' +
          lon +
          '&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m',
        method: 'GET',
        timeout: 10,
      })
      if (wRes.statusCode === 200 && wRes.json && wRes.json.current) {
        var c = wRes.json.current
        wd.temperature = Math.round(c.temperature_2m)
        wd.humidity = c.relative_humidity_2m
        wd.wind_speed = Math.round(c.wind_speed_10m)
        var code = c.weather_code
        if (code === 0) wd.condition = 'Ceu limpo'
        else if (code <= 3) wd.condition = 'Parcialmente nublado'
        else if (code <= 48) wd.condition = 'Nevoa'
        else if (code <= 67) wd.condition = 'Chuva'
        else if (code <= 77) wd.condition = 'Neve'
        else if (code <= 82) wd.condition = 'Pancadas de chuva'
        else if (code <= 99) wd.condition = 'Tempestade'
        if (c.relative_humidity_2m > 80)
          wd.alerts.push(
            'Alta umidade detectada - priorize distribuicao de folhosas para evitar deterioracao',
          )
        if (c.temperature_2m > 30)
          wd.alerts.push(
            'Temperatura elevada - mantenha produtos refrigerados e acelere a logistica',
          )
        if (code >= 95) wd.alerts.push('Tempestade prevista - planeje coletas com antecedencia')
      }
    } catch (_) {}

    return e.json(200, wd)
  },
  $apis.requireAuth(),
)
