routerAdd(
  'POST',
  '/backend/v1/ai/analyze/{productId}',
  (e) => {
    const productId = e.request.pathValue('productId')
    if (!productId) return e.badRequestError('productId is required')

    let product
    try {
      product = $app.findRecordById('products', productId)
    } catch (_) {
      return e.notFoundError('product not found')
    }

    const condition = product.getString('visual_condition')
    const baseScores = {
      RETAIL_STANDARD: 95,
      MINOR_IMPERFECTIONS: 78,
      NON_STANDARD: 60,
      PROCESSING_ONLY: 45,
    }
    const qualityScore = (baseScores[condition] || 70) + Math.floor(Math.random() * 6) - 3
    const shelfLifeDays = Math.floor(qualityScore / 10) + 3

    const recommendedUses = {
      RETAIL_STANDARD: 'Venda direta ao varejo, feiras e mercados',
      MINOR_IMPERFECTIONS: 'Restaurantes, indústrias de processamento, merendas',
      NON_STANDARD: 'Indústria de polpas, sucos, conservas e compostagem',
      PROCESSING_ONLY: 'Processamento industrial: sucos, polpas, rações',
    }

    let aiNotes = 'Análise concluída automaticamente.'
    try {
      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é a Vivi, especialista em pós-colheita. Responda em português, em uma frase curta começando com "A Vivi recomenda", com uma recomendação de uso para o produto.',
          },
          {
            role: 'user',
            content:
              'Produto: ' +
              product.getString('name') +
              ', Condição: ' +
              condition +
              ', Qualidade: ' +
              qualityScore +
              '/100, Quantidade: ' +
              product.get('quantity_kg') +
              'kg',
          },
        ],
      })
      aiNotes = reply.choices[0].message.content
    } catch (err) {
      $app.logger().warn('AI analysis failed', 'productId', productId, 'err', err.message)
    }

    const col = $app.findCollectionByNameOrId('ai_analysis')
    const record = new Record(col)
    record.set('product_id', productId)
    record.set('quality_score', qualityScore)
    record.set('shelf_life_days', shelfLifeDays)
    record.set('recommended_use', recommendedUses[condition] || 'Avaliar caso a caso')
    record.set('notes', aiNotes)
    $app.save(record)

    product.set('status', 'NEGOTIATING')
    $app.save(product)

    return e.json(200, {
      id: record.id,
      product_id: productId,
      quality_score: qualityScore,
      shelf_life_days: shelfLifeDays,
      recommended_use: recommendedUses[condition] || 'Avaliar caso a caso',
      notes: aiNotes,
    })
  },
  $apis.requireAuth(),
)
