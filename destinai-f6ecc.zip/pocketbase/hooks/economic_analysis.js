routerAdd(
  'POST',
  '/backend/v1/economic-analysis',
  (e) => {
    const body = e.requestInfo().body || {}
    const productId = body.product_id
    const buyerId = body.buyer_id
    if (!productId || !buyerId) return e.badRequestError('product_id and buyer_id are required')

    let product, buyer
    try {
      product = $app.findRecordById('products', productId)
    } catch (_) {
      return e.notFoundError('product not found')
    }
    try {
      buyer = $app.findRecordById('buyer_profiles', buyerId)
    } catch (_) {
      return e.notFoundError('buyer not found')
    }

    const prodLat = product.get('latitude') || 0
    const prodLon = product.get('longitude') || 0
    const bLat = buyer.get('latitude') || 0
    const bLon = buyer.get('longitude') || 0

    const R = 6371
    const dLat = ((bLat - prodLat) * Math.PI) / 180
    const dLon = ((bLon - prodLon) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((prodLat * Math.PI) / 180) *
        Math.cos((bLat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const distance = R * c

    const qty = product.get('quantity_kg') || 0
    const pricePerKg = product.get('price_per_kg') || 0
    const lotValue = qty * pricePerKg
    const logisticsCost = Math.round(distance * 2.5 * 100) / 100
    const feePct = 0.02
    const platformFee = Math.round(lotValue * feePct * 100) / 100
    const netRevenue = Math.round((lotValue - logisticsCost - platformFee) * 100) / 100

    const matchScore = Math.min(
      100,
      Math.round(Math.max(0, 80 - distance * 2) + (lotValue > 0 ? 20 : 0)),
    )
    const economicScore =
      lotValue > 0 ? Math.min(100, Math.max(0, Math.round((netRevenue / lotValue) * 100))) : 0
    const logisticsScore = Math.max(0, Math.round(100 - distance * 3))

    let justification = 'Analise baseada em proximidade e viabilidade economica.'
    try {
      const reply = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Voce e um especialista em logistica agricola. Responda em portugues em UMA frase curta justificando a compatibilidade.',
          },
          {
            role: 'user',
            content:
              'Produto: ' +
              product.getString('name') +
              ', ' +
              qty +
              'kg, Distancia: ' +
              Math.round(distance) +
              'km, Valor: R$' +
              lotValue +
              ', Custo logistica: R$' +
              logisticsCost +
              ', Lucro liquido: R$' +
              netRevenue,
          },
        ],
      })
      justification = reply.choices[0].message.content
    } catch (err) {
      $app.logger().warn('AI justification failed', 'err', err.message)
    }

    return e.json(200, {
      match_score: matchScore,
      economic_score: economicScore,
      logistics_score: logisticsScore,
      justification: justification,
      financial: {
        lot_value: lotValue,
        logistics_cost: logisticsCost,
        platform_fee: platformFee,
        net_revenue: netRevenue,
        fee_percentage: feePct * 100,
      },
      distance_km: Math.round(distance * 10) / 10,
    })
  },
  $apis.requireAuth(),
)
