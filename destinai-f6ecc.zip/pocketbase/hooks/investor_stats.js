routerAdd(
  'GET',
  '/backend/v1/investor-stats',
  (e) => {
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')

    var stats = {
      total_volume: 0,
      total_matches: 0,
      total_users: 0,
      total_kg_saved: 0,
      total_revenue: 0,
      total_co2_saved: 0,
      total_water_preserved: 0,
      total_meals: 0,
      producer_count: 0,
      buyer_count: 0,
      transporter_count: 0,
    }

    try {
      var matches = $app.findRecordsByFilter('matches', "status = 'COMPLETED'", '-created', 500, 0)
      stats.total_matches = matches.length
      for (var i = 0; i < matches.length; i++) {
        stats.total_volume += matches[i].get('price_agreed') || 0
      }
    } catch (_) {}

    try {
      stats.total_users = $app.countRecords('users')
    } catch (_) {}

    try {
      var producers = $app.findRecordsByFilter('users', "role = 'PRODUCER'", '', 500, 0)
      stats.producer_count = producers.length
    } catch (_) {}

    try {
      var buyers = $app.findRecordsByFilter('users', "role = 'BUYER'", '', 500, 0)
      stats.buyer_count = buyers.length
    } catch (_) {}

    try {
      var transporters = $app.findRecordsByFilter('users', "role = 'TRANSPORTER'", '', 500, 0)
      stats.transporter_count = transporters.length
    } catch (_) {}

    try {
      var metrics = $app.findRecordsByFilter('impact_metrics', '', '-created', 500, 0)
      for (var j = 0; j < metrics.length; j++) {
        stats.total_kg_saved += metrics[j].get('kg_saved') || 0
        stats.total_revenue += metrics[j].get('revenue_recovered') || 0
        stats.total_co2_saved += metrics[j].get('co2_saved_kg') || 0
        stats.total_water_preserved += metrics[j].get('water_preserved_liters') || 0
        stats.total_meals += metrics[j].get('meals_generated') || 0
      }
    } catch (_) {}

    return e.json(200, stats)
  },
  $apis.requireAuth(),
)
