routerAdd(
  'GET',
  '/backend/v1/achievements',
  (e) => {
    var userId = e.auth ? e.auth.id : ''
    if (!userId) return e.unauthorizedError('auth required')

    var kgSaved = 0,
      co2Saved = 0,
      revenue = 0,
      meals = 0
    try {
      var metrics = $app.findRecordsByFilter(
        'impact_metrics',
        'user_id = "' + userId + '"',
        '-created',
        100,
        0,
      )
      for (var i = 0; i < metrics.length; i++) {
        kgSaved += metrics[i].get('kg_saved') || 0
        co2Saved += metrics[i].get('co2_saved_kg') || 0
        revenue += metrics[i].get('revenue_recovered') || 0
        meals += metrics[i].get('meals_generated') || 0
      }
    } catch (_) {}

    var completedDeliveries = 0
    var role = e.auth.get('role') || ''
    try {
      if (role === 'TRANSPORTER') {
        var tp = $app.findFirstRecordByFilter('transporter_profiles', 'user_id = "' + userId + '"')
        completedDeliveries = $app.findRecordsByFilter(
          'orders',
          'transporter_id = "' + tp.id + '" && status = "DELIVERED"',
          '-created',
          1000,
          0,
        ).length
      } else if (role === 'PRODUCER') {
        var pp = $app.findFirstRecordByFilter('producer_profiles', 'user_id = "' + userId + '"')
        completedDeliveries = $app.findRecordsByFilter(
          'matches',
          'producer_id = "' + pp.id + '" && status = "COMPLETED"',
          '-created',
          1000,
          0,
        ).length
      } else if (role === 'BUYER') {
        var bp = $app.findFirstRecordByFilter('buyer_profiles', 'user_id = "' + userId + '"')
        completedDeliveries = $app.findRecordsByFilter(
          'matches',
          'buyer_id = "' + bp.id + '" && status = "COMPLETED"',
          '-created',
          1000,
          0,
        ).length
      }
    } catch (_) {}

    var ACHIEVEMENTS = [
      {
        slug: 'first_step',
        name: 'Primeiro Passo',
        description: 'Complete sua primeira entrega',
        icon: '\uD83D\uDCA6',
        threshold: 1,
        stat: completedDeliveries,
      },
      {
        slug: 'first_ton',
        name: 'Primeira Tonelada',
        description: 'Salve 1.000kg de alimentos',
        icon: '\uD83C\uDFC6',
        threshold: 1000,
        stat: kgSaved,
      },
      {
        slug: 'logistics_master',
        name: 'Mestre da Logística',
        description: 'Complete 10 entregas',
        icon: '\uD83D\uDE9B',
        threshold: 10,
        stat: completedDeliveries,
      },
      {
        slug: 'eco_hero',
        name: 'Herói Eco',
        description: 'Evite 500kg de CO2',
        icon: '\uD83C\uDF0D',
        threshold: 500,
        stat: co2Saved,
      },
      {
        slug: 'revenue_champion',
        name: 'Campeão de Receita',
        description: 'Recupere R$ 10.000',
        icon: '\uD83D\uDCB0',
        threshold: 10000,
        stat: revenue,
      },
      {
        slug: 'meals_creator',
        name: 'Gerador de Refeições',
        description: 'Gere 1.000 refeições',
        icon: '\uD83C\uDF7D\uFE0F',
        threshold: 1000,
        stat: meals,
      },
      {
        slug: 'waste_warrior',
        name: 'Guerreiro do Desperdício',
        description: 'Salve 5.000kg de alimentos',
        icon: '\u2694\uFE0F',
        threshold: 5000,
        stat: kgSaved,
      },
      {
        slug: 'green_legend',
        name: 'Lenda Verde',
        description: 'Salve 10.000kg de alimentos',
        icon: '\uD83C\uDF3F',
        threshold: 10000,
        stat: kgSaved,
      },
    ]

    var unlocked = {}
    try {
      var existing = $app.findRecordsByFilter(
        'user_achievements',
        'user_id = "' + userId + '"',
        '-unlocked_at',
        100,
        0,
      )
      for (var x = 0; x < existing.length; x++) {
        unlocked[existing[x].getString('achievement_slug')] = true
      }
    } catch (_) {}

    var newUnlocks = []
    var col = null
    try {
      col = $app.findCollectionByNameOrId('user_achievements')
    } catch (_) {}

    if (col) {
      for (var a = 0; a < ACHIEVEMENTS.length; a++) {
        var ach = ACHIEVEMENTS[a]
        if (!unlocked[ach.slug] && ach.stat >= ach.threshold) {
          try {
            var rec = new Record(col)
            rec.set('user_id', userId)
            rec.set('achievement_slug', ach.slug)
            $app.saveNoValidate(rec)
            unlocked[ach.slug] = true
            newUnlocks.push(ach.slug)
            try {
              var nCol = $app.findCollectionByNameOrId('user_notifications')
              var n = new Record(nCol)
              n.set('user_id', userId)
              n.set('title', 'Conquista Desbloqueada! ' + ach.icon)
              n.set('message', ach.description)
              n.set('type', 'ACHIEVEMENT')
              n.set('is_read', false)
              n.set(
                'vivi_insight',
                'A Vivi está orgulhosa! \uD83C\uDF31 Você desbloqueou "' + ach.name + '"',
              )
              $app.saveNoValidate(n)
            } catch (_) {}
          } catch (_) {}
        }
      }
    }

    var result = ACHIEVEMENTS.map(function (ach) {
      return {
        slug: ach.slug,
        name: ach.name,
        description: ach.description,
        icon: ach.icon,
        threshold: ach.threshold,
        current: ach.stat,
        progress: Math.min(100, Math.round((ach.stat / ach.threshold) * 100)),
        unlocked: !!unlocked[ach.slug],
      }
    })

    return e.json(200, {
      achievements: result,
      new_unlocks: newUnlocks,
      stats: {
        kg_saved: kgSaved,
        co2_saved_kg: co2Saved,
        revenue_recovered: revenue,
        meals_generated: meals,
        completed_deliveries: completedDeliveries,
      },
    })
  },
  $apis.requireAuth(),
)
