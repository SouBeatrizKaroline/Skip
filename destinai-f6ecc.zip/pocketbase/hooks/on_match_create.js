onRecordAfterCreateSuccess((e) => {
  const match = e.record

  let transporters = []
  try {
    transporters = $app.findRecordsByFilter('transporter_profiles', '', '-created', 10, 0)
  } catch (_) {}

  if (transporters.length === 0) return e.next()

  const transporter = transporters[0]

  let product = null
  let buyer = null
  try {
    product = $app.findRecordById('products', match.getString('product_id'))
    buyer = $app.findRecordById('buyer_profiles', match.getString('buyer_id'))
  } catch (_) {
    return e.next()
  }

  const pickupCity = product ? product.getString('city') : ''
  const pickupState = product ? product.getString('state') : ''
  const deliveryCity = buyer ? buyer.getString('city') : ''
  const deliveryState = buyer ? buyer.getString('state') : ''

  const pickupAddress = pickupCity + (pickupState ? ' - ' + pickupState : '')
  const deliveryAddress = deliveryCity + (deliveryState ? ' - ' + deliveryState : '')

  var mQty = product ? product.get('quantity_kg') || 0 : 0
  var mPrice = product ? product.get('price_per_kg') || 0 : 0
  var mLotValue = mQty * mPrice
  var mProdLat = product ? product.get('latitude') || 0 : 0
  var mProdLon = product ? product.get('longitude') || 0 : 0
  var mBLat = buyer ? buyer.get('latitude') || 0 : 0
  var mBLon = buyer ? buyer.get('longitude') || 0 : 0
  var mR = 6371
  var mDLat = ((mBLat - mProdLat) * Math.PI) / 180
  var mDLon = ((mBLon - mProdLon) * Math.PI) / 180
  var mA =
    Math.sin(mDLat / 2) * Math.sin(mDLat / 2) +
    Math.cos((mProdLat * Math.PI) / 180) *
      Math.cos((mBLat * Math.PI) / 180) *
      Math.sin(mDLon / 2) *
      Math.sin(mDLon / 2)
  var mC = 2 * Math.atan2(Math.sqrt(mA), Math.sqrt(1 - mA))
  var mDist = mR * mC
  var mLogisticCost = Math.round(mDist * 2.5 * 100) / 100
  var mFeePct = 0.02
  var mPlatformFee = Math.round(mLotValue * mFeePct * 100) / 100
  var mNetRevenue = Math.round((mLotValue - mLogisticCost - mPlatformFee) * 100) / 100

  try {
    var matchRec = $app.findRecordById('matches', match.id)
    matchRec.set('net_revenue', mNetRevenue)
    matchRec.set('platform_fee', mPlatformFee)
    matchRec.set('logistic_cost', mLogisticCost)
    matchRec.set('commission_fee', mPlatformFee)
    matchRec.set('estimated_net_profit', mNetRevenue)
    $app.save(matchRec)
  } catch (_) {}

  const reward = 80 + Math.floor(Math.random() * 200)

  try {
    const ordersCol = $app.findCollectionByNameOrId('orders')
    const order = new Record(ordersCol)
    order.set('match_id', match.id)
    order.set('transporter_id', transporter.id)
    order.set('status', 'PENDING')
    order.set('pickup_address', pickupAddress)
    order.set('delivery_address', deliveryAddress)
    order.set('reward', reward)
    $app.save(order)
  } catch (err) {
    $app.logger().error('Failed to create order for match', 'matchId', match.id, 'err', err.message)
  }

  return e.next()
}, 'matches')
