import { useState, useEffect } from 'react'
import { Menu, X, Sparkles } from 'lucide-react'

interface NavbarProps {
  activeSection: string
}

export function Navbar({ activeSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navLinks = [
    { id: 'hero', label: 'Início' },
    { id: 'historia', label: 'Minha História' },
    { id: 'sete-vidas', label: 'Sete Vidas' },
    { id: 'projetos', label: 'Projetos' },
    { id: 'conquistas', label: 'Conquistas' },
    { id: 'mulher-tech', label: 'Mulher em Tech' },
    { id: 'nordeste', label: 'Global' },
    { id: 'tecnologias', label: 'Tecnologias' },
    { id: 'depoimentos', label: 'Depoimentos' },
    { id: 'contato', label: 'Contato' },
  ]

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false)
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#121218]/90 backdrop-blur-md border-b border-white/10 shadow-xl py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => scrollTo('hero')}
          className="flex items-center gap-2 group text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#1a237e] via-[#7b1fa2] to-[#ff8a65] p-0.5 shadow-lg group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#121218] rounded-[10px] flex items-center justify-center text-lg">
              🐾
            </div>
          </div>
          <div>
            <span className="font-display font-bold text-white text-base tracking-tight block group-hover:text-[#ffd54f] transition-colors">
              Beatriz Karoline
            </span>
            <span className="text-[10px] text-[#ff8a65] font-medium tracking-widest uppercase flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> Multidisciplinar
            </span>
          </div>
        </button>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#1e1e2d]/60 p-1.5 rounded-full border border-white/10 backdrop-blur-md">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id
            return (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-[#7b1fa2] to-[#3f51b5] text-white shadow-md font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            )
          })}
        </nav>

        {/* Contact CTA desktop */}
        <div className="hidden lg:block">
          <button
            onClick={() => scrollTo('contato')}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ff8a65] to-[#ffd54f] text-[#121218] font-bold text-xs hover:opacity-90 transition-opacity shadow-md hover:shadow-lg"
          >
            Falar Comigo
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 rounded-xl bg-[#1e1e2d] text-white border border-white/10 hover:bg-white/10 transition-colors"
          aria-label="Abrir menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#121218]/95 backdrop-blur-xl border-b border-white/10 px-6 py-6 animate-fade-in-down">
          <div className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className={`text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  activeSection === link.id
                    ? 'bg-gradient-to-r from-[#7b1fa2] to-[#3f51b5] text-white font-semibold'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => scrollTo('contato')}
              className="mt-2 w-full py-3 rounded-xl bg-gradient-to-r from-[#ff8a65] to-[#ffd54f] text-[#121218] font-bold text-sm text-center shadow-lg"
            >
              Falar Comigo 🐾
            </button>
          </div>
        </div>
      )}
    </header>
  )
}
