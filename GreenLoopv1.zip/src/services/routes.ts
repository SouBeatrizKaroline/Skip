import pb from '@/lib/pocketbase/client'

export interface RouteStop {
  id: string
  name: string
  address: string
  lat: number
  lng: number
  volumeKg?: number
}

export interface RouteRecord {
  id: string
  collector: string
  name: string
  stops: RouteStop[]
  polyline: [number, number][]
  date: string
  status: 'ativa' | 'finalizada'
  created: string
}

export const getRoutes = (collectorId: string) =>
  pb.collection('routes').getFullList<RouteRecord>({
    filter: `collector = "${collectorId}"`,
    sort: '-created',
  })

export const createRoute = (data: Partial<RouteRecord>) =>
  pb.collection('routes').create<RouteRecord>(data)

export const optimizeRouteAI = (stops: RouteStop[]) =>
  pb.send<{ success: boolean; ordered_stops: RouteStop[] }>('/backend/v1/route-optimize', {
    method: 'POST',
    body: JSON.stringify({ stops }),
    headers: { 'Content-Type': 'application/json' },
  })
