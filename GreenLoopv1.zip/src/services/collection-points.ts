import pb from '@/lib/pocketbase/client'

export interface CollectionPoint {
  id: string
  name: string
  address: string
  lat: number
  lng: number
  type: 'fixo' | 'residencial'
  accepted_materials: string[]
  status: 'ativo' | 'inativo'
  opening_hours?: string
  photo?: string
  owner?: string
  created: string
  updated: string
}

export const getCollectionPoints = (filter = '') =>
  pb.collection('collection_points').getFullList<CollectionPoint>({
    filter,
    sort: '-created',
  })

export const createCollectionPoint = (data: Partial<CollectionPoint>) =>
  pb.collection('collection_points').create<CollectionPoint>(data)

export const updateCollectionPoint = (id: string, data: Partial<CollectionPoint>) =>
  pb.collection('collection_points').update<CollectionPoint>(id, data)

export const deleteCollectionPoint = (id: string) => pb.collection('collection_points').delete(id)
