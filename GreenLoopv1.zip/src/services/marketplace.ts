import pb from '@/lib/pocketbase/client'

export interface MarketplaceListing {
  id: string
  collector: string
  material: string
  quantity: number
  price_per_kg: number
  description?: string
  status: 'ativo' | 'vendido'
  buyer?: string
  created: string
  updated: string
  expand?: {
    collector?: { name: string; cooperative_name?: string; address?: string; phone?: string }
    material?: { type: string; unit: string }
    buyer?: { name: string }
  }
}

export const getMarketplaceListings = (filter = 'status = "ativo"') =>
  pb.collection('marketplace_listings').getFullList<MarketplaceListing>({
    filter,
    sort: '-created',
    expand: 'collector,material,buyer',
  })

export const createMarketplaceListing = (data: Partial<MarketplaceListing>) =>
  pb.collection('marketplace_listings').create<MarketplaceListing>(data)

export const buyMarketplaceListing = (id: string, buyerId: string) =>
  pb.collection('marketplace_listings').update<MarketplaceListing>(id, {
    status: 'vendido',
    buyer: buyerId,
  })
