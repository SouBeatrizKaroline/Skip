import pb from '@/lib/pocketbase/client'

export interface Reward {
  id: string
  name: string
  description?: string
  points_required: number
  stock: number
  image?: string
}

export interface Redemption {
  id: string
  user: string
  reward: string
  redeemed_at: string
  expand?: {
    reward?: Reward
  }
}

export const getRewards = () =>
  pb.collection('rewards').getFullList<Reward>({ sort: 'points_required' })

export const redeemReward = async (userId: string, rewardId: string) => {
  return pb.collection('redemptions').create({
    user: userId,
    reward: rewardId,
  })
}

export const getUserRedemptions = (userId: string) =>
  pb.collection('redemptions').getFullList<Redemption>({
    filter: `user = "${userId}"`,
    sort: '-created',
    expand: 'reward',
  })

export const decrementRewardStock = async (rewardId: string, currentStock: number) => {
  const newStock = Math.max(0, currentStock - 1)
  return pb.collection('rewards').update(rewardId, { stock: newStock })
}

export const deductUserPoints = async (
  statsId: string,
  currentPoints: number,
  deductAmount: number,
) => {
  const newPoints = Math.max(0, currentPoints - deductAmount)
  return pb.collection('user_stats').update(statsId, { points: newPoints })
}
