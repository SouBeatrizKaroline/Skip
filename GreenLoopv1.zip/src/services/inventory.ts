import pb from '@/lib/pocketbase/client'

export interface InventoryItem {
  id: string
  collector: string
  material: string
  quantity: number
  location?: string
  created: string
  updated: string
  expand?: {
    material?: { type: string; unit: string }
  }
}

export const getInventory = (collectorId?: string) => {
  const filter = collectorId ? `collector = "${collectorId}"` : ''
  return pb.collection('inventory').getFullList<InventoryItem>({
    filter,
    expand: 'material',
  })
}

export const updateInventoryItem = (id: string, data: Partial<InventoryItem>) =>
  pb.collection('inventory').update<InventoryItem>(id, data)
