import pb from '@/lib/pocketbase/client'

export interface UserStats {
  id: string
  user: string
  points: number
  level: 'bronze' | 'prata' | 'ouro' | 'diamante'
  co2_saved: number
  plastic_diverted: number
  water_saved: number
  created: string
  updated: string
}

export const getUserStats = async (userId: string): Promise<UserStats | null> => {
  try {
    const list = await pb.collection('user_stats').getFullList<UserStats>({
      filter: `user = "${userId}"`,
    })
    return list[0] || null
  } catch (_) {
    return null
  }
}
