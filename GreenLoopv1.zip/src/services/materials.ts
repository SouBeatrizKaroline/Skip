import pb from '@/lib/pocketbase/client'

export interface Material {
  id: string
  type: 'PET' | 'PEAD' | 'PEBD' | 'PP' | 'PS' | 'Outro'
  unit: 'kg' | 'ton'
  description?: string
}

export const getMaterials = () => pb.collection('materials').getFullList<Material>({ sort: 'type' })
