import pb from '@/lib/pocketbase/client'

export interface CollectionItem {
  id: string
  consumer: string
  collector?: string
  material: string
  quantity: number
  address: string
  status: 'pendente' | 'agendado' | 'coletado' | 'certificado'
  notes?: string
  collected_at?: string
  created: string
  updated: string
  expand?: {
    consumer?: { name: string; email: string; phone?: string }
    collector?: { name: string; cooperative_name?: string }
    material?: { type: string; unit: string }
  }
}

export const getCollections = (filter = '', sort = '-created') =>
  pb.collection('collections').getFullList<CollectionItem>({
    filter,
    sort,
    expand: 'consumer,collector,material',
  })

export const getCollectionById = (id: string) =>
  pb.collection('collections').getOne<CollectionItem>(id, {
    expand: 'consumer,collector,material',
  })

export const createCollection = (data: Partial<CollectionItem>) =>
  pb.collection('collections').create<CollectionItem>(data)

export const updateCollection = (id: string, data: Partial<CollectionItem>) =>
  pb.collection('collections').update<CollectionItem>(id, data)

export const deleteCollection = (id: string) => pb.collection('collections').delete(id)
