import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { PlusCircle, MapPin, Award, Leaf, Trophy, ArrowUpRight } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getUserStats, UserStats } from '@/services/stats'
import { getCollections, CollectionItem } from '@/services/collections'
import { useRealtime } from '@/hooks/use-realtime'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { ImpactChart } from '@/components/ImpactChart'

export default function ConsumidorDashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState<UserStats | null>(null)
  const [collections, setCollections] = useState<CollectionItem[]>([])

  const loadData = async () => {
    if (!user) return
    const [st, cols] = await Promise.all([
      getUserStats(user.id),
      getCollections(`consumer = "${user.id}"`),
    ])
    setStats(st)
    setCollections(cols)
  }

  useEffect(() => {
    loadData()
  }, [user])

  useRealtime('collections', () => loadData())
  useRealtime('user_stats', () => loadData())

  const points = stats?.points || 0
  const level = stats?.level || 'bronze'
  const targetPoints =
    level === 'bronze' ? 100 : level === 'prata' ? 300 : level === 'ouro' ? 600 : 1000
  const progressPercent = Math.min(100, Math.round((points / targetPoints) * 100))

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <Badge className="bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 uppercase tracking-widest text-[10px]">
              Perfil Consumidor Sustentável
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Olá, {user?.name || 'Reciclador'}! 🌱
            </h1>
            <p className="text-emerald-100 text-sm max-w-xl">
              Você já ajudou a desviar{' '}
              <span className="font-bold text-amber-300">{stats?.plastic_diverted || 0} kg</span> de
              plástico dos oceanos e aterros!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              asChild
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
            >
              <Link to="/consumidor/registrar">
                <PlusCircle className="mr-2 h-4 w-4" /> Registrar Material
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10"
            >
              <Link to="/consumidor/mapa">
                <MapPin className="mr-2 h-4 w-4" /> Ver Pontos de Coleta
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Level and Gamification Banner */}
      <Card className="border-emerald-100 bg-white shadow-subtle">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-600">
                <Trophy className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-emerald-950 capitalize">Nível {level}</h3>
                <p className="text-xs text-emerald-600">
                  {points} / {targetPoints} Pontos de Impacto acumulados
                </p>
              </div>
            </div>
            <Badge className="bg-emerald-100 text-emerald-800 text-sm font-bold px-3 py-1">
              {points} Pts
            </Badge>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-emerald-700 font-semibold">
              <span>Progresso de Nível</span>
              <span>{progressPercent}%</span>
            </div>
            <Progress value={progressPercent} className="h-3 bg-emerald-100" />
          </div>
        </CardContent>
      </Card>

      {/* KPI Impact Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-emerald-100 bg-emerald-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-md">
              <Leaf className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">CO₂ Economizado</p>
              <h4 className="text-2xl font-black text-emerald-950">{stats?.co2_saved || 0} kg</h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-teal-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white shadow-md">
              <Award className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-teal-700">Plástico Desviado</p>
              <h4 className="text-2xl font-black text-teal-950">
                {stats?.plastic_diverted || 0} kg
              </h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-amber-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white shadow-md">
              <Trophy className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-amber-800">Água Poupada</p>
              <h4 className="text-2xl font-black text-amber-950">{stats?.water_saved || 0} L</h4>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-emerald-100">
          <CardHeader>
            <CardTitle className="text-base font-bold text-emerald-950">
              Evolução Semanal de Coletas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ImpactChart type="bar" />
          </CardContent>
        </Card>

        <Card className="border-emerald-100">
          <CardHeader>
            <CardTitle className="text-base font-bold text-emerald-950">
              Tipos de Plástico Reciclados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ImpactChart type="pie" />
          </CardContent>
        </Card>
      </div>

      {/* Recent Collections List */}
      <Card className="border-emerald-100">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base font-bold text-emerald-950">
            Minhas Coletas Recentes
          </CardTitle>
          <Button asChild variant="ghost" size="sm" className="text-emerald-700">
            <Link to="/consumidor/historico">
              Ver todas <ArrowUpRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {collections.length === 0 ? (
            <div className="text-center py-8 text-emerald-600 text-sm">
              Nenhum material registrado ainda. Clique em "Registrar Material" para começar!
            </div>
          ) : (
            <div className="divide-y divide-emerald-50">
              {collections.slice(0, 5).map((col) => (
                <div key={col.id} className="py-3 flex items-center justify-between text-sm">
                  <div>
                    <p className="font-bold text-emerald-950">
                      {col.quantity} kg de {col.expand?.material?.type || 'Plástico PET'}
                    </p>
                    <p className="text-xs text-emerald-600">{col.address || 'Ponto de coleta'}</p>
                  </div>
                  <Badge className="capitalize bg-emerald-100 text-emerald-800 border-none">
                    {col.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
