import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { PlusCircle, CheckCircle2, ArrowLeft } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getMaterials, Material } from '@/services/materials'
import { createCollection } from '@/services/collections'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'

export default function RegistrarMaterial() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const [materials, setMaterials] = useState<Material[]>([])
  const [materialId, setMaterialId] = useState('')
  const [quantity, setQuantity] = useState('2.5')
  const [address, setAddress] = useState(user?.address || 'Av. Paulista, 1000 - São Paulo, SP')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    getMaterials().then((data) => {
      setMaterials(data)
      if (data.length > 0) setMaterialId(data[0].id)
    })
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    setLoading(true)

    try {
      await createCollection({
        consumer: user.id,
        material: materialId,
        quantity: parseFloat(quantity),
        address,
        notes,
        status: 'pendente',
      })

      setSuccess(true)
      toast({
        title: 'Material registrado com sucesso! 🎉',
        description: 'Você acumulou novos pontos de impacto sustentável.',
      })
    } catch (err) {
      toast({
        title: 'Erro ao registrar',
        description: 'Verifique os dados informados e tente novamente.',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade-in">
      <Button variant="ghost" onClick={() => navigate(-1)} className="text-emerald-800">
        <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
      </Button>

      <Card className="border-emerald-100 bg-white shadow-lg">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <PlusCircle className="h-6 w-6" />
            </div>
            <div>
              <CardTitle className="text-xl font-bold text-emerald-950">
                Registrar Material Reciclável
              </CardTitle>
              <CardDescription className="text-xs text-emerald-700">
                Informe o tipo e a quantidade de plástico PET separado para coleta
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {success ? (
            <div className="text-center py-8 space-y-4">
              <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-600 animate-bounce" />
              <h3 className="text-2xl font-bold text-emerald-950">Coleta Agendada!</h3>
              <p className="text-sm text-emerald-700 max-w-sm mx-auto">
                Seu registro foi enviado para os catadores e cooperativas parceiras da sua região.
              </p>
              <div className="flex gap-3 justify-center pt-4">
                <Button onClick={() => setSuccess(false)} variant="outline">
                  Registrar Outro
                </Button>
                <Button
                  onClick={() => navigate('/consumidor')}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white"
                >
                  Ir para o Dashboard
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">Tipo de Plástico</Label>
                <Select value={materialId} onValueChange={setMaterialId}>
                  <SelectTrigger className="border-emerald-200">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {materials.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.type} - {m.description}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">
                  Quantidade Estimada (kg)
                </Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  required
                  className="border-emerald-200"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">
                  Endereço de Disponibilização / Coleta
                </Label>
                <Input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  className="border-emerald-200"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">
                  Observações (Opcional)
                </Label>
                <Textarea
                  placeholder="Ex: Garrafas limpas e amassadas dispostas na portaria do prédio."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="border-emerald-200"
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2.5 shadow-md"
              >
                {loading ? 'Confirmando...' : 'Confirmar e Ganhar Pontos'}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
