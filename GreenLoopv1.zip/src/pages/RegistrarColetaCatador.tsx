import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { CheckCircle2, ArrowLeft, Truck } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getMaterials, Material } from '@/services/materials'
import { createCollection } from '@/services/collections'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'

export default function RegistrarColetaCatador() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const [materials, setMaterials] = useState<Material[]>([])
  const [materialId, setMaterialId] = useState('')
  const [quantity, setQuantity] = useState('50')
  const [address, setAddress] = useState('Ponto Central de Coleta')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getMaterials().then((data) => {
      setMaterials(data)
      if (data.length > 0) setMaterialId(data[0].id)
    })
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    setLoading(true)

    try {
      await createCollection({
        consumer: user.id,
        collector: user.id,
        material: materialId,
        quantity: parseFloat(quantity),
        address,
        status: 'coletado',
        collected_at: new Date().toISOString(),
      })

      toast({
        title: 'Coleta Registrada! 🚚',
        description: 'O estoque foi atualizado e o material foi validado.',
      })
      navigate('/catador/estoque')
    } catch (err) {
      toast({
        title: 'Erro ao registrar',
        description: 'Tente novamente.',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade-in">
      <Button variant="ghost" onClick={() => navigate(-1)} className="text-emerald-800">
        <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
      </Button>

      <Card className="border-emerald-100 bg-white shadow-lg">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
              <Truck className="h-6 w-6" />
            </div>
            <div>
              <CardTitle className="text-xl font-bold text-emerald-950">
                Registrar Coleta Realizada
              </CardTitle>
              <CardDescription className="text-xs text-emerald-700">
                Adicione volumes triados diretamente ao seu estoque de galpão
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-emerald-900">
                Tipo de Plástico Coletado
              </Label>
              <Select value={materialId} onValueChange={setMaterialId}>
                <SelectTrigger className="border-emerald-200">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  {materials.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.type} ({m.unit})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-emerald-900">
                Quantidade Total (kg)
              </Label>
              <Input
                type="number"
                step="1"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
                className="border-emerald-200"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-emerald-900">Origem / Endereço</Label>
              <Input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
                className="border-emerald-200"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2.5 shadow-md"
            >
              {loading ? 'Salvando...' : 'Salvar no Estoque'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
