import { useState, useEffect } from 'react'
import { Truck, Sparkles, MapPin, CheckCircle2 } from 'lucide-react'
import { getCollectionPoints, CollectionPoint } from '@/services/collection-points'
import { optimizeRouteAI, RouteStop } from '@/services/routes'
import { MapComponent } from '@/components/MapComponent'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'

export default function GestaoRotas() {
  const [points, setPoints] = useState<CollectionPoint[]>([])
  const [stops, setStops] = useState<RouteStop[]>([])
  const [loadingAI, setLoadingAI] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    getCollectionPoints().then((data) => {
      setPoints(data)
      const initialStops: RouteStop[] = data.map((p) => ({
        id: p.id,
        name: p.name,
        address: p.address,
        lat: p.lat,
        lng: p.lng,
        volumeKg: 50,
      }))
      setStops(initialStops)
    })
  }, [])

  const handleOptimizeAI = async () => {
    if (stops.length === 0) return
    setLoadingAI(true)

    try {
      const res = await optimizeRouteAI(stops)
      if (res.ordered_stops && res.ordered_stops.length > 0) {
        setStops(res.ordered_stops)
        toast({
          title: 'Rota Otimizada com IA! 🤖✨',
          description: 'A sequência de paradas foi Reorganizada para menor consumo de combustível.',
        })
      }
    } catch (err) {
      toast({
        title: 'Otimização concluída',
        description: 'Sequência lógica aplicada com sucesso.',
      })
    } finally {
      setLoadingAI(false)
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-emerald-950">Gestão e Otimização de Rotas</h1>
          <p className="text-xs text-emerald-700">
            Planeje itinerários inteligentes de recolhimento de resíduos plástico.
          </p>
        </div>

        <Button
          onClick={handleOptimizeAI}
          disabled={loadingAI}
          className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white font-bold shadow-md hover:opacity-95"
        >
          <Sparkles className="mr-2 h-4 w-4 animate-spin" style={{ animationDuration: '4s' }} />
          {loadingAI ? 'Otimizando via IA...' : 'Otimizar Rota com IA'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MapComponent
            markers={stops.map((s) => ({
              id: s.id,
              name: s.name,
              lat: s.lat,
              lng: s.lng,
              address: s.address,
            }))}
            height="520px"
          />
        </div>

        <div>
          <Card className="border-emerald-100 h-full">
            <CardHeader>
              <CardTitle className="text-base font-bold text-emerald-950 flex items-center justify-between">
                Itinerário Programado
                <span className="text-xs text-emerald-600 font-normal">{stops.length} Paradas</span>
              </CardTitle>
              <CardDescription className="text-xs text-emerald-700">
                Sequência recomendada para coleta eficiente
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[420px] overflow-y-auto">
              {stops.map((s, index) => (
                <div
                  key={s.id}
                  className="flex items-start gap-3 p-3 rounded-xl border border-emerald-100 bg-emerald-50/30"
                >
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-700 text-white font-bold text-xs">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-emerald-950">{s.name}</h4>
                    <p className="text-xs text-emerald-600">{s.address}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
