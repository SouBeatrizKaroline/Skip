import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Truck, PackageSearch, MapPin, CheckCircle2, ArrowRight } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getCollections, CollectionItem } from '@/services/collections'
import { getInventory, InventoryItem } from '@/services/inventory'
import { useRealtime } from '@/hooks/use-realtime'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function CatadorDashboard() {
  const { user } = useAuth()
  const [pendingCollections, setPendingCollections] = useState<CollectionItem[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])

  const loadData = async () => {
    const [cols, inv] = await Promise.all([
      getCollections('status = "pendente"'),
      getInventory(user?.id),
    ])
    setPendingCollections(cols)
    setInventory(inv)
  }

  useEffect(() => {
    loadData()
  }, [user])

  useRealtime('collections', () => loadData())
  useRealtime('inventory', () => loadData())

  const totalInventoryKg = inventory.reduce((acc, curr) => acc + (curr.quantity || 0), 0)

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 p-6 sm:p-8 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <Badge className="bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 uppercase tracking-widest text-[10px]">
              Gestão de Coleta & Triagem
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-black">
              {user?.cooperative_name || user?.name} 🚛
            </h1>
            <p className="text-emerald-200 text-sm">
              Coletando, organizando e reinserindo plástico reciclável na cadeia circular.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button asChild className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold">
              <Link to="/catador/rotas">
                <Truck className="mr-2 h-4 w-4" /> Gerenciar Rotas
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10"
            >
              <Link to="/catador/registrar-coleta">Registrar Coleta Realizada</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white">
              <MapPin className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">Coletas Pendentes</p>
              <h4 className="text-2xl font-black text-emerald-950">{pendingCollections.length}</h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-600 text-white">
              <PackageSearch className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">Estoque Atual em Galpão</p>
              <h4 className="text-2xl font-black text-emerald-950">{totalInventoryKg} kg</h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">Rota Ativa do Dia</p>
              <h4 className="text-lg font-bold text-emerald-950 truncate">Rota Centro-Paulista</h4>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Collections Available */}
      <Card className="border-emerald-100">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base font-bold text-emerald-950">
            Coletas Solicitadas por Consumidores ({pendingCollections.length})
          </CardTitle>
          <Button asChild variant="ghost" size="sm" className="text-emerald-700">
            <Link to="/catador/rotas">
              Otimizar Rota <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {pendingCollections.length === 0 ? (
            <p className="text-center py-6 text-emerald-600 text-sm">
              Nenhuma coleta pendente na sua região no momento.
            </p>
          ) : (
            <div className="divide-y divide-emerald-50">
              {pendingCollections.map((col) => (
                <div key={col.id} className="py-3 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-950">{col.quantity} kg</span>
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                        {col.expand?.material?.type || 'PET'}
                      </Badge>
                    </div>
                    <p className="text-xs text-emerald-600">{col.address}</p>
                  </div>
                  <Button
                    asChild
                    size="sm"
                    className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs"
                  >
                    <Link to="/catador/registrar-coleta">Atender Coleta</Link>
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
