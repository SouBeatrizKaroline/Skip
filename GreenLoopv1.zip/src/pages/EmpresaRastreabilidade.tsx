import { useEffect, useState } from 'react'
import { FileCheck2, UserCheck, Truck, Building2, CheckCircle2 } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getMarketplaceListings, MarketplaceListing } from '@/services/marketplace'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function EmpresaRastreabilidade() {
  const { user } = useAuth()
  const [purchasedListings, setPurchasedListings] = useState<MarketplaceListing[]>([])

  useEffect(() => {
    if (!user) return
    getMarketplaceListings(`buyer = "${user.id}"`).then(setPurchasedListings)
  }, [user])

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-emerald-950">
          Cadeia de Custódia e Rastreabilidade
        </h1>
        <p className="text-xs text-emerald-700">
          Acompanhe a origem de cada lote de plástico reciclado adquirido por sua empresa.
        </p>
      </div>

      <div className="space-y-6">
        {purchasedListings.length === 0 ? (
          <Card className="border-emerald-100">
            <CardContent className="p-8 text-center text-emerald-600 text-sm">
              Sua empresa ainda não possui lotes com rastreabilidade atrelada. Faça uma compra no
              Marketplace!
            </CardContent>
          </Card>
        ) : (
          purchasedListings.map((lote) => (
            <Card key={lote.id} className="border-emerald-100 bg-white">
              <CardHeader className="flex flex-row items-center justify-between border-b border-emerald-50 pb-4">
                <div>
                  <Badge className="bg-emerald-700 text-white font-bold text-xs">
                    Lote #{lote.id.slice(-6).toUpperCase()} — {lote.quantity} kg{' '}
                    {lote.expand?.material?.type || 'PET'}
                  </Badge>
                  <p className="text-xs text-emerald-600 mt-1">
                    Data de Aquisição: {new Date(lote.updated).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <Badge variant="outline" className="border-emerald-600 text-emerald-800">
                  Selo Rastreabilidade 100%
                </Badge>
              </CardHeader>
              <CardContent className="pt-6">
                {/* Horizontal Chain Timeline */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
                  <div className="flex flex-col items-center text-center p-3 rounded-xl bg-emerald-50/50 border border-emerald-100">
                    <UserCheck className="h-8 w-8 text-emerald-700 mb-2" />
                    <span className="font-bold text-xs text-emerald-950">1. Consumidor</span>
                    <p className="text-[11px] text-emerald-600 mt-1">
                      Descarte consciente em São Paulo, SP
                    </p>
                  </div>

                  <div className="flex flex-col items-center text-center p-3 rounded-xl bg-emerald-50/50 border border-emerald-100">
                    <Truck className="h-8 w-8 text-emerald-700 mb-2" />
                    <span className="font-bold text-xs text-emerald-950">
                      2. Coleta & Logística
                    </span>
                    <p className="text-[11px] text-emerald-600 mt-1">
                      Transporte por rota otimizada
                    </p>
                  </div>

                  <div className="flex flex-col items-center text-center p-3 rounded-xl bg-emerald-50/50 border border-emerald-100">
                    <Building2 className="h-8 w-8 text-emerald-700 mb-2" />
                    <span className="font-bold text-xs text-emerald-950">3. Cooperativa</span>
                    <p className="text-[11px] text-emerald-600 mt-1">
                      {lote.expand?.collector?.cooperative_name || 'Cooperativa Verde'}
                    </p>
                  </div>

                  <div className="flex flex-col items-center text-center p-3 rounded-xl bg-emerald-600 text-white">
                    <CheckCircle2 className="h-8 w-8 text-amber-300 mb-2" />
                    <span className="font-bold text-xs">4. Indústria</span>
                    <p className="text-[11px] text-emerald-100 mt-1">{user?.name}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
