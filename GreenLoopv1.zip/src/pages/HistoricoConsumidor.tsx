import { useEffect, useState } from 'react'
import { History, CheckCircle2, Clock } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getCollections, CollectionItem } from '@/services/collections'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function HistoricoConsumidor() {
  const { user } = useAuth()
  const [items, setItems] = useState<CollectionItem[]>([])

  useEffect(() => {
    if (!user) return
    getCollections(`consumer = "${user.id}"`).then(setItems)
  }, [user])

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-emerald-950">Histórico de Descartes e Coletas</h1>
        <p className="text-xs text-emerald-700">
          Acompanhe todos os seus registros de materiais reciclados.
        </p>
      </div>

      <Card className="border-emerald-100">
        <CardHeader>
          <CardTitle className="text-base font-bold text-emerald-950 flex items-center gap-2">
            <History className="h-5 w-5 text-emerald-600" /> Minhas Entregas ({items.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {items.length === 0 ? (
            <p className="text-center py-8 text-sm text-emerald-600">Nenhum registro encontrado.</p>
          ) : (
            <div className="divide-y divide-emerald-100">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-950 text-base">
                        {item.quantity} kg
                      </span>
                      <Badge className="bg-emerald-100 text-emerald-800 border-none font-semibold">
                        {item.expand?.material?.type || 'PET'}
                      </Badge>
                    </div>
                    <p className="text-xs text-emerald-600 mt-1">{item.address}</p>
                    <p className="text-[11px] text-emerald-400 mt-0.5">
                      Registrado em: {new Date(item.created).toLocaleDateString('pt-BR')}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge
                      className={`capitalize text-xs font-semibold px-2.5 py-1 ${
                        item.status === 'coletado' || item.status === 'certificado'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-amber-100 text-amber-900 border-amber-200'
                      }`}
                    >
                      {item.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
