import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { PackageSearch, PlusCircle, ShoppingBag } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getInventory, InventoryItem } from '@/services/inventory'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function EstoqueCatador() {
  const { user } = useAuth()
  const [items, setItems] = useState<InventoryItem[]>([])

  useEffect(() => {
    if (!user) return
    getInventory(user.id).then(setItems)
  }, [user])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-emerald-950">Estoque de Resíduos Plásticos</h1>
          <p className="text-xs text-emerald-700">
            Controle de volumes triados em galpão disponíveis para venda.
          </p>
        </div>

        <Button asChild className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold">
          <Link to="/catador/meus-lotes">
            <ShoppingBag className="mr-2 h-4 w-4" /> Anunciar no Marketplace
          </Link>
        </Button>
      </div>

      <Card className="border-emerald-100">
        <CardHeader>
          <CardTitle className="text-base font-bold text-emerald-950 flex items-center gap-2">
            <PackageSearch className="h-5 w-5 text-emerald-600" /> Lotes em Estoque
          </CardTitle>
        </CardHeader>
        <CardContent>
          {items.length === 0 ? (
            <p className="text-center py-8 text-sm text-emerald-600">Nenhum estoque registrado.</p>
          ) : (
            <div className="divide-y divide-emerald-100">
              {items.map((item) => (
                <div key={item.id} className="py-4 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-950 text-base">
                        {item.quantity} kg
                      </span>
                      <Badge className="bg-emerald-100 text-emerald-800 border-none font-bold">
                        {item.expand?.material?.type || 'PET'}
                      </Badge>
                    </div>
                    <p className="text-xs text-emerald-600 mt-1">
                      Localização: {item.location || 'Depósito Principal'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
