import { useEffect, useState } from 'react'
import { MapPin, Navigation, Clock, CheckCircle2 } from 'lucide-react'
import { getCollectionPoints, CollectionPoint } from '@/services/collection-points'
import { MapComponent } from '@/components/MapComponent'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function MapaColeta() {
  const [points, setPoints] = useState<CollectionPoint[]>([])
  const [selectedPoint, setSelectedPoint] = useState<CollectionPoint | null>(null)

  useEffect(() => {
    getCollectionPoints().then((data) => {
      setPoints(data)
      if (data.length > 0) setSelectedPoint(data[0])
    })
  }, [])

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-emerald-950">Mapa de Pontos de Coleta PET</h1>
        <p className="text-xs text-emerald-700">
          Encontre ecopontos e locais de entrega voluntária (PEV) mais próximos de você.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MapComponent
            markers={points.map((p) => ({
              id: p.id,
              name: p.name,
              lat: p.lat,
              lng: p.lng,
              type: p.type,
              address: p.address,
              accepted_materials: p.accepted_materials,
            }))}
            selectedMarkerId={selectedPoint?.id}
            onMarkerClick={(m) => {
              const found = points.find((p) => p.id === m.id)
              if (found) setSelectedPoint(found)
            }}
            height="500px"
          />
        </div>

        <div>
          <Card className="border-emerald-100 h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-base font-bold text-emerald-950 flex items-center justify-between">
                Pontos de Entrega
                <Badge className="bg-emerald-100 text-emerald-800">{points.length} Ativos</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto max-h-[420px] space-y-3">
              {points.map((pt) => {
                const isSelected = selectedPoint?.id === pt.id
                return (
                  <div
                    key={pt.id}
                    onClick={() => setSelectedPoint(pt)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-600/20'
                        : 'border-emerald-100 hover:bg-emerald-50/30'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <h4 className="font-bold text-sm text-emerald-950">{pt.name}</h4>
                      <Badge className="text-[9px] capitalize bg-emerald-200/60 text-emerald-900 border-none">
                        {pt.type}
                      </Badge>
                    </div>
                    <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                      <MapPin className="h-3 w-3 shrink-0" /> {pt.address}
                    </p>
                    {pt.opening_hours && (
                      <p className="text-[11px] text-emerald-500 mt-1 flex items-center gap-1">
                        <Clock className="h-3 w-3 shrink-0" /> {pt.opening_hours}
                      </p>
                    )}
                    <div className="mt-2 flex flex-wrap gap-1">
                      {pt.accepted_materials?.map((mat) => (
                        <Badge
                          key={mat}
                          variant="secondary"
                          className="text-[9px] px-1.5 py-0 bg-emerald-100 text-emerald-800"
                        >
                          {mat}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
