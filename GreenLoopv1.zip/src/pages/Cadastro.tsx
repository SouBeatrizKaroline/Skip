import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Recycle, ArrowRight, UserCheck, Truck, Building2, CheckCircle2 } from 'lucide-react'
import { useAuth, UserRole } from '@/hooks/use-auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'
import { extractFieldErrors, getErrorMessage, type FieldErrors } from '@/lib/pocketbase/errors'

export default function Cadastro() {
  const [step, setStep] = useState(1)
  const [role, setRole] = useState<UserRole>('consumidor')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [document, setDocument] = useState('')
  const [cooperativeName, setCooperativeName] = useState('')
  const [loading, setLoading] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const { signUp } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setFieldErrors({})

    const extraData = {
      name,
      role,
      phone,
      address,
      document,
      cooperative_name: cooperativeName,
    }

    const { error } = await signUp(email, password, extraData)
    setLoading(false)

    if (error) {
      const fieldErrs = extractFieldErrors(error)
      setFieldErrors(fieldErrs)
      toast({
        title: 'Erro no cadastro',
        description: getErrorMessage(error),
        variant: 'destructive',
      })
      return
    }

    setStep(3)
    toast({
      title: 'Conta criada com sucesso! 🎉',
      description: 'Sua jornada sustentável começa agora.',
    })
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-gradient-to-br from-emerald-900 via-teal-900 to-emerald-950">
      <div className="w-full max-w-lg space-y-4">
        <div className="text-center space-y-1">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-500/30">
            <Recycle className="h-6 w-6 animate-spin" style={{ animationDuration: '12s' }} />
          </div>
          <h1 className="text-2xl font-black text-white">Criar Conta GreenLoop</h1>
          <p className="text-xs text-emerald-200">
            Escolha seu perfil e junte-se à reciclagem circular
          </p>
        </div>

        <Card className="border-emerald-800/40 bg-white/95 shadow-2xl backdrop-blur-md">
          {step === 1 && (
            <>
              <CardHeader>
                <CardTitle className="text-lg font-bold text-emerald-950">
                  1. Selecione seu perfil
                </CardTitle>
                <CardDescription className="text-xs text-emerald-700">
                  Como você irá atuar na plataforma?
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div
                  onClick={() => setRole('consumidor')}
                  className={`flex items-center gap-4 rounded-xl border p-4 cursor-pointer transition-all ${
                    role === 'consumidor'
                      ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-600/30'
                      : 'border-emerald-100 hover:bg-emerald-50/40'
                  }`}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-600 text-white">
                    <UserCheck className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm text-emerald-950">Consumidor</h3>
                    <p className="text-xs text-emerald-600">
                      Separe plásticos PET, ganhe pontos e troque por prêmios.
                    </p>
                  </div>
                </div>

                <div
                  onClick={() => setRole('catador')}
                  className={`flex items-center gap-4 rounded-xl border p-4 cursor-pointer transition-all ${
                    role === 'catador'
                      ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-600/30'
                      : 'border-emerald-100 hover:bg-emerald-50/40'
                  }`}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-600 text-white">
                    <Truck className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm text-emerald-950">Catador / Cooperativa</h3>
                    <p className="text-xs text-emerald-600">
                      Otimize rotas de coleta e venda lotes para indústrias.
                    </p>
                  </div>
                </div>

                <div
                  onClick={() => setRole('empresa')}
                  className={`flex items-center gap-4 rounded-xl border p-4 cursor-pointer transition-all ${
                    role === 'empresa'
                      ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-600/30'
                      : 'border-emerald-100 hover:bg-emerald-50/40'
                  }`}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-600 text-white">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm text-emerald-950">Empresa / Indústria</h3>
                    <p className="text-xs text-emerald-600">
                      Compre lotes certificados e acompanhe relatórios ESG.
                    </p>
                  </div>
                </div>

                <Button
                  onClick={() => setStep(2)}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white mt-4"
                >
                  Continuar
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </>
          )}

          {step === 2 && (
            <>
              <CardHeader>
                <CardTitle className="text-lg font-bold text-emerald-950">
                  2. Informações do Perfil
                </CardTitle>
                <CardDescription className="text-xs text-emerald-700">
                  Preencha seus dados para concluir o cadastro
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegister} className="space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-emerald-900">
                      Nome Completo / Razão Social
                    </Label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ex: Maria Silva"
                      required
                    />
                    {fieldErrors.name && <p className="text-xs text-red-500">{fieldErrors.name}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-emerald-900">E-mail</Label>
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="email@exemplo.com"
                        required
                      />
                      {fieldErrors.email && (
                        <p className="text-xs text-red-500">{fieldErrors.email}</p>
                      )}
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-emerald-900">Senha</Label>
                      <Input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        required
                      />
                      {fieldErrors.password && (
                        <p className="text-xs text-red-500">{fieldErrors.password}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-emerald-900">
                        Telefone / WhatsApp
                      </Label>
                      <Input
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(11) 98765-4321"
                      />
                      {fieldErrors.phone && (
                        <p className="text-xs text-red-500">{fieldErrors.phone}</p>
                      )}
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-emerald-900">
                        Documento (CPF/CNPJ)
                      </Label>
                      <Input
                        value={document}
                        onChange={(e) => setDocument(e.target.value)}
                        placeholder="000.000.000-00"
                      />
                      {fieldErrors.document && (
                        <p className="text-xs text-red-500">{fieldErrors.document}</p>
                      )}
                    </div>
                  </div>

                  {role === 'catador' && (
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-emerald-900">
                        Nome da Cooperativa (Opcional)
                      </Label>
                      <Input
                        value={cooperativeName}
                        onChange={(e) => setCooperativeName(e.target.value)}
                        placeholder="Ex: Cooperativa Recicla Verde"
                      />
                      {fieldErrors.cooperative_name && (
                        <p className="text-xs text-red-500">{fieldErrors.cooperative_name}</p>
                      )}
                    </div>
                  )}

                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-emerald-900">
                      Endereço Principal
                    </Label>
                    <Input
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Rua, Número, Bairro - Cidade, UF"
                    />
                    {fieldErrors.address && (
                      <p className="text-xs text-red-500">{fieldErrors.address}</p>
                    )}
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(1)}
                      className="w-1/3"
                    >
                      Voltar
                    </Button>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-2/3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold"
                    >
                      {loading ? 'Cadastrando...' : 'Finalizar Cadastro'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </>
          )}

          {step === 3 && (
            <CardContent className="p-8 text-center space-y-4">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                <CheckCircle2 className="h-10 w-10" />
              </div>
              <h2 className="text-2xl font-bold text-emerald-950">Cadastro Realizado!</h2>
              <p className="text-sm text-emerald-700">
                Bem-vindo ao ecossistema GreenLoop. Sua conta de{' '}
                <strong className="capitalize">{role}</strong> está pronta.
              </p>
              <Button
                onClick={() => navigate('/')}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2"
              >
                Ir para o Meu Dashboard
              </Button>
            </CardContent>
          )}

          <div className="text-center pb-4">
            <span className="text-xs text-emerald-700">Já tem uma conta? </span>
            <Link to="/login" className="text-xs font-bold text-emerald-800 hover:underline">
              Entrar
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
