import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Building2, PackageSearch, FileCheck2, BarChart3, ArrowUpRight } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { getMarketplaceListings, MarketplaceListing } from '@/services/marketplace'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ImpactChart } from '@/components/ImpactChart'

export default function EmpresaDashboard() {
  const { user } = useAuth()
  const [purchasedListings, setPurchasedListings] = useState<MarketplaceListing[]>([])

  useEffect(() => {
    if (!user) return
    getMarketplaceListings(`buyer = "${user.id}"`).then(setPurchasedListings)
  }, [user])

  const totalPurchasedKg = purchasedListings.reduce((acc, curr) => acc + (curr.quantity || 0), 0)
  const totalSpent = purchasedListings.reduce(
    (acc, curr) => acc + (curr.quantity * curr.price_per_kg || 0),
    0,
  )

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 p-6 sm:p-8 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <Badge className="bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 uppercase tracking-widest text-[10px]">
              Portal da Indústria Circular
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-black">{user?.name} 🏢</h1>
            <p className="text-emerald-200 text-sm">
              Rastreabilidade completa, fornecedores homologados e impacto ESG verificado.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button asChild className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold">
              <Link to="/empresa/comprar">
                <PackageSearch className="mr-2 h-4 w-4" /> Marketplace de Plásticos
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10"
            >
              <Link to="/empresa/relatorios">Relatório de Impacto ESG</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-700 text-white">
              <PackageSearch className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">Total Adquirido (kg)</p>
              <h4 className="text-2xl font-black text-emerald-950">{totalPurchasedKg} kg</h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white">
              <FileCheck2 className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">Investimento em Reciclagem</p>
              <h4 className="text-2xl font-black text-emerald-950">R$ {totalSpent.toFixed(2)}</h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white">
              <BarChart3 className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">CO₂ Evitado na Cadeia</p>
              <h4 className="text-2xl font-black text-emerald-950">
                {(totalPurchasedKg * 3.0).toFixed(0)} kg
              </h4>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart Section */}
      <Card className="border-emerald-100">
        <CardHeader>
          <CardTitle className="text-base font-bold text-emerald-950">
            Aquisição Semanal de Matéria-Prima Reciclada
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ImpactChart type="bar" />
        </CardContent>
      </Card>
    </div>
  )
}
