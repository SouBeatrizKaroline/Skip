import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Recycle, ArrowRight, ShieldCheck, UserCheck } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    const { error } = await signIn(email, password)
    setLoading(false)

    if (error) {
      toast({
        title: 'Erro ao acessar',
        description: 'E-mail ou senha incorretos. Verifique suas credenciais.',
        variant: 'destructive',
      })
      return
    }

    toast({
      title: 'Bem-vindo de volta ao GreenLoop! ♻️',
      description: 'Acessando seu painel ecológico.',
    })
    navigate('/')
  }

  const setDemoUser = (demoEmail: string) => {
    setEmail(demoEmail)
    setPassword('Skip@Pass')
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center p-4 bg-gradient-to-br from-emerald-900 via-teal-900 to-emerald-950 overflow-hidden">
      {/* Background Floating Elements */}
      <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-emerald-600/20 blur-3xl animate-pulse"></div>
      <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-teal-500/20 blur-3xl animate-pulse"></div>

      <div className="relative w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-300 ring-4 ring-emerald-500/30 backdrop-blur">
            <Recycle className="h-8 w-8 animate-spin" style={{ animationDuration: '10s' }} />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">GreenLoop</h1>
          <p className="text-sm text-emerald-200">
            Logística reversa e economia circular de plástico PET
          </p>
        </div>

        <Card className="border-emerald-800/40 bg-white/95 shadow-2xl backdrop-blur-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl font-bold text-emerald-950">Acesse sua conta</CardTitle>
            <CardDescription className="text-xs text-emerald-700">
              Digite seu e-mail e senha para acessar a plataforma
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs font-semibold text-emerald-900">
                  E-mail
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="border-emerald-200 focus:border-emerald-600 focus:ring-emerald-600"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-xs font-semibold text-emerald-900">
                    Senha
                  </Label>
                  <a
                    href="#reset"
                    onClick={(e) => {
                      e.preventDefault()
                      toast({
                        title: 'Recuperação de senha',
                        description: 'Instruções enviadas para seu e-mail!',
                      })
                    }}
                    className="text-[11px] text-emerald-600 hover:underline"
                  >
                    Esqueceu?
                  </a>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="border-emerald-200 focus:border-emerald-600 focus:ring-emerald-600"
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2.5 shadow-lg shadow-emerald-700/30 transition-all"
              >
                {loading ? 'Entrando...' : 'Entrar no GreenLoop'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>

            <div className="pt-2 border-t border-emerald-100">
              <p className="text-xs text-center font-semibold text-emerald-900 mb-2">
                Acesso Rápido de Teste (Demo):
              </p>
              <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="px-1 py-1 text-emerald-800 border-emerald-200 hover:bg-emerald-50 truncate"
                  onClick={() => setDemoUser('moniquecardoso900@gmail.com')}
                >
                  <UserCheck className="mr-1 h-3 w-3" /> Consumidor
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="px-1 py-1 text-emerald-800 border-emerald-200 hover:bg-emerald-50 truncate"
                  onClick={() => setDemoUser('coop@verde.com')}
                >
                  Catador
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="px-1 py-1 text-emerald-800 border-emerald-200 hover:bg-emerald-50 truncate"
                  onClick={() => setDemoUser('empresa@recicla.com')}
                >
                  Empresa
                </Button>
              </div>
            </div>

            <div className="text-center pt-2">
              <span className="text-xs text-emerald-700">Não tem uma conta? </span>
              <Link to="/cadastro" className="text-xs font-bold text-emerald-800 hover:underline">
                Cadastre-se gratuitamente
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
