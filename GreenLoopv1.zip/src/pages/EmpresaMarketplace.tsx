import { useEffect, useState } from 'react'
import { PackageSearch, ShoppingCart, ShieldCheck } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import {
  getMarketplaceListings,
  buyMarketplaceListing,
  MarketplaceListing,
} from '@/services/marketplace'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'

export default function EmpresaMarketplace() {
  const { user } = useAuth()
  const [listings, setListings] = useState<MarketplaceListing[]>([])
  const { toast } = useToast()

  const loadListings = async () => {
    const data = await getMarketplaceListings('status = "ativo"')
    setListings(data)
  }

  useEffect(() => {
    loadListings()
  }, [])

  const handleBuy = async (listingId: string) => {
    if (!user) return

    try {
      await buyMarketplaceListing(listingId, user.id)
      toast({
        title: 'Compra Confirmada! 🛒🎉',
        description: 'Lote adicionado com sucesso à sua cadeia de custódia.',
      })
      loadListings()
    } catch (err) {
      toast({
        title: 'Erro ao comprar',
        description: 'Tente novamente.',
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-emerald-950">
          Marketplace de Plásticos Reciclados
        </h1>
        <p className="text-xs text-emerald-700">
          Compre lotes diretamente de catadores e cooperativas homologadas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listings.length === 0 ? (
          <div className="col-span-full text-center py-12 text-emerald-600">
            Nenhum lote ativo disponível no momento.
          </div>
        ) : (
          listings.map((l) => (
            <Card
              key={l.id}
              className="border-emerald-100 flex flex-col justify-between shadow-subtle hover:shadow-elevation transition-all"
            >
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Badge className="bg-emerald-100 text-emerald-800 font-bold text-xs border-none">
                    {l.expand?.material?.type || 'PET'}
                  </Badge>
                  <span className="text-xs text-emerald-500 font-medium">Lote Verificado</span>
                </div>
                <CardTitle className="text-xl font-black text-emerald-950 mt-2">
                  {l.quantity} kg
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-xs text-emerald-700 flex-1">
                <p>
                  <strong className="text-emerald-950">Preço:</strong> R${' '}
                  {l.price_per_kg?.toFixed(2)} / kg
                </p>
                <p>
                  <strong className="text-emerald-950">Valor Total:</strong> R${' '}
                  {(l.quantity * l.price_per_kg).toFixed(2)}
                </p>
                <p>
                  <strong className="text-emerald-950">Fornecedor:</strong>{' '}
                  {l.expand?.collector?.cooperative_name ||
                    l.expand?.collector?.name ||
                    'Cooperativa'}
                </p>
                <p className="text-emerald-600 line-clamp-2 mt-2">{l.description}</p>
              </CardContent>
              <CardFooter className="pt-2 border-t border-emerald-50">
                <Button
                  onClick={() => handleBuy(l.id)}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold"
                >
                  <ShoppingCart className="mr-2 h-4 w-4" /> Comprar Lote
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
