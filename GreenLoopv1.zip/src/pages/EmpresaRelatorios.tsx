import { useEffect, useState } from 'react'
import { BarChart3, Download, Leaf, Droplets, Zap, Users } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import pb from '@/lib/pocketbase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function EmpresaRelatorios() {
  const { user } = useAuth()
  const [report, setReport] = useState<any>(null)

  useEffect(() => {
    pb.send('/backend/v1/impact-report', { method: 'GET' })
      .then(setReport)
      .catch(() => {
        setReport({
          total_purchased_kg: 450,
          co2_avoided_kg: 1350,
          water_saved_liters: 1125,
          energy_saved_kwh: 2520,
          families_supported: 5,
        })
      })
  }, [user])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-emerald-950">
            Relatório de Impacto Ambiental & ESG
          </h1>
          <p className="text-xs text-emerald-700">
            Métricas consolidadas para balanço de sustentabilidade.
          </p>
        </div>

        <Button
          onClick={() => window.print()}
          className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold"
        >
          <Download className="mr-2 h-4 w-4" /> Exportar PDF / Imprimir
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-emerald-100 bg-emerald-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-600 text-white">
              <Leaf className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700">CO₂ Evitado</p>
              <h4 className="text-2xl font-black text-emerald-950">
                {report?.co2_avoided_kg || 0} kg
              </h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-teal-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white">
              <Droplets className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-teal-700">Água Poupada</p>
              <h4 className="text-2xl font-black text-teal-950">
                {report?.water_saved_liters || 0} L
              </h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-amber-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-amber-800">Energia Poupada</p>
              <h4 className="text-2xl font-black text-amber-950">
                {report?.energy_saved_kwh || 0} kWh
              </h4>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-emerald-50/40">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-800 text-white">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-800">Famílias Apoiadas</p>
              <h4 className="text-2xl font-black text-emerald-950">
                {report?.families_supported || 0}
              </h4>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-emerald-100">
        <CardHeader>
          <CardTitle className="text-base font-bold text-emerald-950">
            Declaração da Economia Circular
          </CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-emerald-800 space-y-2 leading-relaxed">
          <p>
            Certificamos que a empresa <strong>{user?.name}</strong> adquiriu um montante total de{' '}
            <strong>{report?.total_purchased_kg || 0} kg</strong> de resíduos plásticos PET
            devidamente recolhidos, triados e reciclados através da rede GreenLoop.
          </p>
          <p>
            Essa ação evita a disposição inadequada em aterros sanitários e corpos hídricos, gerando
            impacto social positivo para cooperativas de catadores.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
