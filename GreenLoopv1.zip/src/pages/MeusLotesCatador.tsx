import { useEffect, useState } from 'react'
import { ShoppingBag, Plus, CheckCircle2 } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import {
  getMarketplaceListings,
  createMarketplaceListing,
  MarketplaceListing,
} from '@/services/marketplace'
import { getMaterials, Material } from '@/services/materials'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'

export default function MeusLotesCatador() {
  const { user } = useAuth()
  const [listings, setListings] = useState<MarketplaceListing[]>([])
  const [materials, setMaterials] = useState<Material[]>([])
  const [openModal, setOpenModal] = useState(false)

  const [materialId, setMaterialId] = useState('')
  const [quantity, setQuantity] = useState('200')
  const [price, setPrice] = useState('3.50')
  const [description, setDescription] = useState('')

  const { toast } = useToast()

  const loadData = async () => {
    if (!user) return
    const [mats, list] = await Promise.all([
      getMaterials(),
      getMarketplaceListings(`collector = "${user.id}"`),
    ])
    setMaterials(mats)
    setListings(list)
    if (mats.length > 0) setMaterialId(mats[0].id)
  }

  useEffect(() => {
    loadData()
  }, [user])

  const handleCreateListing = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    try {
      await createMarketplaceListing({
        collector: user.id,
        material: materialId,
        quantity: parseFloat(quantity),
        price_per_kg: parseFloat(price),
        description,
        status: 'ativo',
      })

      toast({
        title: 'Lote Anunciado! 🏷️',
        description: 'Agora empresas parceiras poderão comprar este material.',
      })
      setOpenModal(false)
      loadData()
    } catch (err) {
      toast({
        title: 'Erro ao anunciar',
        description: 'Tente novamente.',
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-emerald-950">Meus Lotes Anunciados</h1>
          <p className="text-xs text-emerald-700">
            Ofertas de plástico reciclado visíveis para compras por indústrias.
          </p>
        </div>

        <Dialog open={openModal} onOpenChange={setOpenModal}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold">
              <Plus className="mr-2 h-4 w-4" /> Anunciar Novo Lote
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-emerald-950 font-bold">
                Anunciar Lote no Marketplace
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateListing} className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">Material</Label>
                <Select value={materialId} onValueChange={setMaterialId}>
                  <SelectTrigger className="border-emerald-200">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {materials.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-emerald-900">Quantidade (kg)</Label>
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-emerald-900">
                    Preço por kg (R$)
                  </Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-emerald-900">Descrição do Lote</Label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ex: Garrafas prensadas em fardos de 50kg."
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold"
              >
                Publicar Lote
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-emerald-100">
        <CardHeader>
          <CardTitle className="text-base font-bold text-emerald-950">
            Lotes Ativos e Vendidos
          </CardTitle>
        </CardHeader>
        <CardContent>
          {listings.length === 0 ? (
            <p className="text-center py-8 text-sm text-emerald-600">
              Nenhum lote anunciado ainda.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {listings.map((l) => (
                <div
                  key={l.id}
                  className="p-4 rounded-xl border border-emerald-100 bg-emerald-50/20 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-950 text-base">{l.quantity} kg</span>
                    <Badge
                      className={
                        l.status === 'ativo'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-800'
                      }
                    >
                      {l.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-emerald-700">
                    Preço:{' '}
                    <strong className="text-emerald-950">R$ {l.price_per_kg?.toFixed(2)}/kg</strong>
                  </p>
                  <p className="text-xs text-emerald-600">
                    {l.description || 'Lote de plástico reciclado triado.'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
