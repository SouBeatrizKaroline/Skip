import { Link } from 'react-router-dom'
import {
  Recycle,
  MapPin,
  Gift,
  Truck,
  PackageSearch,
  Leaf,
  ArrowRight,
  Users,
  Droplets,
  Cloud,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { useAuth } from '@/hooks/use-auth'

const features = [
  {
    icon: MapPin,
    title: 'Mapa de Coletas',
    desc: 'Encontre pontos de coleta próximos para descartar seus resíduos PET.',
  },
  {
    icon: Truck,
    title: 'Coleta Agendada',
    desc: 'Catadores e cooperativas gerenciam rotas de coleta eficientes.',
  },
  {
    icon: PackageSearch,
    title: 'Marketplace',
    desc: 'Empresas compram plásticos processados diretamente de catadores.',
  },
  {
    icon: Gift,
    title: 'Recompensas',
    desc: 'Ganhe pontos e troque por recompensas ao descartar corretamente.',
  },
]

const steps = [
  {
    num: '1',
    title: 'Consumidor Registra',
    desc: 'O consumidor cadastra o plástico PET para descarte no aplicativo.',
  },
  {
    num: '2',
    title: 'Catador Coleta',
    desc: 'Catadores aceitam a coleta e definem rotas otimizadas.',
  },
  {
    num: '3',
    title: 'Material Processado',
    desc: 'O plástico é pesado, registrado no estoque e certificado.',
  },
  {
    num: '4',
    title: 'Empresa Compra',
    desc: 'Empresas adquirem o material processado via marketplace.',
  },
]

const stats = [
  { icon: Recycle, value: '2,5M kg', label: 'Plástico Reciclado' },
  { icon: Cloud, value: '3,8M kg', label: 'CO₂ Evitado' },
  { icon: Droplets, value: '12M L', label: 'Água Economizada' },
  { icon: Users, value: '15.000+', label: 'Participantes' },
]

export default function Index() {
  const { user } = useAuth()

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-700 via-teal-700 to-emerald-900 p-8 md:p-12 text-white">
        <div className="relative z-10 max-w-2xl">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium backdrop-blur">
            <Leaf className="h-4 w-4" /> Economia Circular PET
          </div>
          <h1 className="text-3xl md:text-5xl font-black leading-tight mb-4">
            Transforme resíduos plásticos em{' '}
            <span className="text-emerald-300">impacto positivo</span>
          </h1>
          <p className="text-emerald-100 text-lg mb-6">
            Conectamos consumidores, catadores e empresas para uma logística reversa eficiente.
          </p>
          <div className="flex flex-wrap gap-3">
            {user ? (
              <Button asChild size="lg" className="bg-white text-emerald-800 hover:bg-emerald-50">
                <Link to={`/${user.role}`}>
                  Ir para o Painel <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            ) : (
              <>
                <Button asChild size="lg" className="bg-white text-emerald-800 hover:bg-emerald-50">
                  <Link to="/cadastro">
                    Começar Agora <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 bg-transparent"
                >
                  <Link to="/login">Entrar</Link>
                </Button>
              </>
            )}
          </div>
        </div>
        <Recycle className="absolute -right-8 -bottom-8 h-64 w-64 text-white/5" />
      </section>

      <Tabs defaultValue="inicio">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="inicio">Início</TabsTrigger>
          <TabsTrigger value="como-funciona">Como Funciona</TabsTrigger>
          <TabsTrigger value="impacto">Impacto</TabsTrigger>
          <TabsTrigger value="sobre">Sobre</TabsTrigger>
        </TabsList>

        <TabsContent value="inicio" className="mt-6 space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <Card key={f.title} className="border-emerald-100 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                    <f.icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-emerald-950 text-lg">{f.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-emerald-700">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="como-funciona" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((s) => (
              <Card key={s.num} className="border-emerald-100">
                <CardHeader>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-600 text-white font-bold">
                    {s.num}
                  </div>
                  <CardTitle className="text-emerald-950 text-lg mt-2">{s.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-emerald-700">{s.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="impacto" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {stats.map((s) => (
              <Card
                key={s.label}
                className="border-emerald-100 bg-gradient-to-br from-emerald-50 to-teal-50"
              >
                <CardContent className="pt-6 text-center">
                  <s.icon className="mx-auto mb-2 h-8 w-8 text-emerald-700" />
                  <p className="text-2xl font-black text-emerald-950">{s.value}</p>
                  <p className="text-sm text-emerald-600">{s.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="sobre" className="mt-6">
          <Card className="border-emerald-100">
            <CardContent className="pt-6 space-y-4">
              <h3 className="text-xl font-bold text-emerald-950">Sobre o GreenLoop</h3>
              <p className="text-emerald-700 leading-relaxed">
                O GreenLoop é uma plataforma de economia circular e logística reversa de resíduos
                plásticos PET. Nossa missão é conectar todos os elos da cadeia — do consumidor que
                descarta até a empresa que transforma — criando valor a partir do que antes era
                descartado.
              </p>
              <p className="text-emerald-700 leading-relaxed">
                Através de tecnologia, gamificação e transparência, promovemos a reciclagem como um
                ato transformador que gera impacto ambiental, social e econômico.
              </p>
              {!user && (
                <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                  <Link to="/cadastro">
                    Participe da mudança <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
