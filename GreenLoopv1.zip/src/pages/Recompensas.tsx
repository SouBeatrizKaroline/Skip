import { useEffect, useState, useCallback } from 'react'
import { Gift, Sparkles, CheckCircle2, AlertCircle, Loader2, ShoppingBag } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'
import { useRealtime } from '@/hooks/use-realtime'
import { getUserStats, UserStats } from '@/services/stats'
import {
  getRewards,
  redeemReward,
  decrementRewardStock,
  deductUserPoints,
  Reward,
} from '@/services/rewards'
import { getErrorMessage } from '@/lib/pocketbase/errors'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'

export default function Recompensas() {
  const { user } = useAuth()
  const [rewards, setRewards] = useState<Reward[]>([])
  const [stats, setStats] = useState<UserStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [redeemingId, setRedeemingId] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    if (!user) return
    try {
      const [rw, st] = await Promise.all([getRewards(), getUserStats(user.id)])
      setRewards(rw)
      setStats(st)
    } catch (err) {
      toast.error('Erro ao carregar recompensas', {
        description: getErrorMessage(err),
      })
    } finally {
      setLoading(false)
    }
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useRealtime('rewards', () => loadData())
  useRealtime('user_stats', () => loadData())

  const userPoints = stats?.points ?? 0

  const handleRedeem = async (reward: Reward) => {
    if (!user || !stats) return

    if (reward.stock <= 0) {
      toast.error('Recompensa esgotada', {
        description: 'Não há mais unidades disponíveis desta recompensa.',
      })
      return
    }

    if (userPoints < reward.points_required) {
      toast.error('Pontos insuficientes', {
        description: `Você precisa de ${reward.points_required} pontos, mas tem apenas ${userPoints}.`,
      })
      return
    }

    setRedeemingId(reward.id)
    try {
      await redeemReward(user.id, reward.id)
      await decrementRewardStock(reward.id, reward.stock)
      await deductUserPoints(stats.id, userPoints, reward.points_required)

      toast.success('Recompensa resgatada!', {
        description: `${reward.name} foi resgatada com sucesso. ${reward.points_required} pontos consumidos.`,
        icon: <CheckCircle2 className="h-4 w-4" />,
      })

      await loadData()
    } catch (err) {
      toast.error('Falha ao resgatar recompensa', {
        description: getErrorMessage(err),
        icon: <AlertCircle className="h-4 w-4" />,
      })
    } finally {
      setRedeemingId(null)
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'diamante':
        return 'from-cyan-500 to-blue-600'
      case 'ouro':
        return 'from-amber-400 to-yellow-600'
      case 'prata':
        return 'from-gray-400 to-slate-600'
      default:
        return 'from-amber-700 to-orange-800'
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <Badge className="bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 uppercase tracking-widest text-[10px]">
              <Sparkles className="mr-1 h-3 w-3" /> Programa de Recompensas
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Recompensas GreenLoop 🎁
            </h1>
            <p className="text-emerald-100 text-sm max-w-xl">
              Troque seus pontos de impacto por recompensas exclusivas e continue contribuindo para
              um planeta mais sustentável.
            </p>
          </div>

          <div className="flex flex-col items-center gap-2">
            <div
              className={`flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br ${getLevelColor(stats?.level || 'bronze')} shadow-lg`}
            >
              <Gift className="h-9 w-9 text-white" />
            </div>
            <div className="text-center">
              <p className="text-3xl font-black text-white">{userPoints}</p>
              <p className="text-[10px] text-emerald-200 uppercase tracking-widest font-bold">
                Pontos
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Section Title */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-emerald-950 flex items-center gap-2">
          <ShoppingBag className="h-5 w-5 text-emerald-600" />
          Recompensas Disponíveis
        </h2>
        <Badge className="bg-emerald-100 text-emerald-800 border-none font-medium">
          {rewards.length} {rewards.length === 1 ? 'item' : 'itens'}
        </Badge>
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="border-emerald-100">
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-10 w-full rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : rewards.length === 0 ? (
        /* Empty State */
        <Card className="border-emerald-100 border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 mb-4">
              <Gift className="h-8 w-8 text-emerald-400" />
            </div>
            <h3 className="text-lg font-bold text-emerald-950">Nenhuma recompensa disponível</h3>
            <p className="text-sm text-emerald-600 mt-1 max-w-sm">
              No momento não há recompensas cadastradas. Continue acumulando pontos e volte em
              breve!
            </p>
          </CardContent>
        </Card>
      ) : (
        /* Reward Cards Grid */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rewards.map((reward) => {
            const canRedeem = userPoints >= reward.points_required && reward.stock > 0
            const isRedeeming = redeemingId === reward.id

            return (
              <Card
                key={reward.id}
                className={`border-emerald-100 overflow-hidden transition-all hover:shadow-lg ${
                  canRedeem ? 'hover:border-emerald-300' : 'opacity-75'
                }`}
              >
                <CardHeader className="bg-gradient-to-br from-emerald-50 to-teal-50/50 pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-md shrink-0">
                      <Gift className="h-5 w-5" />
                    </div>
                    <Badge
                      className={
                        reward.stock > 0
                          ? 'bg-emerald-100 text-emerald-800 border-none'
                          : 'bg-red-100 text-red-700 border-none'
                      }
                    >
                      Estoque: {reward.stock}
                    </Badge>
                  </div>
                  <CardTitle className="text-base font-bold text-emerald-950 mt-2">
                    {reward.name}
                  </CardTitle>
                  {reward.description && (
                    <CardDescription className="text-emerald-700 text-xs leading-relaxed">
                      {reward.description}
                    </CardDescription>
                  )}
                </CardHeader>

                <CardContent className="p-4">
                  <div className="flex items-center justify-between bg-emerald-50/60 rounded-lg px-3 py-2">
                    <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wide">
                      Custo
                    </span>
                    <span className="text-lg font-black text-emerald-950 flex items-center gap-1">
                      {reward.points_required}
                      <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                    </span>
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0">
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                    disabled={!canRedeem || isRedeeming}
                    onClick={() => handleRedeem(reward)}
                  >
                    {isRedeeming ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Resgatando...
                      </>
                    ) : reward.stock === 0 ? (
                      'Esgotado'
                    ) : userPoints < reward.points_required ? (
                      `Faltam ${reward.points_required - userPoints} pts`
                    ) : (
                      <>
                        <Gift className="mr-2 h-4 w-4" /> Resgatar
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
