import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { ChartContainer } from '@/components/ui/chart'

interface ImpactChartProps {
  type?: 'bar' | 'pie'
}

const barData = [
  { name: 'Sem 1', kg: 12 },
  { name: 'Sem 2', kg: 18 },
  { name: 'Sem 3', kg: 25 },
  { name: 'Sem 4', kg: 30 },
]

const pieData = [
  { name: 'PET', value: 45, color: '#2E7D32' },
  { name: 'PEAD', value: 25, color: '#00897B' },
  { name: 'PP', value: 20, color: '#FFB300' },
  { name: 'Outros', value: 10, color: '#81C784' },
]

export function ImpactChart({ type = 'bar' }: ImpactChartProps) {
  if (type === 'pie') {
    return (
      <ChartContainer config={{}} className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={4}
              dataKey="value"
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </ChartContainer>
    )
  }

  return (
    <ChartContainer config={{}} className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <XAxis dataKey="name" stroke="#5F6368" fontSize={12} tickLine={false} />
          <YAxis stroke="#5F6368" fontSize={12} tickLine={false} />
          <Tooltip cursor={{ fill: '#f0f7f4' }} />
          <Bar dataKey="kg" fill="#2E7D32" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
