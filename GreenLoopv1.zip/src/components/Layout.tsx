import { Outlet, useLocation } from 'react-router-dom'
import { Navbar } from '@/components/Navbar'

export default function Layout() {
  const location = useLocation()
  const isAuthPage = location.pathname === '/login' || location.pathname === '/cadastro'

  if (isAuthPage) {
    return (
      <main className="min-h-screen bg-[#F5F7F4]">
        <Outlet />
      </main>
    )
  }

  return (
    <div className="min-h-screen bg-[#F5F7F4] flex flex-col font-sans">
      <Navbar />
      <div className="flex-1 md:pl-60">
        <main className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8 pb-20 md:pb-8">
          <Outlet />
        </main>
        <footer className="hidden border-t border-emerald-100 bg-white/60 py-4 text-center text-xs text-emerald-700 md:block">
          GreenLoop v0.0.1 — Feito com ♻️ para o planeta & economia circular PET.
        </footer>
      </div>
    </div>
  )
}
