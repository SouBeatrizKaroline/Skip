import { useState } from 'react'
import { MapPin, Navigation, Compass, Plus, Minus, Layers } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export interface MapMarker {
  id: string
  name: string
  lat: number
  lng: number
  type?: string
  address?: string
  status?: string
  acceptedMaterials?: string[]
}

interface MapComponentProps {
  markers?: MapMarker[]
  onMarkerClick?: (marker: MapMarker) => void
  selectedMarkerId?: string
  height?: string
  center?: { lat: number; lng: number }
  interactive?: boolean
}

export function MapComponent({
  markers = [],
  onMarkerClick,
  selectedMarkerId,
  height = '400px',
  center = { lat: -23.5617, lng: -46.6558 },
}: MapComponentProps) {
  const [zoom, setZoom] = useState(13)
  const [activeTab, setActiveTab] = useState<'map' | 'satellite'>('map')

  const latToY = (lat: number) => {
    const scale = Math.pow(2, zoom) * 8
    return (center.lat - lat) * scale + 200
  }

  const lngToX = (lng: number) => {
    const scale = Math.pow(2, zoom) * 8
    return (lng - center.lng) * scale + 300
  }

  return (
    <div
      style={{ height }}
      className="relative w-full overflow-hidden rounded-2xl border border-emerald-200 bg-[#e8f0ec] shadow-inner select-none"
    >
      {/* Tile Simulated Background */}
      <div
        className={`absolute inset-0 transition-opacity duration-300 ${
          activeTab === 'map' ? 'bg-[#e2ebe6]' : 'bg-[#1e2d27]'
        }`}
      >
        <svg className="h-full w-full opacity-30" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path
                d="M 40 0 L 0 0 0 40"
                fill="none"
                stroke={activeTab === 'map' ? '#2e7d32' : '#81c784'}
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Simulated Roads/Water SVG Graphic */}
      <svg
        className="absolute inset-0 h-full w-full pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M -50 150 Q 200 120, 350 250 T 700 300"
          fill="none"
          stroke={activeTab === 'map' ? '#81d4fa' : '#0288d1'}
          strokeWidth="18"
          opacity="0.6"
        />
        <path
          d="M 100 -20 Q 180 200, 280 450"
          fill="none"
          stroke={activeTab === 'map' ? '#ffffff' : '#37474f'}
          strokeWidth="8"
        />
        <path
          d="M -20 280 Q 300 280, 650 100"
          fill="none"
          stroke={activeTab === 'map' ? '#fff8e1' : '#455a64'}
          strokeWidth="6"
        />
      </svg>

      {/* Markers Canvas Layer */}
      <div className="absolute inset-0">
        {markers.map((m) => {
          const x = lngToX(m.lng)
          const y = latToY(m.lat)
          const isSelected = selectedMarkerId === m.id

          if (x < -20 || x > 1000 || y < -20 || y > 800) return null

          return (
            <div
              key={m.id}
              onClick={() => onMarkerClick?.(m)}
              style={{ left: `${x}px`, top: `${y}px` }}
              className={`absolute -translate-x-1/2 -translate-y-full cursor-pointer transition-all duration-300 z-10 ${
                isSelected ? 'scale-125 z-20' : 'hover:scale-110'
              }`}
            >
              <div className="group relative flex flex-col items-center">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full shadow-lg transition-colors ${
                    m.type === 'residencial'
                      ? 'bg-amber-500 text-white ring-2 ring-amber-200'
                      : 'bg-emerald-600 text-white ring-2 ring-emerald-200'
                  }`}
                >
                  <MapPin className="h-5 w-5" />
                </div>

                {/* Marker Badge Title */}
                <div className="mt-1 max-w-[140px] truncate rounded-md bg-white/90 px-2 py-0.5 text-[10px] font-bold text-emerald-950 shadow-md backdrop-blur border border-emerald-100">
                  {m.name}
                </div>

                {isSelected && (
                  <div className="absolute top-12 left-1/2 -translate-x-1/2 w-48 rounded-xl bg-white p-3 shadow-xl border border-emerald-100 z-30 text-xs">
                    <p className="font-bold text-emerald-950">{m.name}</p>
                    <p className="text-[11px] text-emerald-600 truncate mt-0.5">{m.address}</p>
                    {m.accepted_materials && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {m.accepted_materials.slice(0, 3).map((mat) => (
                          <Badge
                            key={mat}
                            variant="secondary"
                            className="text-[9px] px-1 py-0 bg-emerald-50 text-emerald-700"
                          >
                            {mat}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Control Overlay Buttons */}
      <div className="absolute right-3 top-3 flex flex-col gap-1.5 z-20">
        <div className="flex rounded-lg bg-white p-0.5 shadow-md border border-emerald-100">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-emerald-800"
            onClick={() => setZoom((z) => Math.min(z + 1, 18))}
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-emerald-800"
            onClick={() => setZoom((z) => Math.max(z - 1, 8))}
          >
            <Minus className="h-4 w-4" />
          </Button>
        </div>

        <Button
          variant="secondary"
          size="icon"
          className="h-8 w-8 rounded-lg bg-white shadow-md border border-emerald-100 text-emerald-800 hover:bg-emerald-50"
          onClick={() => setActiveTab((t) => (t === 'map' ? 'satellite' : 'map'))}
        >
          <Layers className="h-4 w-4" />
        </Button>
      </div>

      <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2 rounded-lg bg-white/90 px-3 py-1 text-[11px] font-semibold text-emerald-950 shadow-md backdrop-blur border border-emerald-100">
        <Compass className="h-3.5 w-3.5 text-emerald-600 animate-spin" />
        <span>São Paulo, SP ({markers.length} Pontos)</span>
      </div>
    </div>
  )
}
