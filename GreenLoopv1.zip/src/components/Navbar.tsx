import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import {
  Recycle,
  LayoutDashboard,
  MapPin,
  Gift,
  History,
  Truck,
  PackageSearch,
  FileCheck2,
  BarChart3,
  User,
  LogOut,
  Bell,
  Search,
  PlusCircle,
  Menu,
  X,
  ShieldCheck,
} from 'lucide-react'
import { useAuth, UserRole } from '@/hooks/use-auth'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Badge } from '@/components/ui/badge'

interface NavItem {
  label: string
  path: string
  icon: any
}

const navByRole: Record<UserRole, NavItem[]> = {
  consumidor: [
    { label: 'Painel', path: '/consumidor', icon: LayoutDashboard },
    { label: 'Registrar Plástico', path: '/consumidor/registrar', icon: PlusCircle },
    { label: 'Mapa de Coletas', path: '/consumidor/mapa', icon: MapPin },
    { label: 'Histórico', path: '/consumidor/historico', icon: History },
    { label: 'Recompensas', path: '/recompensas', icon: Gift },
  ],
  catador: [
    { label: 'Painel', path: '/catador', icon: LayoutDashboard },
    { label: 'Gerenciar Rotas', path: '/catador/rotas', icon: Truck },
    { label: 'Registrar Coleta', path: '/catador/registrar-coleta', icon: PlusCircle },
    { label: 'Estoque de Materiais', path: '/catador/estoque', icon: PackageSearch },
    { label: 'Meus Lotes (Vendas)', path: '/catador/meus-lotes', icon: FileCheck2 },
    { label: 'Recompensas', path: '/recompensas', icon: Gift },
  ],
  empresa: [
    { label: 'Painel Geral', path: '/empresa', icon: LayoutDashboard },
    { label: 'Comprar Plásticos', path: '/empresa/comprar', icon: PackageSearch },
    { label: 'Rastreabilidade', path: '/empresa/rastreabilidade', icon: FileCheck2 },
    { label: 'Relatórios de Impacto', path: '/empresa/relatorios', icon: BarChart3 },
    { label: 'Recompensas', path: '/recompensas', icon: Gift },
  ],
  admin: [
    { label: 'Painel Admin', path: '/admin', icon: ShieldCheck },
    { label: 'Pontos de Coleta', path: '/admin/pontos', icon: MapPin },
    { label: 'Recompensas', path: '/recompensas', icon: Gift },
  ],
}

const getInitials = (name?: string) =>
  !name
    ? 'GL'
    : name
        .split(' ')
        .slice(0, 2)
        .map((n) => n[0])
        .join('')
        .toUpperCase()

export function Navbar() {
  const { user, signOut } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)

  const navItems = user?.role ? navByRole[user.role] : []
  const isActive = (path: string) => location.pathname === path
  const handleLogout = () => {
    signOut()
    navigate('/login')
  }

  const renderNavLink = (item: NavItem, onClick?: () => void) => {
    const Icon = item.icon
    return (
      <Link
        key={item.path}
        to={item.path}
        onClick={onClick}
        className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
          isActive(item.path)
            ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
            : 'text-emerald-800 hover:bg-emerald-50 hover:text-emerald-950'
        }`}
      >
        <Icon className="h-5 w-5" /> {item.label}
      </Link>
    )
  }

  return (
    <>
      <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-emerald-100 bg-white/95 px-4 backdrop-blur md:px-8">
        <div className="flex items-center gap-3">
          {navItems.length > 0 && (
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-emerald-900"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          )}
          <Link
            to="/"
            className="flex items-center gap-2 font-bold text-emerald-800 transition hover:opacity-90"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-md shadow-emerald-600/20">
              <Recycle className="h-5 w-5 animate-pulse" />
            </div>
            <span className="text-xl tracking-tight text-emerald-950 font-black">
              Green<span className="text-emerald-600">Loop</span>
            </span>
          </Link>
          {user?.role && (
            <Badge className="hidden sm:inline-flex bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border-none font-medium capitalize">
              {user.role === 'catador' ? 'Catador / Cooperativa' : user.role}
            </Badge>
          )}
        </div>

        {user && (
          <div className="hidden max-w-md flex-1 px-8 md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-500" />
              <input
                type="text"
                placeholder="Buscar pontos de coleta, materiais..."
                className="w-full rounded-full border border-emerald-200 bg-emerald-50/50 py-1.5 pl-9 pr-4 text-sm text-emerald-950 placeholder-emerald-400 focus:border-emerald-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
              />
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          {user ? (
            <>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative text-emerald-800 hover:bg-emerald-50"
                  >
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-amber-500 ring-2 ring-white" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 p-0 border-emerald-100">
                  <div className="border-b border-emerald-100 p-3 bg-emerald-50/50">
                    <h4 className="font-semibold text-emerald-900 text-sm">Notificações</h4>
                  </div>
                  <div className="divide-y divide-emerald-50 max-h-64 overflow-y-auto">
                    <div className="p-3 text-xs text-emerald-800 hover:bg-emerald-50/50 cursor-pointer">
                      <p className="font-semibold text-emerald-950">♻️ Ponto de Coleta Próximo</p>
                      <p className="text-emerald-600 mt-0.5">Novo Ecoponto cadastrado para PET.</p>
                      <span className="text-[10px] text-emerald-400 mt-1 block">Há 10 minutos</span>
                    </div>
                    <div className="p-3 text-xs text-emerald-800 hover:bg-emerald-50/50 cursor-pointer">
                      <p className="font-semibold text-emerald-950">🌟 Meta Semanal Atingida</p>
                      <p className="text-emerald-600 mt-0.5">Você acumulou mais de 100 pontos!</p>
                      <span className="text-[10px] text-emerald-400 mt-1 block">Há 1 hora</span>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="relative h-10 w-10 rounded-full ring-2 ring-emerald-500/20 hover:ring-emerald-500 p-0"
                  >
                    <Avatar className="h-10 w-10 bg-emerald-700 text-white font-semibold">
                      <AvatarFallback className="bg-emerald-700 text-white font-bold">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 border-emerald-100">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-semibold text-emerald-950 leading-none">
                        {user.name}
                      </p>
                      <p className="text-xs text-emerald-600 leading-none">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => navigate('/perfil')}
                    className="cursor-pointer text-emerald-900"
                  >
                    <User className="mr-2 h-4 w-4" /> Meu Perfil
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleLogout}
                    className="cursor-pointer text-red-600 hover:text-red-700"
                  >
                    <LogOut className="mr-2 h-4 w-4" /> Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" asChild className="text-emerald-800 hover:bg-emerald-50">
                <Link to="/login">Entrar</Link>
              </Button>
              <Button asChild className="bg-emerald-600 hover:bg-emerald-700 text-white">
                <Link to="/cadastro">Cadastrar</Link>
              </Button>
            </div>
          )}
        </div>
      </header>

      {navItems.length > 0 && (
        <aside className="fixed left-0 top-16 z-30 hidden h-[calc(100vh-4rem)] w-60 border-r border-emerald-100 bg-white md:block">
          <div className="flex h-full flex-col justify-between p-4">
            <nav className="space-y-1">
              <div className="px-3 py-2 text-xs font-semibold text-emerald-500 uppercase tracking-wider">
                Navegação
              </div>
              {navItems.map((item) => renderNavLink(item))}
            </nav>
            <div className="rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50/50 p-3 border border-emerald-100 text-xs text-emerald-800">
              <p className="font-semibold text-emerald-950">Iniciativa PET 100% Circular</p>
              <p className="mt-1 text-emerald-600 leading-relaxed">
                Incentivando a logística reversa e transformando resíduos em impacto social
                positivo.
              </p>
            </div>
          </div>
        </aside>
      )}

      {mobileOpen && navItems.length > 0 && (
        <div
          className="fixed inset-0 top-16 z-50 bg-emerald-950/20 backdrop-blur-sm md:hidden"
          onClick={() => setMobileOpen(false)}
        >
          <div
            className="h-full w-4/5 max-w-xs bg-white p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <nav className="space-y-2">
              <div className="px-2 text-xs font-semibold text-emerald-500 uppercase tracking-wider mb-2">
                Menu
              </div>
              {navItems.map((item) => renderNavLink(item, () => setMobileOpen(false)))}
            </nav>
          </div>
        </div>
      )}

      {navItems.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-center justify-around border-t border-emerald-100 bg-white/95 backdrop-blur md:hidden">
          {navItems.slice(0, 4).map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1 text-[11px] font-medium transition-colors ${
                  isActive(item.path)
                    ? 'text-emerald-600 font-bold'
                    : 'text-emerald-700 hover:text-emerald-900'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label.split(' ')[0]}</span>
              </Link>
            )
          })}
        </div>
      )}
    </>
  )
}
