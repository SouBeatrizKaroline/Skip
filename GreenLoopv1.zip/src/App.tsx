import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { Toaster as Sonner } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { AuthProvider } from '@/hooks/use-auth'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import Layout from '@/components/Layout'
import Index from '@/pages/Index'
import Login from '@/pages/Login'
import Cadastro from '@/pages/Cadastro'
import NotFound from '@/pages/NotFound'
import ConsumidorDashboard from '@/pages/ConsumidorDashboard'
import RegistrarMaterial from '@/pages/RegistrarMaterial'
import MapaColeta from '@/pages/MapaColeta'
import HistoricoConsumidor from '@/pages/HistoricoConsumidor'
import CatadorDashboard from '@/pages/CatadorDashboard'
import GestaoRotas from '@/pages/GestaoRotas'
import RegistrarColetaCatador from '@/pages/RegistrarColetaCatador'
import EstoqueCatador from '@/pages/EstoqueCatador'
import MeusLotesCatador from '@/pages/MeusLotesCatador'
import EmpresaDashboard from '@/pages/EmpresaDashboard'
import EmpresaMarketplace from '@/pages/EmpresaMarketplace'
import EmpresaRastreabilidade from '@/pages/EmpresaRastreabilidade'
import EmpresaRelatorios from '@/pages/EmpresaRelatorios'
import Recompensas from '@/pages/Recompensas'

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/cadastro" element={<Cadastro />} />
            <Route
              path="/consumidor"
              element={
                <ProtectedRoute roles={['consumidor']}>
                  <ConsumidorDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/consumidor/registrar"
              element={
                <ProtectedRoute roles={['consumidor']}>
                  <RegistrarMaterial />
                </ProtectedRoute>
              }
            />
            <Route
              path="/consumidor/mapa"
              element={
                <ProtectedRoute roles={['consumidor']}>
                  <MapaColeta />
                </ProtectedRoute>
              }
            />
            <Route
              path="/consumidor/historico"
              element={
                <ProtectedRoute roles={['consumidor']}>
                  <HistoricoConsumidor />
                </ProtectedRoute>
              }
            />
            <Route
              path="/catador"
              element={
                <ProtectedRoute roles={['catador']}>
                  <CatadorDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/catador/rotas"
              element={
                <ProtectedRoute roles={['catador']}>
                  <GestaoRotas />
                </ProtectedRoute>
              }
            />
            <Route
              path="/catador/registrar-coleta"
              element={
                <ProtectedRoute roles={['catador']}>
                  <RegistrarColetaCatador />
                </ProtectedRoute>
              }
            />
            <Route
              path="/catador/estoque"
              element={
                <ProtectedRoute roles={['catador']}>
                  <EstoqueCatador />
                </ProtectedRoute>
              }
            />
            <Route
              path="/catador/meus-lotes"
              element={
                <ProtectedRoute roles={['catador']}>
                  <MeusLotesCatador />
                </ProtectedRoute>
              }
            />
            <Route
              path="/empresa"
              element={
                <ProtectedRoute roles={['empresa']}>
                  <EmpresaDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/empresa/comprar"
              element={
                <ProtectedRoute roles={['empresa']}>
                  <EmpresaMarketplace />
                </ProtectedRoute>
              }
            />
            <Route
              path="/empresa/rastreabilidade"
              element={
                <ProtectedRoute roles={['empresa']}>
                  <EmpresaRastreabilidade />
                </ProtectedRoute>
              }
            />
            <Route
              path="/empresa/relatorios"
              element={
                <ProtectedRoute roles={['empresa']}>
                  <EmpresaRelatorios />
                </ProtectedRoute>
              }
            />
            <Route
              path="/recompensas"
              element={
                <ProtectedRoute>
                  <Recompensas />
                </ProtectedRoute>
              }
            />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </TooltipProvider>
    </AuthProvider>
  </BrowserRouter>
)

export default App
