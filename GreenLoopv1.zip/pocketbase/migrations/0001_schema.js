migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')

    if (!users.fields.getByName('role')) {
      users.fields.add(
        new SelectField({
          name: 'role',
          values: ['consumidor', 'catador', 'empresa', 'admin'],
          required: false,
        }),
      )
    }
    if (!users.fields.getByName('phone')) {
      users.fields.add(new TextField({ name: 'phone' }))
    }
    if (!users.fields.getByName('address')) {
      users.fields.add(new TextField({ name: 'address' }))
    }
    if (!users.fields.getByName('document')) {
      users.fields.add(new TextField({ name: 'document' }))
    }
    if (!users.fields.getByName('cooperative_name')) {
      users.fields.add(new TextField({ name: 'cooperative_name' }))
    }
    app.save(users)

    const materials = new Collection({
      name: 'materials',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'type',
          type: 'select',
          values: ['PET', 'PEAD', 'PEBD', 'PP', 'PS', 'Outro'],
          required: true,
        },
        { name: 'unit', type: 'select', values: ['kg', 'ton'], required: true },
        { name: 'description', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(materials)

    const collectionPoints = new Collection({
      name: 'collection_points',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'address', type: 'text', required: true },
        { name: 'lat', type: 'number', required: true },
        { name: 'lng', type: 'number', required: true },
        { name: 'type', type: 'select', values: ['fixo', 'residencial'] },
        { name: 'accepted_materials', type: 'json' },
        { name: 'status', type: 'select', values: ['ativo', 'inativo'] },
        { name: 'photo', type: 'file', maxSelect: 1, maxSize: 5242880 },
        { name: 'opening_hours', type: 'text' },
        { name: 'owner', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(collectionPoints)

    const materialsId = app.findCollectionByNameOrId('materials').id

    const collections = new Collection({
      name: 'collections',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'consumer',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          required: true,
        },
        { name: 'collector', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'material', type: 'relation', collectionId: materialsId, maxSelect: 1 },
        { name: 'quantity', type: 'number', required: true },
        { name: 'address', type: 'text' },
        {
          name: 'status',
          type: 'select',
          values: ['pendente', 'agendado', 'coletado', 'certificado'],
        },
        { name: 'notes', type: 'text' },
        { name: 'collected_at', type: 'date' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(collections)

    const inventory = new Collection({
      name: 'inventory',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'collector',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          required: true,
        },
        { name: 'material', type: 'relation', collectionId: materialsId, maxSelect: 1 },
        { name: 'quantity', type: 'number' },
        { name: 'location', type: 'text' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(inventory)

    const marketplaceListings = new Collection({
      name: 'marketplace_listings',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'collector',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          required: true,
        },
        { name: 'material', type: 'relation', collectionId: materialsId, maxSelect: 1 },
        { name: 'quantity', type: 'number', required: true },
        { name: 'price_per_kg', type: 'number', required: true },
        { name: 'description', type: 'text' },
        { name: 'status', type: 'select', values: ['ativo', 'vendido'] },
        { name: 'buyer', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(marketplaceListings)

    const userStats = new Collection({
      name: 'user_stats',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        {
          name: 'user',
          type: 'relation',
          collectionId: '_pb_users_auth_',
          maxSelect: 1,
          required: true,
        },
        { name: 'points', type: 'number' },
        { name: 'level', type: 'select', values: ['bronze', 'prata', 'ouro', 'diamante'] },
        { name: 'co2_saved', type: 'number' },
        { name: 'plastic_diverted', type: 'number' },
        { name: 'water_saved', type: 'number' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(userStats)

    const rewards = new Collection({
      name: 'rewards',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'description', type: 'text' },
        { name: 'points_required', type: 'number', required: true },
        { name: 'stock', type: 'number' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(rewards)

    const rewardsId = app.findCollectionByNameOrId('rewards').id

    const redemptions = new Collection({
      name: 'redemptions',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'user', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'reward', type: 'relation', collectionId: rewardsId, maxSelect: 1 },
        { name: 'redeemed_at', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(redemptions)

    const routesCol = new Collection({
      name: 'routes',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != ''",
      deleteRule: "@request.auth.id != ''",
      fields: [
        { name: 'collector', type: 'relation', collectionId: '_pb_users_auth_', maxSelect: 1 },
        { name: 'name', type: 'text' },
        { name: 'stops', type: 'json' },
        { name: 'polyline', type: 'json' },
        { name: 'date', type: 'date' },
        { name: 'status', type: 'select', values: ['ativa', 'finalizada'] },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    })
    app.save(routesCol)
  },
  (app) => {
    const names = [
      'routes',
      'redemptions',
      'rewards',
      'user_stats',
      'marketplace_listings',
      'inventory',
      'collections',
      'collection_points',
      'materials',
    ]
    for (const name of names) {
      try {
        const col = app.findCollectionByNameOrId(name)
        app.delete(col)
      } catch (_) {}
    }
  },
)
