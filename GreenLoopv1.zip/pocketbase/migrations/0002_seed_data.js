migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('_pb_users_auth_')

    // Seed User 1: Consumidor Monique
    let user1
    try {
      user1 = app.findAuthRecordByEmail('_pb_users_auth_', 'moniquecardoso900@gmail.com')
    } catch (_) {
      user1 = new Record(users)
      user1.setEmail('moniquecardoso900@gmail.com')
      user1.setPassword('Skip@Pass')
      user1.setVerified(true)
      user1.set('name', 'Monique Cardoso')
      user1.set('role', 'consumidor')
      user1.set('phone', '(11) 98765-4321')
      user1.set('address', 'Av. Paulista, 1000 - São Paulo, SP')
      user1.set('document', '123.456.789-00')
      app.save(user1)
    }

    // Seed User 2: Catador Cooperativa Verde
    let user2
    try {
      user2 = app.findAuthRecordByEmail('_pb_users_auth_', 'coop@verde.com')
    } catch (_) {
      user2 = new Record(users)
      user2.setEmail('coop@verde.com')
      user2.setPassword('Skip@Pass')
      user2.setVerified(true)
      user2.set('name', 'Cooperativa Verde')
      user2.set('role', 'catador')
      user2.set('phone', '(11) 91234-5678')
      user2.set('address', 'Rua das Flores, 45 - São Paulo, SP')
      user2.set('document', '12.345.678/0001-90')
      user2.set('cooperative_name', 'Verde Sustentável')
      app.save(user2)
    }

    // Seed User 3: Empresa Recicla S.A.
    let user3
    try {
      user3 = app.findAuthRecordByEmail('_pb_users_auth_', 'empresa@recicla.com')
    } catch (_) {
      user3 = new Record(users)
      user3.setEmail('empresa@recicla.com')
      user3.setPassword('Skip@Pass')
      user3.setVerified(true)
      user3.set('name', 'Recicla S.A.')
      user3.set('role', 'empresa')
      user3.set('phone', '(11) 3333-4444')
      user3.set('address', 'Alameda Santos, 500 - São Paulo, SP')
      user3.set('document', '98.765.432/0001-10')
      app.save(user3)
    }

    // Seed User 4: Admin
    let user4
    try {
      user4 = app.findAuthRecordByEmail('_pb_users_auth_', 'admin@greenloop.com')
    } catch (_) {
      user4 = new Record(users)
      user4.setEmail('admin@greenloop.com')
      user4.setPassword('Skip@Pass')
      user4.setVerified(true)
      user4.set('name', 'Administrador GreenLoop')
      user4.set('role', 'admin')
      user4.set('phone', '(11) 99999-0000')
      app.save(user4)
    }

    // Seed Materials
    const materialsCol = app.findCollectionByNameOrId('materials')
    const materialList = [
      {
        type: 'PET',
        unit: 'kg',
        description: 'Tereftalato de Polietileno (Garrafas PET, embalagens)',
      },
      {
        type: 'PEAD',
        unit: 'kg',
        description: 'Polietileno de Alta Densidade (Frascos de detergente, shampoo)',
      },
      {
        type: 'PEBD',
        unit: 'kg',
        description: 'Polietileno de Baixa Densidade (Sacolas plásticas, filmes)',
      },
      {
        type: 'PP',
        unit: 'kg',
        description: 'Polipropileno (Tampas de garrafa, potes de alimentos)',
      },
      {
        type: 'PS',
        unit: 'kg',
        description: 'Poliestireno (Copos descartáveis, embalagens rígidas)',
      },
      { type: 'Outro', unit: 'kg', description: 'Outros tipos de plástico ou mistos' },
    ]

    const createdMaterials = {}
    for (const mat of materialList) {
      try {
        const rec = app.findFirstRecordByData('materials', 'type', mat.type)
        createdMaterials[mat.type] = rec.id
      } catch (_) {
        const rec = new Record(materialsCol)
        rec.set('type', mat.type)
        rec.set('unit', mat.unit)
        rec.set('description', mat.description)
        app.save(rec)
        createdMaterials[mat.type] = rec.id
      }
    }

    // Seed Collection Points
    const pointsCol = app.findCollectionByNameOrId('collection_points')
    const pointsData = [
      {
        name: 'Ecoponto Central Paulista',
        address: 'Av. Paulista, 1500 - Bela Vista, São Paulo - SP',
        lat: -23.5617,
        lng: -46.6558,
        type: 'fixo',
        accepted_materials: ['PET', 'PEAD', 'PP'],
        status: 'ativo',
        opening_hours: 'Seg a Sáb: 08h - 18h',
      },
      {
        name: 'Centro de Triagem Cooperativa Verde',
        address: 'Rua do Carmo, 100 - Sé, São Paulo - SP',
        lat: -23.5505,
        lng: -46.6333,
        type: 'fixo',
        accepted_materials: ['PET', 'PEAD', 'PEBD', 'PP', 'PS', 'Outro'],
        status: 'ativo',
        opening_hours: 'Seg a Sex: 07h - 17h',
      },
      {
        name: 'Ponto Ecológico Pinheiros',
        address: 'Rua Gilberto Sabino, 200 - Pinheiros, São Paulo - SP',
        lat: -23.5673,
        lng: -46.6928,
        type: 'fixo',
        accepted_materials: ['PET', 'PEAD', 'PS'],
        status: 'ativo',
        opening_hours: 'Todos os dias: 09h - 19h',
      },
      {
        name: 'PEV Residencial Jardins',
        address: 'Alameda Lorena, 800 - Jardins, São Paulo - SP',
        lat: -23.57,
        lng: -46.66,
        type: 'residencial',
        accepted_materials: ['PET', 'PP'],
        status: 'ativo',
        opening_hours: 'Seg a Sex: 08h - 12h',
      },
    ]

    for (const pt of pointsData) {
      try {
        app.findFirstRecordByData('collection_points', 'name', pt.name)
      } catch (_) {
        const rec = new Record(pointsCol)
        rec.set('name', pt.name)
        rec.set('address', pt.address)
        rec.set('lat', pt.lat)
        rec.set('lng', pt.lng)
        rec.set('type', pt.type)
        rec.set('accepted_materials', pt.accepted_materials)
        rec.set('status', pt.status)
        rec.set('opening_hours', pt.opening_hours)
        rec.set('owner', user1.id)
        app.save(rec)
      }
    }

    // Seed Rewards
    const rewardsCol = app.findCollectionByNameOrId('rewards')
    const rewardsData = [
      {
        name: 'Ecobag de Algodão Reciclado',
        description: 'Sacola ecológica de alta resistência.',
        points_required: 100,
        stock: 50,
      },
      {
        name: 'Desconto de 15% em Lojas Eco',
        description: 'Cupom de desconto válido em parceiros sustentáveis.',
        points_required: 250,
        stock: 100,
      },
      {
        name: 'Kit Canudos de Inox com Escova',
        description: 'Kit reutilizável em aço inox.',
        points_required: 400,
        stock: 30,
      },
      {
        name: 'Curso de Compostagem Doméstica',
        description: 'Acesso completo ao curso online de gestão de resíduos.',
        points_required: 500,
        stock: 200,
      },
      {
        name: 'Voucher R$ 50 para Feiras Orgânicas',
        description: 'Crédito para compra de alimentos orgânicos.',
        points_required: 800,
        stock: 15,
      },
    ]

    for (const rw of rewardsData) {
      try {
        app.findFirstRecordByData('rewards', 'name', rw.name)
      } catch (_) {
        const rec = new Record(rewardsCol)
        rec.set('name', rw.name)
        rec.set('description', rw.description)
        rec.set('points_required', rw.points_required)
        rec.set('stock', rw.stock)
        app.save(rec)
      }
    }

    // Seed User Stats for Monique
    const statsCol = app.findCollectionByNameOrId('user_stats')
    try {
      app.findFirstRecordByData('user_stats', 'user', user1.id)
    } catch (_) {
      const rec = new Record(statsCol)
      rec.set('user', user1.id)
      rec.set('points', 350)
      rec.set('level', 'ouro')
      rec.set('co2_saved', 75.0)
      rec.set('plastic_diverted', 25.0)
      rec.set('water_saved', 50.0)
      app.save(rec)
    }

    // Seed Inventory for Catador
    const invCol = app.findCollectionByNameOrId('inventory')
    try {
      app.findFirstRecordByData('inventory', 'collector', user2.id)
    } catch (_) {
      const rec1 = new Record(invCol)
      rec1.set('collector', user2.id)
      rec1.set('material', createdMaterials['PET'])
      rec1.set('quantity', 450.0)
      rec1.set('location', 'Galpão A - Lote 1')
      app.save(rec1)

      const rec2 = new Record(invCol)
      rec2.set('collector', user2.id)
      rec2.set('material', createdMaterials['PEAD'])
      rec2.set('quantity', 220.0)
      rec2.set('location', 'Galpão B - Lote 3')
      app.save(rec2)
    }

    // Seed Marketplace Listing
    const marketCol = app.findCollectionByNameOrId('marketplace_listings')
    try {
      app.findFirstRecordByData('marketplace_listings', 'collector', user2.id)
    } catch (_) {
      const listing = new Record(marketCol)
      listing.set('collector', user2.id)
      listing.set('material', createdMaterials['PET'])
      listing.set('quantity', 300.0)
      listing.set('price_per_kg', 3.5)
      listing.set(
        'description',
        'Lote de Garrafas PET limpas, prensadas e enfardadas prontas para reciclagem industrial.',
      )
      listing.set('status', 'ativo')
      app.save(listing)
    }
  },
  (app) => {},
)
