routerAdd(
  'POST',
  '/backend/v1/route-optimize',
  (e) => {
    const body = e.requestInfo().body || {}
    const stops = body.stops || []

    if (!Array.isArray(stops) || stops.length === 0) {
      return e.badRequestError('Stops array required')
    }

    try {
      const promptText =
        'Analise as seguintes paradas de coleta com seus endereços e coordenadas: ' +
        JSON.stringify(stops) +
        ". Ordene-as na melhor sequência lógica para minimizar a distância percorrida pelo veículo. Responda com um JSON contendo o array 'ordered_indices' com a ordem dos índices originais de 0 a " +
        (stops.length - 1) +
        '.'

      const aiRes = $ai.chat({
        model: 'fast',
        messages: [
          {
            role: 'system',
            content:
              'Você é um assistente perito em logística reversa e otimização de rotas de coleta.',
          },
          { role: 'user', content: promptText },
        ],
      })

      const reply = aiRes.choices[0].message.content
      let orderedIndices = []

      try {
        const match = reply.match(/\{[\s\S]*\}/)
        if (match) {
          const parsed = JSON.parse(match[0])
          if (Array.isArray(parsed.ordered_indices)) {
            orderedIndices = parsed.ordered_indices
          }
        }
      } catch (_) {}

      if (orderedIndices.length !== stops.length) {
        orderedIndices = stops.map((_, i) => i)
      }

      const orderedStops = orderedIndices.map((idx) => stops[idx] || stops[0])

      return e.json(200, {
        success: true,
        ordered_stops: orderedStops,
        ordered_indices: orderedIndices,
      })
    } catch (err) {
      return e.json(200, {
        success: true,
        ordered_stops: stops,
        ordered_indices: stops.map((_, i) => i),
        note: 'Fallback sequential order',
      })
    }
  },
  $apis.requireAuth(),
)
