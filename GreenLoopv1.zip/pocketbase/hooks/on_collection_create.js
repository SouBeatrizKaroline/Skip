onRecordAfterCreateSuccess((e) => {
  const rec = e.record
  const consumerId = rec.getString('consumer')
  const quantity = rec.getFloat('quantity') || 0

  if (!consumerId || quantity <= 0) return e.next()

  try {
    let stats
    try {
      stats = $app.findFirstRecordByData('user_stats', 'user', consumerId)
    } catch (_) {
      const statsCol = $app.findCollectionByNameOrId('user_stats')
      stats = new Record(statsCol)
      stats.set('user', consumerId)
      stats.set('points', 0)
      stats.set('level', 'bronze')
      stats.set('co2_saved', 0)
      stats.set('plastic_diverted', 0)
      stats.set('water_saved', 0)
    }

    const addedPoints = Math.round(quantity * 10)
    const newPoints = (stats.getInt('points') || 0) + addedPoints
    const newPlastic = (stats.getFloat('plastic_diverted') || 0) + quantity
    const newCo2 = (stats.getFloat('co2_saved') || 0) + quantity * 3.0
    const newWater = (stats.getFloat('water_saved') || 0) + quantity * 2.0

    let newLevel = 'bronze'
    if (newPoints >= 601) {
      newLevel = 'diamante'
    } else if (newPoints >= 301) {
      newLevel = 'ouro'
    } else if (newPoints >= 101) {
      newLevel = 'prata'
    }

    stats.set('points', newPoints)
    stats.set('level', newLevel)
    stats.set('plastic_diverted', newPlastic)
    stats.set('co2_saved', newCo2)
    stats.set('water_saved', newWater)

    $app.save(stats)
  } catch (err) {
    console.log('Error updating stats in on_collection_create:', err.message)
  }

  return e.next()
}, 'collections')
