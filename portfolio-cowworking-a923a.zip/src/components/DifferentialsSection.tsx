import { Gamepad2, Calendar, Briefcase, BarChart3, Sparkles, Heart } from 'lucide-react'

const DIFFERENTIALS = [
  {
    icon: Gamepad2,
    title: 'Gamificação real',
    desc: 'Níveis, badges, raridade e ranking. Cada hackathon te aproxima de virar Lenda do Pasto.',
  },
  {
    icon: BarChart3,
    title: 'Match de equipes',
    desc: 'Algoritmo conecta skills complementares. Dev encontra Designer, Pitchman encontra Estrategista.',
  },
  {
    icon: Calendar,
    title: 'Cowwlendário ativo',
    desc: 'Maratonas e hackathons o ano todo. Sempre há um desafio novo pra ruminar.',
  },
  {
    icon: Briefcase,
    title: 'Oportunidades reais',
    desc: 'Vagas, mentorias e conexões com empresas. Do hackathon à contratação.',
  },
]

const IMPACTS = [
  { value: '2.000+', label: 'Cowpetidores no pasto' },
  { value: '50+', label: 'Maratonas realizadas' },
  { value: 'R$ 100k+', label: 'Em prêmios distribuídos' },
  { value: '100%', label: 'Crescimento coletivo' },
]

export function DifferentialsSection() {
  return (
    <section id="diferenciais" className="py-20 relative bg-[#050807] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            <Sparkles className="w-3.5 h-3.5" /> Diferenciais
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
            Por que a <span className="text-emerald-400">CowWorking</span> é diferente?
          </h2>
          <p className="text-zinc-400 max-w-xl mx-auto text-sm sm:text-base">
            Não é só mais um grupo de WhatsApp. É um ecowssistema gamificado onde comunidade,
            competição e carreira se encontram.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-16">
          {DIFFERENTIALS.map((item, idx) => (
            <div
              key={idx}
              className="group p-6 rounded-2xl bg-[#0B1210] border border-white/10 hover:border-emerald-500/40 transition-all duration-300 hover:-translate-y-1 flex items-start gap-5"
            >
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 group-hover:bg-emerald-500 group-hover:text-black group-hover:scale-105 transition-all duration-300">
                <item.icon className="w-7 h-7" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-zinc-400 leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="relative p-8 sm:p-10 rounded-3xl bg-gradient-to-b from-[#0F1713] to-[#0B1210] border border-emerald-500/20 shadow-[0_0_50px_rgba(34,197,94,0.1)]">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest mb-6">
            <Heart className="w-4 h-4" /> Impacto real
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {IMPACTS.map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-emerald-400 font-display">
                  {stat.value}
                </div>
                <div className="text-xs text-zinc-400 mt-2 uppercase tracking-wider font-semibold">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
