import { useEffect } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'
import type { GalleryItem } from '@/types/portfolio'

interface GalleryLightboxProps {
  items: GalleryItem[]
  currentIndex: number
  onClose: () => void
  onNavigate: (index: number) => void
}

export function GalleryLightbox({
  items,
  currentIndex,
  onClose,
  onNavigate,
}: GalleryLightboxProps) {
  const current = items[currentIndex]

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowLeft') onNavigate((currentIndex - 1 + items.length) % items.length)
      if (e.key === 'ArrowRight') onNavigate((currentIndex + 1) % items.length)
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', handleKeyDown)
    return () => {
      document.body.style.overflow = 'unset'
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [currentIndex, items.length, onClose, onNavigate])

  if (!current) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-xl p-4 animate-fade-in select-none">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-6 right-6 p-3 rounded-full bg-white/10 text-white hover:bg-emerald-500 hover:text-black transition-all z-20"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Prev / Next buttons */}
      <button
        onClick={() => onNavigate((currentIndex - 1 + items.length) % items.length)}
        className="absolute left-4 sm:left-8 p-3 rounded-full bg-white/10 text-white hover:bg-emerald-500 hover:text-black transition-all z-20"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={() => onNavigate((currentIndex + 1) % items.length)}
        className="absolute right-4 sm:right-8 p-3 rounded-full bg-white/10 text-white hover:bg-emerald-500 hover:text-black transition-all z-20"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Main Image Container */}
      <div className="max-w-5xl w-full max-h-[85vh] flex flex-col items-center justify-center space-y-4">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.8)] max-h-[75vh]">
          <img
            src={current.image_url}
            alt={current.caption}
            className="max-h-[75vh] w-auto max-w-full object-contain"
          />
        </div>

        <div className="text-center space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-500 text-black">
            {current.tag}
          </span>
          <p className="text-sm sm:text-base text-white font-medium max-w-2xl mx-auto">
            {current.caption}
          </p>
          <span className="text-xs text-zinc-500 block pt-1">
            {currentIndex + 1} de {items.length}
          </span>
        </div>
      </div>
    </div>
  )
}
