import { ExternalLink, MessageSquare, Users, Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CtaSection() {
  return (
    <section className="py-24 relative bg-[#050807] overflow-hidden border-t border-emerald-500/20">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-emerald-500/20 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border border-dashed border-emerald-500/30 animate-[spin_60s_linear_infinite] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center relative z-10 space-y-8">
        <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-4 py-1.5 rounded-full border border-emerald-500/30">
          🐮 Última chamada pro pasto
        </div>

        <h2 className="text-4xl sm:text-6xl font-extrabold text-white font-display tracking-tight">
          Bora conquistar o{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-lime-300">
            pasto
          </span>{' '}
          juntos?
        </h2>

        <p className="text-zinc-300 text-base sm:text-xl max-w-2xl mx-auto leading-relaxed">
          O rebanho te espera. Entre para a maior cowwmunidade de TEI Sports do Brasil, encontre seu
          time e vire uma Lenda do Pasto. É de graça — só precisa de vontade de cowmpetir. 🐮💚
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <Button
            asChild
            size="lg"
            className="w-full sm:w-auto h-14 px-8 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-extrabold text-base shadow-[0_0_30px_rgba(34,197,94,0.5)] transition-all active:scale-98"
          >
            <a href="https://linktr.ee/cowworking" target="_blank" rel="noopener noreferrer">
              Entre pro rebanho <ExternalLink className="w-5 h-5 ml-2" />
            </a>
          </Button>

          <Button
            asChild
            variant="outline"
            size="lg"
            className="w-full sm:w-auto h-14 px-8 rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-emerald-400 text-white font-bold text-base gap-2"
          >
            <a
              href="https://whatsapp.com/channel/cowworking"
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageSquare className="w-5 h-5 text-emerald-400" /> WhatsApp
            </a>
          </Button>

          <Button
            asChild
            variant="outline"
            size="lg"
            className="w-full sm:w-auto h-14 px-8 rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-emerald-400 text-white font-bold text-base gap-2"
          >
            <a href="https://discord.gg/cowworking" target="_blank" rel="noopener noreferrer">
              <Users className="w-5 h-5 text-indigo-400" /> Discord
            </a>
          </Button>
        </div>

        <p className="text-xs text-zinc-500 font-medium pt-2 flex items-center justify-center gap-1.5">
          <Heart className="w-3 h-3 text-emerald-500/50" /> Ninguém evolui sozinho. Bora cowmpetir?
          🐮
        </p>
      </div>
    </section>
  )
}
