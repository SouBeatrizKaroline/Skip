import { CowLogo } from '@/components/CowLogo'
import { BrandIcon } from '@/components/BrandIcon'

export function Footer() {
  return (
    <footer className="bg-[#050807] border-t border-emerald-500/10 pt-16 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/5">
          <div className="md:col-span-6 space-y-4">
            <CowLogo />
            <p className="text-zinc-400 max-w-md text-sm leading-relaxed">
              A maior cowwmunidade de TEI Sports do Brasil. Conectando cowpetidores, devs, designers
              e empreendedores em jornadas do Bezerro à Lenda do Pasto. 🐮💚
            </p>
            <div className="pt-2 flex items-center gap-3">
              {[
                { name: 'linkedin', href: 'https://linkedin.com/company/cowworking' },
                { name: 'instagram', href: 'https://instagram.com/cowworking' },
                { name: 'discord', href: 'https://discord.gg/cowworking' },
                { name: 'whatsapp', href: 'https://whatsapp.com/channel/cowworking' },
              ].map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#0B1210] border border-white/10 flex items-center justify-center text-zinc-400 hover:text-emerald-400 hover:border-emerald-500/40 hover:bg-emerald-500/10 hover:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all"
                >
                  <BrandIcon icon={s.name} className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">Navegação</h4>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <a href="#inicio" className="hover:text-emerald-400 transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#links" className="hover:text-emerald-400 transition-colors">
                  Links do Rebanho
                </a>
              </li>
              <li>
                <a href="#cowpetidores" className="hover:text-emerald-400 transition-colors">
                  Cowpetidores
                </a>
              </li>
              <li>
                <a href="#competicoes" className="hover:text-emerald-400 transition-colors">
                  Cowmpetições
                </a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-emerald-400 transition-colors">
                  Galeria
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">TEI Sports</h4>
            <p className="text-zinc-400 text-xs leading-relaxed">
              <strong className="text-emerald-400">T</strong>ecnologia,{' '}
              <strong className="text-emerald-400">E</strong>mpreendedorismo e{' '}
              <strong className="text-emerald-400">I</strong>novação. Formando campeões de
              hackathons e maratonas tech.
            </p>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500 text-center sm:text-left">
          <p>© {new Date().getFullYear()} CowWorking — Feito com 💚 pela comunidade.</p>
          <p className="text-zinc-500">TEI Sports: Tecnologia, Empreendedorismo e Inovação</p>
        </div>
      </div>
    </footer>
  )
}
