import {
  Link as LinkIcon,
  MessageSquare,
  Users,
  Calendar,
  BookOpen,
  Trophy,
  Briefcase,
  Linkedin,
  Instagram,
  Sparkles,
  ExternalLink,
  Github,
  Mail,
} from 'lucide-react'

interface BrandIconProps {
  icon: string
  className?: string
}

export function BrandIcon({ icon, className = 'w-5 h-5' }: BrandIconProps) {
  switch (icon.toLowerCase()) {
    case 'whatsapp':
    case 'vip':
      return <MessageSquare className={className} />
    case 'linkedin':
      return <Linkedin className={className} />
    case 'instagram':
      return <Instagram className={className} />
    case 'github':
      return <Github className={className} />
    case 'discord':
      return <Users className={className} />
    case 'calendar':
      return <Calendar className={className} />
    case 'knowledge':
      return <BookOpen className={className} />
    case 'teams':
      return <Trophy className={className} />
    case 'jobs':
      return <Briefcase className={className} />
    case 'email':
      return <Mail className={className} />
    case 'linktree':
    default:
      return <LinkIcon className={className} />
  }
}
