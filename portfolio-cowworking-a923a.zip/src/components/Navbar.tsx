import { useState, useEffect } from 'react'
import { Menu, X, ExternalLink } from 'lucide-react'
import { CowLogo } from '@/components/CowLogo'
import { Button } from '@/components/ui/button'
import { useScrollSpy } from '@/hooks/use-scroll-spy'

const NAV_LINKS = [
  { id: 'inicio', label: 'Início' },
  { id: 'sobre', label: 'Ecowssistema' },
  { id: 'como-funciona', label: 'Como Funciona' },
  { id: 'cowpetidores', label: 'Cowpetidores' },
  { id: 'competicoes', label: 'Cowmpetições' },
  { id: 'galeria', label: 'Galeria' },
]

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const activeSection = useScrollSpy(
    NAV_LINKS.map((l) => l.id),
    100,
  )

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false)
    const element = document.getElementById(id)
    if (element) {
      const offset = 80
      const bodyRect = document.body.getBoundingClientRect().top
      const elementRect = element.getBoundingClientRect().top
      const elementPosition = elementRect - bodyRect
      const offsetPosition = elementPosition - offset

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      })
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#050807]/80 backdrop-blur-md border-b border-emerald-500/10 shadow-lg shadow-black/50 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <a
          href="#inicio"
          onClick={(e) => {
            e.preventDefault()
            scrollToSection('inicio')
          }}
          className="group"
        >
          <CowLogo />
        </a>

        {/* Desktop Links */}
        <nav className="hidden md:flex items-center gap-1 bg-[#0B1210]/60 backdrop-blur-md border border-white/5 rounded-full px-4 py-1.5 shadow-inner">
          {NAV_LINKS.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollToSection(link.id)}
              className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all duration-200 ${
                activeSection === link.id
                  ? 'text-emerald-400 bg-emerald-500/10 font-semibold shadow-[0_0_10px_rgba(34,197,94,0.2)]'
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:block">
          <Button
            asChild
            className="rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-bold px-6 shadow-[0_0_20px_rgba(34,197,94,0.3)] hover:shadow-[0_0_25px_rgba(74,222,128,0.5)] transition-all duration-200 active:scale-95"
          >
            <a href="https://linktr.ee/cowworking" target="_blank" rel="noopener noreferrer">
              Entre pro rebanho <ExternalLink className="w-4 h-4 ml-1.5" />
            </a>
          </Button>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setIsMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-zinc-300 hover:text-white rounded-lg bg-white/5 border border-white/10"
          aria-label="Abrir menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[60px] bg-[#050807]/95 backdrop-blur-xl z-40 flex flex-col justify-between p-6 border-t border-white/10 animate-fade-in">
          <div className="space-y-3 pt-4">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`w-full text-left px-4 py-3 rounded-xl text-lg font-semibold transition-all ${
                  activeSection === link.id
                    ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/30'
                    : 'text-zinc-300 hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-6 border-t border-white/10 space-y-4">
            <Button
              asChild
              className="w-full py-6 text-base font-bold rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-black shadow-[0_0_20px_rgba(34,197,94,0.4)]"
            >
              <a href="https://linktr.ee/cowworking" target="_blank" rel="noopener noreferrer">
                Entre pro rebanho <ExternalLink className="w-5 h-5 ml-2" />
              </a>
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}
