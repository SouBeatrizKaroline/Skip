export function CowLogo({ className = 'h-9' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 font-display select-none ${className}`}>
      <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500/20 to-lime-500/10 border border-emerald-500/40 shadow-[0_0_15px_rgba(34,197,94,0.3)] group-hover:border-emerald-400 group-hover:shadow-[0_0_20px_rgba(74,222,128,0.5)] transition-all duration-300">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform duration-300"
        >
          {/* Geometric Cow Mascot Head */}
          <path d="M7 3L3 8l3 2" />
          <path d="M17 3l4 5-3 2" />
          <path d="M5 9l7-4 7 4v5c0 4.5-3.5 8-7 8s-7-3.5-7-8V9z" />
          <circle cx="9" cy="12" r="1" fill="currentColor" />
          <circle cx="15" cy="12" r="1" fill="currentColor" />
          <ellipse cx="12" cy="16" rx="3" ry="2" />
        </svg>
      </div>
      <span className="text-xl font-extrabold tracking-wider text-white uppercase drop-shadow-[0_0_10px_rgba(34,197,94,0.4)]">
        Cow<span className="text-emerald-400">Working</span>
      </span>
    </div>
  )
}
