import { Outlet } from 'react-router-dom'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'

export function Layout() {
  return (
    <div className="min-h-screen bg-[#050807] text-zinc-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}

export default Layout
