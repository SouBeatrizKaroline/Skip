import { UserPlus, Users, Lightbulb, TrendingUp } from 'lucide-react'

const STEPS = [
  {
    icon: UserPlus,
    num: '01',
    title: 'Entre no rebanho',
    desc: 'Cadastre-se, escolha sua especialidade e conheça a comunidade. Sem burocracia — só vontade de cowmpetir.',
  },
  {
    icon: Users,
    num: '02',
    title: 'Monte seu time',
    desc: 'Encontre cowpetidores com skills complementares. Dev + Designer + Pitchman = time cowwpeão.',
  },
  {
    icon: Lightbulb,
    num: '03',
    title: 'Ruminem ideias',
    desc: '48 horas de hackathon: brainstorwm, código, café e muita inovação. Saia do pasto e construa algo real.',
  },
  {
    icon: TrendingUp,
    num: '04',
    title: 'Evolua junto',
    desc: 'Suba de nível, ganhe badges, conquiste pódios. De Bezerro a Lenda do Pasto — a jornada é coletiva.',
  },
]

export function HowItWorksSection() {
  return (
    <section id="como-funciona" className="py-20 relative bg-[#050807] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            <Lightbulb className="w-3.5 h-3.5" /> Jornada
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
            Como funciona o <span className="text-emerald-400">Ecowssistema</span>
          </h2>
          <p className="text-zinc-400 max-w-xl mx-auto text-sm sm:text-base">
            Do primeiro clique ao pódio — veja como é simples entrar no rebanho e evoluir como
            cowpetidor.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {STEPS.map((step, idx) => (
            <div key={idx} className="relative group">
              {idx < STEPS.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-[60%] w-full h-0.5 bg-gradient-to-r from-emerald-500/30 to-transparent pointer-events-none" />
              )}
              <div className="relative p-6 rounded-2xl bg-[#0B1210] border border-white/10 hover:border-emerald-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.5),0_0_20px_rgba(34,197,94,0.15)] space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-all duration-300">
                    <step.icon className="w-6 h-6" />
                  </div>
                  <span className="text-3xl font-black text-white/5 group-hover:text-emerald-500/20 transition-colors">
                    {step.num}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">
                  {step.title}
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
