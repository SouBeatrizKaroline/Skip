import { useEffect, useState } from 'react'
import { Users, Filter } from 'lucide-react'
import type { Cowpetidor, Rarity } from '@/types/portfolio'
import { getCowpetidores } from '@/services/cowpetidores'
import { useRealtime } from '@/hooks/use-realtime'
import { CowpetidorCard } from '@/components/CowpetidorCard'
import { CowpetidorModal } from '@/components/CowpetidorModal'

const RARITY_OPTIONS: { id: Rarity | 'todos'; label: string }[] = [
  { id: 'todos', label: 'Todos' },
  { id: 'lendario', label: 'Lendário 👑' },
  { id: 'epico', label: 'Épico 💎' },
  { id: 'raro', label: 'Raro ⚡' },
  { id: 'comum', label: 'Comum 🐮' },
]

export function CowpetidoresSection() {
  const [list, setList] = useState<Cowpetidor[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRarity, setSelectedRarity] = useState<Rarity | 'todos'>('todos')
  const [activeModalMember, setActiveModalMember] = useState<Cowpetidor | null>(null)

  const loadData = async () => {
    try {
      const data = await getCowpetidores()
      setList(data)
    } catch {
      // fallback
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('cowpetidores', () => {
    loadData()
  })

  const filtered =
    selectedRarity === 'todos' ? list : list.filter((c) => c.rarity === selectedRarity)

  return (
    <section id="cowpetidores" className="py-20 relative bg-[#050807] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <Users className="w-3.5 h-3.5" /> Nosso plantel
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
              Cowpetidores
            </h2>
            <p className="text-zinc-400 max-w-xl text-sm sm:text-base">
              Nosso plantel de cowpetidores em formato de carta de jogo. Cada um tem raridade, nível
              e atributos — de Bezerro a Lenda do Pasto. Clique pra ver a ficha completa.
            </p>
          </div>

          {/* Rarity Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {RARITY_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setSelectedRarity(opt.id)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap transition-all ${
                  selectedRarity === opt.id
                    ? 'bg-emerald-500 text-black shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Cards Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-96 rounded-2xl bg-white/5 animate-pulse" />
            ))}
            <p className="col-span-full text-center text-zinc-500 text-sm pt-2 animate-pulse">
              Ruminando ideias… 🐮
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 bg-[#0B1210] rounded-2xl border border-white/5">
            <p className="text-zinc-400 text-sm">
              Nenhum cowpetidor nesse pasto. Tente outro filtro! 🐮
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filtered.map((item) => (
              <CowpetidorCard
                key={item.id}
                cowpetidor={item}
                onClick={() => setActiveModalMember(item)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {activeModalMember && (
        <CowpetidorModal
          cowpetidor={activeModalMember}
          onClose={() => setActiveModalMember(null)}
        />
      )}
    </section>
  )
}
