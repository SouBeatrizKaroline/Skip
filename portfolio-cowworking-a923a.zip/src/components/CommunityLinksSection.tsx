import { useEffect, useState } from 'react'
import { ArrowRight, Sparkles } from 'lucide-react'
import type { CommunityLink } from '@/types/portfolio'
import { getCommunityLinks } from '@/services/community-links'
import { useRealtime } from '@/hooks/use-realtime'
import { BrandIcon } from '@/components/BrandIcon'

export function CommunityLinksSection() {
  const [links, setLinks] = useState<CommunityLink[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = async () => {
    try {
      const data = await getCommunityLinks()
      setLinks(data)
    } catch {
      // fallback if error
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('community_links', () => {
    loadData()
  })

  return (
    <section id="links" className="py-20 relative bg-[#050807]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            <Sparkles className="w-3.5 h-3.5" /> Nossos canais
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
            Links & Conexões
          </h2>
          <p className="text-zinc-400 max-w-xl mx-auto text-sm sm:text-base">
            Escolha seu portal de entrada no rebanho. Eventos, vagas, times e conteúdo — tudo a um
            clique do pasto.
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-28 rounded-2xl bg-white/5 animate-pulse" />
            ))}
            <p className="col-span-full text-center text-zinc-500 text-sm pt-2 animate-pulse">
              Ruminando ideias… 🐮
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {links.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative p-5 rounded-2xl bg-[#0B1210] border border-white/10 hover:border-emerald-500/40 hover:bg-[#0F1713] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.5),0_0_20px_rgba(34,197,94,0.15)] flex items-start gap-4"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 group-hover:bg-emerald-500 group-hover:text-black group-hover:scale-105 transition-all duration-300 shadow-inner">
                  <BrandIcon icon={link.icon} className="w-6 h-6" />
                </div>

                <div className="flex-1 min-w-0 pr-6">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors truncate">
                      {link.title}
                    </h3>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
                    {link.description}
                  </p>
                </div>

                <div className="absolute top-5 right-5 text-zinc-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all duration-300">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
