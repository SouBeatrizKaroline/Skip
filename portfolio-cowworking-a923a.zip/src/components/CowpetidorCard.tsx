import { Trophy, Laptop } from 'lucide-react'
import type { Cowpetidor, Rarity } from '@/types/portfolio'
import { LEVEL_DISPLAY, RARITY_DISPLAY, getBadges } from '@/lib/cow-theme'

interface CowpetidorCardProps {
  cowpetidor: Cowpetidor
  onClick: () => void
}

const RARITY_STYLES: Record<
  Rarity,
  { border: string; bg: string; badge: string; text: string; glow: string }
> = {
  comum: {
    border: 'border-slate-500/40 hover:border-slate-400',
    bg: 'from-slate-900/80 to-slate-950',
    badge: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
    text: 'text-slate-300',
    glow: 'hover:shadow-[0_0_25px_rgba(148,163,184,0.25)]',
  },
  raro: {
    border: 'border-emerald-500/50 hover:border-emerald-400',
    bg: 'from-emerald-950/60 to-[#0B1210]',
    badge: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
    text: 'text-emerald-400',
    glow: 'hover:shadow-[0_0_30px_rgba(52,211,153,0.3)]',
  },
  epico: {
    border: 'border-cyan-500/60 hover:border-cyan-400',
    bg: 'from-cyan-950/60 to-[#0B1210]',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    text: 'text-cyan-400',
    glow: 'hover:shadow-[0_0_30px_rgba(34,211,238,0.35)]',
  },
  lendario: {
    border: 'border-amber-400/80 hover:border-amber-300',
    bg: 'from-amber-950/70 via-amber-900/30 to-[#0B1210]',
    badge: 'bg-amber-400/20 text-amber-300 border-amber-400/50 font-bold',
    text: 'text-amber-400',
    glow: 'hover:shadow-[0_0_35px_rgba(255,197,61,0.4)]',
  },
}

export function CowpetidorCard({ cowpetidor, onClick }: CowpetidorCardProps) {
  const style = RARITY_STYLES[cowpetidor.rarity] || RARITY_STYLES.comum

  return (
    <div
      onClick={onClick}
      className={`group relative rounded-2xl bg-gradient-to-b ${style.bg} border ${style.border} ${style.glow} p-4 transition-all duration-300 hover:-translate-y-2 cursor-pointer flex flex-col justify-between overflow-hidden shadow-lg select-none`}
    >
      {/* Shiny Sweep Effect */}
      <div className="absolute -inset-full top-0 block bg-gradient-to-r from-transparent via-white/10 to-transparent group-hover:animate-slide-up pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />

      {/* Card Header Info */}
      <div className="relative space-y-3">
        {/* Rarity & Level Badges */}
        <div className="flex items-center justify-between">
          <span
            className={`text-[10px] uppercase tracking-wider px-2.5 py-0.5 rounded-full border font-bold ${style.badge}`}
          >
            {RARITY_DISPLAY[cowpetidor.rarity]?.emoji} {cowpetidor.rarity}
          </span>

          <span className="text-xs px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-zinc-300 font-medium">
            {LEVEL_DISPLAY[cowpetidor.level].emoji} {LEVEL_DISPLAY[cowpetidor.level].label}
          </span>
        </div>

        {/* Avatar Portrait */}
        <div className="relative aspect-square rounded-xl overflow-hidden bg-black/40 border border-white/10">
          <img
            src={cowpetidor.avatar_url || 'https://img.usecurling.com/ppl/large'}
            alt={cowpetidor.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/80 text-black backdrop-blur-md">
              {cowpetidor.specialty}
            </span>
          </div>
        </div>

        {/* Name & Badges */}
        <div className="space-y-1.5">
          <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
            {cowpetidor.name}
          </h3>
          <div className="flex flex-wrap gap-1">
            {getBadges(cowpetidor.wins, cowpetidor.hackathons_count)
              .slice(0, 2)
              .map((badge, i) => (
                <span
                  key={i}
                  className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                >
                  {badge}
                </span>
              ))}
          </div>
        </div>

        {/* Mini Stats */}
        <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-white/10">
          <div className="flex items-center gap-1.5 text-zinc-300">
            <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <strong className="text-white">{cowpetidor.wins}</strong> vitórias
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300">
            <Laptop className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>
              <strong className="text-white">{cowpetidor.hackathons_count}</strong> hckths
            </span>
          </div>
        </div>

        {/* Mini Attribute Bars */}
        <div className="space-y-1.5 pt-1">
          {Object.entries(cowpetidor.attributes || {})
            .slice(0, 3)
            .map(([key, val]) => (
              <div key={key} className="space-y-0.5">
                <div className="flex justify-between text-[10px] text-zinc-400 capitalize">
                  <span>{key}</span>
                  <span>{val}</span>
                </div>
                <div className="h-1 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-lime-400 rounded-full"
                    style={{ width: `${val}%` }}
                  />
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Button Footer */}
      <div className="mt-4 pt-2">
        <div className="w-full py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold text-center uppercase tracking-wider group-hover:bg-emerald-500 group-hover:text-black transition-all">
          Ver Ficha
        </div>
      </div>
    </div>
  )
}
