import { Rocket, Users, Trophy, Award, Target, Zap, Heart } from 'lucide-react'

export function AboutSection() {
  return (
    <section id="sobre" className="py-20 relative bg-[#050807] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <Rocket className="w-3.5 h-3.5" /> Ecowssistema
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display leading-tight">
              O que é a <span className="text-emerald-400">CowWorking</span>?
            </h2>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-bold uppercase tracking-wider">
                <Zap className="w-4 h-4" /> O problema
              </div>
              <p className="text-zinc-300 text-base sm:text-lg leading-relaxed">
                Entrar em hackathons parece impossível: <strong>falta equipe</strong>, falta
                experiência, falta conexão. Você tem a ideia, a vontade e o código — mas não sabe
                por onde começar.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold uppercase tracking-wider">
                <Heart className="w-4 h-4" /> A solução
              </div>
              <p className="text-zinc-300 text-base sm:text-lg leading-relaxed">
                A <strong>CowWorking</strong> é o ecowssistema que conecta competidores, mentores e
                oportunidades. Aqui você encontra parceiros de equipe, participa de desafios reais e
                evolui como atleta digital — do <strong>Bezerro</strong> a{' '}
                <strong>Lenda do Pasto</strong>.
              </p>
              <p className="text-zinc-400 text-sm leading-relaxed">
                <strong>TEI Sports</strong> são competições de Tecnologia, Empreendedorismo e
                Inovação — hackathons, maratonas e desafios onde participantes criam soluções reais
                sob pressão. E ninguém evolui sozinho: aqui o rebanho cresce junto.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              {[
                {
                  icon: Users,
                  title: 'Networking de verdade',
                  desc: 'Conecte-se com devs de topo, designers e pitchmen.',
                },
                {
                  icon: Trophy,
                  title: 'Portfólio real',
                  desc: 'Projetos funcionais criados em maratonas pra mostrar ao mercado.',
                },
                {
                  icon: Award,
                  title: 'Prêmios & visibilidade',
                  desc: 'Premiações em dinheiro, troféus e destaque em grandes bancas.',
                },
                {
                  icon: Target,
                  title: 'Evolução acelerada',
                  desc: '48h de hackathon equivalem a meses de aprendizado.',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-[#0B1210] border border-white/10 hover:border-emerald-500/30 transition-all space-y-2"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                    <item.icon className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-white">{item.title}</h4>
                  <p className="text-xs text-zinc-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative p-8 rounded-3xl bg-gradient-to-b from-[#0F1713] to-[#0B1210] border border-emerald-500/30 shadow-[0_0_50px_rgba(34,197,94,0.15)] space-y-8 text-center">
              <div className="text-6xl">🐮</div>

              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white font-display">
                  Pilares do Ecowssistema
                </h3>
                <p className="text-xs text-zinc-400">
                  Tudo o que você precisa pra dominar maratonas de inovação.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-left">
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="text-emerald-400 font-extrabold text-xl">01. Aprendizado</div>
                  <div className="text-xs text-zinc-400 mt-1">Trilhas Cowwnhecimento</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="text-emerald-400 font-extrabold text-xl">02. Conexão</div>
                  <div className="text-xs text-zinc-400 mt-1">Montar Times Cowwpeões</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="text-emerald-400 font-extrabold text-xl">03. Competição</div>
                  <div className="text-xs text-zinc-400 mt-1">Cowwlendário de Maratonas</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="text-emerald-400 font-extrabold text-xl">04. Carreira</div>
                  <div className="text-xs text-zinc-400 mt-1">Cowwtratação & Vagas</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
