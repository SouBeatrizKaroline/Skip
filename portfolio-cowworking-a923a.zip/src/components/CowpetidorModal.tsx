import { useEffect } from 'react'
import { X, Trophy, Laptop, Percent, CheckCircle2, Circle, ExternalLink, Award } from 'lucide-react'
import type { Cowpetidor } from '@/types/portfolio'
import { Button } from '@/components/ui/button'
import { BrandIcon } from '@/components/BrandIcon'
import { LEVEL_DISPLAY, getBadges } from '@/lib/cow-theme'

interface CowpetidorModalProps {
  cowpetidor: Cowpetidor
  onClose: () => void
}

export function CowpetidorModal({ cowpetidor, onClose }: CowpetidorModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', handleKeyDown)
    return () => {
      document.body.style.overflow = 'unset'
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [onClose])

  const winRate =
    cowpetidor.hackathons_count > 0
      ? Math.round((cowpetidor.wins / cowpetidor.hackathons_count) * 100)
      : 0

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity animate-fade-in"
      />

      {/* Modal Content */}
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#0B1210] border border-emerald-500/30 shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden z-10 animate-fade-in-up my-auto max-h-[90vh] flex flex-col">
        {/* Header Band */}
        <div className="relative p-6 sm:p-8 bg-gradient-to-r from-emerald-950/80 via-[#0F1713] to-slate-900 border-b border-white/10 shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/40 text-zinc-400 hover:text-white hover:bg-black/60 transition-colors z-20"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-emerald-400 shadow-[0_0_20px_rgba(34,197,94,0.4)] shrink-0 bg-black">
              <img
                src={cowpetidor.avatar_url || 'https://img.usecurling.com/ppl/large'}
                alt={cowpetidor.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="text-center sm:text-left space-y-2 flex-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {cowpetidor.rarity}
                </span>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-white/10 text-zinc-300">
                  {LEVEL_DISPLAY[cowpetidor.level].emoji} {LEVEL_DISPLAY[cowpetidor.level].label}
                </span>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500 text-black font-bold">
                  {cowpetidor.specialty}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                {cowpetidor.name}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-lg">
                {cowpetidor.bio}
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto custom-scrollbar">
          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 sm:p-4 rounded-xl bg-white/5 border border-white/10 text-center">
              <Laptop className="w-5 h-5 mx-auto text-emerald-400 mb-1" />
              <div className="text-lg sm:text-2xl font-black text-white">
                {cowpetidor.hackathons_count}
              </div>
              <div className="text-[10px] sm:text-xs text-zinc-400 uppercase font-semibold">
                Hackathons
              </div>
            </div>

            <div className="p-3 sm:p-4 rounded-xl bg-white/5 border border-white/10 text-center">
              <Trophy className="w-5 h-5 mx-auto text-amber-400 mb-1" />
              <div className="text-lg sm:text-2xl font-black text-white">{cowpetidor.wins}</div>
              <div className="text-[10px] sm:text-xs text-zinc-400 uppercase font-semibold">
                Vitórias
              </div>
            </div>

            <div className="p-3 sm:p-4 rounded-xl bg-white/5 border border-white/10 text-center">
              <Percent className="w-5 h-5 mx-auto text-cyan-400 mb-1" />
              <div className="text-lg sm:text-2xl font-black text-white">{winRate}%</div>
              <div className="text-[10px] sm:text-xs text-zinc-400 uppercase font-semibold">
                Taxa Vitória
              </div>
            </div>
          </div>

          {/* Badges */}
          {getBadges(cowpetidor.wins, cowpetidor.hackathons_count).length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" /> Badges & Conquistas
              </h3>
              <div className="flex flex-wrap gap-2">
                {getBadges(cowpetidor.wins, cowpetidor.hackathons_count).map((badge, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold"
                  >
                    {badge}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Atributos */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Atributos Técnicos & Comportamentais
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Object.entries(cowpetidor.attributes || {}).map(([key, val]) => (
                <div
                  key={key}
                  className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5"
                >
                  <div className="flex justify-between text-xs font-semibold text-zinc-300 capitalize">
                    <span>{key}</span>
                    <span className="text-emerald-400">{val}/100</span>
                  </div>
                  <div className="h-2 rounded-full bg-black/50 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-lime-400 rounded-full transition-all duration-1000"
                      style={{ width: `${val}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills */}
          {cowpetidor.skills && cowpetidor.skills.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Habilidades</h3>
              <div className="flex flex-wrap gap-2">
                {cowpetidor.skills.map((skill, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Histórico */}
          {cowpetidor.history && cowpetidor.history.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Histórico de Maratonas
              </h3>
              <div className="space-y-2">
                {cowpetidor.history.map((item, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl bg-white/5 border-l-4 flex items-center justify-between text-xs gap-3 ${
                      item.venceu ? 'border-l-emerald-500 bg-emerald-500/5' : 'border-l-zinc-600'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-white text-sm">{item.competicao}</div>
                      <div className="text-zinc-400 text-[11px] mt-0.5">
                        {item.data} • Tema: {item.tema} • Função: {item.funcao}
                      </div>
                    </div>
                    <div>
                      {item.venceu ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                          <CheckCircle2 className="w-3 h-3" /> Venceu
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-800 text-zinc-400 font-medium text-[10px]">
                          <Circle className="w-3 h-3" /> Participou
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contatos */}
          {cowpetidor.contacts && Object.keys(cowpetidor.contacts).length > 0 && (
            <div className="pt-2 border-t border-white/10 space-y-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Contatos do Cowpetidor
              </h3>
              <div className="flex flex-wrap gap-2">
                {Object.entries(cowpetidor.contacts).map(([key, val]) => (
                  <Button
                    key={key}
                    asChild
                    variant="outline"
                    size="sm"
                    className="rounded-xl border-white/10 bg-white/5 hover:border-emerald-400 hover:text-emerald-400 text-xs gap-2"
                  >
                    <a
                      href={key === 'email' ? `mailto:${val}` : val}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <BrandIcon icon={key} className="w-4 h-4" />
                      <span className="capitalize">{key}</span>
                      <ExternalLink className="w-3 h-3 opacity-60" />
                    </a>
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
