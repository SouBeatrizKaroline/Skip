import { useEffect, useState } from 'react'
import { Trophy, Calendar, Medal, CheckCircle, Clock, Zap } from 'lucide-react'
import type { Competition, CompetitionStatus } from '@/types/portfolio'
import { getCompetitions } from '@/services/competitions'
import { useRealtime } from '@/hooks/use-realtime'

const STATUS_FILTERS: { id: CompetitionStatus | 'todas'; label: string }[] = [
  { id: 'todas', label: 'Todas' },
  { id: 'acontecendo', label: 'Ao Vivo ⚡' },
  { id: 'em_breve', label: 'Em breve ⏳' },
  { id: 'encerrada', label: 'Encerradas 🏆' },
]

export function CompetitionsSection() {
  const [competitions, setCompetitions] = useState<Competition[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedStatus, setSelectedStatus] = useState<CompetitionStatus | 'todas'>('todas')

  const loadData = async () => {
    try {
      const data = await getCompetitions()
      setCompetitions(data)
    } catch {
      // fallback
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('competitions', () => {
    loadData()
  })

  const filtered =
    selectedStatus === 'todas'
      ? competitions
      : competitions.filter((c) => c.status === selectedStatus)

  return (
    <section id="competicoes" className="py-20 relative bg-[#050807]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <Trophy className="w-3.5 h-3.5" /> Histórico de batalhas
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
              Cowmpetições & Maratonas
            </h2>
            <p className="text-zinc-400 max-w-xl text-sm sm:text-base">
              Acompanhe nosso Cowwlendário de maratonas, veja os pódios das edições passadas e
              prepare seu time pra próxima batalha.
            </p>
          </div>

          {/* Status Filters */}
          <div className="flex items-center gap-2">
            {STATUS_FILTERS.map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedStatus(f.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-full transition-all ${
                  selectedStatus === f.id
                    ? 'bg-emerald-500 text-black shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-32 rounded-2xl bg-white/5 animate-pulse" />
            ))}
            <p className="text-center text-zinc-500 text-sm pt-2 animate-pulse">
              Ruminando ideias… 🐮
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 bg-[#0B1210] rounded-2xl border border-white/5">
            <p className="text-zinc-400 text-sm">
              Nenhuma cowmpetição encontrada nesta categoria. 🐮
            </p>
          </div>
        ) : (
          <div className="space-y-6 relative before:absolute before:left-4 md:before:left-1/2 before:top-0 before:bottom-0 before:w-0.5 before:bg-white/10">
            {filtered.map((comp, idx) => {
              const isEven = idx % 2 === 0
              const dateObj = new Date(comp.date)
              const formattedDate = dateObj.toLocaleDateString('pt-BR', {
                month: 'short',
                year: 'numeric',
              })

              return (
                <div
                  key={comp.id}
                  className={`relative flex flex-col md:flex-row items-start ${
                    isEven ? 'md:flex-row-reverse' : ''
                  } gap-8`}
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-4 md:left-1/2 -translate-x-1/2 top-6 w-5 h-5 rounded-full bg-emerald-500 border-4 border-[#050807] shadow-[0_0_15px_rgba(34,197,94,0.8)] z-10" />

                  {/* Card Container */}
                  <div className="pl-12 md:pl-0 md:w-1/2 w-full">
                    <div className="p-6 rounded-2xl bg-[#0B1210] border border-white/10 hover:border-emerald-500/40 transition-all duration-300 hover:shadow-[0_10px_30px_rgba(0,0,0,0.5)] space-y-4">
                      {/* Top status */}
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                          <Calendar className="w-3.5 h-3.5" /> {formattedDate}
                        </span>

                        {comp.status === 'acontecendo' && (
                          <span className="animate-pulse inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold">
                            <Zap className="w-3.5 h-3.5 fill-amber-300" /> Ao Vivo
                          </span>
                        )}
                        {comp.status === 'em_breve' && (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-semibold">
                            <Clock className="w-3.5 h-3.5" /> Em Breve
                          </span>
                        )}
                        {comp.status === 'encerrada' && (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-800 text-zinc-400 border border-white/10 text-xs font-medium">
                            <CheckCircle className="w-3.5 h-3.5" /> Encerrada
                          </span>
                        )}
                      </div>

                      {/* Header */}
                      <div>
                        <h3 className="text-xl font-bold text-white font-display">{comp.name}</h3>
                        <p className="text-xs text-emerald-400 font-semibold mt-1">
                          Tema: {comp.theme}
                        </p>
                      </div>

                      {comp.description && (
                        <p className="text-xs text-zinc-400 leading-relaxed">{comp.description}</p>
                      )}

                      {/* Podium */}
                      {comp.podium && comp.podium.length > 0 && (
                        <div className="pt-3 border-t border-white/10 space-y-2">
                          <div className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                            <Medal className="w-4 h-4 text-amber-400" /> Pódio da Edição
                          </div>

                          <div className="space-y-1.5">
                            {comp.podium.map((pod) => (
                              <div
                                key={pod.posicao}
                                className="flex items-center justify-between text-xs p-2 rounded-lg bg-white/5 border border-white/5"
                              >
                                <div className="flex items-center gap-2">
                                  <span className="text-base">
                                    {pod.posicao === 1 ? '🥇' : pod.posicao === 2 ? '🥈' : '🥉'}
                                  </span>
                                  <span className="font-bold text-white">{pod.time}</span>
                                </div>
                                <span className="text-[11px] text-zinc-400 truncate max-w-[200px]">
                                  {pod.membros.join(', ')}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </section>
  )
}
