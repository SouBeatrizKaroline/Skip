import { useEffect, useState } from 'react'
import { Camera, ZoomIn } from 'lucide-react'
import type { GalleryItem, GalleryTag } from '@/types/portfolio'
import { getGallery } from '@/services/gallery'
import { useRealtime } from '@/hooks/use-realtime'
import { GalleryLightbox } from '@/components/GalleryLightbox'

const TAG_OPTIONS: { id: GalleryTag | 'todas'; label: string }[] = [
  { id: 'todas', label: 'Todas' },
  { id: 'hackathon', label: 'Hackathons' },
  { id: 'encontro', label: 'Encontros' },
  { id: 'bootcamp', label: 'Bootcamps' },
  { id: 'social', label: 'Social' },
]

export function GallerySection() {
  const [items, setItems] = useState<GalleryItem[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTag, setSelectedTag] = useState<GalleryTag | 'todas'>('todas')
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)

  const loadData = async () => {
    try {
      const data = await getGallery()
      setItems(data)
    } catch {
      // fallback
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  useRealtime('gallery', () => {
    loadData()
  })

  const filtered = selectedTag === 'todas' ? items : items.filter((i) => i.tag === selectedTag)

  return (
    <section id="galeria" className="py-20 relative bg-[#050807] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <Camera className="w-3.5 h-3.5" /> Momentos
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
              Galeria da Comunidade
            </h2>
            <p className="text-zinc-400 max-w-xl text-sm sm:text-base">
              Registros dos nossos encontros, hackathons madrugadas adentro e comemorações no palco.
              Momentos que fazem o rebanho crescer junto.
            </p>
          </div>

          {/* Tags */}
          <div className="flex items-center gap-2">
            {TAG_OPTIONS.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedTag(t.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-full transition-all ${
                  selectedTag === t.id
                    ? 'bg-emerald-500 text-black shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-60 rounded-2xl bg-white/5 animate-pulse" />
            ))}
            <p className="col-span-full text-center text-zinc-500 text-sm pt-2 animate-pulse">
              Ruminando ideias… 🐮
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 bg-[#0B1210] rounded-2xl border border-white/5">
            <p className="text-zinc-400 text-sm">
              Nenhuma foto neste pasto. Tente outra categoria! 🐮
            </p>
          </div>
        ) : (
          <div className="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
            {filtered.map((item, idx) => (
              <div
                key={item.id}
                onClick={() => setLightboxIndex(idx)}
                className="group relative rounded-2xl overflow-hidden bg-black/40 border border-white/10 cursor-pointer break-inside-avoid shadow-lg hover:border-emerald-500/50 transition-all duration-300"
              >
                <img
                  src={item.image_url}
                  alt={item.caption}
                  className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-bold uppercase px-2.5 py-1 rounded-full bg-emerald-500 text-black">
                      {item.tag}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center">
                      <ZoomIn className="w-4 h-4" />
                    </div>
                  </div>

                  <p className="text-xs text-white font-medium line-clamp-2">{item.caption}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {lightboxIndex !== null && (
        <GalleryLightbox
          items={filtered}
          currentIndex={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
          onNavigate={(newIdx) => setLightboxIndex(newIdx)}
        />
      )}
    </section>
  )
}
