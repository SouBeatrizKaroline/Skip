import { ExternalLink, Trophy, ArrowDown } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden"
    >
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#16a34a0a_1px,transparent_1px),linear-gradient(to_bottom,#16a34a0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-10 w-[400px] h-[400px] bg-lime-500/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="absolute top-28 left-[10%] text-2xl animate-float pointer-events-none hidden md:block">
        🐮
      </div>
      <div className="absolute top-40 right-[12%] text-2xl animate-float [animation-delay:1s] pointer-events-none hidden md:block">
        ⚡
      </div>
      <div className="absolute bottom-32 left-[15%] text-2xl animate-float [animation-delay:2s] pointer-events-none hidden md:block">
        🏆
      </div>
      <div className="absolute bottom-40 right-[18%] text-2xl animate-float [animation-delay:3s] pointer-events-none hidden md:block">
        ✦
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center relative z-10 space-y-8">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm font-semibold tracking-wide uppercase shadow-[0_0_15px_rgba(34,197,94,0.15)] animate-fade-in-down">
          <span>🐮</span>
          <span>O rebanho #1 de TEI Sports do Brasil</span>
        </div>

        <div className="space-y-4 animate-fade-in-up">
          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-extrabold tracking-tight font-display text-white">
            Cow
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-lime-300 to-emerald-500 drop-shadow-[0_0_30px_rgba(34,197,94,0.4)]">
              Working
            </span>
            <span className="inline-block animate-float ml-3">🐮</span>
          </h1>
          <p className="text-2xl sm:text-3xl lg:text-4xl font-bold text-zinc-100 tracking-tight">
            A maior cowwmunidade de TEI Sports do Brasil
          </p>
        </div>

        <p className="max-w-2xl mx-auto text-base sm:text-lg text-zinc-400 leading-relaxed font-normal">
          Já tentou entrar num hackathon e não achou equipe? A gente sabe como é. A CowWorking é o
          ecowssistema onde cowpetidores se encontram, times se formam e ideias saem do pasto pra
          virar solução — em 48 horas de pura inovação.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <Button
            asChild
            size="lg"
            className="w-full sm:w-auto h-14 px-8 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-extrabold text-base shadow-[0_0_25px_rgba(34,197,94,0.4)] hover:shadow-[0_0_35px_rgba(74,222,128,0.6)] transition-all duration-300 active:scale-98"
          >
            <a href="https://linktr.ee/cowworking" target="_blank" rel="noopener noreferrer">
              Entre pro rebanho <ExternalLink className="w-5 h-5 ml-2" />
            </a>
          </Button>

          <Button
            variant="outline"
            size="lg"
            onClick={() => scrollToSection('competicoes')}
            className="w-full sm:w-auto h-14 px-8 rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-emerald-400 text-white font-bold text-base transition-all duration-300"
          >
            <Trophy className="w-5 h-5 mr-2 text-emerald-400" />
            Ver cowmpetições
          </Button>
        </div>

        <div className="pt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
          {[
            { label: 'Maratonas realizadas', value: '50+' },
            { label: 'Cowpetidores ativos', value: '2.000+' },
            { label: 'Conquistados em prêmios', value: 'R$ 100k+' },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-[#0B1210]/80 border border-emerald-500/20 backdrop-blur-md hover:border-emerald-500/40 transition-all"
            >
              <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-emerald-400 font-display">
                {stat.value}
              </div>
              <div className="text-xs text-zinc-400 mt-1 uppercase tracking-wider font-semibold">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        <div className="pt-8">
          <button
            onClick={() => scrollToSection('sobre')}
            className="inline-flex flex-col items-center gap-2 text-zinc-500 hover:text-emerald-400 transition-colors animate-bounce"
            aria-label="Rolar para baixo"
          >
            <span className="text-xs font-semibold uppercase tracking-widest">
              Explorar o pasto
            </span>
            <ArrowDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  )
}
