import { useLocation, Link } from 'react-router-dom'
import { useEffect } from 'react'
import { ArrowLeft } from 'lucide-react'

const NotFound = () => {
  const location = useLocation()

  useEffect(() => {
    console.error('404 Error: User attempted to access non-existent route:', location.pathname)
  }, [location.pathname])

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050807] px-4">
      <div className="text-center space-y-6">
        <div className="text-7xl">🐄💨</div>
        <h1 className="text-6xl font-extrabold text-white font-display">404</h1>
        <p className="text-xl text-zinc-300 font-semibold">Essa página fugiu do pasto!</p>
        <p className="text-zinc-500 text-sm max-w-md mx-auto">
          A URL que você buscou não existe no nosso ecowssistema. Talvez ela tenha sido ruminada por
          algum cowpetidor curioso…
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black font-bold transition-all duration-300 shadow-[0_0_20px_rgba(34,197,94,0.3)]"
        >
          <ArrowLeft className="w-4 h-4" /> Voltar pro pasto
        </Link>
      </div>
    </div>
  )
}

export default NotFound
