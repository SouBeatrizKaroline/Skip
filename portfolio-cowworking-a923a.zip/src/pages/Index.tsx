import { HeroSection } from '@/components/HeroSection'
import { AboutSection } from '@/components/AboutSection'
import { HowItWorksSection } from '@/components/HowItWorksSection'
import { CommunityLinksSection } from '@/components/CommunityLinksSection'
import { CowpetidoresSection } from '@/components/CowpetidoresSection'
import { CompetitionsSection } from '@/components/CompetitionsSection'
import { GallerySection } from '@/components/GallerySection'
import { DifferentialsSection } from '@/components/DifferentialsSection'
import { CtaSection } from '@/components/CtaSection'

export default function Index() {
  return (
    <div className="space-y-0">
      <HeroSection />
      <AboutSection />
      <HowItWorksSection />
      <CommunityLinksSection />
      <CowpetidoresSection />
      <CompetitionsSection />
      <GallerySection />
      <DifferentialsSection />
      <CtaSection />
    </div>
  )
}
