export type Rarity = 'comum' | 'raro' | 'epico' | 'lendario'
export type Level = 'iniciante' | 'pro' | 'elite'
export type Specialty = 'UX' | 'Dev' | 'Pitch' | 'Data' | 'Design' | 'Estratégia' | 'IA'

export interface CowpetidorAttributes {
  criatividade: number
  tecnica: number
  equipe: number
  estrategia: number
}

export interface CompetitionHistoryItem {
  competicao: string
  data: string
  tema: string
  venceu: boolean
  funcao: string
}

export interface Contacts {
  linkedin?: string
  github?: string
  instagram?: string
  email?: string
}

export interface Cowpetidor {
  id: string
  name: string
  slug: string
  avatar_url?: string
  hackathons_count: number
  wins: number
  specialty: Specialty
  level: Level
  rarity: Rarity
  bio: string
  skills: string[]
  attributes: CowpetidorAttributes
  history: CompetitionHistoryItem[]
  contacts?: Contacts
  featured?: boolean
}

export type CompetitionStatus = 'encerrada' | 'em_breve' | 'acontecendo'

export interface PodiumMember {
  posicao: number
  time: string
  membros: string[]
}

export interface Competition {
  id: string
  name: string
  date: string
  theme: string
  status: CompetitionStatus
  description?: string
  podium?: PodiumMember[]
  featured?: boolean
}

export type GalleryTag = 'hackathon' | 'encontro' | 'bootcamp' | 'social'

export interface GalleryItem {
  id: string
  image_url: string
  caption: string
  tag: GalleryTag
}

export type LinkCategory = 'comunidade' | 'conteudo' | 'carreira'

export interface CommunityLink {
  id: string
  title: string
  description: string
  url: string
  icon: string
  category: LinkCategory
  sort_order: number
}
