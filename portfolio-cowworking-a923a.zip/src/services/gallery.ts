import pb from '@/lib/pocketbase/client'
import type { GalleryItem } from '@/types/portfolio'

export async function getGallery(): Promise<GalleryItem[]> {
  const records = await pb.collection('gallery').getFullList<GalleryItem>({
    sort: '-created',
  })
  return records
}
