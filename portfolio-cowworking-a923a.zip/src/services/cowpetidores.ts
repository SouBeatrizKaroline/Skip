import pb from '@/lib/pocketbase/client'
import type { Cowpetidor } from '@/types/portfolio'

export async function getCowpetidores(): Promise<Cowpetidor[]> {
  const records = await pb.collection('cowpetidores').getFullList<Cowpetidor>({
    sort: '-wins,-hackathons_count',
  })
  return records
}

export async function getCowpetidorBySlug(slug: string): Promise<Cowpetidor | null> {
  try {
    return await pb.collection('cowpetidores').getFirstListItem<Cowpetidor>(`slug="${slug}"`)
  } catch {
    return null
  }
}
