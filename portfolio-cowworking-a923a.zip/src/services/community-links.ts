import pb from '@/lib/pocketbase/client'
import type { CommunityLink } from '@/types/portfolio'

export async function getCommunityLinks(): Promise<CommunityLink[]> {
  const records = await pb.collection('community_links').getFullList<CommunityLink>({
    sort: 'sort_order',
  })
  return records
}
