import pb from '@/lib/pocketbase/client'
import type { Competition } from '@/types/portfolio'

export async function getCompetitions(): Promise<Competition[]> {
  const records = await pb.collection('competitions').getFullList<Competition>({
    sort: '-date',
  })
  return records
}
