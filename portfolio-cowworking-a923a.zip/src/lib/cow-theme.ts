import type { Level, Rarity } from '@/types/portfolio'

export const LEVEL_DISPLAY: Record<Level, { label: string; emoji: string; desc: string }> = {
  iniciante: { label: 'Bezerro', emoji: '🐂', desc: 'Recém-chegado ao pasto' },
  pro: { label: 'Touro Pro', emoji: '🐃', desc: 'Veterano de maratonas' },
  elite: { label: 'Lenda do Pasto', emoji: '👑', desc: 'Campeão consagrado' },
}

export const RARITY_DISPLAY: Record<Rarity, { label: string; emoji: string }> = {
  comum: { label: 'Comum', emoji: '🐮' },
  raro: { label: 'Raro', emoji: '⚡' },
  epico: { label: 'Épico', emoji: '💎' },
  lendario: { label: 'Lendário', emoji: '👑' },
}

export function getBadges(wins: number, hackathonsCount: number): string[] {
  const badges: string[] = []
  if (wins >= 10) badges.push('Cowpeão 👑')
  if (wins >= 5) badges.push('HackaTouro 🏆')
  if (hackathonsCount >= 15) badges.push('Maratonista 🏅')
  if (hackathonsCount >= 5 && wins >= 1) badges.push('Estrela em Ascensão ⭐')
  if (wins === 0 && hackathonsCount >= 3) badges.push('Persistente 💪')
  return badges
}
