migrate(
  (app) => {
    // Seed admin user
    try {
      app.findAuthRecordByEmail('_pb_users_auth_', '1aspiraqualquer@gmail.com')
    } catch (_) {
      const usersCol = app.findCollectionByNameOrId('_pb_users_auth_')
      const userRec = new Record(usersCol)
      userRec.setEmail('1aspiraqualquer@gmail.com')
      userRec.setPassword('Skip@Pass')
      userRec.setVerified(true)
      userRec.set('name', 'Admin CowWorking')
      app.save(userRec)
    }

    // Seed Links
    const linksCol = app.findCollectionByNameOrId('community_links')
    const linksData = [
      {
        title: 'Link da bio',
        description: 'Todos os nossos links em um só lugar',
        url: 'https://linktr.ee/cowworking',
        icon: 'linktree',
        category: 'comunidade',
        sort_order: 1,
      },
      {
        title: 'WhatsApp Canal',
        description: 'Novidades e programação da comunidade',
        url: 'https://whatsapp.com/channel/cowworking',
        icon: 'whatsapp',
        category: 'comunidade',
        sort_order: 2,
      },
      {
        title: 'Grupo VIP',
        description: 'Networking com os cowpetidores mais ativos',
        url: 'https://chat.whatsapp.com/cowworkingvip',
        icon: 'vip',
        category: 'comunidade',
        sort_order: 3,
      },
      {
        title: 'Cowwlendário (maratonas)',
        description: 'Maratonas, hackathons e eventos da comunidade',
        url: 'https://cowworking.com.br/calendario',
        icon: 'calendar',
        category: 'conteudo',
        sort_order: 4,
      },
      {
        title: 'Cowwnhecimento (conteúdos e oportunidades)',
        description: 'Conteúdos e oportunidades para evoluir',
        url: 'https://cowworking.com.br/conhecimento',
        icon: 'knowledge',
        category: 'conteudo',
        sort_order: 5,
      },
      {
        title: 'Montar times Cowwpeões',
        description: 'Monte ou entre em um time campeão',
        url: 'https://cowworking.com.br/times',
        icon: 'teams',
        category: 'conteudo',
        sort_order: 6,
      },
      {
        title: 'Cowwtratação (empregos)',
        description: 'Vagas e oportunidades de trabalho',
        url: 'https://cowworking.com.br/vagas',
        icon: 'jobs',
        category: 'carreira',
        sort_order: 7,
      },
      {
        title: 'LinkedIn',
        description: 'Nossa rede profissional',
        url: 'https://linkedin.com/company/cowworking',
        icon: 'linkedin',
        category: 'carreira',
        sort_order: 8,
      },
      {
        title: 'Instagram',
        description: 'Cenas dos bastidores e eventos',
        url: 'https://instagram.com/cowworking',
        icon: 'instagram',
        category: 'carreira',
        sort_order: 9,
      },
      {
        title: 'Discord',
        description: 'O point oficial da comunidade',
        url: 'https://discord.gg/cowworking',
        icon: 'discord',
        category: 'comunidade',
        sort_order: 10,
      },
    ]

    linksData.forEach((item) => {
      try {
        app.findFirstRecordByData('community_links', 'title', item.title)
      } catch (_) {
        const rec = new Record(linksCol)
        rec.set('title', item.title)
        rec.set('description', item.description)
        rec.set('url', item.url)
        rec.set('icon', item.icon)
        rec.set('category', item.category)
        rec.set('sort_order', item.sort_order)
        app.save(rec)
      }
    })

    // Seed Cowpetidores
    const cowCol = app.findCollectionByNameOrId('cowpetidores')
    const cowData = [
      {
        name: 'Ana "Vaca Elétrica" Souza',
        slug: 'ana-souza',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=female&seed=101',
        hackathons_count: 18,
        wins: 8,
        specialty: 'Data',
        level: 'elite',
        rarity: 'lendario',
        bio: 'Especialista em Machine Learning e engenharia de dados. Líder nata e estrategista de soluções de alto impacto.',
        skills: ['Python', 'PyTorch', 'SQL', 'Big Data', 'PowerBI'],
        attributes: { criatividade: 88, tecnica: 98, equipe: 92, estrategia: 95 },
        history: [
          {
            competicao: 'CowHack IA 2025',
            data: 'Jan 2025',
            tema: 'IA Generativa',
            venceu: true,
            funcao: 'Data Scientist',
          },
          {
            competicao: 'Maratona AgroTech 2024',
            data: 'Set 2024',
            tema: 'Agrotech',
            venceu: true,
            funcao: 'ML Engineer',
          },
          {
            competicao: 'Game Jam da Vaca 2024',
            data: 'Jun 2024',
            tema: 'GameDev',
            venceu: false,
            funcao: 'Data Analyst',
          },
        ],
        contacts: {
          linkedin: 'https://linkedin.com/in/anasouza-data',
          github: 'https://github.com/anasouza',
          instagram: 'https://instagram.com/ana.data',
          email: 'ana@cowworking.br',
        },
        featured: true,
      },
      {
        name: 'Bruno "BugZero" Lima',
        slug: 'bruno-lima',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=male&seed=202',
        hackathons_count: 12,
        wins: 4,
        specialty: 'Dev',
        level: 'pro',
        rarity: 'raro',
        bio: 'Fullstack dev acelerado. Escreve código limpo e funcional em ritmo de maratona de 48 horas.',
        skills: ['React', 'TypeScript', 'Node.js', 'TailwindCSS', 'Docker'],
        attributes: { criatividade: 80, tecnica: 92, equipe: 85, estrategia: 78 },
        history: [
          {
            competicao: 'Hackathon CowWorking #1',
            data: 'Mar 2024',
            tema: 'Educação Tech',
            venceu: true,
            funcao: 'Lead Fullstack',
          },
          {
            competicao: 'CowHack IA 2025',
            data: 'Jan 2025',
            tema: 'IA Generativa',
            venceu: false,
            funcao: 'Frontend Dev',
          },
        ],
        contacts: {
          linkedin: 'https://linkedin.com/in/brunolima-dev',
          github: 'https://github.com/brunolima',
        },
        featured: true,
      },
      {
        name: 'Carla "Pixel" Mendes',
        slug: 'carla-mendes',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=female&seed=303',
        hackathons_count: 9,
        wins: 3,
        specialty: 'UX',
        level: 'pro',
        rarity: 'raro',
        bio: 'Designer de produto focada em prototipagem ultra-rápida, testes com usuários e pitchs visuais marcantes.',
        skills: ['Figma', 'UI/UX', 'Prototipagem', 'User Research', 'Design System'],
        attributes: { criatividade: 95, tecnica: 75, equipe: 90, estrategia: 82 },
        history: [
          {
            competicao: 'Maratona FinTech 2025',
            data: 'Mar 2025',
            tema: 'FinTech',
            venceu: false,
            funcao: 'Lead Designer',
          },
          {
            competicao: 'Maratona AgroTech 2024',
            data: 'Set 2024',
            tema: 'Agrotech',
            venceu: true,
            funcao: 'Product Designer',
          },
        ],
        contacts: {
          linkedin: 'https://linkedin.com/in/carlamendes-ux',
          instagram: 'https://instagram.com/carla.pixel',
        },
        featured: false,
      },
      {
        name: 'Diego "Pitch" Farias',
        slug: 'diego-farias',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=male&seed=404',
        hackathons_count: 15,
        wins: 6,
        specialty: 'Pitch',
        level: 'elite',
        rarity: 'epico',
        bio: 'Mestre da oratória e modelagem de negócios. Transforma ideias complexas em apresentações de 3 minutos campeãs.',
        skills: ['Storytelling', 'Modelo de Negócios', 'Pitch Deck', 'Financial Model', 'Growth'],
        attributes: { criatividade: 90, tecnica: 70, equipe: 96, estrategia: 94 },
        history: [
          {
            competicao: 'Hackathon CowWorking #1',
            data: 'Mar 2024',
            tema: 'Educação Tech',
            venceu: true,
            funcao: 'Hustler / Pitchman',
          },
          {
            competicao: 'CowHack IA 2025',
            data: 'Jan 2025',
            tema: 'IA Generativa',
            venceu: true,
            funcao: 'Business Strategist',
          },
        ],
        contacts: {
          linkedin: 'https://linkedin.com/in/diegofarias-pitch',
          instagram: 'https://instagram.com/diegopitch',
        },
        featured: true,
      },
      {
        name: 'Marina "Byte" Rocha',
        slug: 'marina-rocha',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=female&seed=505',
        hackathons_count: 14,
        wins: 5,
        specialty: 'IA',
        level: 'elite',
        rarity: 'epico',
        bio: 'Pesquisadora de Inteligência Artificial Generativa e Agentes autônomos. Especialista em integrar LLMs em produtos.',
        skills: ['LLMs', 'LangChain', 'Python', 'Vector DBs', 'FastAPI'],
        attributes: { criatividade: 87, tecnica: 96, equipe: 82, estrategia: 88 },
        history: [
          {
            competicao: 'CowHack IA 2025',
            data: 'Jan 2025',
            tema: 'IA Generativa',
            venceu: true,
            funcao: 'AI Engineer',
          },
        ],
        contacts: {
          github: 'https://github.com/marinabyte',
          linkedin: 'https://linkedin.com/in/marinarocha-ai',
        },
        featured: true,
      },
      {
        name: 'Rafael "Tática" Nunes',
        slug: 'rafael-nunes',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=male&seed=606',
        hackathons_count: 8,
        wins: 2,
        specialty: 'Estratégia',
        level: 'pro',
        rarity: 'raro',
        bio: 'Orquestrador de cronograma e validação de mercado. Garante que o MVP atenda às regras de negócio da banca.',
        skills: ['Product Management', 'Scrum', 'Validation', 'KPIs'],
        attributes: { criatividade: 75, tecnica: 80, equipe: 91, estrategia: 93 },
        history: [
          {
            competicao: 'Game Jam da Vaca 2024',
            data: 'Jun 2024',
            tema: 'GameDev',
            venceu: true,
            funcao: 'Project Manager',
          },
        ],
        contacts: { linkedin: 'https://linkedin.com/in/rafaelnunes-pm' },
        featured: false,
      },
      {
        name: 'Julia "Spark" Alves',
        slug: 'julia-alves',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=female&seed=707',
        hackathons_count: 4,
        wins: 1,
        specialty: 'Dev',
        level: 'iniciante',
        rarity: 'comum',
        bio: 'Desenvolvedora Frontend promissora. Focada em criar interfaces bonitas, responsivas e acessíveis rapidamente.',
        skills: ['React', 'HTML/CSS', 'JavaScript', 'Git'],
        attributes: { criatividade: 82, tecnica: 70, equipe: 88, estrategia: 68 },
        history: [
          {
            competicao: 'Maratona FinTech 2025',
            data: 'Mar 2025',
            tema: 'FinTech',
            venceu: true,
            funcao: 'Frontend Developer',
          },
        ],
        contacts: { github: 'https://github.com/juliaspark' },
        featured: false,
      },
      {
        name: 'Pedro "Root" Carvalho',
        slug: 'pedro-carvalho',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=male&seed=808',
        hackathons_count: 3,
        wins: 0,
        specialty: 'Data',
        level: 'iniciante',
        rarity: 'comum',
        bio: 'Entusiasta de dados e backend. Aprende rápido sob pressão e tem grande energia em maratonas noturnas.',
        skills: ['Python', 'Pandas', 'PostgreSQL', 'Linux'],
        attributes: { criatividade: 68, tecnica: 74, equipe: 84, estrategia: 65 },
        history: [
          {
            competicao: 'Maratona FinTech 2025',
            data: 'Mar 2025',
            tema: 'FinTech',
            venceu: false,
            funcao: 'Backend Jr',
          },
        ],
        contacts: { github: 'https://github.com/pedroroot' },
        featured: false,
      },
      {
        name: 'Sofia "Cowmando" Ribeiro',
        slug: 'sofia-ribeiro',
        avatar_url: 'https://img.usecurling.com/ppl/large?gender=female&seed=909',
        hackathons_count: 22,
        wins: 10,
        specialty: 'Pitch',
        level: 'elite',
        rarity: 'lendario',
        bio: 'Veterana e fundadora de 2 startups nascidas em hackathons. Mentora e campeã em mais de 10 maratonas nacionais.',
        skills: ['Venture Building', 'Fundraising', 'Pitch', 'Product Strategy', 'Leadership'],
        attributes: { criatividade: 94, tecnica: 85, equipe: 98, estrategia: 99 },
        history: [
          {
            competicao: 'Maratona AgroTech 2024',
            data: 'Set 2024',
            tema: 'Agrotech',
            venceu: true,
            funcao: 'Captain & Pitch',
          },
          {
            competicao: 'Hackathon CowWorking #1',
            data: 'Mar 2024',
            tema: 'Educação Tech',
            venceu: true,
            funcao: 'CEO & Presenter',
          },
        ],
        contacts: {
          linkedin: 'https://linkedin.com/in/sofiaribeiro-ceo',
          instagram: 'https://instagram.com/sofiacowmando',
        },
        featured: true,
      },
    ]

    cowData.forEach((item) => {
      try {
        app.findFirstRecordByData('cowpetidores', 'slug', item.slug)
      } catch (_) {
        const rec = new Record(cowCol)
        rec.set('name', item.name)
        rec.set('slug', item.slug)
        rec.set('avatar_url', item.avatar_url)
        rec.set('hackathons_count', item.hackathons_count)
        rec.set('wins', item.wins)
        rec.set('specialty', item.specialty)
        rec.set('level', item.level)
        rec.set('rarity', item.rarity)
        rec.set('bio', item.bio)
        rec.set('skills', item.skills)
        rec.set('attributes', item.attributes)
        rec.set('history', item.history)
        rec.set('contacts', item.contacts)
        rec.set('featured', item.featured)
        app.save(rec)
      }
    })

    // Seed Competitions
    const compCol = app.findCollectionByNameOrId('competitions')
    const compData = [
      {
        name: 'Hackathon CowWorking #1 — Soluções para Educação',
        date: '2024-03-15 00:00:00.000Z',
        theme: 'Educação Tech',
        status: 'encerrada',
        description:
          'Desafio de 48h para criar plataformas de aprendizagem gamificada e inclusão escolar.',
        podium: [
          {
            posicao: 1,
            time: 'EduCow',
            membros: ['Sofia "Cowmando" Ribeiro', 'Bruno "BugZero" Lima', 'Diego "Pitch" Farias'],
          },
          { posicao: 2, time: 'MooAcademy', membros: ['Carla Mendes', 'Rafael Nunes'] },
          { posicao: 3, time: 'ByteKids', membros: ['Julia Alves', 'Pedro Carvalho'] },
        ],
        featured: true,
      },
      {
        name: 'Game Jam da Vaca — Jogos em 48h',
        date: '2024-06-20 00:00:00.000Z',
        theme: 'GameDev & Web3',
        status: 'encerrada',
        description: 'Criação de jogos 2D/3D com mecânicas inovadoras e ecossistema gamificado.',
        podium: [
          { posicao: 1, time: 'Tática Games', membros: ['Rafael "Tática" Nunes', 'Lucas Silva'] },
          { posicao: 2, time: 'Vaca Voadora', membros: ['Ana "Vaca Elétrica" Souza'] },
        ],
        featured: false,
      },
      {
        name: 'Maratona AgroTech — Tecnologia no Campo',
        date: '2024-09-10 00:00:00.000Z',
        theme: 'Agrotech & Sustentabilidade',
        status: 'encerrada',
        description:
          'Desenvolvimento de sensores IoT, análise de dados de safra e rastreabilidade agrícola.',
        podium: [
          {
            posicao: 1,
            time: 'AgroCow',
            membros: [
              'Ana "Vaca Elétrica" Souza',
              'Sofia "Cowmando" Ribeiro',
              'Carla "Pixel" Mendes',
            ],
          },
          { posicao: 2, time: 'GreenField', membros: ['Diego Farias', 'Bruno Lima'] },
        ],
        featured: true,
      },
      {
        name: 'CowHack IA — IA Generativa para o Bem',
        date: '2025-01-25 00:00:00.000Z',
        theme: 'IA Generativa & Agentes',
        status: 'encerrada',
        description:
          'Construção de assistentes inteligentes, automação e soluções com LLMs para impacto social.',
        podium: [
          {
            posicao: 1,
            time: 'NeuralCow',
            membros: ['Marina "Byte" Rocha', 'Ana "Vaca Elétrica" Souza', 'Diego "Pitch" Farias'],
          },
          { posicao: 2, time: 'PromptMasters', membros: ['Bruno Lima', 'Julia Alves'] },
        ],
        featured: true,
      },
      {
        name: 'Maratona FinTech — Inclusão Financeira',
        date: '2025-03-14 00:00:00.000Z',
        theme: 'FinTech & Pix Open Banking',
        status: 'acontecendo',
        description:
          'Maratona ao vivo! Soluções para microcrédito, educação financeira e pagamentos inteligentes.',
        podium: [],
        featured: true,
      },
      {
        name: 'Mega Hackathon CowWorking — Cidades Inteligentes',
        date: '2025-07-20 00:00:00.000Z',
        theme: 'Smart Cities & Mobilidade',
        status: 'em_breve',
        description:
          'A maior edição do ano! R$ 50 mil em prêmios para acelerar soluções urbanas e mobilidade.',
        podium: [],
        featured: true,
      },
    ]

    compData.forEach((item) => {
      try {
        app.findFirstRecordByData('competitions', 'name', item.name)
      } catch (_) {
        const rec = new Record(compCol)
        rec.set('name', item.name)
        rec.set('date', item.date)
        rec.set('theme', item.theme)
        rec.set('status', item.status)
        rec.set('description', item.description)
        rec.set('podium', item.podium)
        rec.set('featured', item.featured)
        app.save(rec)
      }
    })

    // Seed Gallery
    const galCol = app.findCollectionByNameOrId('gallery')
    const galData = [
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=hackathon%20presentation&color=green',
        caption: 'Palco principal da CowHack IA com banca avaliadora',
        tag: 'hackathon',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=developers%20coding&color=cyan',
        caption: 'Maratona de código madrugada adentro na Game Jam',
        tag: 'hackathon',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=tech%20community%20meetup&color=green',
        caption: 'Encontro presencial de Cowpetidores em São Paulo',
        tag: 'encontro',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=ai%20workshop%20stage',
        caption: 'Bootcamp de Agentes de IA e Engenharia de Prompt',
        tag: 'bootcamp',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=award%20trophy%20team',
        caption: 'Momento da entrega do troféu da Maratona AgroTech',
        tag: 'social',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=startup%20pitch%20deck',
        caption: 'Sessão de mentoria de Pitch antes do horário limite',
        tag: 'bootcamp',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=hackathon%20winners%20cheering',
        caption: 'Time campeão da edição Hackathon CowWorking #1',
        tag: 'social',
      },
      {
        image_url: 'https://img.usecurling.com/p/800/600?q=coworking%20community%20party',
        caption: 'Confraternização e networking pós-maratona',
        tag: 'encontro',
      },
    ]

    galData.forEach((item) => {
      try {
        app.findFirstRecordByData('gallery', 'caption', item.caption)
      } catch (_) {
        const rec = new Record(galCol)
        rec.set('image_url', item.image_url)
        rec.set('caption', item.caption)
        rec.set('tag', item.tag)
        app.save(rec)
      }
    })
  },
  (app) => {},
)
