migrate(
  (app) => {
    const cowpetidores = new Collection({
      name: 'cowpetidores',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'slug', type: 'text', required: true },
        { name: 'avatar_url', type: 'text' },
        { name: 'hackathons_count', type: 'number', required: true },
        { name: 'wins', type: 'number' },
        {
          name: 'specialty',
          type: 'select',
          required: true,
          values: ['UX', 'Dev', 'Pitch', 'Data', 'Design', 'Estratégia', 'IA'],
          maxSelect: 1,
        },
        {
          name: 'level',
          type: 'select',
          required: true,
          values: ['iniciante', 'pro', 'elite'],
          maxSelect: 1,
        },
        {
          name: 'rarity',
          type: 'select',
          required: true,
          values: ['comum', 'raro', 'epico', 'lendario'],
          maxSelect: 1,
        },
        { name: 'bio', type: 'text', required: true },
        { name: 'skills', type: 'json', required: true },
        { name: 'attributes', type: 'json', required: true },
        { name: 'history', type: 'json', required: true },
        { name: 'contacts', type: 'json' },
        { name: 'featured', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE UNIQUE INDEX idx_cowpetidores_slug ON cowpetidores (slug)',
        'CREATE INDEX idx_cowpetidores_rarity ON cowpetidores (rarity)',
        'CREATE INDEX idx_cowpetidores_level ON cowpetidores (level)',
        'CREATE INDEX idx_cowpetidores_specialty ON cowpetidores (specialty)',
      ],
    })
    app.save(cowpetidores)

    const competitions = new Collection({
      name: 'competitions',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'name', type: 'text', required: true },
        { name: 'date', type: 'date', required: true },
        { name: 'theme', type: 'text', required: true },
        {
          name: 'status',
          type: 'select',
          required: true,
          values: ['encerrada', 'em_breve', 'acontecendo'],
          maxSelect: 1,
        },
        { name: 'description', type: 'text' },
        { name: 'podium', type: 'json' },
        { name: 'featured', type: 'bool' },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_competitions_status ON competitions (status)',
        'CREATE INDEX idx_competitions_date ON competitions (date)',
      ],
    })
    app.save(competitions)

    const gallery = new Collection({
      name: 'gallery',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'image_url', type: 'text', required: true },
        { name: 'caption', type: 'text', required: true },
        {
          name: 'tag',
          type: 'select',
          required: true,
          values: ['hackathon', 'encontro', 'bootcamp', 'social'],
          maxSelect: 1,
        },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE INDEX idx_gallery_tag ON gallery (tag)'],
    })
    app.save(gallery)

    const communityLinks = new Collection({
      name: 'community_links',
      type: 'base',
      listRule: '',
      viewRule: '',
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'title', type: 'text', required: true },
        { name: 'description', type: 'text', required: true },
        { name: 'url', type: 'url', required: true },
        { name: 'icon', type: 'text', required: true },
        {
          name: 'category',
          type: 'select',
          required: true,
          values: ['comunidade', 'conteudo', 'carreira'],
          maxSelect: 1,
        },
        { name: 'sort_order', type: 'number', required: true },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: ['CREATE INDEX idx_community_links_sort ON community_links (sort_order)'],
    })
    app.save(communityLinks)
  },
  (app) => {
    const cols = ['community_links', 'gallery', 'competitions', 'cowpetidores']
    cols.forEach((name) => {
      try {
        const col = app.findCollectionByNameOrId(name)
        app.delete(col)
      } catch (_) {}
    })
  },
)
